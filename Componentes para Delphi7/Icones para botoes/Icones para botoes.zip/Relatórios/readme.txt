

My name is Johan Spee, I am an Icoholic...

This is the second Icoholics Anonymous icon collection. Despite my best
intentions I have not been able to stop at 500. That's what addiction
does to you: You end up with 1000 cream-of-the-crop icons. At first I
settled for whatever icons I could find, then I started patching them
up and finally I found myself creating my own. I'd say about 25% of 
these icons are 'home-grown', the rest was stolen or redesigned.

Icoholic 2 is not a sequel to Icoholic 1, but an extended version. 99%
of the icons in the first collection are also included here. I did 
change quite a few names though.

THIS IS POSTCARDWARE!!

Icoholic 1 has been on the internet for almost a year. I received less
than 20 postcards, from all distant corners of the world. Only 2 came
from the U.S.A., both from the south. I find it hard to believe that
not one single person in, let's say, New York City has downloaded my file.
I'd like to thank all of you who did send me a postcard and hope you
enjoy this new collection.

If these Icons please you, please please me and send a postcard to:

	Johan Spee
	Irisstraat 33
	6666 BE Heteren
	The Netherlands


You want you own favorite icons included in the next version? Sure, why not.
I aim for 2000 icons in the year 2000, but with your help it could be 10000.
Zip and UUencode the icons and attach them to an e-mail to:

	Johan Spee@epr.bc.wau.nl


Even when you e-mail: DON'T FORGET THE POSTCARD!!  Enjoy!
