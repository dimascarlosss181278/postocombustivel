//---------------------------------------------------------------------------

#include <basepch.h>
#pragma hdrstop
USEFORMNS("..\Delphi\UDWindowZoom.pas", Udwindowzoom, CrpeWindowZoomDlg);
USEFORMNS("..\Delphi\UCrpeDSAbout.pas", Ucrpedsabout, CrpeDSAboutDlg);
USEFORMNS("..\Delphi\UDAbout.pas", Udabout, CrpeAboutBox);
USEFORMNS("..\Delphi\UDAreaFormat.pas", Udareaformat, CrpeAreaFormatDlg);
USEFORMNS("..\Delphi\UDBorder.pas", Udborder, CrpeBorderDlg);
USEFORMNS("..\Delphi\UDBoxes.pas", Udboxes, CrpeBoxesDlg);
USEFORMNS("..\Delphi\UDConnect.pas", Udconnect, CrpeConnectDlg);
USEFORMNS("..\Delphi\UDCrossTabGroups.pas", Udcrosstabgroups, CrpeCrossTabGroupsDlg);
USEFORMNS("..\Delphi\UDCrossTabs.pas", Udcrosstabs, CrpeCrossTabsDlg);
USEFORMNS("..\Delphi\UDCrossTabSummaries.pas", Udcrosstabsummaries, CrpeCrossTabSummariesDlg);
USEFORMNS("..\Delphi\UDDatabaseFields.pas", Uddatabasefields, CrpeDatabaseFieldsDlg);
USEFORMNS("..\Delphi\UDDesignControls.pas", Uddesigncontrols, CrpeDesignControlsDlg);
USEFORMNS("..\Delphi\UDEmbeddedFields.pas", Udembeddedfields, CrpeEmbeddedFieldsDlg);
USEFORMNS("..\Delphi\UDExportExcel.pas", Udexportexcel, CrpeExcelDlg);
USEFORMNS("..\Delphi\UDExportHTML4.pas", Udexporthtml4, CrpeHTML4Dlg);
USEFORMNS("..\Delphi\UDExportOdbc.pas", Udexportodbc, CrpeOdbcDlg);
USEFORMNS("..\Delphi\UDExportOptions.pas", Udexportoptions, CrpeExportOptionsDlg);
USEFORMNS("..\Delphi\UDExportPagText.pas", Udexportpagtext, CrpePagTextDlg);
USEFORMNS("..\Delphi\UDExportPDF.pas", Udexportpdf, CrpeAdobeAcrobatPDFDlg);
USEFORMNS("..\Delphi\UDExportRTF.pas", Udexportrtf, CrpeRichTextFormatDlg);
USEFORMNS("..\Delphi\UDExportXML.pas", Udexportxml, CrpeXML1Dlg);
USEFORMNS("..\Delphi\UDFieldMapping.pas", Udfieldmapping, CrpeFieldMappingDlg);
USEFORMNS("..\Delphi\UDFieldSelect.pas", Udfieldselect, CrpeFieldSelectDlg);
USEFORMNS("..\Delphi\UDFont.pas", Udfont, CrpeFontDlg);
USEFORMNS("..\Delphi\UDFormat.pas", Udformat, CrpeFormatDlg);
USEFORMNS("..\Delphi\UDFormulaEdit.pas", Udformulaedit, CrpeFormulaEditDlg);
USEFORMNS("..\Delphi\UDFormulas.pas", Udformulas, CrpeFormulasDlg);
USEFORMNS("..\Delphi\UDGlobalOptions.pas", Udglobaloptions, CrpeGlobalOptionsDlg);
USEFORMNS("..\Delphi\UDGraphs.pas", Udgraphs, CrpeGraphsDlg);
USEFORMNS("..\Delphi\UDGroupNameFields.pas", Udgroupnamefields, CrpeGroupNameFieldsDlg);
USEFORMNS("..\Delphi\UDGroups.pas", Udgroups, CrpeGroupsDlg);
USEFORMNS("..\Delphi\UDGroupSelection.pas", Udgroupselection, CrpeGroupSelectionDlg);
USEFORMNS("..\Delphi\UDGroupSortFields.pas", Udgroupsortfields, CrpeGroupSortFieldsDlg);
USEFORMNS("..\Delphi\UDHiliteConditions.pas", Udhiliteconditions, CrpeHiliteConditionsDlg);
USEFORMNS("..\Delphi\UDLines.pas", Udlines, CrpeLinesDlg);
USEFORMNS("..\Delphi\UDLogOnInfo.pas", Udlogoninfo, CrpeLogOnInfoDlg);
USEFORMNS("..\Delphi\UDLogOnServer.pas", Udlogonserver, CrpeLogOnServerDlg);
USEFORMNS("..\Delphi\UDLogOnServerAdd.pas", Udlogonserveradd, CrpeLogOnServerAddDlg);
USEFORMNS("..\Delphi\UDMapCondField.pas", Udmapcondfield, CrpeMapConditionFieldsDlg);
USEFORMNS("..\Delphi\UDMaps.pas", Udmaps, CrpeMapsDlg);
USEFORMNS("..\Delphi\UDMapSumField.pas", Udmapsumfield, CrpeMapSummaryFieldsDlg);
USEFORMNS("..\Delphi\UDMargins.pas", Udmargins, CrpeMarginsDlg);
USEFORMNS("..\Delphi\UDMiscellaneous.pas", Udmiscellaneous, CrpeMiscellaneousDlg);
USEFORMNS("..\Delphi\UDOLAPCubes.pas", Udolapcubes, CrpeOLAPCubesDlg);
USEFORMNS("..\Delphi\UDOleObjects.pas", Udoleobjects, CrpeOleObjectsDlg);
USEFORMNS("..\Delphi\UDPages.pas", Udpages, CrpePagesDlg);
USEFORMNS("..\Delphi\UDParagraphs.pas", Udparagraphs, CrpeParagraphsDlg);
USEFORMNS("..\Delphi\UDParamFields.pas", Udparamfields, CrpeParamFieldsDlg);
USEFORMNS("..\Delphi\UDPathEdit.pas", Udpathedit, CrpePathDlg);
USEFORMNS("..\Delphi\UDPFCValues.pas", Udpfcvalues, CrpePFCurrentValuesDlg);
USEFORMNS("..\Delphi\UDPFPValues.pas", Udpfpvalues, CrpePFPromptValuesDlg);
USEFORMNS("..\Delphi\UDPFRanges.pas", Udpfranges, CrpeParamFieldRangesDlg);
USEFORMNS("..\Delphi\UDPictures.pas", Udpictures, CrpePicturesDlg);
USEFORMNS("..\Delphi\UDPrinter.pas", Udprinter, CrpePrinterDlg);
USEFORMNS("..\Delphi\UDPrintOptions.pas", Udprintoptions, CrpePrintOptionsDlg);
USEFORMNS("..\Delphi\UDRecords.pas", Udrecords, CrpeRecordsDlg);
USEFORMNS("..\Delphi\UDReportOptions.pas", Udreportoptions, CrpeReportOptionsDlg);
USEFORMNS("..\Delphi\UDRunningTotals.pas", Udrunningtotals, CrpeRunningTotalsDlg);
USEFORMNS("..\Delphi\UDSectionFont.pas", Udsectionfont, CrpeSectionFontDlg);
USEFORMNS("..\Delphi\UDSectionFormat.pas", Udsectionformat, CrpeSectionFormatDlg);
USEFORMNS("..\Delphi\UDSectionSize.pas", Udsectionsize, CrpeSectionSizeDlg);
USEFORMNS("..\Delphi\UDSelection.pas", Udselection, CrpeSelectionDlg);
USEFORMNS("..\Delphi\UDSessionInfo.pas", Udsessioninfo, CrpeSessionInfoDlg);
USEFORMNS("..\Delphi\UDSortFieldBuild.pas", Udsortfieldbuild, CrpeBuildSortFieldDlg);
USEFORMNS("..\Delphi\UDSortFields.pas", Udsortfields, CrpeSortFieldsDlg);
USEFORMNS("..\Delphi\UDSpecialFields.pas", Udspecialfields, CrpeSpecialFieldsDlg);
USEFORMNS("..\Delphi\UDSQLExpressions.pas", Udsqlexpressions, CrpeSQLExpressionsDlg);
USEFORMNS("..\Delphi\UDSQLQuery.pas", Udsqlquery, CrpeSQLQueryDlg);
USEFORMNS("..\Delphi\UDSubreports.pas", Udsubreports, CrpeSubreportsDlg);
USEFORMNS("..\Delphi\UDSummaryFields.pas", Udsummaryfields, CrpeSummaryFieldsDlg);
USEFORMNS("..\Delphi\UDSummaryInfo.pas", Udsummaryinfo, CrpeSummaryInfoDlg);
USEFORMNS("..\Delphi\UDTableFields.pas", Udtablefields, CrpeTableFieldsDlg);
USEFORMNS("..\Delphi\UDTables.pas", Udtables, CrpeTablesDlg);
USEFORMNS("..\Delphi\UDTabStops.pas", Udtabstops, CrpeTabStopsDlg);
USEFORMNS("..\Delphi\UDTextObjects.pas", Udtextobjects, CrpeTextObjectsDlg);
USEFORMNS("..\Delphi\UDTODeleteText.pas", Udtodeletetext, CrpeDeleteTextDlg);
USEFORMNS("..\Delphi\UDToolTipEdit.pas", Udtooltipedit, CrpeToolTipEditDlg);
USEFORMNS("..\Delphi\UDVersion.pas", Udversion, CrpeVersionDlg);
USEFORMNS("..\Delphi\UDWindowButtonBar.pas", Udwindowbuttonbar, CrpeWindowButtonBarDlg);
USEFORMNS("..\Delphi\UDWindowCursor.pas", Udwindowcursor, CrpeWindowCursorDlg);
USEFORMNS("..\Delphi\UDWindowParent.pas", Udwindowparent, CrpeWindowParentDlg);
USEFORMNS("..\Delphi\UDWindowSize.pas", Udwindowsize, CrpeWindowSizeDlg);
USEFORMNS("..\Delphi\UDWindowStyle.pas", Udwindowstyle, CrpeWindowStyleDlg);
USEFORMNS("..\Delphi\UDExportSepVal.pas", Udexportsepval, CrpeSepValDlg);
USEFORMNS("..\Delphi\UDExportWord.pas", Udexportword, CrpeWordDlg);
USEFORMNS("..\Delphi\UDExportRecords.pas", Udexportrecords, CrpeExportRecordsDlg);
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------

//   Package source.
//---------------------------------------------------------------------------

#pragma argsused
int WINAPI DllEntryPoint(HINSTANCE hinst, unsigned long reason, void*)
{
        return 1;
}
//---------------------------------------------------------------------------
