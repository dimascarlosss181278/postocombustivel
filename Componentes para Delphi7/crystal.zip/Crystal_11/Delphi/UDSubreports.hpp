// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'UDSubreports.pas' rev: 6.00

#ifndef UDSubreportsHPP
#define UDSubreportsHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <UCrpe32.hpp>	// Pascal unit
#include <Buttons.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Udsubreports
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TCrpeSubreportsDlg;
class PASCALIMPLEMENTATION TCrpeSubreportsDlg : public Forms::TForm 
{
	typedef Forms::TForm inherited;
	
__published:
	Extctrls::TPanel* pnlSubreports;
	Stdctrls::TListBox* lbSubNames;
	Stdctrls::TGroupBox* GroupBox1;
	Stdctrls::TButton* btnBorder;
	Stdctrls::TButton* btnFormat;
	Stdctrls::TEdit* editTop;
	Stdctrls::TLabel* lblTop;
	Stdctrls::TLabel* lblLeft;
	Stdctrls::TEdit* editLeft;
	Stdctrls::TLabel* lblSection;
	Stdctrls::TEdit* editWidth;
	Stdctrls::TLabel* lblWidth;
	Stdctrls::TLabel* lblHeight;
	Stdctrls::TEdit* editHeight;
	Stdctrls::TComboBox* cbSection;
	Stdctrls::TButton* btnOk;
	Stdctrls::TButton* btnClear;
	Dialogs::TFontDialog* FontDialog1;
	Stdctrls::TEdit* editNLinks;
	Stdctrls::TLabel* lblNLinks;
	Stdctrls::TCheckBox* cbSubExecute;
	Stdctrls::TRadioButton* rbMain;
	Stdctrls::TRadioButton* rbSub;
	Extctrls::TImage* imgReport;
	Dialogs::TOpenDialog* OpenDialog1;
	Buttons::TSpeedButton* sbFormulaRed;
	Buttons::TSpeedButton* sbFormulaBlue;
	Stdctrls::TGroupBox* GroupBox2;
	Stdctrls::TCheckBox* cbIsExternal;
	Stdctrls::TCheckBox* cbOnDemand;
	Buttons::TSpeedButton* sbOnDemandCaption;
	Stdctrls::TLabel* lblOnDemandCaption;
	Stdctrls::TLabel* lblPreviewTabCaption;
	Buttons::TSpeedButton* sbPreviewTabCaption;
	Stdctrls::TCheckBox* cbReImportWhenOpening;
	Extctrls::TRadioGroup* rgUnits;
	void __fastcall btnClearClick(System::TObject* Sender);
	void __fastcall lbSubNamesClick(System::TObject* Sender);
	void __fastcall FormClose(System::TObject* Sender, Forms::TCloseAction &Action);
	void __fastcall FormShow(System::TObject* Sender);
	void __fastcall UpdateSubreports(void);
	void __fastcall btnOkClick(System::TObject* Sender);
	void __fastcall FormCreate(System::TObject* Sender);
	void __fastcall editSizeEnter(System::TObject* Sender);
	void __fastcall editSizeExit(System::TObject* Sender);
	void __fastcall cbSectionChange(System::TObject* Sender);
	void __fastcall btnBorderClick(System::TObject* Sender);
	void __fastcall rbMainClick(System::TObject* Sender);
	void __fastcall rbSubClick(System::TObject* Sender);
	void __fastcall InitializeControls(bool OnOff);
	void __fastcall btnFormatClick(System::TObject* Sender);
	void __fastcall sbOnDemandCaptionClick(System::TObject* Sender);
	void __fastcall sbPreviewTabCaptionClick(System::TObject* Sender);
	void __fastcall cbSubExecuteClick(System::TObject* Sender);
	void __fastcall rgUnitsClick(System::TObject* Sender);
	
public:
	Ucrpe32::TCrpe* Cr;
	int SubIndex;
	int SubNameIndex;
	AnsiString PrevSize;
	AnsiString OpenDir;
public:
	#pragma option push -w-inl
	/* TCustomForm.Create */ inline __fastcall virtual TCrpeSubreportsDlg(Classes::TComponent* AOwner) : Forms::TForm(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.CreateNew */ inline __fastcall virtual TCrpeSubreportsDlg(Classes::TComponent* AOwner, int Dummy) : Forms::TForm(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TCrpeSubreportsDlg(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TCrpeSubreportsDlg(HWND ParentWindow) : Forms::TForm(ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TCrpeSubreportsDlg* CrpeSubreportsDlg;
extern PACKAGE bool bSubreports;

}	/* namespace Udsubreports */
using namespace Udsubreports;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// UDSubreports
