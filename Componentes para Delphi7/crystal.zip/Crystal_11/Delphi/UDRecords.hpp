// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'UDRecords.pas' rev: 6.00

#ifndef UDRecordsHPP
#define UDRecordsHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <UCrpe32.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Udrecords
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TCrpeRecordsDlg;
class PASCALIMPLEMENTATION TCrpeRecordsDlg : public Forms::TForm 
{
	typedef Forms::TForm inherited;
	
__published:
	Extctrls::TPanel* pnlRecords;
	Extctrls::TPanel* pnlMonitor;
	Stdctrls::TLabel* lblRead;
	Stdctrls::TLabel* lblSelected;
	Stdctrls::TLabel* lblPrinted;
	Stdctrls::TEdit* editRead;
	Stdctrls::TEdit* editSelected;
	Stdctrls::TEdit* editPrinted;
	Stdctrls::TCheckBox* cbMonitor;
	Stdctrls::TButton* btnOk;
	Stdctrls::TButton* btnCancel;
	Extctrls::TTimer* Timer1;
	Stdctrls::TButton* btnSetRecordLimit;
	Stdctrls::TEdit* editSetRecordLimit;
	Stdctrls::TButton* btnSetTimeLimit;
	Stdctrls::TEdit* editSetTimeLimit;
	Stdctrls::TLabel* lblPercentRead;
	Stdctrls::TLabel* lblPercentCompleted;
	Stdctrls::TEdit* editPercentRead;
	Stdctrls::TEdit* editPercentCompleted;
	void __fastcall FormCreate(System::TObject* Sender);
	void __fastcall FormShow(System::TObject* Sender);
	void __fastcall btnOkClick(System::TObject* Sender);
	void __fastcall btnCancelClick(System::TObject* Sender);
	void __fastcall editSetRecordLimitEnter(System::TObject* Sender);
	void __fastcall editSetRecordLimitExit(System::TObject* Sender);
	void __fastcall editSetTimeLimitEnter(System::TObject* Sender);
	void __fastcall editSetTimeLimitExit(System::TObject* Sender);
	void __fastcall btnSetRecordLimitClick(System::TObject* Sender);
	void __fastcall btnSetTimeLimitClick(System::TObject* Sender);
	void __fastcall FormClose(System::TObject* Sender, Forms::TCloseAction &Action);
	void __fastcall UpdateRecords(void);
	void __fastcall InitializeControls(bool OnOff);
	void __fastcall Timer1Timer(System::TObject* Sender);
	void __fastcall cbMonitorClick(System::TObject* Sender);
	
public:
	Ucrpe32::TCrpe* Cr;
	AnsiString PrevNum;
public:
	#pragma option push -w-inl
	/* TCustomForm.Create */ inline __fastcall virtual TCrpeRecordsDlg(Classes::TComponent* AOwner) : Forms::TForm(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.CreateNew */ inline __fastcall virtual TCrpeRecordsDlg(Classes::TComponent* AOwner, int Dummy) : Forms::TForm(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TCrpeRecordsDlg(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TCrpeRecordsDlg(HWND ParentWindow) : Forms::TForm(ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TCrpeRecordsDlg* CrpeRecordsDlg;
extern PACKAGE bool bRecords;

}	/* namespace Udrecords */
using namespace Udrecords;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// UDRecords
