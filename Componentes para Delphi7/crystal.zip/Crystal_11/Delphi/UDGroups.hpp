// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'UDGroups.pas' rev: 6.00

#ifndef UDGroupsHPP
#define UDGroupsHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Buttons.hpp>	// Pascal unit
#include <UCrpe32.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Udgroups
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TCrpeGroupsDlg;
class PASCALIMPLEMENTATION TCrpeGroupsDlg : public Forms::TForm 
{
	typedef Forms::TForm inherited;
	
__published:
	Extctrls::TPanel* pnlGroups;
	Stdctrls::TLabel* lblFieldName;
	Stdctrls::TLabel* lblNumber;
	Stdctrls::TLabel* lblCondition;
	Stdctrls::TLabel* lblDirection;
	Stdctrls::TLabel* lblGroupType;
	Stdctrls::TEdit* editFieldName;
	Stdctrls::TListBox* lbNumbers;
	Stdctrls::TComboBox* cbCondition;
	Stdctrls::TComboBox* cbDirection;
	Stdctrls::TCheckBox* cbKeepTogether;
	Stdctrls::TCheckBox* cbRepeatGH;
	Stdctrls::TComboBox* cbGroupType;
	Stdctrls::TButton* btnOk;
	Stdctrls::TButton* btnClear;
	Stdctrls::TLabel* lblCount;
	Stdctrls::TEdit* editCount;
	Stdctrls::TGroupBox* gbTopN;
	Stdctrls::TLabel* lblSortType;
	Stdctrls::TComboBox* cbSortType;
	Stdctrls::TLabel* lblNGroups;
	Stdctrls::TEdit* editNGroups;
	Stdctrls::TCheckBox* cbIncludeOthers;
	Stdctrls::TLabel* lblSortField;
	Stdctrls::TEdit* editSortField;
	Stdctrls::TGroupBox* gbHierarchy;
	Stdctrls::TCheckBox* cbEnabled;
	Stdctrls::TLabel* lblInstanceField;
	Stdctrls::TEdit* editInstanceField;
	Stdctrls::TLabel* lblParentField;
	Stdctrls::TEdit* editParentField;
	Stdctrls::TLabel* lblIndent;
	Stdctrls::TEdit* editIndent;
	Stdctrls::TRadioButton* rbInches;
	Stdctrls::TRadioButton* rbTwips;
	Stdctrls::TButton* btnSortField;
	Stdctrls::TCheckBox* cbCustomizeGroupName;
	Stdctrls::TEdit* editOthersName;
	Stdctrls::TLabel* lblOthersName;
	Buttons::TSpeedButton* sbFormulaBlue;
	Buttons::TSpeedButton* sbFormulaRed;
	Buttons::TSpeedButton* sbGroupNameFormula;
	Stdctrls::TLabel* lblGroupNameFormula;
	void __fastcall lbNumbersClick(System::TObject* Sender);
	void __fastcall FormShow(System::TObject* Sender);
	void __fastcall cbGroupTypeChange(System::TObject* Sender);
	void __fastcall cbDirectionChange(System::TObject* Sender);
	void __fastcall cbSortTypeChange(System::TObject* Sender);
	void __fastcall cbConditionChange(System::TObject* Sender);
	void __fastcall cbKeepTogetherClick(System::TObject* Sender);
	void __fastcall cbRepeatGHClick(System::TObject* Sender);
	void __fastcall cbIncludeOthersClick(System::TObject* Sender);
	void __fastcall btnClearClick(System::TObject* Sender);
	void __fastcall FormClose(System::TObject* Sender, Forms::TCloseAction &Action);
	void __fastcall UpdateGroups(void);
	void __fastcall btnOkClick(System::TObject* Sender);
	void __fastcall FormCreate(System::TObject* Sender);
	void __fastcall InitializeControls(bool OnOff);
	void __fastcall cbEnabledClick(System::TObject* Sender);
	void __fastcall rbInchesClick(System::TObject* Sender);
	void __fastcall rbTwipsClick(System::TObject* Sender);
	void __fastcall editIndentEnter(System::TObject* Sender);
	void __fastcall editIndentExit(System::TObject* Sender);
	void __fastcall btnSortFieldClick(System::TObject* Sender);
	void __fastcall lbNumbersDragOver(System::TObject* Sender, System::TObject* Source, int X, int Y, Controls::TDragState State, bool &Accept);
	void __fastcall lbNumbersDragDrop(System::TObject* Sender, System::TObject* Source, int X, int Y);
	void __fastcall editFieldNameEnter(System::TObject* Sender);
	void __fastcall editFieldNameExit(System::TObject* Sender);
	void __fastcall editSortFieldEnter(System::TObject* Sender);
	void __fastcall editSortFieldExit(System::TObject* Sender);
	void __fastcall editInstanceFieldEnter(System::TObject* Sender);
	void __fastcall editInstanceFieldExit(System::TObject* Sender);
	void __fastcall editParentFieldEnter(System::TObject* Sender);
	void __fastcall editParentFieldExit(System::TObject* Sender);
	void __fastcall editNGroupsEnter(System::TObject* Sender);
	void __fastcall editNGroupsExit(System::TObject* Sender);
	void __fastcall editOthersNameExit(System::TObject* Sender);
	void __fastcall cbCustomizeGroupNameClick(System::TObject* Sender);
	void __fastcall sbGroupNameFormulaClick(System::TObject* Sender);
	
public:
	Ucrpe32::TCrpe* Cr;
	short GIndex;
	AnsiString PrevSize;
	AnsiString PrevName;
public:
	#pragma option push -w-inl
	/* TCustomForm.Create */ inline __fastcall virtual TCrpeGroupsDlg(Classes::TComponent* AOwner) : Forms::TForm(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.CreateNew */ inline __fastcall virtual TCrpeGroupsDlg(Classes::TComponent* AOwner, int Dummy) : Forms::TForm(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TCrpeGroupsDlg(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TCrpeGroupsDlg(HWND ParentWindow) : Forms::TForm(ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TCrpeGroupsDlg* CrpeGroupsDlg;
extern PACKAGE bool bGroups;

}	/* namespace Udgroups */
using namespace Udgroups;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// UDGroups
