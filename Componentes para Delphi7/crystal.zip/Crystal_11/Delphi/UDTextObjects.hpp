// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'UDTextObjects.pas' rev: 6.00

#ifndef UDTextObjectsHPP
#define UDTextObjectsHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <UCrpe32.hpp>	// Pascal unit
#include <Buttons.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Udtextobjects
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TCrpeTextObjectsDlg;
class PASCALIMPLEMENTATION TCrpeTextObjectsDlg : public Forms::TForm 
{
	typedef Forms::TForm inherited;
	
__published:
	Extctrls::TPanel* pnlTextObjects;
	Stdctrls::TLabel* lblNumber;
	Stdctrls::TListBox* lbNumbers;
	Stdctrls::TEdit* editCount;
	Stdctrls::TLabel* lblCount;
	Stdctrls::TGroupBox* GroupBox1;
	Stdctrls::TButton* btnBorder;
	Stdctrls::TButton* btnFont;
	Stdctrls::TButton* btnFormat;
	Stdctrls::TEdit* editTop;
	Stdctrls::TLabel* lblTop;
	Stdctrls::TLabel* lblLeft;
	Stdctrls::TEdit* editLeft;
	Stdctrls::TLabel* lblSection;
	Stdctrls::TEdit* editWidth;
	Stdctrls::TLabel* lblWidth;
	Stdctrls::TLabel* lblHeight;
	Stdctrls::TEdit* editHeight;
	Stdctrls::TComboBox* cbSection;
	Stdctrls::TButton* btnOk;
	Stdctrls::TButton* btnClear;
	Dialogs::TFontDialog* FontDialog1;
	Stdctrls::TMemo* memoLines;
	Stdctrls::TLabel* lblLines;
	Extctrls::TRadioGroup* rgUnits;
	Stdctrls::TButton* btnEmbeddedFields;
	Stdctrls::TButton* btnParagraphs;
	Stdctrls::TEdit* editTextSize;
	Stdctrls::TLabel* lblTextSize;
	Stdctrls::TLabel* lblTextHeight;
	Stdctrls::TEdit* editTextHeight;
	Stdctrls::TButton* btnInsertText;
	Stdctrls::TButton* btnDeleteText;
	Stdctrls::TButton* btnInsertFile;
	Dialogs::TOpenDialog* OpenDialog1;
	void __fastcall btnClearClick(System::TObject* Sender);
	void __fastcall lbNumbersClick(System::TObject* Sender);
	void __fastcall FormClose(System::TObject* Sender, Forms::TCloseAction &Action);
	void __fastcall FormShow(System::TObject* Sender);
	void __fastcall UpdateTextObjects(void);
	void __fastcall btnOkClick(System::TObject* Sender);
	void __fastcall FormCreate(System::TObject* Sender);
	void __fastcall btnFontClick(System::TObject* Sender);
	void __fastcall editSizeEnter(System::TObject* Sender);
	void __fastcall editSizeExit(System::TObject* Sender);
	void __fastcall cbSectionChange(System::TObject* Sender);
	void __fastcall btnBorderClick(System::TObject* Sender);
	void __fastcall InitializeControls(bool OnOff);
	void __fastcall rgUnitsClick(System::TObject* Sender);
	void __fastcall memoLinesExit(System::TObject* Sender);
	void __fastcall btnEmbeddedFieldsClick(System::TObject* Sender);
	void __fastcall btnParagraphsClick(System::TObject* Sender);
	void __fastcall btnFormatClick(System::TObject* Sender);
	void __fastcall btnInsertFileClick(System::TObject* Sender);
	void __fastcall btnInsertTextClick(System::TObject* Sender);
	void __fastcall btnDeleteTextClick(System::TObject* Sender);
	
public:
	Ucrpe32::TCrpe* Cr;
	int TIndex;
	AnsiString PrevSize;
	AnsiString OpenDir;
public:
	#pragma option push -w-inl
	/* TCustomForm.Create */ inline __fastcall virtual TCrpeTextObjectsDlg(Classes::TComponent* AOwner) : Forms::TForm(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.CreateNew */ inline __fastcall virtual TCrpeTextObjectsDlg(Classes::TComponent* AOwner, int Dummy) : Forms::TForm(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TCrpeTextObjectsDlg(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TCrpeTextObjectsDlg(HWND ParentWindow) : Forms::TForm(ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TCrpeTextObjectsDlg* CrpeTextObjectsDlg;
extern PACKAGE bool bTextObjects;

}	/* namespace Udtextobjects */
using namespace Udtextobjects;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// UDTextObjects
