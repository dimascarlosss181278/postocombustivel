// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'UDFormat.pas' rev: 6.00

#ifndef UDFormatHPP
#define UDFormatHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <UCrpeClasses.hpp>	// Pascal unit
#include <UCrpe32.hpp>	// Pascal unit
#include <ComCtrls.hpp>	// Pascal unit
#include <Buttons.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Udformat
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TCrpeFormatDlg;
class PASCALIMPLEMENTATION TCrpeFormatDlg : public Forms::TForm 
{
	typedef Forms::TForm inherited;
	
__published:
	Comctrls::TPageControl* pcFormat;
	Comctrls::TTabSheet* tsCommon;
	Comctrls::TTabSheet* tsNumber;
	Comctrls::TTabSheet* tsCurrency;
	Comctrls::TTabSheet* tsDate;
	Comctrls::TTabSheet* tsTime;
	Comctrls::TTabSheet* tsDateTime;
	Stdctrls::TGroupBox* gbCommon;
	Stdctrls::TCheckBox* cbSuppress;
	Stdctrls::TLabel* lblAlignment;
	Stdctrls::TComboBox* cbAlignment;
	Stdctrls::TCheckBox* cbKeepTogether;
	Stdctrls::TCheckBox* cbCloseBorder;
	Stdctrls::TCheckBox* cbCanGrow;
	Stdctrls::TEdit* editMaxNLines;
	Stdctrls::TLabel* lblMaxNLines;
	Stdctrls::TLabel* lblToolTip;
	Stdctrls::TLabel* lblTextRotation;
	Stdctrls::TComboBox* cbTextRotation;
	Buttons::TSpeedButton* sbFormulaRed;
	Buttons::TSpeedButton* sbFormulaBlue;
	Buttons::TSpeedButton* sbSuppress;
	Buttons::TSpeedButton* sbAlignment;
	Buttons::TSpeedButton* sbKeepTogether;
	Buttons::TSpeedButton* sbCloseBorder;
	Buttons::TSpeedButton* sbToolTip;
	Comctrls::TTabSheet* tsParagraph;
	Stdctrls::TLabel* lblHyperLink;
	Buttons::TSpeedButton* sbHyperLink;
	Stdctrls::TCheckBox* cbSuppressIfDuplicated;
	Buttons::TSpeedButton* sbSuppressIfDuplicated;
	Extctrls::TPanel* pnlNumber1;
	Stdctrls::TCheckBox* cbUseSystemDefaultFormatting;
	Extctrls::TPanel* pnlNumber2;
	Stdctrls::TCheckBox* cbSuppressIfZero;
	Stdctrls::TLabel* lblDecimalPlaces;
	Stdctrls::TLabel* lblRoundingFormat;
	Stdctrls::TComboBox* cbRoundingFormat;
	Stdctrls::TLabel* lblNegativeFormat;
	Stdctrls::TComboBox* cbNegativeFormat;
	Stdctrls::TCheckBox* cbAllowFieldClipping;
	Stdctrls::TEdit* editDecimalPlaces;
	Buttons::TSpeedButton* sbSuppressIfZero;
	Buttons::TSpeedButton* sbDecimalPlaces;
	Buttons::TSpeedButton* sbNegativeFormat;
	Buttons::TSpeedButton* sbRoundingFormat;
	Buttons::TSpeedButton* sbAllowFieldClipping;
	Stdctrls::TLabel* lblDecimalSymbol;
	Stdctrls::TEdit* editDecimalSymbol;
	Buttons::TSpeedButton* sbDecimalSymbol;
	Stdctrls::TCheckBox* cbUseThousandsSeparators;
	Buttons::TSpeedButton* sbUseThousandsSeparators;
	Stdctrls::TLabel* lblThousandSymbol;
	Stdctrls::TEdit* editThousandSymbol;
	Buttons::TSpeedButton* sbThousandSymbol;
	Stdctrls::TCheckBox* cbUseLeadingZero;
	Buttons::TSpeedButton* sbUseLeadingZero;
	Stdctrls::TCheckBox* cbUseAccountingFormat;
	Stdctrls::TCheckBox* cbReverseSignForDisplay;
	Buttons::TSpeedButton* sbReverseSignForDisplay;
	Stdctrls::TLabel* lblShowZeroValueAs;
	Extctrls::TPanel* pnlCurrency;
	Buttons::TSpeedButton* sbCurrencySymbolFormat;
	Stdctrls::TLabel* lblCurrencySymbolFormat;
	Stdctrls::TComboBox* cbCurrencySymbolFormat;
	Stdctrls::TCheckBox* cbOneCurrencySymbolPerPage;
	Buttons::TSpeedButton* sbOneCurrencySymbolPerPage;
	Stdctrls::TLabel* lblCurrencySymbol;
	Stdctrls::TEdit* editCurrencySymbol;
	Buttons::TSpeedButton* sbCurrencySymbol;
	Stdctrls::TLabel* lblCurrencySymbolPlacement;
	Stdctrls::TComboBox* cbCurrencySymbolPosition;
	Buttons::TSpeedButton* sbCurrencySymbolPosition;
	Stdctrls::TLabel* lblDateType;
	Stdctrls::TLabel* lblCalendarType;
	Buttons::TSpeedButton* sbCalendarType;
	Buttons::TSpeedButton* sbDateType;
	Stdctrls::TComboBox* cbDateType;
	Stdctrls::TComboBox* cbCalendarType;
	Stdctrls::TGroupBox* gbFormat;
	Stdctrls::TGroupBox* gbDateOrder;
	Stdctrls::TGroupBox* gbDayOfWeek;
	Stdctrls::TGroupBox* gbSeparators;
	Stdctrls::TEdit* editPrefix;
	Buttons::TSpeedButton* sbPrefix;
	Stdctrls::TLabel* lblPrefix;
	Stdctrls::TEdit* editFirst;
	Buttons::TSpeedButton* sbFirst;
	Stdctrls::TLabel* lblFirst;
	Stdctrls::TEdit* editSecond;
	Buttons::TSpeedButton* sbSecond;
	Stdctrls::TLabel* lblSecond;
	Stdctrls::TEdit* editSuffix;
	Buttons::TSpeedButton* sbSuffix;
	Stdctrls::TLabel* lblSuffix;
	Stdctrls::TLabel* lblMonth;
	Stdctrls::TLabel* lblDay;
	Buttons::TSpeedButton* sbDay;
	Buttons::TSpeedButton* sbMonth;
	Stdctrls::TComboBox* cbMonth;
	Stdctrls::TComboBox* cbDay;
	Stdctrls::TLabel* lblYear;
	Buttons::TSpeedButton* sbYear;
	Stdctrls::TComboBox* cbYear;
	Stdctrls::TLabel* lblDateOrder;
	Stdctrls::TComboBox* cbDateOrder;
	Buttons::TSpeedButton* sbDateOrder;
	Stdctrls::TLabel* lblType;
	Stdctrls::TComboBox* cbType;
	Buttons::TSpeedButton* sbType;
	Stdctrls::TLabel* lblSeparator;
	Stdctrls::TEdit* editSeparator;
	Buttons::TSpeedButton* sbSeparator;
	Stdctrls::TLabel* lblEnclosure;
	Stdctrls::TComboBox* cbEnclosure;
	Buttons::TSpeedButton* sbEnclosure;
	Stdctrls::TLabel* lblPosition;
	Stdctrls::TComboBox* cbPosition;
	Buttons::TSpeedButton* sbPosition;
	Stdctrls::TLabel* lblDateEra;
	Stdctrls::TComboBox* cbDateEra;
	Buttons::TSpeedButton* sbDateEra;
	Extctrls::TPanel* pnlTime1;
	Extctrls::TPanel* pnlTime2;
	Stdctrls::TLabel* lblTimeBase;
	Buttons::TSpeedButton* sbTimeBase;
	Stdctrls::TComboBox* cbTimeBase;
	Stdctrls::TLabel* lblAMString;
	Stdctrls::TEdit* editAMString;
	Buttons::TSpeedButton* sbAMString;
	Stdctrls::TLabel* lblPMString;
	Stdctrls::TEdit* editPMString;
	Buttons::TSpeedButton* sbPMString;
	Stdctrls::TLabel* lblAmPmPosition;
	Stdctrls::TComboBox* cbAmPmPosition;
	Buttons::TSpeedButton* sbAmPmPosition;
	Stdctrls::TLabel* lblHourType;
	Stdctrls::TLabel* lblMinuteType;
	Buttons::TSpeedButton* sbMinuteType;
	Buttons::TSpeedButton* sbHourType;
	Stdctrls::TComboBox* cbHourType;
	Stdctrls::TComboBox* cbMinuteType;
	Stdctrls::TLabel* lblSecondType;
	Buttons::TSpeedButton* sbSecondType;
	Stdctrls::TComboBox* cbSecondType;
	Stdctrls::TLabel* lblHourMinSeparator;
	Stdctrls::TEdit* editHourMinSeparator;
	Buttons::TSpeedButton* sbHourMinSeparator;
	Stdctrls::TLabel* lblMinSecSeparator;
	Stdctrls::TEdit* editMinSecSeparator;
	Buttons::TSpeedButton* sbMinSecSeparator;
	Extctrls::TPanel* pnlDateTime;
	Stdctrls::TLabel* lblOrder;
	Stdctrls::TComboBox* cbOrder;
	Buttons::TSpeedButton* sbOrder;
	Stdctrls::TLabel* lblDateTimeSeparator;
	Stdctrls::TEdit* editDateTimeSeparator;
	Buttons::TSpeedButton* sbDateTimeSeparator;
	Stdctrls::TGroupBox* gbIndentations;
	Stdctrls::TGroupBox* gbSpacing;
	Stdctrls::TGroupBox* gbTextInterpretation;
	Stdctrls::TLabel* lblIndentFirstLine;
	Stdctrls::TEdit* editIndentFirstLine;
	Stdctrls::TLabel* lblIndentLeft;
	Stdctrls::TEdit* editIndentLeft;
	Stdctrls::TLabel* lblIndentRight;
	Stdctrls::TEdit* editIndentRight;
	Stdctrls::TLabel* lblTextInterpretation;
	Buttons::TSpeedButton* sbTextInterpretation;
	Stdctrls::TComboBox* cbTextInterpretation;
	Stdctrls::TLabel* lblLineSpacingType;
	Stdctrls::TComboBox* cbLineSpacingType;
	Stdctrls::TButton* btnOk;
	Stdctrls::TButton* btnClear;
	Comctrls::TTabSheet* tsBoolean;
	Extctrls::TPanel* pnlBoolean;
	Stdctrls::TLabel* lblBooleanType;
	Stdctrls::TComboBox* cbBooleanType;
	Buttons::TSpeedButton* sbBooleanType;
	Extctrls::TPanel* pnlTimeDefault;
	Stdctrls::TCheckBox* cbUseSystemDefaultForDate;
	Stdctrls::TCheckBox* cbUseSystemDefaultForTime;
	Stdctrls::TEdit* editShowZeroValueAs;
	Buttons::TSpeedButton* sbCanGrow;
	Stdctrls::TLabel* lblLineSpacing;
	Stdctrls::TEdit* editLineSpacing;
	Stdctrls::TLabel* lblLineSpacingText;
	Stdctrls::TLabel* lblCharacterSpacing;
	Stdctrls::TEdit* editCharacterSpacing;
	Stdctrls::TLabel* lblPoints;
	Extctrls::TRadioGroup* rgUnits;
	void __fastcall FormCreate(System::TObject* Sender);
	void __fastcall FormShow(System::TObject* Sender);
	void __fastcall UpdateFormat(void);
	void __fastcall Initialize(bool OnOff);
	void __fastcall cbSuppressClick(System::TObject* Sender);
	void __fastcall cbAlignmentChange(System::TObject* Sender);
	void __fastcall cbKeepTogetherClick(System::TObject* Sender);
	void __fastcall cbCloseBorderClick(System::TObject* Sender);
	void __fastcall cbCanGrowClick(System::TObject* Sender);
	void __fastcall cbTextRotationChange(System::TObject* Sender);
	void __fastcall editMaxNLinesChange(System::TObject* Sender);
	void __fastcall cbSuppressIfDuplicatedClick(System::TObject* Sender);
	void __fastcall FormClose(System::TObject* Sender, Forms::TCloseAction &Action);
	void __fastcall btnOkClick(System::TObject* Sender);
	void __fastcall btnClearClick(System::TObject* Sender);
	void __fastcall sbSuppressClick(System::TObject* Sender);
	void __fastcall sbAlignmentClick(System::TObject* Sender);
	void __fastcall sbKeepTogetherClick(System::TObject* Sender);
	void __fastcall sbCloseBorderClick(System::TObject* Sender);
	void __fastcall sbToolTipClick(System::TObject* Sender);
	void __fastcall sbHyperLinkClick(System::TObject* Sender);
	void __fastcall sbSuppressIfDuplicatedClick(System::TObject* Sender);
	void __fastcall cbUseSystemDefaultFormattingClick(System::TObject* Sender);
	void __fastcall cbUseAccountingFormatClick(System::TObject* Sender);
	void __fastcall cbSuppressIfZeroClick(System::TObject* Sender);
	void __fastcall editDecimalPlacesChange(System::TObject* Sender);
	void __fastcall cbRoundingFormatChange(System::TObject* Sender);
	void __fastcall cbNegativeFormatChange(System::TObject* Sender);
	void __fastcall cbReverseSignForDisplayClick(System::TObject* Sender);
	void __fastcall cbAllowFieldClippingClick(System::TObject* Sender);
	void __fastcall editDecimalSymbolChange(System::TObject* Sender);
	void __fastcall cbUseThousandsSeparatorsClick(System::TObject* Sender);
	void __fastcall editThousandSymbolChange(System::TObject* Sender);
	void __fastcall cbUseLeadingZeroClick(System::TObject* Sender);
	void __fastcall editShowZeroValueAsChange(System::TObject* Sender);
	void __fastcall cbCurrencySymbolFormatChange(System::TObject* Sender);
	void __fastcall cbOneCurrencySymbolPerPageClick(System::TObject* Sender);
	void __fastcall cbCurrencySymbolPositionChange(System::TObject* Sender);
	void __fastcall editCurrencySymbolChange(System::TObject* Sender);
	void __fastcall sbCurrencySymbolFormatClick(System::TObject* Sender);
	void __fastcall sbOneCurrencySymbolPerPageClick(System::TObject* Sender);
	void __fastcall sbCurrencySymbolPositionClick(System::TObject* Sender);
	void __fastcall sbCurrencySymbolClick(System::TObject* Sender);
	void __fastcall cbDateTypeChange(System::TObject* Sender);
	void __fastcall cbUseSystemDefaultForDateClick(System::TObject* Sender);
	void __fastcall cbCalendarTypeChange(System::TObject* Sender);
	void __fastcall cbMonthChange(System::TObject* Sender);
	void __fastcall cbDayChange(System::TObject* Sender);
	void __fastcall cbYearChange(System::TObject* Sender);
	void __fastcall cbDateEraChange(System::TObject* Sender);
	void __fastcall cbDateOrderChange(System::TObject* Sender);
	void __fastcall cbTypeChange(System::TObject* Sender);
	void __fastcall editSeparatorChange(System::TObject* Sender);
	void __fastcall cbEnclosureChange(System::TObject* Sender);
	void __fastcall cbPositionChange(System::TObject* Sender);
	void __fastcall editPrefixChange(System::TObject* Sender);
	void __fastcall editFirstChange(System::TObject* Sender);
	void __fastcall editSecondChange(System::TObject* Sender);
	void __fastcall editSuffixChange(System::TObject* Sender);
	void __fastcall cbOrderChange(System::TObject* Sender);
	void __fastcall editDateTimeSeparatorChange(System::TObject* Sender);
	void __fastcall cbUseSystemDefaultForTimeClick(System::TObject* Sender);
	void __fastcall cbTimeBaseChange(System::TObject* Sender);
	void __fastcall editAMStringChange(System::TObject* Sender);
	void __fastcall editPMStringChange(System::TObject* Sender);
	void __fastcall cbAmPmPositionChange(System::TObject* Sender);
	void __fastcall cbHourTypeChange(System::TObject* Sender);
	void __fastcall cbMinuteTypeChange(System::TObject* Sender);
	void __fastcall cbSecondTypeChange(System::TObject* Sender);
	void __fastcall editHourMinSeparatorChange(System::TObject* Sender);
	void __fastcall editMinSecSeparatorChange(System::TObject* Sender);
	void __fastcall cbLineSpacingTypeChange(System::TObject* Sender);
	void __fastcall cbTextInterpretationChange(System::TObject* Sender);
	void __fastcall cbBooleanTypeChange(System::TObject* Sender);
	void __fastcall sbBooleanTypeClick(System::TObject* Sender);
	void __fastcall sbDateTypeClick(System::TObject* Sender);
	void __fastcall sbCalendarTypeClick(System::TObject* Sender);
	void __fastcall sbMonthClick(System::TObject* Sender);
	void __fastcall sbDayClick(System::TObject* Sender);
	void __fastcall sbYearClick(System::TObject* Sender);
	void __fastcall sbDateEraClick(System::TObject* Sender);
	void __fastcall sbDateOrderClick(System::TObject* Sender);
	void __fastcall sbTypeClick(System::TObject* Sender);
	void __fastcall sbSeparatorClick(System::TObject* Sender);
	void __fastcall sbEnclosureClick(System::TObject* Sender);
	void __fastcall sbPositionClick(System::TObject* Sender);
	void __fastcall sbPrefixClick(System::TObject* Sender);
	void __fastcall sbFirstClick(System::TObject* Sender);
	void __fastcall sbSecondClick(System::TObject* Sender);
	void __fastcall sbSuffixClick(System::TObject* Sender);
	void __fastcall sbOrderClick(System::TObject* Sender);
	void __fastcall sbDateTimeSeparatorClick(System::TObject* Sender);
	void __fastcall sbTimeBaseClick(System::TObject* Sender);
	void __fastcall sbAMStringClick(System::TObject* Sender);
	void __fastcall sbPMStringClick(System::TObject* Sender);
	void __fastcall sbAmPmPositionClick(System::TObject* Sender);
	void __fastcall sbHourTypeClick(System::TObject* Sender);
	void __fastcall sbMinuteTypeClick(System::TObject* Sender);
	void __fastcall sbSecondTypeClick(System::TObject* Sender);
	void __fastcall sbHourMinSeparatorClick(System::TObject* Sender);
	void __fastcall sbMinSecSeparatorClick(System::TObject* Sender);
	void __fastcall sbTextInterpretationClick(System::TObject* Sender);
	void __fastcall sbCanGrowClick(System::TObject* Sender);
	void __fastcall sbSuppressIfZeroClick(System::TObject* Sender);
	void __fastcall sbDecimalPlacesClick(System::TObject* Sender);
	void __fastcall sbRoundingFormatClick(System::TObject* Sender);
	void __fastcall sbNegativeFormatClick(System::TObject* Sender);
	void __fastcall sbReverseSignForDisplayClick(System::TObject* Sender);
	void __fastcall sbAllowFieldClippingClick(System::TObject* Sender);
	void __fastcall sbDecimalSymbolClick(System::TObject* Sender);
	void __fastcall sbUseThousandsSeparatorsClick(System::TObject* Sender);
	void __fastcall sbThousandSymbolClick(System::TObject* Sender);
	void __fastcall sbUseLeadingZeroClick(System::TObject* Sender);
	void __fastcall SetFormulaGlyph(Buttons::TSpeedButton* fBtn, Classes::TStrings* sList);
	void __fastcall SetFormulaGlyphEx(Buttons::TSpeedButton* fBtn, Ucrpeclasses::TCrFormatFormulaName fName);
	void __fastcall editLineSpacingExit(System::TObject* Sender);
	void __fastcall editLineSpacingEnter(System::TObject* Sender);
	void __fastcall editCharacterSpacingEnter(System::TObject* Sender);
	void __fastcall editCharacterSpacingExit(System::TObject* Sender);
	void __fastcall editIndentEnter(System::TObject* Sender);
	void __fastcall editIndentExit(System::TObject* Sender);
	void __fastcall rgUnitsClick(System::TObject* Sender);
	
public:
	Ucrpeclasses::TCrpePersistent* Format;
	Ucrpeclasses::TCrpeFormatA* Cfa;
	Ucrpeclasses::TCrpeFormatC* Cfb;
	Ucrpeclasses::TCrpeFieldObjectFormat* Cff;
	AnsiString prevStr;
	bool bClose;
public:
	#pragma option push -w-inl
	/* TCustomForm.Create */ inline __fastcall virtual TCrpeFormatDlg(Classes::TComponent* AOwner) : Forms::TForm(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.CreateNew */ inline __fastcall virtual TCrpeFormatDlg(Classes::TComponent* AOwner, int Dummy) : Forms::TForm(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TCrpeFormatDlg(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TCrpeFormatDlg(HWND ParentWindow) : Forms::TForm(ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TCrpeFormatDlg* CrpeFormatDlg;
extern PACKAGE bool bFormat;

}	/* namespace Udformat */
using namespace Udformat;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// UDFormat
