// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'UDPages.pas' rev: 6.00

#ifndef UDPagesHPP
#define UDPagesHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <UCrpe32.hpp>	// Pascal unit
#include <Buttons.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Udpages
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TCrpePagesDlg;
class PASCALIMPLEMENTATION TCrpePagesDlg : public Forms::TForm 
{
	typedef Forms::TForm inherited;
	
__published:
	Stdctrls::TButton* btnOk;
	Stdctrls::TButton* btnCancel;
	Extctrls::TPanel* pnlPages;
	Stdctrls::TEdit* editStartPageNumber;
	Stdctrls::TLabel* lblStartPageNumber;
	Buttons::TSpeedButton* sbFirst;
	Buttons::TSpeedButton* sbPrevious;
	Buttons::TSpeedButton* sbNext;
	Buttons::TSpeedButton* sbLast;
	Extctrls::TPanel* pnlMonitor;
	Stdctrls::TCheckBox* cbMonitor;
	Stdctrls::TLabel* Label1;
	Stdctrls::TEdit* editStart;
	Stdctrls::TLabel* Label2;
	Stdctrls::TEdit* editLatest;
	Stdctrls::TLabel* Label3;
	Stdctrls::TEdit* editDisplayed;
	Stdctrls::TButton* btnGoToPage;
	Stdctrls::TEdit* editGoToPage;
	Extctrls::TTimer* Timer1;
	Stdctrls::TLabel* lblInstructions;
	void __fastcall FormCreate(System::TObject* Sender);
	void __fastcall FormShow(System::TObject* Sender);
	void __fastcall UpdatePages(void);
	void __fastcall InitializeControls(bool OnOff);
	void __fastcall sbFirstClick(System::TObject* Sender);
	void __fastcall sbPreviousClick(System::TObject* Sender);
	void __fastcall btnGoToPageClick(System::TObject* Sender);
	void __fastcall sbNextClick(System::TObject* Sender);
	void __fastcall sbLastClick(System::TObject* Sender);
	void __fastcall cbMonitorClick(System::TObject* Sender);
	void __fastcall editGoToPageEnter(System::TObject* Sender);
	void __fastcall editGoToPageExit(System::TObject* Sender);
	void __fastcall Timer1Timer(System::TObject* Sender);
	void __fastcall FormClose(System::TObject* Sender, Forms::TCloseAction &Action);
	void __fastcall btnOkClick(System::TObject* Sender);
	void __fastcall editStartPageNumberEnter(System::TObject* Sender);
	void __fastcall editStartPageNumberExit(System::TObject* Sender);
	void __fastcall btnCancelClick(System::TObject* Sender);
	void __fastcall FormDeactivate(System::TObject* Sender);
	
public:
	Ucrpe32::TCrpe* Cr;
	int rStartPage;
	AnsiString PrevNum;
public:
	#pragma option push -w-inl
	/* TCustomForm.Create */ inline __fastcall virtual TCrpePagesDlg(Classes::TComponent* AOwner) : Forms::TForm(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.CreateNew */ inline __fastcall virtual TCrpePagesDlg(Classes::TComponent* AOwner, int Dummy) : Forms::TForm(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TCrpePagesDlg(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TCrpePagesDlg(HWND ParentWindow) : Forms::TForm(ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TCrpePagesDlg* CrpePagesDlg;
extern PACKAGE bool bPages;

}	/* namespace Udpages */
using namespace Udpages;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// UDPages
