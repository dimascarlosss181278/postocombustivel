// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'UCrpeClasses.pas' rev: 6.00

#ifndef UCrpeClassesHPP
#define UCrpeClassesHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <CRDynamic.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Ucrpeclasses
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TComponentX;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TComponentX : public Classes::TComponent 
{
	typedef Classes::TComponent inherited;
	
public:
	#pragma option push -w-inl
	/* TComponent.Create */ inline __fastcall virtual TComponentX(Classes::TComponent* AOwner) : Classes::TComponent(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TComponent.Destroy */ inline __fastcall virtual ~TComponentX(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

#pragma option push -b-
enum TCrFieldValueType { fvUnknown, fvInt8s, fvInt8u, fvInt16s, fvInt16u, fvInt32s, fvInt32u, fvNumber, fvCurrency, fvBoolean, fvDate, fvTime, fvString, fvTransientMemo, fvPersistentMemo, fvBlob, fvDateTime, fvBitmap, fvIcon, fvPicture, fvOle, fvGraph };
#pragma option pop

#pragma option push -b-
enum TCrObjectType { otUnknown, otField, otText, otLine, otBox, otSubreport, otOle, otGraph, otCrossTab, otBlob, otMap, otOLAPCube };
#pragma option pop

#pragma option push -b-
enum TCrFieldObjectType { oftNone, oftDatabase, oftFormula, oftSummary, oftSpecialVar, oftGroupName, oftParameter, oftExpression, oftRunningTotal };
#pragma option pop

#pragma option push -b-
enum TCrLineStyle { lsNone, lsSingle, lsDouble, lsDash, lsDot };
#pragma option pop

#pragma option push -b-
enum TCrHiliteRangeCondition { hrcEqualTo, hrcNotEqualTo, hrcLessThan, hrcLessThanOrEqualTo, hrcGreaterThan, hrcGreaterThanOrEqualTo, hrcBetween, hrcNotBetween };
#pragma option pop

#pragma option push -b-
enum TCrHiliteBorderStyle { hbsDefault, hbsNone, hbsSingleBox, hbsDoubleBox, hbsSingleUnderline, hbsDoubleUnderline, hbsSingleOverline, hbsDoubleOverline, hbsSingleBoxWithDoubleUnderline };
#pragma option pop

#pragma option push -b-
enum TCrHiliteFontStyle { hfsDefault, hfsRegular, hfsItalic, hfsBold, hfsBoldItalic };
#pragma option pop

typedef AnsiString TCrLookupString;

typedef int TCrLookupNumber;

#pragma option push -b-
enum TCrHorizontalAlignment { haDefault, haLeft, haCenter, haRight, haJustified, haDecimal };
#pragma option pop

#pragma option push -b-
enum TCrNegativeFormat { nfNone, nfLeading, nfTrailing, nfBracketed };
#pragma option pop

#pragma option push -b-
enum TCrRoundingFormat { rfTenBillionth, rfBillionth, rfHundredMillionth, rfTenMillionth, rfMillionth, rfHundredThousandth, rfTenThousandth, rfThousandth, rfHundredth, rfTenth, rfUnit, rfTen, rfHundred, rfThousand, rfTenThousand, rfHundredThousand, rfMillion };
#pragma option pop

#pragma option push -b-
enum TCrCurrencySymbolFormat { csfNone, csfFixed, csfFloating };
#pragma option pop

#pragma option push -b-
enum TCrCurrencySymbolPosition { cspLeadingInside, cspLeadingOutside, cspTrailingInside, cspTrailingOutside };
#pragma option pop

#pragma option push -b-
enum TCrBooleanType { TrueFalse, TF, YesNo, YN, OneZero };
#pragma option pop

#pragma option push -b-
enum TCrDateType { dfWindowsLong, dfWindowsShort, dfUserDefined };
#pragma option pop

#pragma option push -b-
enum TCrCalendarType { ctGregorian, ctGregorianus, ctJapanese, ctTaiwanese, ctKorean, ctHijri, ctThai, ctHebrew, ctGregorianMEFrench, ctGregorianArabic, ctGregorianTransEnglish, ctGregorianTransFrench };
#pragma option pop

#pragma option push -b-
enum TCrDateOrder { doYMD, doDMY, doMDY };
#pragma option pop

#pragma option push -b-
enum TCrYearFormat { yfShort, yfLong, yfNone };
#pragma option pop

#pragma option push -b-
enum TCrMonthFormat { mfNumeric, mfLeadingZeroNumeric, mfShort, mfLong, mfNone };
#pragma option pop

#pragma option push -b-
enum TCrDayFormat { dfNumeric, dfLeadingZeroNumeric, dfNone };
#pragma option pop

#pragma option push -b-
enum TCrDayOfWeekType { dwfShort, dwfLong, dwfNone };
#pragma option pop

#pragma option push -b-
enum TCrDayOfWeekPosition { dwpLeading, dwpTrailing };
#pragma option pop

#pragma option push -b-
enum TCrDayOfWeekEnclosure { dweNone, dweParentheses, dweFWParentheses, dweSquareBrackets, dweFWSquareBrackets };
#pragma option pop

#pragma option push -b-
enum TCrDateEra { deShort, deLong, deNone };
#pragma option pop

#pragma option push -b-
enum TCrTimeBase { tf12Hour, tf24Hour };
#pragma option pop

#pragma option push -b-
enum TCrAmPmPosition { ampmBefore, ampmAfter };
#pragma option pop

#pragma option push -b-
enum TCrTimeFormat { tfNumeric, tfNoLeadingZero, tfNone };
#pragma option pop

#pragma option push -b-
enum TCrDateTimeOrder { dtoDateTime, dtoTimeDate, dtoDate, dtoTime };
#pragma option pop

#pragma option push -b-
enum TCrTextInterpretation { tiNone, tiRTF, tiHTML };
#pragma option pop

#pragma option push -b-
enum TCrLineSpacingType { lsMultiple, lsExact };
#pragma option pop

#pragma option push -b-
enum TCrTextRotation { trZero, tr90, tr270 };
#pragma option pop

#pragma option push -b-
enum TCrFormatFormulaName { ffnSuppressIfZero, ffnNegativeFormat, ffnUseThousandsSeparators, ffnUseLeadingZero, ffnDecimalPlaces, ffnRoundingFormat, ffnCurrencySymbolFormat, ffnOneCurrencySymbolPerPage, ffnCurrencySymbolPosition, ffnThousandSymbol, ffnDecimalSymbol, ffnCurrencySymbol, ffnReverseSignForDisplay, ffnAllowFieldClipping, ffnBooleanType, ffnDateType, ffnDateOrder, ffnYearFormat, ffnMonthFormat, ffnDayFormat, ffnFirstDateSeparator, ffnSecondDateSeparator, ffnDayOfWeekType, ffnDayOfWeekSeparator, ffnDayOfWeekPosition, ffnDateEraFormat, ffnCalendarType, ffnPrefixSeparator, ffnSuffixSeparator, ffnDayOfWeekEnclosure, ffnTimeBase, ffnAmPmPosition, ffnHourType, ffnMinuteType, ffnSecondType, ffnHourMinSeparator, ffnMinSecSeparator, ffnAMString, ffnPMString, ffnDateTimeOrder, ffnDateTimeSeparator, ffnFirstLineIndent, ffnLeftIndent, ffnRightIndent, ffnMaxNLines, ffnTextInterpretation, ffnFontColor };
#pragma option pop

class DELPHICLASS TCrpePersistent;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpePersistent : public Classes::TPersistent 
{
	typedef Classes::TPersistent inherited;
	
protected:
	Classes::TList* FSubClassList;
	
public:
	Classes::TComponent* Cx;
	int FIndex;
	unsigned Handle;
	TCrpePersistent* Parent;
	void __fastcall PropagateCrpe(const Classes::TComponent* Crpe, const TCrpePersistent* Par);
	void __fastcall PropagateHandle(const unsigned NewHandle);
	void __fastcall PropagateIndex(const int NewIndex);
	__fastcall TCrpePersistent(void);
	__fastcall virtual ~TCrpePersistent(void);
};

#pragma pack(pop)

class DELPHICLASS TCrpeItem;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeItem : public TCrpePersistent 
{
	typedef TCrpePersistent inherited;
	
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Create */ inline __fastcall TCrpeItem(void) : TCrpePersistent() { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpeItem(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

class DELPHICLASS TCrpeObjectItem;
class DELPHICLASS TCrpeBorder;
class DELPHICLASS TCrpeBorderFormulas;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeBorderFormulas : public TCrpePersistent 
{
	typedef TCrpePersistent inherited;
	
protected:
	short FFieldN;
	Classes::TStrings* FLeft;
	Classes::TStrings* FRight;
	Classes::TStrings* FTop;
	Classes::TStrings* FBottom;
	Classes::TStrings* FTightHorizontal;
	Classes::TStrings* FDropShadow;
	Classes::TStrings* FForeColor;
	Classes::TStrings* FBackgroundColor;
	Classes::TStrings* xFormula;
	bool __fastcall StatusIsGo(void);
	Classes::TStrings* __fastcall GetLeft(void);
	void __fastcall SetLeft(const Classes::TStrings* Value);
	Classes::TStrings* __fastcall GetRight(void);
	void __fastcall SetRight(const Classes::TStrings* Value);
	Classes::TStrings* __fastcall GetTop(void);
	void __fastcall SetTop(const Classes::TStrings* Value);
	Classes::TStrings* __fastcall GetBottom(void);
	void __fastcall SetBottom(const Classes::TStrings* Value);
	Classes::TStrings* __fastcall GetTightHorizontal(void);
	void __fastcall SetTightHorizontal(const Classes::TStrings* Value);
	Classes::TStrings* __fastcall GetDropShadow(void);
	void __fastcall SetDropShadow(const Classes::TStrings* Value);
	Classes::TStrings* __fastcall GetForeColor(void);
	void __fastcall SetForeColor(const Classes::TStrings* Value);
	Classes::TStrings* __fastcall GetBackgroundColor(void);
	void __fastcall SetBackgroundColor(const Classes::TStrings* Value);
	void __fastcall OnChangeLeft(System::TObject* Sender);
	void __fastcall OnChangeRight(System::TObject* Sender);
	void __fastcall OnChangeTop(System::TObject* Sender);
	void __fastcall OnChangeBottom(System::TObject* Sender);
	void __fastcall OnChangeTightHorizontal(System::TObject* Sender);
	void __fastcall OnChangeDropShadow(System::TObject* Sender);
	void __fastcall OnChangeForeColor(System::TObject* Sender);
	void __fastcall OnChangeBackgroundColor(System::TObject* Sender);
	
__published:
	__property Classes::TStrings* Left = {read=GetLeft, write=SetLeft};
	__property Classes::TStrings* Right = {read=GetRight, write=SetRight};
	__property Classes::TStrings* Top = {read=GetTop, write=SetTop};
	__property Classes::TStrings* Bottom = {read=GetBottom, write=SetBottom};
	__property Classes::TStrings* TightHorizontal = {read=GetTightHorizontal, write=SetTightHorizontal};
	__property Classes::TStrings* DropShadow = {read=GetDropShadow, write=SetDropShadow};
	__property Classes::TStrings* ForeColor = {read=GetForeColor, write=SetForeColor};
	__property Classes::TStrings* BackgroundColor = {read=GetBackgroundColor, write=SetBackgroundColor};
	
public:
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	void __fastcall Clear(void);
	__fastcall TCrpeBorderFormulas(void);
	__fastcall virtual ~TCrpeBorderFormulas(void);
};

#pragma pack(pop)

#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeBorder : public TCrpePersistent 
{
	typedef TCrpePersistent inherited;
	
protected:
	short FFieldN;
	TCrLineStyle FLeft;
	TCrLineStyle FRight;
	TCrLineStyle FTop;
	TCrLineStyle FBottom;
	bool FTightHorizontal;
	bool FDropShadow;
	Graphics::TColor FForeColor;
	Graphics::TColor FBackgroundColor;
	TCrpeBorderFormulas* FFormulas;
	bool __fastcall StatusIsGo(void);
	
__published:
	TCrLineStyle __fastcall GetLeft(void);
	void __fastcall SetLeft(const TCrLineStyle Value);
	TCrLineStyle __fastcall GetRight(void);
	void __fastcall SetRight(const TCrLineStyle Value);
	TCrLineStyle __fastcall GetTop(void);
	void __fastcall SetTop(const TCrLineStyle Value);
	TCrLineStyle __fastcall GetBottom(void);
	void __fastcall SetBottom(const TCrLineStyle Value);
	bool __fastcall GetTightHorizontal(void);
	void __fastcall SetTightHorizontal(const bool Value);
	bool __fastcall GetDropShadow(void);
	void __fastcall SetDropShadow(const bool Value);
	Graphics::TColor __fastcall GetForeColor(void);
	void __fastcall SetForeColor(const Graphics::TColor Value);
	Graphics::TColor __fastcall GetBackgroundColor(void);
	void __fastcall SetBackgroundColor(const Graphics::TColor Value);
	__property TCrLineStyle Left = {read=GetLeft, write=SetLeft, nodefault};
	__property TCrLineStyle Right = {read=GetRight, write=SetRight, nodefault};
	__property TCrLineStyle Top = {read=GetTop, write=SetTop, nodefault};
	__property TCrLineStyle Bottom = {read=GetBottom, write=SetBottom, nodefault};
	__property bool TightHorizontal = {read=GetTightHorizontal, write=SetTightHorizontal, nodefault};
	__property bool DropShadow = {read=GetDropShadow, write=SetDropShadow, nodefault};
	__property Graphics::TColor ForeColor = {read=GetForeColor, write=SetForeColor, nodefault};
	__property Graphics::TColor BackgroundColor = {read=GetBackgroundColor, write=SetBackgroundColor, nodefault};
	__property TCrpeBorderFormulas* Formulas = {read=FFormulas, write=FFormulas};
	
public:
	void __fastcall SetFNum(short nField);
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	void __fastcall GetBorder(void);
	void __fastcall Clear(void);
	__fastcall TCrpeBorder(void);
	__fastcall virtual ~TCrpeBorder(void);
};

#pragma pack(pop)

#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeObjectItem : public TCrpeItem 
{
	typedef TCrpeItem inherited;
	
protected:
	int FTop;
	int FLeft;
	int FWidth;
	int FHeight;
	AnsiString FSection;
	TCrpeBorder* FBorder;
	void __fastcall SetTop(const int Value);
	void __fastcall SetLeft(const int Value);
	void __fastcall SetWidth(const int Value);
	void __fastcall SetHeight(const int Value);
	void __fastcall SetSection(const AnsiString Value);
	TCrpeBorder* __fastcall GetBorder(void);
	bool __fastcall StatusIsGo(int nIndex);
	
__published:
	__property int Top = {read=FTop, write=SetTop, nodefault};
	__property int Left = {read=FLeft, write=SetLeft, nodefault};
	__property int Width = {read=FWidth, write=SetWidth, nodefault};
	__property int Height = {read=FHeight, write=SetHeight, nodefault};
	__property AnsiString Section = {read=FSection, write=SetSection};
	__property TCrpeBorder* Border = {read=GetBorder, write=FBorder};
	
public:
	void __fastcall Clear(void);
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	__fastcall TCrpeObjectItem(void);
	__fastcall virtual ~TCrpeObjectItem(void);
};

#pragma pack(pop)

class DELPHICLASS TCrpeObjectItemA;
class DELPHICLASS TCrpeFormatA;
class DELPHICLASS TCrpeFormat;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeFormat : public TCrpePersistent 
{
	typedef TCrpePersistent inherited;
	
protected:
	bool FSuppress;
	bool FKeepTogether;
	bool FCloseBorder;
	AnsiString FToolTip;
	bool __fastcall StatusIsGo(void);
	
__published:
	virtual bool __fastcall GetSuppress(void) = 0 ;
	virtual void __fastcall SetSuppress(const bool Value) = 0 ;
	virtual bool __fastcall GetKeepTogether(void) = 0 ;
	virtual void __fastcall SetKeepTogether(const bool Value) = 0 ;
	virtual bool __fastcall GetCloseBorder(void) = 0 ;
	virtual void __fastcall SetCloseBorder(const bool Value) = 0 ;
	virtual AnsiString __fastcall GetToolTip(void) = 0 ;
	virtual void __fastcall SetToolTip(const AnsiString Value) = 0 ;
	__property bool Suppress = {read=GetSuppress, write=SetSuppress, default=0};
	__property bool KeepTogether = {read=GetKeepTogether, write=SetKeepTogether, default=1};
	__property bool CloseBorder = {read=GetCloseBorder, write=SetCloseBorder, default=1};
	__property AnsiString ToolTip = {read=GetToolTip, write=SetToolTip};
	
public:
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	virtual void __fastcall Clear(void);
	__fastcall TCrpeFormat(void);
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpeFormat(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

class DELPHICLASS TCrpeFormatFormulasA;
class DELPHICLASS TCrpeFormatFormulas;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeFormatFormulas : public TCrpePersistent 
{
	typedef TCrpePersistent inherited;
	
private:
	Classes::TStrings* FSuppress;
	Classes::TStrings* FKeepTogether;
	Classes::TStrings* FCloseBorder;
	Classes::TStrings* FHyperLink;
	Classes::TStrings* xFormula;
	
protected:
	bool __fastcall StatusIsGo(void);
	virtual Classes::TStrings* __fastcall GetSuppress(void) = 0 ;
	virtual void __fastcall SetSuppress(const Classes::TStrings* Value) = 0 ;
	virtual Classes::TStrings* __fastcall GetKeepTogether(void) = 0 ;
	virtual void __fastcall SetKeepTogether(const Classes::TStrings* Value) = 0 ;
	virtual Classes::TStrings* __fastcall GetCloseBorder(void) = 0 ;
	virtual void __fastcall SetCloseBorder(const Classes::TStrings* Value) = 0 ;
	virtual Classes::TStrings* __fastcall GetHyperLink(void) = 0 ;
	virtual void __fastcall SetHyperLink(const Classes::TStrings* Value) = 0 ;
	
__published:
	__property Classes::TStrings* Suppress = {read=GetSuppress, write=SetSuppress};
	__property Classes::TStrings* KeepTogether = {read=GetKeepTogether, write=SetKeepTogether};
	__property Classes::TStrings* CloseBorder = {read=GetCloseBorder, write=SetCloseBorder};
	__property Classes::TStrings* HyperLink = {read=GetHyperLink, write=SetHyperLink};
	
public:
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	virtual void __fastcall Clear(void);
	__fastcall TCrpeFormatFormulas(void);
	__fastcall virtual ~TCrpeFormatFormulas(void);
};

#pragma pack(pop)

#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeFormatFormulasA : public TCrpeFormatFormulas 
{
	typedef TCrpeFormatFormulas inherited;
	
protected:
	virtual Classes::TStrings* __fastcall GetSuppress(void);
	virtual void __fastcall SetSuppress(const Classes::TStrings* Value);
	virtual Classes::TStrings* __fastcall GetKeepTogether(void);
	virtual void __fastcall SetKeepTogether(const Classes::TStrings* Value);
	virtual Classes::TStrings* __fastcall GetCloseBorder(void);
	virtual void __fastcall SetCloseBorder(const Classes::TStrings* Value);
	virtual Classes::TStrings* __fastcall GetHyperLink(void);
	virtual void __fastcall SetHyperLink(const Classes::TStrings* Value);
	void __fastcall OnChangeSuppress(System::TObject* Sender);
	void __fastcall OnChangeKeepTogether(System::TObject* Sender);
	void __fastcall OnChangeCloseBorder(System::TObject* Sender);
	void __fastcall OnChangeHyperLink(System::TObject* Sender);
	
public:
	__fastcall TCrpeFormatFormulasA(void);
	__fastcall virtual ~TCrpeFormatFormulasA(void);
};

#pragma pack(pop)

#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeFormatA : public TCrpeFormat 
{
	typedef TCrpeFormat inherited;
	
protected:
	TCrpeFormatFormulasA* FFormulas;
	
__published:
	virtual bool __fastcall GetSuppress(void);
	virtual void __fastcall SetSuppress(const bool Value);
	virtual bool __fastcall GetKeepTogether(void);
	virtual void __fastcall SetKeepTogether(const bool Value);
	virtual bool __fastcall GetCloseBorder(void);
	virtual void __fastcall SetCloseBorder(const bool Value);
	virtual AnsiString __fastcall GetToolTip();
	virtual void __fastcall SetToolTip(const AnsiString Value);
	__property TCrpeFormatFormulasA* Formulas = {read=FFormulas, write=FFormulas};
	
public:
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	void __fastcall GetFormat(void);
	virtual void __fastcall Clear(void);
	__fastcall TCrpeFormatA(void);
	__fastcall virtual ~TCrpeFormatA(void);
};

#pragma pack(pop)

#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeObjectItemA : public TCrpeObjectItem 
{
	typedef TCrpeObjectItem inherited;
	
protected:
	TCrpeFormatA* FFormat;
	
__published:
	__property TCrpeFormatA* Format = {read=FFormat, write=FFormat};
	
public:
	HIDESBASE void __fastcall Clear(void);
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	__fastcall TCrpeObjectItemA(void);
	__fastcall virtual ~TCrpeObjectItemA(void);
};

#pragma pack(pop)

class DELPHICLASS TCrpeObjectItemB;
class DELPHICLASS TCrpeFormatC;
class DELPHICLASS TCrpeFormatB;
class DELPHICLASS TCrpeFormatFormulasB;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeFormatFormulasB : public TCrpeFormatFormulas 
{
	typedef TCrpeFormatFormulas inherited;
	
protected:
	short FFieldN;
	Classes::TStrings* FAlignment;
	Classes::TStrings* FCanGrow;
	Classes::TStrings* FSuppressIfDuplicated;
	virtual Classes::TStrings* __fastcall GetSuppress(void);
	virtual void __fastcall SetSuppress(const Classes::TStrings* Value);
	virtual Classes::TStrings* __fastcall GetKeepTogether(void);
	virtual void __fastcall SetKeepTogether(const Classes::TStrings* Value);
	virtual Classes::TStrings* __fastcall GetCloseBorder(void);
	virtual void __fastcall SetCloseBorder(const Classes::TStrings* Value);
	virtual Classes::TStrings* __fastcall GetHyperLink(void);
	virtual void __fastcall SetHyperLink(const Classes::TStrings* Value);
	Classes::TStrings* __fastcall GetAlignment(void);
	void __fastcall SetAlignment(const Classes::TStrings* Value);
	Classes::TStrings* __fastcall GetCanGrow(void);
	void __fastcall SetCanGrow(const Classes::TStrings* Value);
	Classes::TStrings* __fastcall GetSuppressIfDuplicated(void);
	void __fastcall SetSuppressIfDuplicated(const Classes::TStrings* Value);
	void __fastcall OnChangeSuppress(System::TObject* Sender);
	void __fastcall OnChangeKeepTogether(System::TObject* Sender);
	void __fastcall OnChangeCloseBorder(System::TObject* Sender);
	void __fastcall OnChangeHyperLink(System::TObject* Sender);
	void __fastcall OnChangeAlignment(System::TObject* Sender);
	void __fastcall OnChangeCanGrow(System::TObject* Sender);
	void __fastcall OnChangeSuppressIfDuplicated(System::TObject* Sender);
	
__published:
	__property Classes::TStrings* Alignment = {read=GetAlignment, write=SetAlignment};
	__property Classes::TStrings* SuppressIfDuplicated = {read=GetSuppressIfDuplicated, write=SetSuppressIfDuplicated};
	__property Classes::TStrings* CanGrow = {read=GetCanGrow, write=SetCanGrow};
	
public:
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	virtual void __fastcall Clear(void);
	__fastcall TCrpeFormatFormulasB(void);
	__fastcall virtual ~TCrpeFormatFormulasB(void);
};

#pragma pack(pop)

#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeFormatB : public TCrpeFormat 
{
	typedef TCrpeFormat inherited;
	
protected:
	TCrFieldValueType FFieldType;
	short FFieldN;
	TCrHorizontalAlignment FAlignment;
	bool FCanGrow;
	int FMaxNLines;
	TCrTextRotation FTextRotation;
	bool FSuppressIfDuplicated;
	TCrpeFormatFormulasB* FFormulas;
	
__published:
	virtual bool __fastcall GetSuppress(void);
	virtual void __fastcall SetSuppress(const bool Value);
	virtual bool __fastcall GetKeepTogether(void);
	virtual void __fastcall SetKeepTogether(const bool Value);
	virtual bool __fastcall GetCloseBorder(void);
	virtual void __fastcall SetCloseBorder(const bool Value);
	virtual AnsiString __fastcall GetToolTip();
	virtual void __fastcall SetToolTip(const AnsiString Value);
	TCrHorizontalAlignment __fastcall GetAlignment(void);
	void __fastcall SetAlignment(const TCrHorizontalAlignment Value);
	bool __fastcall GetCanGrow(void);
	void __fastcall SetCanGrow(const bool Value);
	int __fastcall GetMaxNLines(void);
	void __fastcall SetMaxNLines(const int Value);
	TCrTextRotation __fastcall GetTextRotation(void);
	void __fastcall SetTextRotation(const TCrTextRotation Value);
	bool __fastcall GetSuppressIfDuplicated(void);
	void __fastcall SetSuppressIfDuplicated(const bool Value);
	__property TCrHorizontalAlignment Alignment = {read=GetAlignment, write=SetAlignment, nodefault};
	__property bool SuppressIfDuplicated = {read=GetSuppressIfDuplicated, write=SetSuppressIfDuplicated, nodefault};
	__property bool CanGrow = {read=GetCanGrow, write=SetCanGrow, nodefault};
	__property int MaxNLines = {read=GetMaxNLines, write=SetMaxNLines, default=1};
	__property TCrTextRotation TextRotation = {read=GetTextRotation, write=SetTextRotation, default=0};
	__property TCrpeFormatFormulasB* Formulas = {read=FFormulas, write=FFormulas};
	
public:
	void __fastcall SetFieldType(TCrFieldValueType FType);
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	void __fastcall GetFormat(void);
	virtual void __fastcall Clear(void);
	__fastcall TCrpeFormatB(void);
	__fastcall virtual ~TCrpeFormatB(void);
};

#pragma pack(pop)

class DELPHICLASS TCrpeParagraphFormat;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeParagraphFormat : public TCrpePersistent 
{
	typedef TCrpePersistent inherited;
	
protected:
	TCrFieldValueType FFieldType;
	short FFieldN;
	int FIndentFirstLine;
	int FIndentLeft;
	int FIndentRight;
	TCrTextInterpretation FTextInterpretation;
	TCrLineSpacingType FLineSpacingType;
	double FLineSpacing;
	double FCharacterSpacing;
	bool __fastcall StatusIsGo(void);
	
__published:
	int __fastcall GetIndentFirstLine(void);
	int __fastcall GetIndentLeft(void);
	int __fastcall GetIndentRight(void);
	TCrTextInterpretation __fastcall GetTextInterpretation(void);
	TCrLineSpacingType __fastcall GetLineSpacingType(void);
	double __fastcall GetLineSpacing(void);
	double __fastcall GetCharacterSpacing(void);
	void __fastcall SetIndentFirstLine(const int Value);
	void __fastcall SetIndentLeft(const int Value);
	void __fastcall SetIndentRight(const int Value);
	void __fastcall SetTextInterpretation(const TCrTextInterpretation Value);
	void __fastcall SetLineSpacingType(const TCrLineSpacingType Value);
	void __fastcall SetLineSpacing(const double Value);
	void __fastcall SetCharacterSpacing(const double Value);
	__property int IndentFirstLine = {read=GetIndentFirstLine, write=SetIndentFirstLine, default=0};
	__property int IndentLeft = {read=GetIndentLeft, write=SetIndentLeft, default=0};
	__property int IndentRight = {read=GetIndentRight, write=SetIndentRight, default=0};
	__property TCrTextInterpretation TextInterpretation = {read=GetTextInterpretation, write=SetTextInterpretation, default=0};
	__property TCrLineSpacingType LineSpacingType = {read=GetLineSpacingType, write=SetLineSpacingType, default=0};
	__property double LineSpacing = {read=GetLineSpacing, write=SetLineSpacing};
	__property double CharacterSpacing = {read=GetCharacterSpacing, write=SetCharacterSpacing};
	
public:
	bool FForEmbeddedField;
	bool FForTextObject;
	void __fastcall GetFormat(void);
	void __fastcall SetFieldType(TCrFieldValueType FType);
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	void __fastcall Clear(void);
	__fastcall TCrpeParagraphFormat(void);
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpeParagraphFormat(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeFormatC : public TCrpeFormatB 
{
	typedef TCrpeFormatB inherited;
	
protected:
	TCrpeParagraphFormat* FParagraph;
	
__published:
	__property TCrpeParagraphFormat* Paragraph = {read=FParagraph, write=FParagraph};
	
public:
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	virtual void __fastcall Clear(void);
	__fastcall TCrpeFormatC(void);
	__fastcall virtual ~TCrpeFormatC(void);
};

#pragma pack(pop)

class DELPHICLASS TCrpeFont;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeFont : public Graphics::TFont 
{
	typedef Graphics::TFont inherited;
	
protected:
	int FIndex;
	double FActualSize;
	double __fastcall GetActualSize(void);
	void __fastcall SetActualSize(const double Value);
	bool __fastcall HasChanged(const Crdynamic::PEFontColorInfo &RptFontInfo);
	void __fastcall CopyFontInfo(Crdynamic::PEFontColorInfo &FontInfo, TCrpeFont* VCLFont);
	
__published:
	__property double ActualSize = {read=GetActualSize, write=SetActualSize};
	
public:
	Classes::TComponent* Cx;
	TCrpePersistent* Parent;
	unsigned Handle;
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	void __fastcall Clear(void);
	void __fastcall GetFont(void);
	void __fastcall SetFont(void);
	__fastcall TCrpeFont(void);
public:
	#pragma option push -w-inl
	/* TFont.Destroy */ inline __fastcall virtual ~TCrpeFont(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeObjectItemB : public TCrpeObjectItem 
{
	typedef TCrpeObjectItem inherited;
	
protected:
	TCrpeFormatC* FFormat;
	TCrpeFont* FFont;
	TCrpeFont* __fastcall GetFont(void);
	void __fastcall OnChangeFont(System::TObject* Sender);
	
__published:
	__property TCrpeFormatC* Format = {read=FFormat, write=FFormat};
	__property TCrpeFont* Font = {read=GetFont, write=FFont};
	
public:
	HIDESBASE void __fastcall Clear(void);
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	__fastcall TCrpeObjectItemB(void);
	__fastcall virtual ~TCrpeObjectItemB(void);
};

#pragma pack(pop)

class DELPHICLASS TCrpeFieldObjectItem;
class DELPHICLASS TCrpeFieldObjectFormat;
class DELPHICLASS TCrpeFieldFormat;
class DELPHICLASS TCrpeNumberFormat;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeNumberFormat : public TCrpePersistent 
{
	typedef TCrpePersistent inherited;
	
protected:
	TCrFieldValueType FFieldType;
	short FFieldN;
	bool FSuppressIfZero;
	TCrNegativeFormat FNegativeFormat;
	bool FUseThousandsSeparators;
	bool FUseLeadingZero;
	int FDecimalPlaces;
	TCrRoundingFormat FRoundingFormat;
	bool FReverseSignForDisplay;
	bool FUseAccountingFormat;
	AnsiString FCurrencySymbol;
	TCrCurrencySymbolFormat FCurrencySymbolFormat;
	bool FOneCurrencySymbolPerPage;
	TCrCurrencySymbolPosition FCurrencySymbolPosition;
	AnsiString FThousandSymbol;
	AnsiString FDecimalSymbol;
	AnsiString FShowZeroValueAs;
	bool FAllowFieldClipping;
	bool __fastcall GetSuppressIfZero(void);
	TCrNegativeFormat __fastcall GetNegativeFormat(void);
	bool __fastcall GetUseThousandsSeparators(void);
	bool __fastcall GetUseLeadingZero(void);
	int __fastcall GetDecimalPlaces(void);
	TCrRoundingFormat __fastcall GetRoundingFormat(void);
	bool __fastcall GetReverseSignForDisplay(void);
	bool __fastcall GetUseAccountingFormat(void);
	AnsiString __fastcall GetCurrencySymbol();
	TCrCurrencySymbolFormat __fastcall GetCurrencySymbolFormat(void);
	bool __fastcall GetOneCurrencySymbolPerPage(void);
	TCrCurrencySymbolPosition __fastcall GetCurrencySymbolPosition(void);
	AnsiString __fastcall GetThousandSymbol();
	AnsiString __fastcall GetDecimalSymbol();
	AnsiString __fastcall GetShowZeroValueAs();
	bool __fastcall GetAllowFieldClipping(void);
	void __fastcall SetSuppressIfZero(const bool Value);
	void __fastcall SetNegativeFormat(const TCrNegativeFormat Value);
	void __fastcall SetUseThousandsSeparators(const bool Value);
	void __fastcall SetUseLeadingZero(const bool Value);
	void __fastcall SetDecimalPlaces(const int Value);
	void __fastcall SetRoundingFormat(const TCrRoundingFormat Value);
	void __fastcall SetReverseSignForDisplay(const bool Value);
	void __fastcall SetUseAccountingFormat(const bool Value);
	void __fastcall SetCurrencySymbol(const AnsiString Value);
	void __fastcall SetCurrencySymbolFormat(const TCrCurrencySymbolFormat Value);
	void __fastcall SetOneCurrencySymbolPerPage(const bool Value);
	void __fastcall SetCurrencySymbolPosition(const TCrCurrencySymbolPosition Value);
	void __fastcall SetThousandSymbol(const AnsiString Value);
	void __fastcall SetDecimalSymbol(const AnsiString Value);
	void __fastcall SetShowZeroValueAs(const AnsiString Value);
	void __fastcall SetAllowFieldClipping(const bool Value);
	bool __fastcall StatusIsGo(void);
	
__published:
	__property bool SuppressIfZero = {read=GetSuppressIfZero, write=SetSuppressIfZero, default=0};
	__property TCrNegativeFormat NegativeFormat = {read=GetNegativeFormat, write=SetNegativeFormat, default=1};
	__property bool UseThousandsSeparators = {read=GetUseThousandsSeparators, write=SetUseThousandsSeparators, default=1};
	__property bool UseLeadingZero = {read=GetUseLeadingZero, write=SetUseLeadingZero, default=1};
	__property int DecimalPlaces = {read=GetDecimalPlaces, write=SetDecimalPlaces, default=0};
	__property TCrRoundingFormat RoundingFormat = {read=GetRoundingFormat, write=SetRoundingFormat, default=10};
	__property bool ReverseSignForDisplay = {read=GetReverseSignForDisplay, write=SetReverseSignForDisplay, default=0};
	__property bool UseAccountingFormat = {read=GetUseAccountingFormat, write=SetUseAccountingFormat, default=0};
	__property AnsiString CurrencySymbol = {read=GetCurrencySymbol, write=SetCurrencySymbol};
	__property TCrCurrencySymbolFormat CurrencySymbolFormat = {read=GetCurrencySymbolFormat, write=SetCurrencySymbolFormat, default=2};
	__property bool OneCurrencySymbolPerPage = {read=GetOneCurrencySymbolPerPage, write=SetOneCurrencySymbolPerPage, default=0};
	__property TCrCurrencySymbolPosition CurrencySymbolPosition = {read=GetCurrencySymbolPosition, write=SetCurrencySymbolPosition, default=0};
	__property AnsiString ThousandSymbol = {read=GetThousandSymbol, write=SetThousandSymbol};
	__property AnsiString DecimalSymbol = {read=GetDecimalSymbol, write=SetDecimalSymbol};
	__property AnsiString ShowZeroValueAs = {read=GetShowZeroValueAs, write=SetShowZeroValueAs};
	__property bool AllowFieldClipping = {read=GetAllowFieldClipping, write=SetAllowFieldClipping, default=1};
	
public:
	void __fastcall GetFormat(void);
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	void __fastcall Clear(void);
	__fastcall TCrpeNumberFormat(void);
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpeNumberFormat(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

class DELPHICLASS TCrpeDateFormat;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeDateFormat : public TCrpePersistent 
{
	typedef TCrpePersistent inherited;
	
protected:
	TCrFieldValueType FFieldType;
	short FFieldN;
	TCrDateType FDateType;
	TCrDateOrder FDateOrder;
	TCrYearFormat FYearFormat;
	TCrMonthFormat FMonthFormat;
	TCrDayFormat FDayFormat;
	TCrDayOfWeekType FDayOfWeekType;
	AnsiString FFirstSeparator;
	AnsiString FSecondSeparator;
	AnsiString FDayOfWeekSeparator;
	TCrDayOfWeekPosition FDayOfWeekPosition;
	TCrDayOfWeekEnclosure FDayOfWeekEnclosure;
	TCrDateEra FDateEra;
	TCrCalendarType FCalendarType;
	AnsiString FPrefixSeparator;
	AnsiString FSuffixSeparator;
	TCrDateType __fastcall GetDateType(void);
	TCrDateOrder __fastcall GetDateOrder(void);
	TCrYearFormat __fastcall GetYearFormat(void);
	TCrMonthFormat __fastcall GetMonthFormat(void);
	TCrDayFormat __fastcall GetDayFormat(void);
	TCrDayOfWeekType __fastcall GetDayOfWeekType(void);
	AnsiString __fastcall GetFirstSeparator();
	AnsiString __fastcall GetSecondSeparator();
	AnsiString __fastcall GetDayOfWeekSeparator();
	TCrDayOfWeekPosition __fastcall GetDayOfWeekPosition(void);
	TCrDayOfWeekEnclosure __fastcall GetDayOfWeekEnclosure(void);
	TCrDateEra __fastcall GetDateEra(void);
	TCrCalendarType __fastcall GetCalendarType(void);
	AnsiString __fastcall GetPrefixSeparator();
	AnsiString __fastcall GetSuffixSeparator();
	void __fastcall SetDateType(const TCrDateType Value);
	void __fastcall SetDateOrder(const TCrDateOrder Value);
	void __fastcall SetYearFormat(const TCrYearFormat Value);
	void __fastcall SetMonthFormat(const TCrMonthFormat Value);
	void __fastcall SetDayFormat(const TCrDayFormat Value);
	void __fastcall SetDayOfWeekType(const TCrDayOfWeekType Value);
	void __fastcall SetFirstSeparator(const AnsiString Value);
	void __fastcall SetSecondSeparator(const AnsiString Value);
	void __fastcall SetDayOfWeekSeparator(const AnsiString Value);
	void __fastcall SetDayOfWeekPosition(const TCrDayOfWeekPosition Value);
	void __fastcall SetDayOfWeekEnclosure(const TCrDayOfWeekEnclosure Value);
	void __fastcall SetDateEra(const TCrDateEra Value);
	void __fastcall SetCalendarType(const TCrCalendarType Value);
	void __fastcall SetPrefixSeparator(const AnsiString Value);
	void __fastcall SetSuffixSeparator(const AnsiString Value);
	bool __fastcall StatusIsGo(void);
	
__published:
	__property TCrDateType DateType = {read=GetDateType, write=SetDateType, default=1};
	__property TCrDateOrder DateOrder = {read=GetDateOrder, write=SetDateOrder, default=2};
	__property TCrYearFormat YearFormat = {read=GetYearFormat, write=SetYearFormat, default=1};
	__property TCrMonthFormat MonthFormat = {read=GetMonthFormat, write=SetMonthFormat, default=1};
	__property TCrDayFormat DayFormat = {read=GetDayFormat, write=SetDayFormat, default=1};
	__property TCrDayOfWeekType DayOfWeekType = {read=GetDayOfWeekType, write=SetDayOfWeekType, default=2};
	__property AnsiString FirstSeparator = {read=GetFirstSeparator, write=SetFirstSeparator};
	__property AnsiString SecondSeparator = {read=GetSecondSeparator, write=SetSecondSeparator};
	__property AnsiString DayOfWeekSeparator = {read=GetDayOfWeekSeparator, write=SetDayOfWeekSeparator};
	__property TCrDayOfWeekPosition DayOfWeekPosition = {read=GetDayOfWeekPosition, write=SetDayOfWeekPosition, default=0};
	__property TCrDayOfWeekEnclosure DayOfWeekEnclosure = {read=GetDayOfWeekEnclosure, write=SetDayOfWeekEnclosure, default=0};
	__property TCrDateEra DateEra = {read=GetDateEra, write=SetDateEra, default=2};
	__property TCrCalendarType CalendarType = {read=GetCalendarType, write=SetCalendarType, default=0};
	__property AnsiString PrefixSeparator = {read=GetPrefixSeparator, write=SetPrefixSeparator};
	__property AnsiString SuffixSeparator = {read=GetSuffixSeparator, write=SetSuffixSeparator};
	
public:
	void __fastcall GetFormat(void);
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	void __fastcall Clear(void);
	__fastcall TCrpeDateFormat(void);
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpeDateFormat(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

class DELPHICLASS TCrpeTimeFormat;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeTimeFormat : public TCrpePersistent 
{
	typedef TCrpePersistent inherited;
	
protected:
	TCrFieldValueType FFieldType;
	short FFieldN;
	TCrTimeBase FTimeBase;
	TCrAmPmPosition FAmPmPosition;
	TCrTimeFormat FHourType;
	TCrTimeFormat FMinuteType;
	TCrTimeFormat FSecondType;
	AnsiString FAMString;
	AnsiString FPMString;
	AnsiString FHourMinSeparator;
	AnsiString FMinSecSeparator;
	TCrTimeBase __fastcall GetTimeBase(void);
	TCrAmPmPosition __fastcall GetAmPmPosition(void);
	TCrTimeFormat __fastcall GetHourType(void);
	TCrTimeFormat __fastcall GetMinuteType(void);
	TCrTimeFormat __fastcall GetSecondType(void);
	AnsiString __fastcall GetAMString();
	AnsiString __fastcall GetPMString();
	AnsiString __fastcall GetHourMinSeparator();
	AnsiString __fastcall GetMinSecSeparator();
	void __fastcall SetTimeBase(const TCrTimeBase Value);
	void __fastcall SetAmPmPosition(const TCrAmPmPosition Value);
	void __fastcall SetHourType(const TCrTimeFormat Value);
	void __fastcall SetMinuteType(const TCrTimeFormat Value);
	void __fastcall SetSecondType(const TCrTimeFormat Value);
	void __fastcall SetAMString(const AnsiString Value);
	void __fastcall SetPMString(const AnsiString Value);
	void __fastcall SetHourMinSeparator(const AnsiString Value);
	void __fastcall SetMinSecSeparator(const AnsiString Value);
	bool __fastcall StatusIsGo(void);
	
__published:
	__property TCrTimeBase TimeBase = {read=GetTimeBase, write=SetTimeBase, default=0};
	__property TCrAmPmPosition AmPmPosition = {read=GetAmPmPosition, write=SetAmPmPosition, default=1};
	__property TCrTimeFormat HourType = {read=GetHourType, write=SetHourType, default=1};
	__property TCrTimeFormat MinuteType = {read=GetMinuteType, write=SetMinuteType, default=0};
	__property TCrTimeFormat SecondType = {read=GetSecondType, write=SetSecondType, default=0};
	__property AnsiString AMString = {read=GetAMString, write=SetAMString};
	__property AnsiString PMString = {read=GetPMString, write=SetPMString};
	__property AnsiString HourMinSeparator = {read=GetHourMinSeparator, write=SetHourMinSeparator};
	__property AnsiString MinSecSeparator = {read=GetMinSecSeparator, write=SetMinSecSeparator};
	
public:
	void __fastcall GetFormat(void);
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	void __fastcall Clear(void);
	__fastcall TCrpeTimeFormat(void);
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpeTimeFormat(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

class DELPHICLASS TCrpeDateTimeFormat;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeDateTimeFormat : public TCrpePersistent 
{
	typedef TCrpePersistent inherited;
	
protected:
	TCrFieldValueType FFieldType;
	short FFieldN;
	TCrDateTimeOrder FOrder;
	AnsiString FSeparator;
	TCrDateTimeOrder __fastcall GetOrder(void);
	AnsiString __fastcall GetSeparator();
	void __fastcall SetOrder(const TCrDateTimeOrder Value);
	void __fastcall SetSeparator(const AnsiString Value);
	bool __fastcall StatusIsGo(void);
	
__published:
	__property TCrDateTimeOrder Order = {read=GetOrder, write=SetOrder, default=0};
	__property AnsiString Separator = {read=GetSeparator, write=SetSeparator};
	
public:
	void __fastcall GetFormat(void);
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	void __fastcall Clear(void);
	__fastcall TCrpeDateTimeFormat(void);
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpeDateTimeFormat(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

class DELPHICLASS TCrpeFieldFormatFormulas;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeFieldFormatFormulas : public TCrpePersistent 
{
	typedef TCrpePersistent inherited;
	
protected:
	TCrFieldValueType FFieldType;
	short FFieldN;
	TCrFormatFormulaName FName;
	Classes::TStrings* FFormula;
	Classes::TStrings* xFormula;
	bool __fastcall StatusIsGo(void);
	Classes::TStrings* __fastcall GetFormula(void);
	void __fastcall SetFormula(const Classes::TStrings* Value);
	void __fastcall SetName(const TCrFormatFormulaName Value);
	void __fastcall OnChangeStrings(System::TObject* Sender);
	
__published:
	__property TCrFormatFormulaName Name = {read=FName, write=SetName, default=46};
	__property Classes::TStrings* Formula = {read=GetFormula, write=SetFormula};
	
public:
	__property TCrFieldValueType FieldType = {read=FFieldType, nodefault};
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	void __fastcall Clear(void);
	__fastcall TCrpeFieldFormatFormulas(void);
	__fastcall virtual ~TCrpeFieldFormatFormulas(void);
};

#pragma pack(pop)

#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeFieldFormat : public TCrpePersistent 
{
	typedef TCrpePersistent inherited;
	
protected:
	TCrFieldValueType FFieldType;
	short FFieldN;
	bool FUseSystemDefaultFormatting;
	TCrBooleanType FBooleanType;
	TCrpeNumberFormat* FNumber;
	TCrpeDateFormat* FDate;
	TCrpeTimeFormat* FTime;
	TCrpeDateTimeFormat* FDateTime;
	TCrpeParagraphFormat* FParagraph;
	TCrpeFieldFormatFormulas* FFormulas;
	bool __fastcall GetUseSystemDefaultFormatting(void);
	TCrBooleanType __fastcall GetBooleanType(void);
	void __fastcall SetUseSystemDefaultFormatting(const bool Value);
	void __fastcall SetBooleanType(const TCrBooleanType Value);
	bool __fastcall StatusIsGo(void);
	
__published:
	__property bool UseSystemDefaultFormatting = {read=GetUseSystemDefaultFormatting, write=SetUseSystemDefaultFormatting, default=1};
	__property TCrBooleanType BooleanType = {read=GetBooleanType, write=SetBooleanType, default=0};
	__property TCrpeNumberFormat* Number = {read=FNumber, write=FNumber};
	__property TCrpeDateFormat* Date = {read=FDate, write=FDate};
	__property TCrpeTimeFormat* Time = {read=FTime, write=FTime};
	__property TCrpeDateTimeFormat* DateTime = {read=FDateTime, write=FDateTime};
	__property TCrpeParagraphFormat* Paragraph = {read=FParagraph, write=FParagraph};
	__property TCrpeFieldFormatFormulas* Formulas = {read=FFormulas, write=FFormulas};
	
public:
	__property TCrFieldValueType FieldType = {read=FFieldType, nodefault};
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	void __fastcall Clear(void);
	__fastcall TCrpeFieldFormat(void);
	__fastcall virtual ~TCrpeFieldFormat(void);
};

#pragma pack(pop)

#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeFieldObjectFormat : public TCrpeFormatB 
{
	typedef TCrpeFormatB inherited;
	
protected:
	TCrpeFieldFormat* FField;
	
__published:
	__property TCrpeFieldFormat* Field = {read=FField, write=FField};
	
public:
	HIDESBASE void __fastcall SetFieldType(TCrFieldValueType FType);
	void __fastcall SetFNum(short nField);
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	virtual void __fastcall Clear(void);
	__fastcall TCrpeFieldObjectFormat(void);
	__fastcall virtual ~TCrpeFieldObjectFormat(void);
};

#pragma pack(pop)

class DELPHICLASS TCrpeHiliteConditions;
class DELPHICLASS TCrpeContainer;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeContainer : public TCrpePersistent 
{
	typedef TCrpePersistent inherited;
	
public:
	virtual int __fastcall Count(void) = 0 ;
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Create */ inline __fastcall TCrpeContainer(void) : TCrpePersistent() { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpeContainer(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

class DELPHICLASS TCrpeHiliteConditionsItem;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeHiliteConditionsItem : public TCrpeItem 
{
	typedef TCrpeItem inherited;
	
protected:
	TCrHiliteRangeCondition FRangeCondition;
	double FStartValue;
	double FEndValue;
	Graphics::TColor FFontColor;
	Graphics::TColor FBackground;
	TCrHiliteBorderStyle FBorderStyle;
	TCrHiliteFontStyle FFontStyle;
	bool __fastcall StatusIsGo(void);
	void __fastcall SetRangeCondition(const TCrHiliteRangeCondition Value);
	void __fastcall SetStartValue(const double Value);
	void __fastcall SetEndValue(const double Value);
	void __fastcall SetFontColor(const Graphics::TColor Value);
	void __fastcall SetBackground(const Graphics::TColor Value);
	void __fastcall SetBorderStyle(const TCrHiliteBorderStyle Value);
	void __fastcall SetFontStyle(const TCrHiliteFontStyle Value);
	
__published:
	__property TCrHiliteRangeCondition RangeCondition = {read=FRangeCondition, write=SetRangeCondition, default=0};
	__property double StartValue = {read=FStartValue, write=SetStartValue};
	__property double EndValue = {read=FEndValue, write=SetEndValue};
	__property Graphics::TColor FontColor = {read=FFontColor, write=SetFontColor, default=0};
	__property Graphics::TColor Background = {read=FBackground, write=SetBackground, default=16777215};
	__property TCrHiliteBorderStyle BorderStyle = {read=FBorderStyle, write=SetBorderStyle, default=0};
	__property TCrHiliteFontStyle FontStyle = {read=FFontStyle, write=SetFontStyle, default=0};
	
public:
	void __fastcall SetPriority(short nIndex);
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	void __fastcall Clear(void);
	__fastcall TCrpeHiliteConditionsItem(void);
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpeHiliteConditionsItem(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeHiliteConditions : public TCrpeContainer 
{
	typedef TCrpeContainer inherited;
	
public:
	TCrpeHiliteConditionsItem* operator[](int nIndex) { return Items[nIndex]; }
	
protected:
	TCrFieldValueType FFieldType;
	TCrpeHiliteConditionsItem* FItem;
	bool __fastcall StatusIsGo(void);
	TCrpeHiliteConditionsItem* __fastcall GetItem(int nIndex);
	
__published:
	void __fastcall SetIndex(int nIndex);
	__property int Number = {read=FIndex, write=SetIndex, default=-1};
	__property TCrpeHiliteConditionsItem* Item = {read=FItem, write=FItem};
	
public:
	__property int ItemIndex = {read=FIndex, write=SetIndex, nodefault};
	__property TCrpeHiliteConditionsItem* Items[int nIndex] = {read=GetItem/*, default*/};
	virtual int __fastcall Count(void);
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	void __fastcall Clear(void);
	int __fastcall Add(void);
	void __fastcall Delete(int nIndex);
	__fastcall TCrpeHiliteConditions(void);
	__fastcall virtual ~TCrpeHiliteConditions(void);
};

#pragma pack(pop)

#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeFieldObjectItem : public TCrpeObjectItem 
{
	typedef TCrpeObjectItem inherited;
	
protected:
	AnsiString FFieldName;
	TCrFieldValueType FFieldType;
	Word FFieldLength;
	TCrpeFieldObjectFormat* FFormat;
	TCrpeFont* FFont;
	TCrpeHiliteConditions* FHiliteConditions;
	TCrpeFont* __fastcall GetFont(void);
	void __fastcall OnChangeFont(System::TObject* Sender);
	void __fastcall SetFName(const AnsiString Value);
	void __fastcall SetFType(const TCrFieldValueType Value);
	void __fastcall SetFLength(const Word Value);
	
__published:
	__property AnsiString FieldName = {read=FFieldName, write=SetFName};
	__property TCrFieldValueType FieldType = {read=FFieldType, write=SetFType, default=0};
	__property Word FieldLength = {read=FFieldLength, write=SetFLength, default=0};
	__property TCrpeFieldObjectFormat* Format = {read=FFormat, write=FFormat};
	__property TCrpeFont* Font = {read=GetFont, write=FFont};
	__property TCrpeHiliteConditions* HiliteConditions = {read=FHiliteConditions, write=FHiliteConditions};
	
public:
	void __fastcall SetFieldType(const TCrFieldValueType FType);
	HIDESBASE void __fastcall Clear(void);
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	__fastcall TCrpeFieldObjectItem(void);
	__fastcall virtual ~TCrpeFieldObjectItem(void);
};

#pragma pack(pop)

class DELPHICLASS TCrpeObjectContainer;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeObjectContainer : public TCrpeContainer 
{
	typedef TCrpeContainer inherited;
	
protected:
	TCrObjectType FObjectType;
	TCrFieldObjectType FFieldObjectType;
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Create */ inline __fastcall TCrpeObjectContainer(void) : TCrpeContainer() { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpeObjectContainer(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

class DELPHICLASS TCrpeObjectContainerA;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeObjectContainerA : public TCrpeObjectContainer 
{
	typedef TCrpeObjectContainer inherited;
	
protected:
	TCrpeObjectItemA* FItem;
	void __fastcall SetIndex(int nIndex);
	
public:
	virtual int __fastcall Count(void);
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Create */ inline __fastcall TCrpeObjectContainerA(void) : TCrpeObjectContainer() { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpeObjectContainerA(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

class DELPHICLASS TCrpeObjectContainerB;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeObjectContainerB : public TCrpeObjectContainer 
{
	typedef TCrpeObjectContainer inherited;
	
protected:
	TCrpeObjectItemB* FItem;
	void __fastcall SetIndex(int nIndex);
	
public:
	virtual int __fastcall Count(void);
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Create */ inline __fastcall TCrpeObjectContainerB(void) : TCrpeObjectContainer() { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpeObjectContainerB(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

class DELPHICLASS TCrpeFieldObjectContainer;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeFieldObjectContainer : public TCrpeObjectContainer 
{
	typedef TCrpeObjectContainer inherited;
	
protected:
	TCrpeFieldObjectItem* FItem;
	void __fastcall SetIndex(int nIndex);
	
public:
	virtual int __fastcall Count(void);
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Create */ inline __fastcall TCrpeFieldObjectContainer(void) : TCrpeObjectContainer() { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpeFieldObjectContainer(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

//-- var, const, procedure ---------------------------------------------------

}	/* namespace Ucrpeclasses */
using namespace Ucrpeclasses;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// UCrpeClasses
