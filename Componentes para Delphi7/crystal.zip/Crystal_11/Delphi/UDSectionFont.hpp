// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'UDSectionFont.pas' rev: 6.00

#ifndef UDSectionFontHPP
#define UDSectionFontHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <UCrpe32.hpp>	// Pascal unit
#include <Buttons.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Udsectionfont
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TCrpeSectionFontDlg;
class PASCALIMPLEMENTATION TCrpeSectionFontDlg : public Forms::TForm 
{
	typedef Forms::TForm inherited;
	
__published:
	Extctrls::TPanel* pnlSectionFont;
	Stdctrls::TLabel* lblName;
	Stdctrls::TLabel* lblSize;
	Stdctrls::TLabel* lblCharSet;
	Stdctrls::TLabel* lblFamily;
	Stdctrls::TLabel* lblWeight;
	Stdctrls::TLabel* lblSection;
	Stdctrls::TEdit* editName;
	Extctrls::TPanel* pnlSample;
	Stdctrls::TLabel* lblSample;
	Stdctrls::TEdit* editSize;
	Buttons::TBitBtn* btnSelectFont;
	Stdctrls::TComboBox* cbCharSet;
	Stdctrls::TCheckBox* cbItalic;
	Stdctrls::TCheckBox* cbUnderlined;
	Stdctrls::TCheckBox* cbStrikeThrough;
	Stdctrls::TComboBox* cbFamily;
	Extctrls::TRadioGroup* rgScope;
	Extctrls::TRadioGroup* rgPitch;
	Stdctrls::TComboBox* cbWeight;
	Stdctrls::TListBox* lbSections;
	Stdctrls::TButton* btnOk;
	Stdctrls::TButton* btnClear;
	Dialogs::TFontDialog* FontDialog1;
	Stdctrls::TLabel* lblCount;
	Stdctrls::TEdit* editCount;
	void __fastcall btnSelectFontClick(System::TObject* Sender);
	void __fastcall FormClose(System::TObject* Sender, Forms::TCloseAction &Action);
	void __fastcall FormShow(System::TObject* Sender);
	void __fastcall lbSectionsClick(System::TObject* Sender);
	void __fastcall editNameChange(System::TObject* Sender);
	void __fastcall cbItalicClick(System::TObject* Sender);
	void __fastcall cbUnderlinedClick(System::TObject* Sender);
	void __fastcall cbStrikeThroughClick(System::TObject* Sender);
	void __fastcall editSizeKeyPress(System::TObject* Sender, char &Key);
	void __fastcall editSizeExit(System::TObject* Sender);
	void __fastcall cbWeightChange(System::TObject* Sender);
	void __fastcall rgScopeClick(System::TObject* Sender);
	void __fastcall rgPitchClick(System::TObject* Sender);
	void __fastcall cbCharSetChange(System::TObject* Sender);
	void __fastcall cbFamilyChange(System::TObject* Sender);
	void __fastcall btnClearClick(System::TObject* Sender);
	void __fastcall UpdateSectionFont(void);
	void __fastcall btnOkClick(System::TObject* Sender);
	void __fastcall FormCreate(System::TObject* Sender);
	void __fastcall InitializeControls(bool OnOff);
	
public:
	Ucrpe32::TCrpe* Cr;
	short SFIndex;
public:
	#pragma option push -w-inl
	/* TCustomForm.Create */ inline __fastcall virtual TCrpeSectionFontDlg(Classes::TComponent* AOwner) : Forms::TForm(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.CreateNew */ inline __fastcall virtual TCrpeSectionFontDlg(Classes::TComponent* AOwner, int Dummy) : Forms::TForm(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TCrpeSectionFontDlg(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TCrpeSectionFontDlg(HWND ParentWindow) : Forms::TForm(ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TCrpeSectionFontDlg* CrpeSectionFontDlg;
extern PACKAGE bool bSectionFont;

}	/* namespace Udsectionfont */
using namespace Udsectionfont;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// UDSectionFont
