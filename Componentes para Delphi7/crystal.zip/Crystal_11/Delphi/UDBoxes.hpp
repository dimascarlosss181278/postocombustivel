// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'UDBoxes.pas' rev: 6.00

#ifndef UDBoxesHPP
#define UDBoxesHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <UCrpe32.hpp>	// Pascal unit
#include <Buttons.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Udboxes
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TCrpeBoxesDlg;
class PASCALIMPLEMENTATION TCrpeBoxesDlg : public Forms::TForm 
{
	typedef Forms::TForm inherited;
	
__published:
	Extctrls::TPanel* pnlBoxes;
	Stdctrls::TLabel* lblNumber;
	Stdctrls::TListBox* lbNumbers;
	Stdctrls::TLabel* lblCount;
	Stdctrls::TEdit* editCount;
	Stdctrls::TGroupBox* gbBorder;
	Stdctrls::TLabel* lblBorderStyle;
	Stdctrls::TComboBox* cbBorderStyle;
	Stdctrls::TLabel* lblBorderWidth;
	Stdctrls::TEdit* editBorderWidth;
	Stdctrls::TLabel* lblBorderColor;
	Stdctrls::TCheckBox* cbDropShadow;
	Stdctrls::TLabel* lblFillColor;
	Stdctrls::TCheckBox* cbCloseBorder;
	Stdctrls::TCheckBox* cbExtend;
	Stdctrls::TCheckBox* cbSuppress;
	Stdctrls::TGroupBox* gbCornerRounding;
	Stdctrls::TLabel* lblCornerRoundingHeight;
	Stdctrls::TLabel* lblCornerRoundingWidth;
	Stdctrls::TEdit* editCornerRoundingHeight;
	Stdctrls::TEdit* editCornerRoundingWidth;
	Stdctrls::TGroupBox* gbSizeAndPosition;
	Extctrls::TPanel* pnlSize;
	Stdctrls::TLabel* lblTop;
	Stdctrls::TLabel* lblLeft;
	Stdctrls::TLabel* lblBottom;
	Stdctrls::TLabel* lblRight;
	Stdctrls::TEdit* editTop;
	Stdctrls::TEdit* editLeft;
	Stdctrls::TEdit* editBottom;
	Stdctrls::TEdit* editRight;
	Extctrls::TRadioGroup* rgUnits;
	Stdctrls::TLabel* lblSectionStart;
	Stdctrls::TComboBox* cbSectionStart;
	Stdctrls::TLabel* lblSectionEnd;
	Stdctrls::TComboBox* cbSectionEnd;
	Stdctrls::TButton* btnOk;
	Stdctrls::TButton* btnClear;
	Extctrls::TColorBox* cbBorderColor;
	Extctrls::TColorBox* cbFillColor;
	void __fastcall btnClearClick(System::TObject* Sender);
	void __fastcall FormClose(System::TObject* Sender, Forms::TCloseAction &Action);
	void __fastcall FormShow(System::TObject* Sender);
	void __fastcall UpdateBoxes(void);
	void __fastcall FormCreate(System::TObject* Sender);
	void __fastcall editSizeEnter(System::TObject* Sender);
	void __fastcall editSizeExit(System::TObject* Sender);
	void __fastcall lbNumbersClick(System::TObject* Sender);
	void __fastcall cbBorderColorChange(System::TObject* Sender);
	void __fastcall cbFillColorChange(System::TObject* Sender);
	void __fastcall cbBorderStyleChange(System::TObject* Sender);
	void __fastcall editBorderWidthEnter(System::TObject* Sender);
	void __fastcall editBorderWidthExit(System::TObject* Sender);
	void __fastcall cbCloseBorderClick(System::TObject* Sender);
	void __fastcall cbExtendClick(System::TObject* Sender);
	void __fastcall cbSuppressClick(System::TObject* Sender);
	void __fastcall editCornerRoundingEnter(System::TObject* Sender);
	void __fastcall editCornerRoundingExit(System::TObject* Sender);
	void __fastcall cbSectionStartChange(System::TObject* Sender);
	void __fastcall cbSectionEndChange(System::TObject* Sender);
	void __fastcall btnOkClick(System::TObject* Sender);
	void __fastcall cbDropShadowClick(System::TObject* Sender);
	void __fastcall InitializeControls(bool OnOff);
	void __fastcall rgUnitsClick(System::TObject* Sender);
	
public:
	Ucrpe32::TCrpe* Cr;
	short BoxIndex;
	AnsiString PrevSize;
	Graphics::TColor CustomBorderColor;
	Graphics::TColor CustomFillColor;
public:
	#pragma option push -w-inl
	/* TCustomForm.Create */ inline __fastcall virtual TCrpeBoxesDlg(Classes::TComponent* AOwner) : Forms::TForm(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.CreateNew */ inline __fastcall virtual TCrpeBoxesDlg(Classes::TComponent* AOwner, int Dummy) : Forms::TForm(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TCrpeBoxesDlg(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TCrpeBoxesDlg(HWND ParentWindow) : Forms::TForm(ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TCrpeBoxesDlg* CrpeBoxesDlg;
extern PACKAGE bool bBoxes;

}	/* namespace Udboxes */
using namespace Udboxes;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// UDBoxes
