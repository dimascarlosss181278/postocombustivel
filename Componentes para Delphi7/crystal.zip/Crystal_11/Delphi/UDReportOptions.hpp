// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'UDReportOptions.pas' rev: 6.00

#ifndef UDReportOptionsHPP
#define UDReportOptionsHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <UCrpe32.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Udreportoptions
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TCrpeReportOptionsDlg;
class PASCALIMPLEMENTATION TCrpeReportOptionsDlg : public Forms::TForm 
{
	typedef Forms::TForm inherited;
	
__published:
	Stdctrls::TButton* btnOk;
	Stdctrls::TButton* btnCancel;
	Stdctrls::TButton* btnClear;
	Stdctrls::TGroupBox* gbROptions;
	Stdctrls::TLabel* lblConvertDateTimeType;
	Stdctrls::TLabel* lblZoomMode;
	Stdctrls::TComboBox* cbConvertDateTimeType;
	Stdctrls::TComboBox* cbZoomMode;
	Extctrls::TPanel* pnlROptions2;
	Stdctrls::TCheckBox* cbConvertNullFieldToDefault;
	Stdctrls::TCheckBox* cbSaveDataWithReport;
	Stdctrls::TCheckBox* cbSaveSummariesWithReport;
	Stdctrls::TCheckBox* cbUseIndexForSpeed;
	Stdctrls::TCheckBox* cbUseDummyData;
	Stdctrls::TCheckBox* cbCaseInsensitiveSQLData;
	Stdctrls::TCheckBox* cbCreateGroupTree;
	Stdctrls::TCheckBox* cbPerformGroupingOnServer;
	Stdctrls::TCheckBox* cbNoDataForHiddenObjects;
	Stdctrls::TCheckBox* cbVerifyOnEveryPrint;
	Stdctrls::TCheckBox* cbAsyncQuery;
	Stdctrls::TCheckBox* cbSelectDistinctRecords;
	Stdctrls::TLabel* lblPromptMode;
	Stdctrls::TComboBox* cbPromptMode;
	Stdctrls::TCheckBox* cbAlwaysSortLocally;
	Stdctrls::TCheckBox* cbCanSelectDistinctRecords;
	Stdctrls::TCheckBox* cbIsReadOnly;
	Stdctrls::TCheckBox* cbConvertOtherNullsToDefault;
	Stdctrls::TCheckBox* cbVerifyStoredProcOnRefresh;
	Stdctrls::TCheckBox* cbRetainImageColorDepth;
	Stdctrls::TCheckBox* cbPrintEngineErrorMessages;
	void __fastcall FormShow(System::TObject* Sender);
	void __fastcall FormClose(System::TObject* Sender, Forms::TCloseAction &Action);
	void __fastcall UpdateReportOptions(void);
	void __fastcall btnClearClick(System::TObject* Sender);
	void __fastcall btnOkClick(System::TObject* Sender);
	void __fastcall btnCancelClick(System::TObject* Sender);
	void __fastcall FormCreate(System::TObject* Sender);
	void __fastcall InitializeControls(bool OnOff);
	
public:
	Ucrpe32::TCrpe* Cr;
	short rConvertDateTimeType;
	short rZoomMode;
	short rPromptMode;
	bool rConvertNullFieldToDefault;
	bool rConvertOtherNullsToDefault;
	bool rAlwaysSortLocally;
	bool rCaseInsensitiveSQLData;
	bool rPerformGroupingOnServer;
	bool rUseIndexForSpeed;
	bool rVerifyOnEveryPrint;
	bool rVerifyStoredProcOnRefresh;
	bool rNoDataForHiddenObjects;
	bool rPrintEngineErrorMessages;
	bool rSaveDataWithReport;
	bool rSaveSummariesWithReport;
	bool rAsyncQuery;
	bool rCreateGroupTree;
	bool rIsReadOnly;
	bool rSelectDistinctRecords;
	bool rCanSelectDistinctRecords;
	bool rUseDummyData;
	bool rRetainImageColourDepth;
public:
	#pragma option push -w-inl
	/* TCustomForm.Create */ inline __fastcall virtual TCrpeReportOptionsDlg(Classes::TComponent* AOwner) : Forms::TForm(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.CreateNew */ inline __fastcall virtual TCrpeReportOptionsDlg(Classes::TComponent* AOwner, int Dummy) : Forms::TForm(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TCrpeReportOptionsDlg(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TCrpeReportOptionsDlg(HWND ParentWindow) : Forms::TForm(ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TCrpeReportOptionsDlg* CrpeReportOptionsDlg;
extern PACKAGE bool bReportOptions;

}	/* namespace Udreportoptions */
using namespace Udreportoptions;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// UDReportOptions
