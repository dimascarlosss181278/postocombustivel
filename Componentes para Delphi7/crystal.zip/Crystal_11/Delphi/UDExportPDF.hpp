// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'UDExportPDF.pas' rev: 6.00

#ifndef UDExportPDFHPP
#define UDExportPDFHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <UCrpe32.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Udexportpdf
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TCrpeAdobeAcrobatPDFDlg;
class PASCALIMPLEMENTATION TCrpeAdobeAcrobatPDFDlg : public Forms::TForm 
{
	typedef Forms::TForm inherited;
	
__published:
	Stdctrls::TButton* btnOk;
	Stdctrls::TButton* btnCancel;
	Extctrls::TPanel* pnlPDF;
	Extctrls::TPanel* pnlPageRange;
	Stdctrls::TCheckBox* cbUsePageRange;
	Stdctrls::TLabel* lblFirstPage;
	Stdctrls::TEdit* editFirstPage;
	Stdctrls::TLabel* lblLastPage;
	Stdctrls::TEdit* editLastPage;
	Stdctrls::TCheckBox* cbPrompt;
	void __fastcall FormCreate(System::TObject* Sender);
	void __fastcall FormShow(System::TObject* Sender);
	void __fastcall btnOkClick(System::TObject* Sender);
	void __fastcall btnCancelClick(System::TObject* Sender);
	void __fastcall FormClose(System::TObject* Sender, Forms::TCloseAction &Action);
	void __fastcall cbUsePageRangeClick(System::TObject* Sender);
	void __fastcall cbPromptClick(System::TObject* Sender);
	
public:
	Ucrpe32::TCrpe* Cr;
public:
	#pragma option push -w-inl
	/* TCustomForm.Create */ inline __fastcall virtual TCrpeAdobeAcrobatPDFDlg(Classes::TComponent* AOwner) : Forms::TForm(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.CreateNew */ inline __fastcall virtual TCrpeAdobeAcrobatPDFDlg(Classes::TComponent* AOwner, int Dummy) : Forms::TForm(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TCrpeAdobeAcrobatPDFDlg(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TCrpeAdobeAcrobatPDFDlg(HWND ParentWindow) : Forms::TForm(ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TCrpeAdobeAcrobatPDFDlg* CrpeAdobeAcrobatPDFDlg;

}	/* namespace Udexportpdf */
using namespace Udexportpdf;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// UDExportPDF
