// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'UCrpeDS.pas' rev: 6.00

#ifndef UCrpeDSHPP
#define UCrpeDSHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <UCrDataSource.hpp>	// Pascal unit
#include <DB.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Ucrpeds
{
//-- type declarations -------------------------------------------------------
typedef void __fastcall (__closure *TCrpeDSFieldCountEvent)(System::TObject* Sender, Db::TDataSet* DataSet, short &FieldCount);

typedef void __fastcall (__closure *TCrpeDSRecordCountEvent)(System::TObject* Sender, Db::TDataSet* DataSet, int &RecordCount);

typedef void __fastcall (__closure *TCrpeDSFieldNameEvent)(System::TObject* Sender, Db::TDataSet* DataSet, short FieldIndex, WideString &FieldName);

typedef void __fastcall (__closure *TCrpeDSFieldTypeEvent)(System::TObject* Sender, Db::TDataSet* DataSet, short FieldIndex, short &FieldType);

typedef void __fastcall (__closure *TCrpeDSBlobFieldValueEvent)(System::TObject* Sender, Db::TDataSet* DataSet, short FieldIndex, Classes::TMemoryStream* &BlobFieldValue);

typedef void __fastcall (__closure *TCrpeDSFieldValueEvent)(System::TObject* Sender, Db::TDataSet* DataSet, short FieldIndex, OleVariant &FieldValue);

typedef void __fastcall (__closure *TCrpeDSMoveFirstEvent)(System::TObject* Sender, Db::TDataSet* DataSet);

typedef void __fastcall (__closure *TCrpeDSMoveNextEvent)(System::TObject* Sender, Db::TDataSet* DataSet);

typedef void __fastcall (__closure *TCrpeDSGetBookmarkEvent)(System::TObject* Sender, Db::TDataSet* DataSet, OleVariant &Bookmark);

typedef void __fastcall (__closure *TCrpeDSSetBookmarkEvent)(System::TObject* Sender, Db::TDataSet* DataSet, OleVariant &Bookmark);

typedef void __fastcall (__closure *TCrpeDSGetEOFEvent)(System::TObject* Sender, Db::TDataSet* DataSet, bool &EndOfFile);

class DELPHICLASS TCrDataSource;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrDataSource : public System::TInterfacedObject 
{
	typedef System::TInterfacedObject inherited;
	
private:
	Classes::TComponent* FComponent;
	Db::TDataSet* FDataSet;
	TCrpeDSFieldCountEvent FOnFieldCount;
	TCrpeDSRecordCountEvent FOnRecordCount;
	TCrpeDSFieldNameEvent FOnFieldName;
	TCrpeDSFieldTypeEvent FOnFieldType;
	TCrpeDSBlobFieldValueEvent FOnBlobFieldValue;
	TCrpeDSFieldValueEvent FOnFieldValue;
	TCrpeDSMoveFirstEvent FOnMoveFirst;
	TCrpeDSMoveNextEvent FOnMoveNext;
	TCrpeDSGetBookmarkEvent FOnGetBookmark;
	TCrpeDSSetBookmarkEvent FOnSetBookmark;
	TCrpeDSGetEOFEvent FOnGetEOF;
	
public:
	HRESULT __stdcall Get_FieldCount(/* out */ short &pVal);
	HRESULT __stdcall Get_RecordCount(/* out */ int &pVal);
	HRESULT __stdcall Get_FieldName(short FieldIndex, /* out */ WideString &pVal);
	HRESULT __stdcall Get_FieldType(short FieldIndex, /* out */ short &pVal);
	HRESULT __stdcall Get_FieldValue(short FieldIndex, /* out */ OleVariant &pVal);
	HRESULT __stdcall MoveFirst(void);
	HRESULT __stdcall MoveNext(void);
	HRESULT __stdcall Get_Bookmark(/* out */ OleVariant &pVal);
	HRESULT __stdcall Set_Bookmark(const OleVariant pVal);
	HRESULT __stdcall Get_EOF(/* out */ Word &pVal);
	void __fastcall SetDataSet(Db::TDataSet* xDataSet);
public:
	#pragma option push -w-inl
	/* TObject.Create */ inline __fastcall TCrDataSource(void) : System::TInterfacedObject() { }
	#pragma option pop
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~TCrDataSource(void) { }
	#pragma option pop
	
private:
	void *__ICRDataSource;	/* Ucrdatasource::ICRDataSource */
	
public:
	operator ICRDataSource*(void) { return (ICRDataSource*)&__ICRDataSource; }
	
};

#pragma pack(pop)

typedef AnsiString TCrDSAbout;

class DELPHICLASS TCrpeDS;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeDS : public Classes::TComponent 
{
	typedef Classes::TComponent inherited;
	
private:
	TCrDataSource* FCrDataSource;
	Ucrdatasource::_di_ICRDataSource FInterface;
	AnsiString FAbout;
	TCrpeDSFieldCountEvent FOnFieldCount;
	TCrpeDSRecordCountEvent FOnRecordCount;
	TCrpeDSFieldNameEvent FOnFieldName;
	TCrpeDSFieldTypeEvent FOnFieldType;
	TCrpeDSBlobFieldValueEvent FOnBlobFieldValue;
	TCrpeDSFieldValueEvent FOnFieldValue;
	TCrpeDSMoveFirstEvent FOnMoveFirst;
	TCrpeDSMoveNextEvent FOnMoveNext;
	TCrpeDSGetBookmarkEvent FOnGetBookmark;
	TCrpeDSSetBookmarkEvent FOnSetBookmark;
	TCrpeDSGetEOFEvent FOnGetEOF;
	
protected:
	Db::TDataSet* __fastcall GetDataSet(void);
	void __fastcall SetDataSet(Db::TDataSet* xDataSet);
	
__published:
	__property AnsiString About = {read=FAbout, write=FAbout};
	__property Db::TDataSet* DataSet = {read=GetDataSet, write=SetDataSet};
	__property TCrpeDSFieldCountEvent OnGetFieldCount = {read=FOnFieldCount, write=FOnFieldCount};
	__property TCrpeDSRecordCountEvent OnGetRecordCount = {read=FOnRecordCount, write=FOnRecordCount};
	__property TCrpeDSFieldNameEvent OnGetFieldName = {read=FOnFieldName, write=FOnFieldName};
	__property TCrpeDSFieldTypeEvent OnGetFieldType = {read=FOnFieldType, write=FOnFieldType};
	__property TCrpeDSBlobFieldValueEvent OnGetBlobFieldValue = {read=FOnBlobFieldValue, write=FOnBlobFieldValue};
	__property TCrpeDSFieldValueEvent OnGetFieldValue = {read=FOnFieldValue, write=FOnFieldValue};
	__property TCrpeDSMoveFirstEvent OnMoveFirst = {read=FOnMoveFirst, write=FOnMoveFirst};
	__property TCrpeDSMoveNextEvent OnMoveNext = {read=FOnMoveNext, write=FOnMoveNext};
	__property TCrpeDSGetBookmarkEvent OnGetBookmark = {read=FOnGetBookmark, write=FOnGetBookmark};
	__property TCrpeDSSetBookmarkEvent OnSetBookmark = {read=FOnSetBookmark, write=FOnSetBookmark};
	__property TCrpeDSGetEOFEvent OnEOF = {read=FOnGetEOF, write=FOnGetEOF};
	
public:
	void * __fastcall DataPointer(void);
	__fastcall virtual TCrpeDS(Classes::TComponent* AOwner);
	__fastcall virtual ~TCrpeDS(void);
};

#pragma pack(pop)

//-- var, const, procedure ---------------------------------------------------

}	/* namespace Ucrpeds */
using namespace Ucrpeds;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// UCrpeDS
