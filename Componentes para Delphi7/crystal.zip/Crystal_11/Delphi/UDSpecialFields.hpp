// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'UDSpecialFields.pas' rev: 6.00

#ifndef UDSpecialFieldsHPP
#define UDSpecialFieldsHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <UCrpe32.hpp>	// Pascal unit
#include <Buttons.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Udspecialfields
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TCrpeSpecialFieldsDlg;
class PASCALIMPLEMENTATION TCrpeSpecialFieldsDlg : public Forms::TForm 
{
	typedef Forms::TForm inherited;
	
__published:
	Extctrls::TPanel* pnlSpecialFields;
	Stdctrls::TLabel* lblNames;
	Stdctrls::TListBox* lbNumbers;
	Stdctrls::TButton* btnOk;
	Stdctrls::TButton* btnClear;
	Dialogs::TFontDialog* FontDialog1;
	Stdctrls::TLabel* lblFieldName;
	Stdctrls::TLabel* lblFieldType;
	Stdctrls::TLabel* lblFieldLength;
	Stdctrls::TLabel* lblTop;
	Stdctrls::TLabel* lblLeft;
	Stdctrls::TLabel* lblSection;
	Stdctrls::TLabel* lblWidth;
	Stdctrls::TLabel* lblHeight;
	Stdctrls::TEdit* editFieldName;
	Stdctrls::TEdit* editFieldType;
	Stdctrls::TEdit* editFieldLength;
	Stdctrls::TButton* btnBorder;
	Stdctrls::TButton* btnFont;
	Stdctrls::TButton* btnFormat;
	Stdctrls::TEdit* editTop;
	Stdctrls::TEdit* editLeft;
	Stdctrls::TEdit* editWidth;
	Stdctrls::TEdit* editHeight;
	Stdctrls::TComboBox* cbSection;
	Stdctrls::TLabel* lblCount;
	Stdctrls::TEdit* editCount;
	Stdctrls::TButton* btnHiliteConditions;
	Extctrls::TRadioGroup* rgUnits;
	void __fastcall btnClearClick(System::TObject* Sender);
	void __fastcall lbNumbersClick(System::TObject* Sender);
	void __fastcall FormClose(System::TObject* Sender, Forms::TCloseAction &Action);
	void __fastcall FormShow(System::TObject* Sender);
	void __fastcall UpdateSpecialFields(void);
	void __fastcall btnOkClick(System::TObject* Sender);
	void __fastcall FormCreate(System::TObject* Sender);
	void __fastcall btnFontClick(System::TObject* Sender);
	void __fastcall editSizeEnter(System::TObject* Sender);
	void __fastcall editSizeExit(System::TObject* Sender);
	void __fastcall cbSectionChange(System::TObject* Sender);
	void __fastcall btnBorderClick(System::TObject* Sender);
	void __fastcall btnFormatClick(System::TObject* Sender);
	void __fastcall btnHiliteConditionsClick(System::TObject* Sender);
	void __fastcall rgUnitsClick(System::TObject* Sender);
	void __fastcall InitializeControls(bool OnOff);
	
public:
	Ucrpe32::TCrpe* Cr;
	short SFIndex;
	AnsiString PrevSize;
public:
	#pragma option push -w-inl
	/* TCustomForm.Create */ inline __fastcall virtual TCrpeSpecialFieldsDlg(Classes::TComponent* AOwner) : Forms::TForm(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.CreateNew */ inline __fastcall virtual TCrpeSpecialFieldsDlg(Classes::TComponent* AOwner, int Dummy) : Forms::TForm(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TCrpeSpecialFieldsDlg(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TCrpeSpecialFieldsDlg(HWND ParentWindow) : Forms::TForm(ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TCrpeSpecialFieldsDlg* CrpeSpecialFieldsDlg;
extern PACKAGE bool bSpecialFields;

}	/* namespace Udspecialfields */
using namespace Udspecialfields;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// UDSpecialFields
