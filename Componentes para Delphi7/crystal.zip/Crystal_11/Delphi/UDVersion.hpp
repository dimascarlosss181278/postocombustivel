// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'UDVersion.pas' rev: 6.00

#ifndef UDVersionHPP
#define UDVersionHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <ComCtrls.hpp>	// Pascal unit
#include <UCrpe32.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Udversion
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TCrpeVersionDlg;
class PASCALIMPLEMENTATION TCrpeVersionDlg : public Forms::TForm 
{
	typedef Forms::TForm inherited;
	
__published:
	Stdctrls::TButton* btnOk;
	Extctrls::TPanel* pnlVersion;
	Stdctrls::TGroupBox* gbCrpe;
	Stdctrls::TLabel* lblDLL;
	Stdctrls::TLabel* lblEngine;
	Stdctrls::TLabel* lblFileVersion;
	Stdctrls::TLabel* lblMajor;
	Stdctrls::TLabel* lblMid;
	Stdctrls::TLabel* lblMinor;
	Stdctrls::TEdit* editDLL;
	Stdctrls::TEdit* editEngine;
	Stdctrls::TEdit* editFileVersion;
	Stdctrls::TEdit* editMajor;
	Stdctrls::TEdit* editMinor;
	Stdctrls::TEdit* editRelease;
	Stdctrls::TGroupBox* gbReport;
	Stdctrls::TLabel* lblRMajor;
	Stdctrls::TLabel* lblRMinor;
	Stdctrls::TLabel* lblLetter;
	Stdctrls::TEdit* editRMajor;
	Stdctrls::TEdit* editRMinor;
	Stdctrls::TEdit* editLetter;
	Stdctrls::TGroupBox* gbWindows;
	Stdctrls::TLabel* lblPlatform;
	Stdctrls::TLabel* lblWMajor;
	Stdctrls::TLabel* lblWMinor;
	Stdctrls::TLabel* lblWBuild;
	Stdctrls::TEdit* editPlatform;
	Stdctrls::TEdit* editWMajor;
	Stdctrls::TEdit* editWMinor;
	Stdctrls::TEdit* editWBuild;
	Stdctrls::TLabel* lblBuild;
	Stdctrls::TEdit* editBuild;
	void __fastcall FormClose(System::TObject* Sender, Forms::TCloseAction &Action);
	void __fastcall FormShow(System::TObject* Sender);
	void __fastcall btnOkClick(System::TObject* Sender);
	void __fastcall FormCreate(System::TObject* Sender);
	void __fastcall InitializeControls(bool OnOff);
	void __fastcall UpdateVersion(void);
	
public:
	Ucrpe32::TCrpe* Cr;
public:
	#pragma option push -w-inl
	/* TCustomForm.Create */ inline __fastcall virtual TCrpeVersionDlg(Classes::TComponent* AOwner) : Forms::TForm(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.CreateNew */ inline __fastcall virtual TCrpeVersionDlg(Classes::TComponent* AOwner, int Dummy) : Forms::TForm(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TCrpeVersionDlg(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TCrpeVersionDlg(HWND ParentWindow) : Forms::TForm(ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TCrpeVersionDlg* CrpeVersionDlg;
extern PACKAGE bool bVersion;

}	/* namespace Udversion */
using namespace Udversion;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// UDVersion
