// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'UDExportOptions.pas' rev: 6.00

#ifndef UDExportOptionsHPP
#define UDExportOptionsHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <UCrpe32.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <ComCtrls.hpp>	// Pascal unit
#include <Buttons.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Udexportoptions
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TCrpeExportOptionsDlg;
class PASCALIMPLEMENTATION TCrpeExportOptionsDlg : public Forms::TForm 
{
	typedef Forms::TForm inherited;
	
__published:
	Extctrls::TPanel* pnlExport;
	Extctrls::TPanel* pnlDestination;
	Stdctrls::TCheckBox* cbKeepOpen;
	Buttons::TBitBtn* btnExport;
	Dialogs::TSaveDialog* SaveDialog1;
	Extctrls::TPanel* pnlDestinations;
	Comctrls::TPageControl* pcDestination;
	Comctrls::TTabSheet* tsToFile;
	Comctrls::TTabSheet* tsToEmailViaMapi;
	Comctrls::TTabSheet* tsToEmailViaVim;
	Comctrls::TTabSheet* tsToMsExchange;
	Comctrls::TTabSheet* tsToLotusNotes;
	Comctrls::TTabSheet* tsToApplication;
	Extctrls::TPanel* pnlFile;
	Stdctrls::TLabel* lblFileName;
	Stdctrls::TEdit* editFileName;
	Stdctrls::TButton* btnEdit;
	Extctrls::TPanel* pnlApplication;
	Stdctrls::TLabel* lblAFileName;
	Stdctrls::TLabel* lblAppName;
	Stdctrls::TEdit* editAFileName;
	Stdctrls::TButton* btnAFileName;
	Stdctrls::TEdit* editAppName;
	Stdctrls::TButton* btnApplication;
	Extctrls::TPanel* pnlExchange;
	Stdctrls::TLabel* lblProfile;
	Stdctrls::TLabel* lblExchangePassword;
	Stdctrls::TLabel* lblFolder;
	Stdctrls::TEdit* editProfile;
	Stdctrls::TEdit* editFolder;
	Stdctrls::TEdit* editExchangePassword;
	Extctrls::TPanel* pnlMapi;
	Stdctrls::TLabel* lblSubject;
	Stdctrls::TLabel* lblMessage;
	Stdctrls::TLabel* lblCCList;
	Stdctrls::TLabel* lblToList;
	Stdctrls::TEdit* editToList;
	Stdctrls::TEdit* editCCList;
	Stdctrls::TEdit* editSubject;
	Stdctrls::TMemo* memoMessage;
	Extctrls::TPanel* pnlEmailVim;
	Stdctrls::TLabel* lblVimSubject;
	Stdctrls::TLabel* lblVimMessage;
	Stdctrls::TLabel* lblVimTo;
	Stdctrls::TLabel* lblVimCC;
	Stdctrls::TLabel* lblVimBcc;
	Stdctrls::TEdit* editVimTo;
	Stdctrls::TEdit* editVimCC;
	Stdctrls::TEdit* editVimSubject;
	Stdctrls::TMemo* memoVimMessage;
	Stdctrls::TEdit* editVimBcc;
	Extctrls::TPanel* pnlLotusNotes;
	Stdctrls::TLabel* lblDBName;
	Stdctrls::TLabel* lblComments;
	Stdctrls::TLabel* lblFormName;
	Stdctrls::TEdit* editDBName;
	Stdctrls::TEdit* editFormName;
	Stdctrls::TEdit* editComments;
	Stdctrls::TButton* btnClear;
	Stdctrls::TButton* btnCancel;
	Stdctrls::TButton* btnOk;
	Extctrls::TRadioGroup* rgDestination;
	Extctrls::TRadioGroup* rgFileType;
	Stdctrls::TButton* btnOptions;
	Stdctrls::TCheckBox* cbPromptForOptions;
	Stdctrls::TCheckBox* cbPromptOnOverwrite;
	Stdctrls::TCheckBox* cbProgressDialog;
	Stdctrls::TEdit* editUserName;
	Stdctrls::TLabel* lblUserName;
	Stdctrls::TEdit* editPassword;
	Stdctrls::TLabel* lblPassword;
	void __fastcall FormShow(System::TObject* Sender);
	void __fastcall FormClose(System::TObject* Sender, Forms::TCloseAction &Action);
	void __fastcall btnExportClick(System::TObject* Sender);
	void __fastcall editFileNameDblClick(System::TObject* Sender);
	void __fastcall cbPromptForOptionsClick(System::TObject* Sender);
	void __fastcall rgDestinationClick(System::TObject* Sender);
	void __fastcall cbKeepOpenClick(System::TObject* Sender);
	void __fastcall cbProgressDialogClick(System::TObject* Sender);
	void __fastcall editFileNameChange(System::TObject* Sender);
	void __fastcall editProfileChange(System::TObject* Sender);
	void __fastcall editFolderChange(System::TObject* Sender);
	void __fastcall editExchangePasswordChange(System::TObject* Sender);
	void __fastcall editToListChange(System::TObject* Sender);
	void __fastcall editCCListChange(System::TObject* Sender);
	void __fastcall editSubjectChange(System::TObject* Sender);
	void __fastcall memoMessageChange(System::TObject* Sender);
	void __fastcall editToListVChange(System::TObject* Sender);
	void __fastcall editCCListVChange(System::TObject* Sender);
	void __fastcall editBCCListVChange(System::TObject* Sender);
	void __fastcall editSubjectVChange(System::TObject* Sender);
	void __fastcall memoMessageVChange(System::TObject* Sender);
	void __fastcall cbPromptOnOverwriteClick(System::TObject* Sender);
	void __fastcall editAFileNameChange(System::TObject* Sender);
	void __fastcall editAFileNameDblClick(System::TObject* Sender);
	void __fastcall editAppNameChange(System::TObject* Sender);
	void __fastcall editAppNameDblClick(System::TObject* Sender);
	void __fastcall pcDestinationChange(System::TObject* Sender);
	void __fastcall btnCancelClick(System::TObject* Sender);
	void __fastcall btnOkClick(System::TObject* Sender);
	void __fastcall FormCreate(System::TObject* Sender);
	void __fastcall rgFileTypeClick(System::TObject* Sender);
	void __fastcall btnOptionsClick(System::TObject* Sender);
	void __fastcall editUserNameChange(System::TObject* Sender);
	void __fastcall editPasswordChange(System::TObject* Sender);
	
private:
	AnsiString ExportPath;
	AnsiString rAppName;
	AnsiString rFileName;
	int rFileType;
	int rDestination;
	bool rPromptForOptions;
	bool rPromptOnOverwrite;
	AnsiString rToList;
	AnsiString rCCList;
	AnsiString rMessage;
	AnsiString rSubject;
	AnsiString rPassword;
	AnsiString rUserName;
	AnsiString rBCCList;
	AnsiString rArea;
	bool rChopPageHeader;
	int rColumnWidth;
	double rConstant;
	bool rConvertDatesToStrings;
	bool rCreatePageBreaks;
	bool rExportHeaderFooter;
	Word rExcelFirstPage;
	Word rExcelLastPage;
	bool rExcelUsePageRange;
	bool rWorksheetFunctions;
	int rXLSType;
	AnsiString rFolder;
	AnsiString rExchPassword;
	AnsiString rProfile;
	Word rHTMLFirstPage;
	Word rHTMLLastPage;
	bool rPageNavigator;
	bool rSeparatePages;
	bool rHTMLUsePageRange;
	AnsiString rDBName;
	AnsiString rFormName;
	AnsiString rComments;
	bool rODBCPrompt;
	AnsiString rODBCPassword;
	AnsiString rODBCSource;
	AnsiString rODBCTable;
	AnsiString rODBCUser;
	bool rPDFUsePageRange;
	Word rPDFFirstPage;
	Word rPDFLastPage;
	bool rPDFPrompt;
	bool rRTFUsePageRange;
	Word rRTFFirstPage;
	Word rRTFLastPage;
	bool rRTFPrompt;
	bool rUseRptNumberFmt;
	bool rUseRptDateFmt;
	char rStringDelimiter;
	AnsiString rFieldSeparator;
	Word rLinesPerPage;
	Word rCharPerInch;
	int rRecordsType;
	Word rWordFirstPage;
	Word rWordLastPage;
	bool rWordPrompt;
	bool rWordUsePageRange;
	bool rXMLPrompt;
	bool rXMLSeparatePages;
	
public:
	Ucrpe32::TCrpe* Cr;
public:
	#pragma option push -w-inl
	/* TCustomForm.Create */ inline __fastcall virtual TCrpeExportOptionsDlg(Classes::TComponent* AOwner) : Forms::TForm(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.CreateNew */ inline __fastcall virtual TCrpeExportOptionsDlg(Classes::TComponent* AOwner, int Dummy) : Forms::TForm(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TCrpeExportOptionsDlg(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TCrpeExportOptionsDlg(HWND ParentWindow) : Forms::TForm(ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TCrpeExportOptionsDlg* CrpeExportOptionsDlg;
extern PACKAGE bool bExportOptions;

}	/* namespace Udexportoptions */
using namespace Udexportoptions;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// UDExportOptions
