// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'UDCrossTabGroups.pas' rev: 6.00

#ifndef UDCrossTabGroupsHPP
#define UDCrossTabGroupsHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <UCrpe32.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Udcrosstabgroups
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TCrpeCrossTabGroupsDlg;
class PASCALIMPLEMENTATION TCrpeCrossTabGroupsDlg : public Forms::TForm 
{
	typedef Forms::TForm inherited;
	
__published:
	Extctrls::TPanel* pnlCrossTabGroups;
	Stdctrls::TEdit* editFieldName;
	Stdctrls::TLabel* lblFieldName;
	Stdctrls::TLabel* lblGOCondition;
	Stdctrls::TComboBox* cbCondition;
	Stdctrls::TLabel* lblGODirection;
	Stdctrls::TComboBox* cbDirection;
	Stdctrls::TCheckBox* cbSuppressSubtotal;
	Stdctrls::TCheckBox* cbSuppressLabel;
	Stdctrls::TLabel* lblBackgroundColor;
	Stdctrls::TComboBox* cbBackgroundColor;
	Stdctrls::TButton* btnOk;
	Stdctrls::TLabel* lblNumber;
	Stdctrls::TListBox* lbNumbers;
	Stdctrls::TLabel* lblCount;
	Stdctrls::TEdit* editCount;
	Dialogs::TColorDialog* ColorDialog1;
	void __fastcall FormCreate(System::TObject* Sender);
	void __fastcall editFieldNameChange(System::TObject* Sender);
	void __fastcall btnOkClick(System::TObject* Sender);
	void __fastcall UpdateCrossTabGroups(void);
	void __fastcall InitializeControls(bool OnOff);
	void __fastcall lbNumbersClick(System::TObject* Sender);
	void __fastcall cbConditionChange(System::TObject* Sender);
	void __fastcall cbDirectionChange(System::TObject* Sender);
	void __fastcall cbBackgroundColorChange(System::TObject* Sender);
	void __fastcall cbSuppressSubtotalClick(System::TObject* Sender);
	void __fastcall cbSuppressLabelClick(System::TObject* Sender);
	void __fastcall btnClearClick(System::TObject* Sender);
	void __fastcall FormClose(System::TObject* Sender, Forms::TCloseAction &Action);
	void __fastcall FormShow(System::TObject* Sender);
	void __fastcall cbBackgroundColorDrawItem(Controls::TWinControl* Control, int Index, const Types::TRect &Rect, Windows::TOwnerDrawState State);
	
public:
	Ucrpe32::TCrpeCrossTabGroups* Crg;
	int CIndex;
	Graphics::TColor CustomBGColor;
public:
	#pragma option push -w-inl
	/* TCustomForm.Create */ inline __fastcall virtual TCrpeCrossTabGroupsDlg(Classes::TComponent* AOwner) : Forms::TForm(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.CreateNew */ inline __fastcall virtual TCrpeCrossTabGroupsDlg(Classes::TComponent* AOwner, int Dummy) : Forms::TForm(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TCrpeCrossTabGroupsDlg(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TCrpeCrossTabGroupsDlg(HWND ParentWindow) : Forms::TForm(ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TCrpeCrossTabGroupsDlg* CrpeCrossTabGroupsDlg;
extern PACKAGE bool bCrossTabGroups;

}	/* namespace Udcrosstabgroups */
using namespace Udcrosstabgroups;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// UDCrossTabGroups
