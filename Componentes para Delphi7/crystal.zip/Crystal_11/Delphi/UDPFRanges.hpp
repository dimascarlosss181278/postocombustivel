// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'UDPFRanges.pas' rev: 6.00

#ifndef UDPFRangesHPP
#define UDPFRangesHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <UCrpe32.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <Buttons.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Udpfranges
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TCrpeParamFieldRangesDlg;
class PASCALIMPLEMENTATION TCrpeParamFieldRangesDlg : public Forms::TForm 
{
	typedef Forms::TForm inherited;
	
__published:
	Stdctrls::TButton* btnOk;
	Extctrls::TPanel* pnlPFValues;
	Stdctrls::TLabel* lblRangeStart;
	Stdctrls::TLabel* lblRangeEnd;
	Stdctrls::TEdit* editRangeStart;
	Stdctrls::TEdit* editRangeEnd;
	Stdctrls::TLabel* lblBounds;
	Stdctrls::TComboBox* cbBounds;
	Stdctrls::TListBox* lbNumbers;
	Stdctrls::TLabel* lblNumber;
	Stdctrls::TButton* btnClear;
	Stdctrls::TButton* btnAdd;
	Stdctrls::TButton* btnDelete;
	Stdctrls::TLabel* lblCount;
	Stdctrls::TEdit* editCount;
	void __fastcall FormShow(System::TObject* Sender);
	void __fastcall FormClose(System::TObject* Sender, Forms::TCloseAction &Action);
	void __fastcall UpdateRanges(void);
	void __fastcall lbNumbersClick(System::TObject* Sender);
	void __fastcall cbBoundsChange(System::TObject* Sender);
	void __fastcall btnAddClick(System::TObject* Sender);
	void __fastcall btnDeleteClick(System::TObject* Sender);
	void __fastcall btnClearClick(System::TObject* Sender);
	void __fastcall FormCreate(System::TObject* Sender);
	void __fastcall btnOkClick(System::TObject* Sender);
	void __fastcall InitializeControls(bool OnOff);
	void __fastcall editRangeStartEnter(System::TObject* Sender);
	void __fastcall editRangeStartExit(System::TObject* Sender);
	void __fastcall editRangeEndEnter(System::TObject* Sender);
	void __fastcall editRangeEndExit(System::TObject* Sender);
	
public:
	Ucrpe32::TCrpeParamFieldRanges* Crr;
	int RIndex;
	AnsiString PrevVal;
public:
	#pragma option push -w-inl
	/* TCustomForm.Create */ inline __fastcall virtual TCrpeParamFieldRangesDlg(Classes::TComponent* AOwner) : Forms::TForm(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.CreateNew */ inline __fastcall virtual TCrpeParamFieldRangesDlg(Classes::TComponent* AOwner, int Dummy) : Forms::TForm(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TCrpeParamFieldRangesDlg(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TCrpeParamFieldRangesDlg(HWND ParentWindow) : Forms::TForm(ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TCrpeParamFieldRangesDlg* CrpeParamFieldRangesDlg;

}	/* namespace Udpfranges */
using namespace Udpfranges;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// UDPFRanges
