// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'UCrDataSource.pas' rev: 6.00

#ifndef UCrDataSourceHPP
#define UCrDataSourceHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <StdVCL.hpp>	// Pascal unit
#include <OleCtrls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <ActiveX.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Ucrdatasource
{
//-- type declarations -------------------------------------------------------
__interface ICRDataSource;
typedef System::DelphiInterface<ICRDataSource> _di_ICRDataSource;
typedef ICRDataSource CRDataSource;
;

__interface INTERFACE_UUID("{F4ED51D0-E0D5-11D1-92B3-00A0C92765B4}") ICRDataSource  : public IInterface 
{
	
public:
	virtual HRESULT __stdcall Get_FieldCount(/* out */ short &pVal) = 0 ;
	virtual HRESULT __stdcall Get_RecordCount(/* out */ int &pVal) = 0 ;
	virtual HRESULT __stdcall Get_FieldName(short FieldIndex, /* out */ WideString &pVal) = 0 ;
	virtual HRESULT __stdcall Get_FieldType(short FieldIndex, /* out */ short &pVal) = 0 ;
	virtual HRESULT __stdcall Get_FieldValue(short FieldIndex, /* out */ OleVariant &pVal) = 0 ;
	virtual HRESULT __stdcall MoveFirst(void) = 0 ;
	virtual HRESULT __stdcall MoveNext(void) = 0 ;
	virtual HRESULT __stdcall Get_Bookmark(/* out */ OleVariant &pVal) = 0 ;
	virtual HRESULT __stdcall Set_Bookmark(const OleVariant pVal) = 0 ;
	virtual HRESULT __stdcall Get_EOF(/* out */ Word &pVal) = 0 ;
};

class DELPHICLASS CoCRDataSource;
class PASCALIMPLEMENTATION CoCRDataSource : public System::TObject 
{
	typedef System::TObject inherited;
	
public:
	/*         class method */ static _di_ICRDataSource __fastcall Create(TMetaClass* vmt);
	/*         class method */ static _di_ICRDataSource __fastcall CreateRemote(TMetaClass* vmt, const AnsiString MachineName);
public:
	#pragma option push -w-inl
	/* TObject.Create */ inline __fastcall CoCRDataSource(void) : System::TObject() { }
	#pragma option pop
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~CoCRDataSource(void) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE GUID LIBID_CRDataSourceLib;
extern PACKAGE GUID IID_ICRDataSource;
extern PACKAGE GUID CLASS_CRDataSource;

}	/* namespace Ucrdatasource */
using namespace Ucrdatasource;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// UCrDataSource
