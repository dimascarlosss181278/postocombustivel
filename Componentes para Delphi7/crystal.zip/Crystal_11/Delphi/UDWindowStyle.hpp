// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'UDWindowStyle.pas' rev: 6.00

#ifndef UDWindowStyleHPP
#define UDWindowStyleHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <UCrpe32.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Udwindowstyle
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TCrpeWindowStyleDlg;
class PASCALIMPLEMENTATION TCrpeWindowStyleDlg : public Forms::TForm 
{
	typedef Forms::TForm inherited;
	
__published:
	Extctrls::TPanel* pnlWindowStyle;
	Stdctrls::TLabel* lblWindowTitle;
	Stdctrls::TCheckBox* cbSystemMenu;
	Stdctrls::TCheckBox* cbMinButton;
	Stdctrls::TCheckBox* cbMaxButton;
	Extctrls::TRadioGroup* rgBorderStyle;
	Stdctrls::TEdit* editTitle;
	Stdctrls::TCheckBox* cbDisabled;
	Stdctrls::TButton* btnOk;
	Stdctrls::TButton* btnCancel;
	Stdctrls::TButton* btnClear;
	void __fastcall FormShow(System::TObject* Sender);
	void __fastcall UpdateWindowStyle(void);
	void __fastcall FormClose(System::TObject* Sender, Forms::TCloseAction &Action);
	void __fastcall btnClearClick(System::TObject* Sender);
	void __fastcall cbSystemMenuClick(System::TObject* Sender);
	void __fastcall cbMinButtonClick(System::TObject* Sender);
	void __fastcall cbMaxButtonClick(System::TObject* Sender);
	void __fastcall cbDisabledClick(System::TObject* Sender);
	void __fastcall editTitleChange(System::TObject* Sender);
	void __fastcall rgBorderStyleClick(System::TObject* Sender);
	void __fastcall FormCreate(System::TObject* Sender);
	void __fastcall btnOkClick(System::TObject* Sender);
	void __fastcall btnCancelClick(System::TObject* Sender);
	void __fastcall InitializeControls(bool OnOff);
	
public:
	Ucrpe32::TCrpe* Cr;
	bool rSystemMenu;
	bool rMinButton;
	bool rMaxButton;
	short rBorderStyle;
	bool rDisabled;
	AnsiString rTitle;
public:
	#pragma option push -w-inl
	/* TCustomForm.Create */ inline __fastcall virtual TCrpeWindowStyleDlg(Classes::TComponent* AOwner) : Forms::TForm(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.CreateNew */ inline __fastcall virtual TCrpeWindowStyleDlg(Classes::TComponent* AOwner, int Dummy) : Forms::TForm(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TCrpeWindowStyleDlg(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TCrpeWindowStyleDlg(HWND ParentWindow) : Forms::TForm(ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TCrpeWindowStyleDlg* CrpeWindowStyleDlg;
extern PACKAGE bool bWindowStyle;

}	/* namespace Udwindowstyle */
using namespace Udwindowstyle;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// UDWindowStyle
