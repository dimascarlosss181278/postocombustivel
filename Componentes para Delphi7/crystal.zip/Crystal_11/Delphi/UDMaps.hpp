// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'UDMaps.pas' rev: 6.00

#ifndef UDMapsHPP
#define UDMapsHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <UCrpe32.hpp>	// Pascal unit
#include <ComCtrls.hpp>	// Pascal unit
#include <Buttons.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Udmaps
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TCrpeMapsDlg;
class PASCALIMPLEMENTATION TCrpeMapsDlg : public Forms::TForm 
{
	typedef Forms::TForm inherited;
	
__published:
	Extctrls::TPanel* pnlMaps;
	Stdctrls::TLabel* lblNumber;
	Stdctrls::TListBox* lbNumbers;
	Stdctrls::TEdit* editCount;
	Stdctrls::TLabel* lblCount;
	Stdctrls::TGroupBox* GroupBox1;
	Stdctrls::TButton* btnBorder;
	Stdctrls::TButton* btnFormat;
	Stdctrls::TEdit* editTop;
	Stdctrls::TLabel* lblTop;
	Stdctrls::TLabel* lblLeft;
	Stdctrls::TEdit* editLeft;
	Stdctrls::TLabel* lblSection;
	Stdctrls::TEdit* editWidth;
	Stdctrls::TLabel* lblWidth;
	Stdctrls::TLabel* lblHeight;
	Stdctrls::TEdit* editHeight;
	Stdctrls::TComboBox* cbSection;
	Stdctrls::TButton* btnOk;
	Stdctrls::TButton* btnClear;
	Comctrls::TPageControl* pcMaps;
	Comctrls::TTabSheet* tsLayout;
	Comctrls::TTabSheet* tsType;
	Comctrls::TTabSheet* tsText;
	Stdctrls::TEdit* editTitle;
	Stdctrls::TLabel* lblTitle;
	Buttons::TSpeedButton* sbDetail;
	Buttons::TSpeedButton* sbGroup;
	Buttons::TSpeedButton* sbCrossTab;
	Buttons::TSpeedButton* sbOlap;
	Stdctrls::TCheckBox* cbDontSummarizeValues;
	Stdctrls::TLabel* lblDetail;
	Stdctrls::TLabel* lblGroup;
	Stdctrls::TLabel* lblCrossTab;
	Stdctrls::TLabel* lblOlap;
	Buttons::TSpeedButton* sbRanged;
	Buttons::TSpeedButton* sbBarChart;
	Buttons::TSpeedButton* sbPieChart;
	Buttons::TSpeedButton* sbGraduated;
	Stdctrls::TLabel* lblRanged;
	Stdctrls::TLabel* lblBarChart;
	Stdctrls::TLabel* lblPieChart;
	Stdctrls::TLabel* lblGraduated;
	Buttons::TSpeedButton* sbDotDensity;
	Buttons::TSpeedButton* sbIndividualValue;
	Stdctrls::TLabel* lblDotDensity;
	Stdctrls::TLabel* lblIndividualValue;
	Stdctrls::TGroupBox* gbRanged;
	Stdctrls::TLabel* lblNumberOfIntervals;
	Stdctrls::TEdit* editNumberOfIntervals;
	Stdctrls::TLabel* lblDistributionMethod;
	Stdctrls::TComboBox* cbDistributionMethod;
	Stdctrls::TLabel* lblColorHighestInterval;
	Stdctrls::TLabel* lblColorLowestInterval;
	Stdctrls::TCheckBox* cbAllowEmptyIntervals;
	Stdctrls::TGroupBox* gbLegend;
	Stdctrls::TGroupBox* gbLegendTitle;
	Stdctrls::TLabel* lblLegendTitle;
	Stdctrls::TLabel* lblLegendSubTitle;
	Stdctrls::TRadioButton* rbAuto;
	Stdctrls::TRadioButton* rbSpecific;
	Stdctrls::TEdit* editLegendTitle;
	Stdctrls::TEdit* editLegendSubTitle;
	Stdctrls::TRadioButton* rbFull;
	Stdctrls::TRadioButton* rbCompact;
	Stdctrls::TRadioButton* rbNone;
	Stdctrls::TGroupBox* gbPieChart;
	Stdctrls::TCheckBox* cbPieProportional;
	Stdctrls::TGroupBox* gbDotDensity;
	Stdctrls::TLabel* lblDotSize;
	Stdctrls::TEdit* editDotSize;
	Stdctrls::TLabel* lblPieSize;
	Stdctrls::TEdit* editPieSize;
	Extctrls::TRadioGroup* rgUnits;
	Dialogs::TColorDialog* ColorDialog1;
	Stdctrls::TGroupBox* gbBarChart;
	Stdctrls::TLabel* lblBarSize;
	Stdctrls::TEdit* editBarSize;
	Stdctrls::TGroupBox* gbConditions;
	Stdctrls::TComboBox* cbOrientation;
	Stdctrls::TLabel* lblOrientation;
	Stdctrls::TCheckBox* cbGroupSelected;
	Stdctrls::TButton* btnSummaryFields;
	Stdctrls::TButton* btnConditionFields;
	Extctrls::TColorBox* cbColorHighestInterval;
	Extctrls::TColorBox* cbColorLowestInterval;
	void __fastcall btnClearClick(System::TObject* Sender);
	void __fastcall lbNumbersClick(System::TObject* Sender);
	void __fastcall FormClose(System::TObject* Sender, Forms::TCloseAction &Action);
	void __fastcall FormShow(System::TObject* Sender);
	void __fastcall UpdateMaps(void);
	void __fastcall btnOkClick(System::TObject* Sender);
	void __fastcall FormCreate(System::TObject* Sender);
	void __fastcall editSizeEnter(System::TObject* Sender);
	void __fastcall editSizeExit(System::TObject* Sender);
	void __fastcall cbSectionChange(System::TObject* Sender);
	void __fastcall btnBorderClick(System::TObject* Sender);
	void __fastcall InitializeControls(bool OnOff);
	void __fastcall rbFullClick(System::TObject* Sender);
	void __fastcall rbCompactClick(System::TObject* Sender);
	void __fastcall rbNoneClick(System::TObject* Sender);
	void __fastcall rgUnitsClick(System::TObject* Sender);
	void __fastcall cbColorHighestIntervalChange(System::TObject* Sender);
	void __fastcall rbAutoClick(System::TObject* Sender);
	void __fastcall rbSpecificClick(System::TObject* Sender);
	void __fastcall editLegendTitleChange(System::TObject* Sender);
	void __fastcall editLegendSubTitleChange(System::TObject* Sender);
	void __fastcall editTitleChange(System::TObject* Sender);
	void __fastcall sbRangedClick(System::TObject* Sender);
	void __fastcall sbDotDensityClick(System::TObject* Sender);
	void __fastcall sbBarChartClick(System::TObject* Sender);
	void __fastcall sbPieChartClick(System::TObject* Sender);
	void __fastcall sbGraduatedClick(System::TObject* Sender);
	void __fastcall sbIndividualValueClick(System::TObject* Sender);
	void __fastcall editNumberOfIntervalsChange(System::TObject* Sender);
	void __fastcall cbDistributionMethodChange(System::TObject* Sender);
	void __fastcall cbAllowEmptyIntervalsClick(System::TObject* Sender);
	void __fastcall editDotSizeChange(System::TObject* Sender);
	void __fastcall editPieSizeChange(System::TObject* Sender);
	void __fastcall cbPieProportionalClick(System::TObject* Sender);
	void __fastcall sbDetailClick(System::TObject* Sender);
	void __fastcall sbGroupClick(System::TObject* Sender);
	void __fastcall sbCrossTabClick(System::TObject* Sender);
	void __fastcall sbOlapClick(System::TObject* Sender);
	void __fastcall cbDontSummarizeValuesClick(System::TObject* Sender);
	void __fastcall btnFormatClick(System::TObject* Sender);
	void __fastcall cbColorLowestIntervalChange(System::TObject* Sender);
	void __fastcall editBarSizeChange(System::TObject* Sender);
	void __fastcall btnSummaryFieldsClick(System::TObject* Sender);
	void __fastcall btnConditionFieldsClick(System::TObject* Sender);
	
public:
	Ucrpe32::TCrpe* Cr;
	short MapIndex;
	AnsiString PrevSize;
	Graphics::TColor CustomHighestColor;
	Graphics::TColor CustomLowestColor;
public:
	#pragma option push -w-inl
	/* TCustomForm.Create */ inline __fastcall virtual TCrpeMapsDlg(Classes::TComponent* AOwner) : Forms::TForm(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.CreateNew */ inline __fastcall virtual TCrpeMapsDlg(Classes::TComponent* AOwner, int Dummy) : Forms::TForm(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TCrpeMapsDlg(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TCrpeMapsDlg(HWND ParentWindow) : Forms::TForm(ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TCrpeMapsDlg* CrpeMapsDlg;
extern PACKAGE bool bMaps;

}	/* namespace Udmaps */
using namespace Udmaps;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// UDMaps
