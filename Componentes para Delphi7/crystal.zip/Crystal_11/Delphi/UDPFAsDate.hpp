// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'UDPFAsDate.pas' rev: 6.00

#ifndef UDPFAsDateHPP
#define UDPFAsDateHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <UCrpe32.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <ComCtrls.hpp>	// Pascal unit
#include <Buttons.hpp>	// Pascal unit
#include <Calendar.hpp>	// Pascal unit
#include <Grids.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Udpfasdate
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TCrpePFAsDateDlg;
class PASCALIMPLEMENTATION TCrpePFAsDateDlg : public Forms::TForm 
{
	typedef Forms::TForm inherited;
	
__published:
	Extctrls::TPanel* pnlPValueEdit;
	Comctrls::TPageControl* pcPValueEdit;
	Comctrls::TTabSheet* tsDate;
	Extctrls::TPanel* pnlAsDate;
	Stdctrls::TLabel* lblMonthYear1;
	Buttons::TSpeedButton* sbYearMinus1;
	Buttons::TSpeedButton* sbYearPlus1;
	Buttons::TSpeedButton* sbMonthPlus1;
	Buttons::TSpeedButton* sbMonthMinus1;
	Stdctrls::TLabel* lblYear1;
	Stdctrls::TLabel* lblMonth1;
	Stdctrls::TLabel* lblDay1;
	Calendar::TCalendar* Calendar2;
	Stdctrls::TEdit* editDay1;
	Stdctrls::TEdit* editMonth1;
	Stdctrls::TEdit* editYear1;
	Stdctrls::TCheckBox* cbToday1;
	Comctrls::TTabSheet* tsBoolean;
	Extctrls::TPanel* pnlAsBoolean;
	Comctrls::TTabSheet* tsNumber;
	Extctrls::TPanel* pnlAsNumber;
	Stdctrls::TLabel* lblDot1;
	Comctrls::TTabSheet* tsCurrency;
	Extctrls::TPanel* pnlAsCurrency;
	Stdctrls::TLabel* lblDollar;
	Stdctrls::TButton* btnOk;
	Stdctrls::TButton* btnCancel;
	Comctrls::TTabSheet* tsDateTime;
	Comctrls::TTabSheet* tsTime;
	Extctrls::TPanel* pnlAsTime;
	Extctrls::TPanel* pnlDateTime;
	Buttons::TSpeedButton* sbTrue;
	Buttons::TSpeedButton* sbFalse;
	Stdctrls::TLabel* lblHourMinSep2;
	Stdctrls::TLabel* lblMinSecSep2;
	Stdctrls::TLabel* lblHours;
	Stdctrls::TLabel* lblMinutes;
	Stdctrls::TLabel* lblSeconds;
	Stdctrls::TLabel* lblMonthYear2;
	Buttons::TSpeedButton* sbYearMinus2;
	Buttons::TSpeedButton* sbYearPlus2;
	Buttons::TSpeedButton* sbMonthPlus2;
	Buttons::TSpeedButton* sbMonthMinus2;
	Stdctrls::TLabel* lblYear2;
	Stdctrls::TLabel* lblMonth2;
	Stdctrls::TLabel* lblDay2;
	Calendar::TCalendar* Calendar1;
	Stdctrls::TEdit* editDay2;
	Stdctrls::TEdit* editMonth2;
	Stdctrls::TEdit* editYear2;
	Stdctrls::TCheckBox* cbToday2;
	Stdctrls::TLabel* lblHourMinSep;
	Stdctrls::TLabel* lblMinSecSep;
	Stdctrls::TLabel* lblHours2;
	Stdctrls::TLabel* lblMinutes2;
	Stdctrls::TLabel* lblSeconds2;
	Stdctrls::TLabel* lblYearMonthSep;
	Stdctrls::TLabel* lblMonthDaySep;
	Stdctrls::TEdit* editHours2;
	Stdctrls::TEdit* editMinutes2;
	Stdctrls::TEdit* editSeconds2;
	Stdctrls::TEdit* editHour;
	Stdctrls::TEdit* editMinutes;
	Stdctrls::TEdit* editSeconds;
	Stdctrls::TEdit* editNumber;
	Stdctrls::TEdit* editDecimal1;
	Stdctrls::TEdit* editDecimal2;
	Stdctrls::TLabel* Label2;
	Stdctrls::TEdit* editNumber2;
	Stdctrls::TEdit* editDecimal3;
	Stdctrls::TEdit* editDecimal4;
	void __fastcall btnOkClick(System::TObject* Sender);
	void __fastcall FormShow(System::TObject* Sender);
	void __fastcall FormClose(System::TObject* Sender, Forms::TCloseAction &Action);
	void __fastcall cbTodayClick(System::TObject* Sender);
	void __fastcall CalendarChange(System::TObject* Sender);
	void __fastcall editDayExit(System::TObject* Sender);
	void __fastcall editMonthExit(System::TObject* Sender);
	void __fastcall editYearExit(System::TObject* Sender);
	void __fastcall editFieldKeyPress(System::TObject* Sender, char &Key);
	void __fastcall editHours2Exit(System::TObject* Sender);
	void __fastcall editMinutes2Exit(System::TObject* Sender);
	void __fastcall editSeconds2Exit(System::TObject* Sender);
	void __fastcall sbMonthMinusClick(System::TObject* Sender);
	void __fastcall sbMonthPlusClick(System::TObject* Sender);
	void __fastcall sbYearMinusClick(System::TObject* Sender);
	void __fastcall sbYearPlusClick(System::TObject* Sender);
	void __fastcall FormCreate(System::TObject* Sender);
	
public:
	AnsiString Value;
	Ucrpe32::TCrParamFieldType ValueType;
public:
	#pragma option push -w-inl
	/* TCustomForm.Create */ inline __fastcall virtual TCrpePFAsDateDlg(Classes::TComponent* AOwner) : Forms::TForm(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.CreateNew */ inline __fastcall virtual TCrpePFAsDateDlg(Classes::TComponent* AOwner, int Dummy) : Forms::TForm(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TCrpePFAsDateDlg(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TCrpePFAsDateDlg(HWND ParentWindow) : Forms::TForm(ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TCrpePFAsDateDlg* CrpePFAsDateDlg;

}	/* namespace Udpfasdate */
using namespace Udpfasdate;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// UDPFAsDate
