// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'UDFont.pas' rev: 6.00

#ifndef UDFontHPP
#define UDFontHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <UCrpeClasses.hpp>	// Pascal unit
#include <UCrpe32.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Udfont
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TCrpeFontDlg;
class PASCALIMPLEMENTATION TCrpeFontDlg : public Forms::TForm 
{
	typedef Forms::TForm inherited;
	
__published:
	Stdctrls::TEdit* editFontName;
	Stdctrls::TListBox* lbFontNames;
	Stdctrls::TLabel* Label1;
	Stdctrls::TEdit* editStyle;
	Stdctrls::TListBox* lbStyles;
	Stdctrls::TLabel* Label2;
	Stdctrls::TEdit* editSize;
	Stdctrls::TListBox* lbSizes;
	Stdctrls::TLabel* Label3;
	Stdctrls::TButton* btnOk;
	Stdctrls::TButton* btnCancel;
	Stdctrls::TGroupBox* gbEffects;
	Stdctrls::TCheckBox* cbStrikeout;
	Stdctrls::TCheckBox* cbUnderline;
	Stdctrls::TGroupBox* gbSample;
	Extctrls::TPanel* pnlSample;
	Stdctrls::TLabel* lblColor;
	Dialogs::TColorDialog* ColorDialog1;
	Stdctrls::TLabel* lblActualSize;
	Stdctrls::TEdit* editActualSize;
	Extctrls::TPaintBox* PaintBox1;
	Extctrls::TImage* imgTrueType;
	Extctrls::TImage* imgType1;
	Extctrls::TColorBox* cbColor;
	void __fastcall cbColorChange(System::TObject* Sender);
	void __fastcall FormCreate(System::TObject* Sender);
	void __fastcall FormShow(System::TObject* Sender);
	void __fastcall FormClose(System::TObject* Sender, Forms::TCloseAction &Action);
	void __fastcall lbFontNamesClick(System::TObject* Sender);
	void __fastcall editFontNameChange(System::TObject* Sender);
	void __fastcall UpdateFont(void);
	void __fastcall editStyleChange(System::TObject* Sender);
	void __fastcall lbStylesClick(System::TObject* Sender);
	void __fastcall editSizeChange(System::TObject* Sender);
	void __fastcall lbSizesClick(System::TObject* Sender);
	void __fastcall editActualSizeChange(System::TObject* Sender);
	void __fastcall cbStrikeoutClick(System::TObject* Sender);
	void __fastcall cbUnderlineClick(System::TObject* Sender);
	void __fastcall btnOkClick(System::TObject* Sender);
	void __fastcall btnCancelClick(System::TObject* Sender);
	void __fastcall editFontNameExit(System::TObject* Sender);
	void __fastcall editStyleExit(System::TObject* Sender);
	void __fastcall editSizeExit(System::TObject* Sender);
	void __fastcall lbFontNamesDrawItem(Controls::TWinControl* Control, int Index, const Types::TRect &Rect, Windows::TOwnerDrawState State);
	
public:
	Ucrpeclasses::TCrpeFont* Crf;
	Graphics::TColor CustomColor;
	bool bFont;
public:
	#pragma option push -w-inl
	/* TCustomForm.Create */ inline __fastcall virtual TCrpeFontDlg(Classes::TComponent* AOwner) : Forms::TForm(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.CreateNew */ inline __fastcall virtual TCrpeFontDlg(Classes::TComponent* AOwner, int Dummy) : Forms::TForm(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TCrpeFontDlg(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TCrpeFontDlg(HWND ParentWindow) : Forms::TForm(ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TCrpeFontDlg* CrpeFontDlg;

}	/* namespace Udfont */
using namespace Udfont;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// UDFont
