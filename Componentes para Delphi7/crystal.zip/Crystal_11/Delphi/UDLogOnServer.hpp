// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'UDLogOnServer.pas' rev: 6.00

#ifndef UDLogOnServerHPP
#define UDLogOnServerHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <UCrpe32.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <Buttons.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Udlogonserver
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TCrpeLogOnServerDlg;
class PASCALIMPLEMENTATION TCrpeLogOnServerDlg : public Forms::TForm 
{
	typedef Forms::TForm inherited;
	
__published:
	Extctrls::TPanel* pnlLogOnServer1;
	Stdctrls::TLabel* lblNumber;
	Stdctrls::TListBox* lbNumbers;
	Stdctrls::TButton* btnOk;
	Stdctrls::TButton* btnLogOn;
	Stdctrls::TButton* btnLogOff;
	Stdctrls::TButton* btnAdd;
	Stdctrls::TButton* btnDelete;
	Stdctrls::TButton* btnRetrieve;
	Stdctrls::TButton* btnClear;
	Stdctrls::TLabel* lblCount;
	Stdctrls::TEdit* editCount;
	Stdctrls::TLabel* lblServerName;
	Stdctrls::TLabel* lblDatabaseName;
	Stdctrls::TLabel* lblUserID;
	Stdctrls::TLabel* lblPassword;
	Stdctrls::TLabel* lblDLLName;
	Stdctrls::TEdit* editServerName;
	Stdctrls::TEdit* editDatabaseName;
	Stdctrls::TEdit* editUserID;
	Stdctrls::TEdit* editPassword;
	Stdctrls::TEdit* editDLLName;
	Stdctrls::TLabel* lblLogNumber;
	Stdctrls::TEdit* editLogNumber;
	Stdctrls::TCheckBox* cbIsLoggedOn;
	void __fastcall btnLogOnClick(System::TObject* Sender);
	void __fastcall btnLogOffClick(System::TObject* Sender);
	void __fastcall btnAddClick(System::TObject* Sender);
	void __fastcall btnDeleteClick(System::TObject* Sender);
	void __fastcall btnClearClick(System::TObject* Sender);
	void __fastcall btnRetrieveClick(System::TObject* Sender);
	void __fastcall lbNumbersClick(System::TObject* Sender);
	void __fastcall editServerNameChange(System::TObject* Sender);
	void __fastcall editUserIDChange(System::TObject* Sender);
	void __fastcall editPasswordChange(System::TObject* Sender);
	void __fastcall editDatabaseNameChange(System::TObject* Sender);
	void __fastcall editDLLNameChange(System::TObject* Sender);
	void __fastcall FormCreate(System::TObject* Sender);
	void __fastcall FormShow(System::TObject* Sender);
	void __fastcall FormClose(System::TObject* Sender, Forms::TCloseAction &Action);
	void __fastcall btnOkClick(System::TObject* Sender);
	void __fastcall InitializeControls(bool OnOff);
	void __fastcall UpdateLogOnServer(void);
	
public:
	Ucrpe32::TCrpe* Cr;
	short SIndex;
public:
	#pragma option push -w-inl
	/* TCustomForm.Create */ inline __fastcall virtual TCrpeLogOnServerDlg(Classes::TComponent* AOwner) : Forms::TForm(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.CreateNew */ inline __fastcall virtual TCrpeLogOnServerDlg(Classes::TComponent* AOwner, int Dummy) : Forms::TForm(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TCrpeLogOnServerDlg(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TCrpeLogOnServerDlg(HWND ParentWindow) : Forms::TForm(ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TCrpeLogOnServerDlg* CrpeLogOnServerDlg;
extern PACKAGE bool bLogOnServer;

}	/* namespace Udlogonserver */
using namespace Udlogonserver;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// UDLogOnServer
