// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'UDPictures.pas' rev: 6.00

#ifndef UDPicturesHPP
#define UDPicturesHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <UCrpe32.hpp>	// Pascal unit
#include <Buttons.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Udpictures
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TCrpePicturesDlg;
class PASCALIMPLEMENTATION TCrpePicturesDlg : public Forms::TForm 
{
	typedef Forms::TForm inherited;
	
__published:
	Extctrls::TPanel* pnlPictures;
	Stdctrls::TLabel* lblNumber;
	Stdctrls::TListBox* lbNumbers;
	Stdctrls::TEdit* editCount;
	Stdctrls::TLabel* lblCount;
	Stdctrls::TButton* btnOk;
	Stdctrls::TButton* btnClear;
	Stdctrls::TGroupBox* gbCropFrom;
	Stdctrls::TLabel* lblCropLeft;
	Stdctrls::TLabel* lblCropRight;
	Stdctrls::TLabel* lblCropTop;
	Stdctrls::TLabel* lblCropBottom;
	Stdctrls::TEdit* editCropLeft;
	Stdctrls::TEdit* editCropRight;
	Stdctrls::TEdit* editCropTop;
	Stdctrls::TEdit* editCropBottom;
	Stdctrls::TGroupBox* gbScaling;
	Stdctrls::TLabel* lblScalingWidth;
	Stdctrls::TLabel* lblScalingHeight;
	Stdctrls::TEdit* editScalingWidth;
	Stdctrls::TEdit* editScalingHeight;
	Stdctrls::TLabel* lblPercent1;
	Stdctrls::TLabel* lblPercent2;
	Extctrls::TRadioGroup* rgUnits;
	Stdctrls::TButton* btnBorder;
	Stdctrls::TButton* btnFormat;
	Stdctrls::TGroupBox* gbFormat;
	Stdctrls::TLabel* lblTop;
	Stdctrls::TLabel* lblLeft;
	Stdctrls::TLabel* lblSection;
	Stdctrls::TLabel* lblWidth;
	Stdctrls::TLabel* lblHeight;
	Stdctrls::TEdit* editTop;
	Stdctrls::TEdit* editLeft;
	Stdctrls::TEdit* editWidth;
	Stdctrls::TEdit* editHeight;
	Stdctrls::TComboBox* cbSection;
	void __fastcall btnClearClick(System::TObject* Sender);
	void __fastcall lbNumbersClick(System::TObject* Sender);
	void __fastcall FormClose(System::TObject* Sender, Forms::TCloseAction &Action);
	void __fastcall FormShow(System::TObject* Sender);
	void __fastcall UpdatePictures(void);
	void __fastcall btnOkClick(System::TObject* Sender);
	void __fastcall FormCreate(System::TObject* Sender);
	void __fastcall editSizeEnter(System::TObject* Sender);
	void __fastcall editSizeExit(System::TObject* Sender);
	void __fastcall cbSectionChange(System::TObject* Sender);
	void __fastcall btnBorderClick(System::TObject* Sender);
	void __fastcall InitializeControls(bool OnOff);
	void __fastcall rgUnitsClick(System::TObject* Sender);
	void __fastcall btnFormatClick(System::TObject* Sender);
	
public:
	Ucrpe32::TCrpe* Cr;
	short PIndex;
	AnsiString PrevSize;
public:
	#pragma option push -w-inl
	/* TCustomForm.Create */ inline __fastcall virtual TCrpePicturesDlg(Classes::TComponent* AOwner) : Forms::TForm(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.CreateNew */ inline __fastcall virtual TCrpePicturesDlg(Classes::TComponent* AOwner, int Dummy) : Forms::TForm(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TCrpePicturesDlg(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TCrpePicturesDlg(HWND ParentWindow) : Forms::TForm(ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TCrpePicturesDlg* CrpePicturesDlg;
extern PACKAGE bool bPictures;

}	/* namespace Udpictures */
using namespace Udpictures;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// UDPictures
