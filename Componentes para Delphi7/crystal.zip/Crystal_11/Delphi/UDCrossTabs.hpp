// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'UDCrossTabs.pas' rev: 6.00

#ifndef UDCrossTabsHPP
#define UDCrossTabsHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <UCrpe32.hpp>	// Pascal unit
#include <Buttons.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Udcrosstabs
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TCrpeCrossTabsDlg;
class PASCALIMPLEMENTATION TCrpeCrossTabsDlg : public Forms::TForm 
{
	typedef Forms::TForm inherited;
	
__published:
	Extctrls::TPanel* pnlCrossTabs;
	Stdctrls::TGroupBox* gbObjectFormatting;
	Stdctrls::TButton* btnBorder;
	Stdctrls::TButton* btnFormat;
	Stdctrls::TEdit* editTop;
	Stdctrls::TLabel* lblTop;
	Stdctrls::TLabel* lblLeft;
	Stdctrls::TEdit* editLeft;
	Stdctrls::TLabel* lblSection;
	Stdctrls::TEdit* editWidth;
	Stdctrls::TLabel* lblWidth;
	Stdctrls::TLabel* lblHeight;
	Stdctrls::TEdit* editHeight;
	Stdctrls::TComboBox* cbSection;
	Stdctrls::TButton* btnOk;
	Stdctrls::TLabel* lblNumber;
	Stdctrls::TListBox* lbNumbers;
	Stdctrls::TEdit* editCount;
	Stdctrls::TLabel* lblCount;
	Stdctrls::TGroupBox* gbGridOptions;
	Stdctrls::TCheckBox* cbShowCellMargins;
	Stdctrls::TCheckBox* cbShowGridLines;
	Stdctrls::TCheckBox* cbRepeatRowLabels;
	Stdctrls::TCheckBox* cbKeepColumnsTogether;
	Stdctrls::TCheckBox* cbSuppressEmptyRows;
	Stdctrls::TCheckBox* cbSuppressEmptyColumns;
	Stdctrls::TCheckBox* cbSuppressRowGrandTotals;
	Stdctrls::TCheckBox* cbSuppressColumnGrandTotals;
	Stdctrls::TLabel* lblColorRowGrandTotals;
	Stdctrls::TComboBox* cbColorRowGrandTotals;
	Dialogs::TColorDialog* ColorDialog1;
	Stdctrls::TLabel* lblColorColumnGrandTotals;
	Stdctrls::TComboBox* cbColorColumnGrandTotals;
	Extctrls::TRadioGroup* rgUnits;
	Stdctrls::TButton* btnSummaries;
	Stdctrls::TButton* btnRowGroups;
	Stdctrls::TButton* btnColumnGroups;
	void __fastcall FormClose(System::TObject* Sender, Forms::TCloseAction &Action);
	void __fastcall FormShow(System::TObject* Sender);
	void __fastcall btnOkClick(System::TObject* Sender);
	void __fastcall FormCreate(System::TObject* Sender);
	void __fastcall editSizeEnter(System::TObject* Sender);
	void __fastcall editSizeExit(System::TObject* Sender);
	void __fastcall cbSectionChange(System::TObject* Sender);
	void __fastcall btnBorderClick(System::TObject* Sender);
	void __fastcall btnFormatClick(System::TObject* Sender);
	void __fastcall UpdateCrossTabs(void);
	void __fastcall lbNumbersClick(System::TObject* Sender);
	void __fastcall cbColorRowGrandTotalsDrawItem(Controls::TWinControl* Control, int Index, const Types::TRect &Rect, Windows::TOwnerDrawState State);
	void __fastcall cbColorColumnGrandTotalsDrawItem(Controls::TWinControl* Control, int Index, const Types::TRect &Rect, Windows::TOwnerDrawState State);
	void __fastcall cbColorRowGrandTotalsChange(System::TObject* Sender);
	void __fastcall cbColorColumnGrandTotalsChange(System::TObject* Sender);
	void __fastcall cbShowCellMarginsClick(System::TObject* Sender);
	void __fastcall cbShowGridLinesClick(System::TObject* Sender);
	void __fastcall cbRepeatRowLabelsClick(System::TObject* Sender);
	void __fastcall cbKeepColumnsTogetherClick(System::TObject* Sender);
	void __fastcall cbSuppressEmptyRowsClick(System::TObject* Sender);
	void __fastcall cbSuppressEmptyColumnsClick(System::TObject* Sender);
	void __fastcall cbSuppressRowGrandTotalsClick(System::TObject* Sender);
	void __fastcall cbSuppressColumnGrandTotalsClick(System::TObject* Sender);
	void __fastcall btnSummariesClick(System::TObject* Sender);
	void __fastcall btnRowGroupsClick(System::TObject* Sender);
	void __fastcall btnColumnGroupsClick(System::TObject* Sender);
	void __fastcall rgUnitsClick(System::TObject* Sender);
	void __fastcall InitializeControls(bool OnOff);
	
public:
	Ucrpe32::TCrpe* Cr;
	short CrossTabIndex;
	AnsiString PrevSize;
	Graphics::TColor CustomRowColor;
	Graphics::TColor CustomColumnColor;
public:
	#pragma option push -w-inl
	/* TCustomForm.Create */ inline __fastcall virtual TCrpeCrossTabsDlg(Classes::TComponent* AOwner) : Forms::TForm(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.CreateNew */ inline __fastcall virtual TCrpeCrossTabsDlg(Classes::TComponent* AOwner, int Dummy) : Forms::TForm(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TCrpeCrossTabsDlg(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TCrpeCrossTabsDlg(HWND ParentWindow) : Forms::TForm(ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TCrpeCrossTabsDlg* CrpeCrossTabsDlg;
extern PACKAGE bool bCrossTabs;

}	/* namespace Udcrosstabs */
using namespace Udcrosstabs;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// UDCrossTabs
