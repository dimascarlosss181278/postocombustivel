// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'UDSectionFormat.pas' rev: 6.00

#ifndef UDSectionFormatHPP
#define UDSectionFormatHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <UCrpe32.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <Buttons.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Udsectionformat
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TCrpeSectionFormatDlg;
class PASCALIMPLEMENTATION TCrpeSectionFormatDlg : public Forms::TForm 
{
	typedef Forms::TForm inherited;
	
__published:
	Extctrls::TPanel* pnlSectionFormat;
	Stdctrls::TLabel* lblSection;
	Stdctrls::TCheckBox* cbPrintAtBottomOfPage;
	Stdctrls::TCheckBox* cbNewPageBefore;
	Stdctrls::TCheckBox* cbNewPageAfter;
	Stdctrls::TCheckBox* cbResetPageNAfter;
	Stdctrls::TCheckBox* cbKeepTogether;
	Stdctrls::TCheckBox* cbSuppressBlankSection;
	Stdctrls::TCheckBox* cbUnderlaySection;
	Stdctrls::TCheckBox* cbSuppress;
	Stdctrls::TCheckBox* cbFreeFormPlacement;
	Stdctrls::TListBox* lbSections;
	Stdctrls::TButton* btnOk;
	Buttons::TSpeedButton* sbSuppress;
	Buttons::TSpeedButton* sbPrintAtBottomOfPage;
	Buttons::TSpeedButton* sbNewPageBefore;
	Buttons::TSpeedButton* sbNewPageAfter;
	Buttons::TSpeedButton* sbResetPageNAfter;
	Buttons::TSpeedButton* sbKeepTogether;
	Buttons::TSpeedButton* sbSuppressBlankSection;
	Buttons::TSpeedButton* sbUnderlaySection;
	Buttons::TSpeedButton* sbFormulaRed;
	Buttons::TSpeedButton* sbFormulaBlue;
	Stdctrls::TLabel* lblCount;
	Stdctrls::TEdit* editCount;
	Stdctrls::TGroupBox* gbBackgroundColor;
	Stdctrls::TLabel* lblRed;
	Stdctrls::TLabel* lblGreen;
	Stdctrls::TLabel* lblBlue;
	Stdctrls::TEdit* editRed;
	Stdctrls::TEdit* editGreen;
	Stdctrls::TEdit* editBlue;
	Stdctrls::TCheckBox* cbBackgroundColor;
	Buttons::TSpeedButton* sbBackgroundColor;
	Extctrls::TColorBox* colorboxBackgroundColor;
	void __fastcall FormClose(System::TObject* Sender, Forms::TCloseAction &Action);
	void __fastcall FormShow(System::TObject* Sender);
	void __fastcall lbSectionsClick(System::TObject* Sender);
	void __fastcall cbCommonClick(System::TObject* Sender);
	void __fastcall btnOkClick(System::TObject* Sender);
	void __fastcall FormCreate(System::TObject* Sender);
	void __fastcall UpdateSectionFormat(void);
	void __fastcall sbFormulaButtonClick(System::TObject* Sender);
	void __fastcall InitializeControls(bool OnOff);
	void __fastcall colorboxBackgroundColorChange(System::TObject* Sender);
	
public:
	Ucrpe32::TCrpe* Cr;
	short SFIndex;
public:
	#pragma option push -w-inl
	/* TCustomForm.Create */ inline __fastcall virtual TCrpeSectionFormatDlg(Classes::TComponent* AOwner) : Forms::TForm(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.CreateNew */ inline __fastcall virtual TCrpeSectionFormatDlg(Classes::TComponent* AOwner, int Dummy) : Forms::TForm(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TCrpeSectionFormatDlg(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TCrpeSectionFormatDlg(HWND ParentWindow) : Forms::TForm(ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TCrpeSectionFormatDlg* CrpeSectionFormatDlg;
extern PACKAGE bool bSectionFormat;

}	/* namespace Udsectionformat */
using namespace Udsectionformat;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// UDSectionFormat
