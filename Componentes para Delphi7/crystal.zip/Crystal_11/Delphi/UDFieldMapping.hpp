// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'UDFieldMapping.pas' rev: 6.00

#ifndef UDFieldMappingHPP
#define UDFieldMappingHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <UCrpe32.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Udfieldmapping
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TCrpeFieldMappingDlg;
class PASCALIMPLEMENTATION TCrpeFieldMappingDlg : public Forms::TForm 
{
	typedef Forms::TForm inherited;
	
__published:
	Extctrls::TPanel* pnlMapFields;
	Stdctrls::TListBox* lbReportFields;
	Stdctrls::TLabel* lblUnmappedFields;
	Stdctrls::TComboBox* cbDatabaseFields;
	Stdctrls::TLabel* lblDatabaseFields;
	Stdctrls::TButton* btnMap;
	Stdctrls::TButton* btnOk;
	Stdctrls::TButton* btnCancel;
	Stdctrls::TEdit* editFieldType;
	Stdctrls::TLabel* lblFieldType;
	void __fastcall FormShow(System::TObject* Sender);
	void __fastcall FormClose(System::TObject* Sender, Forms::TCloseAction &Action);
	void __fastcall lbReportFieldsClick(System::TObject* Sender);
	void __fastcall btnMapClick(System::TObject* Sender);
	void __fastcall cbDatabaseFieldsChange(System::TObject* Sender);
	void __fastcall FormCreate(System::TObject* Sender);
	void __fastcall btnOkClick(System::TObject* Sender);
	void __fastcall btnCancelClick(System::TObject* Sender);
	
public:
	Classes::TList* ReportFields1;
	Classes::TList* DataBaseFields1;
public:
	#pragma option push -w-inl
	/* TCustomForm.Create */ inline __fastcall virtual TCrpeFieldMappingDlg(Classes::TComponent* AOwner) : Forms::TForm(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.CreateNew */ inline __fastcall virtual TCrpeFieldMappingDlg(Classes::TComponent* AOwner, int Dummy) : Forms::TForm(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TCrpeFieldMappingDlg(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TCrpeFieldMappingDlg(HWND ParentWindow) : Forms::TForm(ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TCrpeFieldMappingDlg* CrpeFieldMappingDlg;
extern PACKAGE Ucrpe32::TCrFieldMappingInfo* RptFields;
extern PACKAGE Ucrpe32::TCrFieldMappingInfo* DBFields;
extern PACKAGE Classes::TStringList* slRptFields;
extern PACKAGE Classes::TStringList* slDBFields;

}	/* namespace Udfieldmapping */
using namespace Udfieldmapping;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// UDFieldMapping
