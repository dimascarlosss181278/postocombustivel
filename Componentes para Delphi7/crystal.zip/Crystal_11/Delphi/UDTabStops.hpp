// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'UDTabStops.pas' rev: 6.00

#ifndef UDTabStopsHPP
#define UDTabStopsHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <ExtCtrls.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <UCrpe32.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Udtabstops
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TCrpeTabStopsDlg;
class PASCALIMPLEMENTATION TCrpeTabStopsDlg : public Forms::TForm 
{
	typedef Forms::TForm inherited;
	
__published:
	Extctrls::TPanel* pnlTabStops;
	Stdctrls::TLabel* lblNames;
	Stdctrls::TLabel* lblFieldName;
	Stdctrls::TLabel* lblCount;
	Stdctrls::TListBox* lbNumbers;
	Stdctrls::TEdit* editCount;
	Stdctrls::TComboBox* cbAlignment;
	Stdctrls::TButton* btnOk;
	Stdctrls::TButton* btnClear;
	Stdctrls::TLabel* lblOffset;
	Stdctrls::TEdit* editOffset;
	Extctrls::TRadioGroup* rgUnits;
	Stdctrls::TButton* btnAdd;
	Stdctrls::TButton* btnDelete;
	void __fastcall FormCreate(System::TObject* Sender);
	void __fastcall FormShow(System::TObject* Sender);
	void __fastcall lbNumbersClick(System::TObject* Sender);
	void __fastcall rgUnitsClick(System::TObject* Sender);
	void __fastcall cbAlignmentChange(System::TObject* Sender);
	void __fastcall editOffsetEnter(System::TObject* Sender);
	void __fastcall editOffsetExit(System::TObject* Sender);
	void __fastcall btnOkClick(System::TObject* Sender);
	void __fastcall btnAddClick(System::TObject* Sender);
	void __fastcall btnDeleteClick(System::TObject* Sender);
	void __fastcall btnClearClick(System::TObject* Sender);
	void __fastcall FormClose(System::TObject* Sender, Forms::TCloseAction &Action);
	void __fastcall UpdateTabStops(void);
	void __fastcall InitializeControls(bool OnOff);
	
public:
	Ucrpe32::TCrpeTabStops* Crt;
	int TIndex;
	AnsiString PrevSize;
public:
	#pragma option push -w-inl
	/* TCustomForm.Create */ inline __fastcall virtual TCrpeTabStopsDlg(Classes::TComponent* AOwner) : Forms::TForm(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.CreateNew */ inline __fastcall virtual TCrpeTabStopsDlg(Classes::TComponent* AOwner, int Dummy) : Forms::TForm(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TCrpeTabStopsDlg(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TCrpeTabStopsDlg(HWND ParentWindow) : Forms::TForm(ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TCrpeTabStopsDlg* CrpeTabStopsDlg;

}	/* namespace Udtabstops */
using namespace Udtabstops;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// UDTabStops
