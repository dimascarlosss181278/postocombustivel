// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'UDWindowParent.pas' rev: 6.00

#ifndef UDWindowParentHPP
#define UDWindowParentHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <UCrpe32.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Buttons.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Udwindowparent
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TCrpeWindowParentDlg;
class PASCALIMPLEMENTATION TCrpeWindowParentDlg : public Forms::TForm 
{
	typedef Forms::TForm inherited;
	
__published:
	Extctrls::TPanel* pnlBtnBar;
	Stdctrls::TComboBox* cbZoom;
	Buttons::TSpeedButton* sbClose;
	Extctrls::TPanel* pnlStatus;
	Extctrls::TPanel* pnlReportName;
	Stdctrls::TLabel* lblExplanation;
	Buttons::TSpeedButton* sbPrint;
	Buttons::TSpeedButton* sbExport;
	Buttons::TSpeedButton* sbPageNext;
	Buttons::TSpeedButton* sbPageFirst;
	Buttons::TSpeedButton* sbPagePrev;
	Buttons::TSpeedButton* sbPageLast;
	Stdctrls::TComboBox* cbPage;
	Buttons::TSpeedButton* sbZoom1;
	Buttons::TSpeedButton* sbZoom2;
	Buttons::TSpeedButton* sbZoom3;
	Stdctrls::TLabel* lblPages;
	Extctrls::TPanel* pnlRecordsRead;
	Stdctrls::TLabel* lblRead;
	Extctrls::TPanel* pnlRecordsSelected;
	Stdctrls::TLabel* lblSelected;
	Extctrls::TPanel* pnlRecordsPrinted;
	Stdctrls::TLabel* lblRecordsPrinted;
	Extctrls::TTimer* Timer1;
	Stdctrls::TLabel* lblPrinted;
	Stdctrls::TLabel* lblRecordsSelected;
	Stdctrls::TLabel* lblRecordsRead;
	Buttons::TSpeedButton* sbCancel;
	void __fastcall FormResize(System::TObject* Sender);
	void __fastcall sbCloseClick(System::TObject* Sender);
	void __fastcall FormShow(System::TObject* Sender);
	void __fastcall cbZoomChange(System::TObject* Sender);
	void __fastcall FormClose(System::TObject* Sender, Forms::TCloseAction &Action);
	void __fastcall sbPrintClick(System::TObject* Sender);
	void __fastcall sbExportClick(System::TObject* Sender);
	void __fastcall sbPageFirstClick(System::TObject* Sender);
	void __fastcall sbPagePrevClick(System::TObject* Sender);
	void __fastcall sbPageNextClick(System::TObject* Sender);
	void __fastcall sbPageLastClick(System::TObject* Sender);
	void __fastcall sbZoom1Click(System::TObject* Sender);
	void __fastcall sbZoom2Click(System::TObject* Sender);
	void __fastcall sbZoom3Click(System::TObject* Sender);
	void __fastcall cbPageChange(System::TObject* Sender);
	void __fastcall FormCreate(System::TObject* Sender);
	void __fastcall Timer1Timer(System::TObject* Sender);
	void __fastcall sbCancelClick(System::TObject* Sender);
	
public:
	Ucrpe32::TCrpe* Cr;
	AnsiString PagePlus;
public:
	#pragma option push -w-inl
	/* TCustomForm.Create */ inline __fastcall virtual TCrpeWindowParentDlg(Classes::TComponent* AOwner) : Forms::TForm(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.CreateNew */ inline __fastcall virtual TCrpeWindowParentDlg(Classes::TComponent* AOwner, int Dummy) : Forms::TForm(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TCrpeWindowParentDlg(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TCrpeWindowParentDlg(HWND ParentWindow) : Forms::TForm(ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TCrpeWindowParentDlg* CrpeWindowParentDlg;
extern PACKAGE bool bWindowParent;
extern PACKAGE int iPreventInfiniteLoop;

}	/* namespace Udwindowparent */
using namespace Udwindowparent;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// UDWindowParent
