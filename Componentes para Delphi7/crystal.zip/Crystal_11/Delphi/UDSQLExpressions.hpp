// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'UDSQLExpressions.pas' rev: 6.00

#ifndef UDSQLExpressionsHPP
#define UDSQLExpressionsHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <UCrpe32.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Udsqlexpressions
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TCrpeSQLExpressionsDlg;
class PASCALIMPLEMENTATION TCrpeSQLExpressionsDlg : public Forms::TForm 
{
	typedef Forms::TForm inherited;
	
__published:
	Extctrls::TPanel* pnlExpressions;
	Stdctrls::TLabel* lblExpression;
	Stdctrls::TLabel* lblExpressionName;
	Stdctrls::TListBox* lbNames;
	Stdctrls::TMemo* memoExpression;
	Stdctrls::TButton* btnCheck;
	Stdctrls::TButton* btnCheckAll;
	Stdctrls::TButton* btnOk;
	Stdctrls::TButton* btnClear;
	Stdctrls::TLabel* lblCount;
	Stdctrls::TEdit* editCount;
	Stdctrls::TGroupBox* gbFormat;
	Stdctrls::TLabel* lblFieldName;
	Stdctrls::TLabel* lblFieldType;
	Stdctrls::TLabel* lblFieldLength;
	Stdctrls::TLabel* lblTop;
	Stdctrls::TLabel* lblLeft;
	Stdctrls::TLabel* lblSection;
	Stdctrls::TLabel* lblWidth;
	Stdctrls::TLabel* lblHeight;
	Stdctrls::TEdit* editFieldName;
	Stdctrls::TEdit* editFieldType;
	Stdctrls::TEdit* editFieldLength;
	Stdctrls::TButton* btnBorder;
	Stdctrls::TButton* btnFont;
	Stdctrls::TButton* btnFormat;
	Stdctrls::TEdit* editTop;
	Stdctrls::TEdit* editLeft;
	Stdctrls::TEdit* editWidth;
	Stdctrls::TEdit* editHeight;
	Stdctrls::TComboBox* cbSection;
	Extctrls::TRadioGroup* rgUnits;
	Dialogs::TFontDialog* FontDialog1;
	Stdctrls::TButton* btnHiliteConditions;
	Stdctrls::TCheckBox* cbObjectPropertiesActive;
	void __fastcall lbNamesClick(System::TObject* Sender);
	void __fastcall memoExpressionChange(System::TObject* Sender);
	void __fastcall btnCheckClick(System::TObject* Sender);
	void __fastcall btnCheckAllClick(System::TObject* Sender);
	void __fastcall btnClearClick(System::TObject* Sender);
	void __fastcall FormClose(System::TObject* Sender, Forms::TCloseAction &Action);
	void __fastcall FormShow(System::TObject* Sender);
	void __fastcall UpdateSQLExpressions(void);
	void __fastcall btnOkClick(System::TObject* Sender);
	void __fastcall FormCreate(System::TObject* Sender);
	void __fastcall rgUnitsClick(System::TObject* Sender);
	void __fastcall editSizeEnter(System::TObject* Sender);
	void __fastcall editSizeExit(System::TObject* Sender);
	void __fastcall cbSectionChange(System::TObject* Sender);
	void __fastcall btnBorderClick(System::TObject* Sender);
	void __fastcall btnFontClick(System::TObject* Sender);
	void __fastcall btnFormatClick(System::TObject* Sender);
	void __fastcall btnHiliteConditionsClick(System::TObject* Sender);
	void __fastcall InitializeControls(bool OnOff);
	void __fastcall InitializeFormatControls(bool OnOff);
	void __fastcall cbObjectPropertiesActiveClick(System::TObject* Sender);
	
public:
	Ucrpe32::TCrpe* Cr;
	short ExIndex;
	AnsiString PrevSize;
public:
	#pragma option push -w-inl
	/* TCustomForm.Create */ inline __fastcall virtual TCrpeSQLExpressionsDlg(Classes::TComponent* AOwner) : Forms::TForm(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.CreateNew */ inline __fastcall virtual TCrpeSQLExpressionsDlg(Classes::TComponent* AOwner, int Dummy) : Forms::TForm(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TCrpeSQLExpressionsDlg(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TCrpeSQLExpressionsDlg(HWND ParentWindow) : Forms::TForm(ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TCrpeSQLExpressionsDlg* CrpeSQLExpressionsDlg;
extern PACKAGE bool bSQLExpressions;

}	/* namespace Udsqlexpressions */
using namespace Udsqlexpressions;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// UDSQLExpressions
