// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'UDExportExcel.pas' rev: 6.00

#ifndef UDExportExcelHPP
#define UDExportExcelHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <UCrpe32.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Buttons.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Udexportexcel
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TCrpeExcelDlg;
class PASCALIMPLEMENTATION TCrpeExcelDlg : public Forms::TForm 
{
	typedef Forms::TForm inherited;
	
__published:
	Extctrls::TPanel* panel1;
	Stdctrls::TGroupBox* gbColumnWidth;
	Stdctrls::TRadioButton* rbByConstant;
	Stdctrls::TRadioButton* rbByArea;
	Stdctrls::TEdit* editConstant;
	Stdctrls::TComboBox* cbArea;
	Stdctrls::TButton* btnOk;
	Stdctrls::TButton* btnCancel;
	Stdctrls::TCheckBox* cbWorksheetFunctions;
	Stdctrls::TComboBox* cbXLSType;
	Stdctrls::TLabel* lblXLSType;
	Stdctrls::TCheckBox* cbCreatePageBreaks;
	Stdctrls::TCheckBox* cbConvertDatesToStrings;
	Stdctrls::TCheckBox* cbChopPageHeader;
	Stdctrls::TCheckBox* cbExportHeaderFooter;
	Stdctrls::TGroupBox* gbPageRange;
	Stdctrls::TLabel* lblLastPage;
	Stdctrls::TRadioButton* rbAllPages;
	Stdctrls::TRadioButton* rbFirstPage;
	Stdctrls::TEdit* editFirstPage;
	Stdctrls::TEdit* editLastPage;
	Stdctrls::TLabel* lblConstantNote;
	Stdctrls::TLabel* Label1;
	void __fastcall FormClose(System::TObject* Sender, Forms::TCloseAction &Action);
	void __fastcall FormShow(System::TObject* Sender);
	void __fastcall btnOKClick(System::TObject* Sender);
	void __fastcall rbByConstantClick(System::TObject* Sender);
	void __fastcall rbByAreaClick(System::TObject* Sender);
	void __fastcall editConstantKeyPress(System::TObject* Sender, char &Key);
	void __fastcall FormCreate(System::TObject* Sender);
	void __fastcall btnCancelClick(System::TObject* Sender);
	void __fastcall cbXLSTypeChange(System::TObject* Sender);
	void __fastcall rbAllPagesClick(System::TObject* Sender);
	void __fastcall rbFirstPageClick(System::TObject* Sender);
	
public:
	Ucrpe32::TCrpe* Cr;
public:
	#pragma option push -w-inl
	/* TCustomForm.Create */ inline __fastcall virtual TCrpeExcelDlg(Classes::TComponent* AOwner) : Forms::TForm(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.CreateNew */ inline __fastcall virtual TCrpeExcelDlg(Classes::TComponent* AOwner, int Dummy) : Forms::TForm(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TCrpeExcelDlg(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TCrpeExcelDlg(HWND ParentWindow) : Forms::TForm(ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TCrpeExcelDlg* CrpeExcelDlg;

}	/* namespace Udexportexcel */
using namespace Udexportexcel;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// UDExportExcel
