// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'UCrpeUtl.pas' rev: 6.00

#ifndef UCrpeUtlHPP
#define UCrpeUtlHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <CRDynamic.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Ucrpeutl
{
//-- type declarations -------------------------------------------------------
//-- var, const, procedure ---------------------------------------------------
extern PACKAGE bool __fastcall IsNumeric(AnsiString Value);
extern PACKAGE bool __fastcall IsFloating(AnsiString Value);
extern PACKAGE bool __fastcall IsQuoted(AnsiString Value);
extern PACKAGE AnsiString __fastcall AddBackSlash(const AnsiString sPath);
extern PACKAGE bool __fastcall GetPathFromAlias(const AnsiString sAlias, AnsiString &sPath);
extern PACKAGE bool __fastcall StrToSectionCode(const AnsiString Value, short &nCode);
extern PACKAGE AnsiString __fastcall AreaCodeToStr(const short Value);
extern PACKAGE AnsiString __fastcall SectionCodeToStr(const short Value);
extern PACKAGE AnsiString __fastcall GetToken(AnsiString &s, const AnsiString sDelimiter);
extern PACKAGE AnsiString __fastcall GetStrFromRsc(int RscNum);
extern PACKAGE int __fastcall GetErrorNum(const AnsiString sError);
extern PACKAGE AnsiString __fastcall GetErrorStr(const AnsiString sError);
extern PACKAGE unsigned __fastcall GetVersionInfo(const AnsiString Filename, const AnsiString Key, AnsiString &sVersion);
extern PACKAGE bool __fastcall StrToValueInfo(const AnsiString sValue, Crdynamic::PEValueInfo &ValueInfo);
extern PACKAGE AnsiString __fastcall ValueInfoToStr(Crdynamic::PEValueInfo &ValueInfo);
extern PACKAGE AnsiString __fastcall DrillValueInfoToStr(Crdynamic::PEDrillValueInfo &ValueInfo);
extern PACKAGE void __fastcall ValueInfoToDefault(Crdynamic::PEValueInfo &ValueInfo);
extern PACKAGE AnsiString __fastcall NameToCrFormulaFormat(const AnsiString Name, AnsiString InstanceName);
extern PACKAGE AnsiString __fastcall CrFormulaFormatToName(const AnsiString ffName);
extern PACKAGE bool __fastcall CrStrToBoolean(const AnsiString sValue);
extern PACKAGE AnsiString __fastcall CrBooleanToStr(const bool bValue, bool ResultAsNum);
extern PACKAGE AnsiString __fastcall BooleanToStr(bool bTmp);
extern PACKAGE int __fastcall CrStrToInteger(const AnsiString sValue);
extern PACKAGE double __fastcall CrStrToFloating(const AnsiString sValue);
extern PACKAGE AnsiString __fastcall CrFloatingToStr(const double fValue);
extern PACKAGE bool __fastcall CrStrToDate(const AnsiString sValue, System::TDateTime &dValue);
extern PACKAGE AnsiString __fastcall CrDateToStr(const System::TDateTime dValue);
extern PACKAGE bool __fastcall CrStrToDateTime(const AnsiString sValue, System::TDateTime &dtValue);
extern PACKAGE AnsiString __fastcall CrDateTimeToStr(const System::TDateTime dtValue, bool bMSec);
extern PACKAGE bool __fastcall CrStrToTime(const AnsiString sValue, System::TDateTime &tValue);
extern PACKAGE AnsiString __fastcall CrTimeToStr(const System::TDateTime tValue);
extern PACKAGE bool __fastcall ExDateTimeStr(AnsiString sValue, AnsiString &sYear, AnsiString &sMonth, AnsiString &sDay, AnsiString &sHour, AnsiString &sMin, AnsiString &sSec);
extern PACKAGE bool __fastcall ExDateStr(AnsiString sValue, AnsiString &sYear, AnsiString &sMonth, AnsiString &sDay);
extern PACKAGE bool __fastcall ExTimeStr(AnsiString sValue, AnsiString &sHour, AnsiString &sMin, AnsiString &sSec);
extern PACKAGE AnsiString __fastcall TruncStr(AnsiString sValue);
extern PACKAGE AnsiString __fastcall RemoveSpaces(const AnsiString sValue);
extern PACKAGE void __fastcall RemoveChar(AnsiString &sValue, char ch);
extern PACKAGE AnsiString __fastcall RTrimList(const Classes::TStrings* sList);
extern PACKAGE bool __fastcall IsStrEmpty(const AnsiString sValue);
extern PACKAGE bool __fastcall IsStringListEmpty(const Classes::TStrings* sList);
extern PACKAGE AnsiString __fastcall MakeCRLF(AnsiString Value);
extern PACKAGE AnsiString __fastcall CrGetTempPath();
extern PACKAGE void __fastcall CopyDevMode(_devicemodeA &SourceDM, _devicemodeA &DestinationDM);
extern PACKAGE Graphics::TColor __fastcall ColorState(bool Enable);
extern PACKAGE double __fastcall TwipsToInches(int iValue);
extern PACKAGE int __fastcall InchesToTwips(double fValue);
extern PACKAGE AnsiString __fastcall TwipsToInchesStr(int iValue);
extern PACKAGE int __fastcall InchesStrToTwips(AnsiString sValue);
extern PACKAGE bool __fastcall CompareTwipsToInches(int iTwips, double dInches);
extern PACKAGE double __fastcall TwipsToPoints(int iValue);
extern PACKAGE int __fastcall PointsToTwips(double fValue);
extern PACKAGE AnsiString __fastcall TwipsToPointsStr(int iValue);
extern PACKAGE int __fastcall PointsStrToTwips(AnsiString sValue);
extern PACKAGE bool __fastcall CompareTwipsToPoints(int iTwips, double dPoints);
extern PACKAGE void __fastcall LoadFormPos(Forms::TForm* frmTemp);
extern PACKAGE void __fastcall SaveFormPos(Forms::TForm* frmTemp);
extern PACKAGE void __fastcall LoadFormSize(Forms::TForm* frmTemp);
extern PACKAGE void __fastcall SaveFormSize(Forms::TForm* frmTemp);
extern PACKAGE AnsiString __fastcall GetCommonFilesPath();
extern PACKAGE AnsiString __fastcall CrGetTempName(const AnsiString Extension);

}	/* namespace Ucrpeutl */
using namespace Ucrpeutl;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// UCrpeUtl
