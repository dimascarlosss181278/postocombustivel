// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'UDAreaFormat.pas' rev: 6.00

#ifndef UDAreaFormatHPP
#define UDAreaFormatHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <UCrpe32.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <Buttons.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Udareaformat
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TCrpeAreaFormatDlg;
class PASCALIMPLEMENTATION TCrpeAreaFormatDlg : public Forms::TForm 
{
	typedef Forms::TForm inherited;
	
__published:
	Extctrls::TPanel* pnlAreaFormat;
	Stdctrls::TLabel* lblArea;
	Stdctrls::TCheckBox* cbPrintAtBottomOfPage;
	Stdctrls::TCheckBox* cbNewPageBefore;
	Stdctrls::TCheckBox* cbNewPageAfter;
	Stdctrls::TCheckBox* cbResetPageNAfter;
	Stdctrls::TCheckBox* cbKeepTogether;
	Stdctrls::TCheckBox* cbHide;
	Stdctrls::TCheckBox* cbSuppress;
	Stdctrls::TListBox* lbAreas;
	Stdctrls::TButton* btnOk;
	Stdctrls::TButton* btnClear;
	Buttons::TSpeedButton* sbSuppress;
	Buttons::TSpeedButton* sbPrintAtBottomOfPage;
	Buttons::TSpeedButton* sbNewPageBefore;
	Buttons::TSpeedButton* sbNewPageAfter;
	Buttons::TSpeedButton* sbResetPageNAfter;
	Buttons::TSpeedButton* sbKeepTogether;
	Buttons::TSpeedButton* sbHide;
	Buttons::TSpeedButton* sbFormulaRed;
	Buttons::TSpeedButton* sbFormulaBlue;
	Stdctrls::TLabel* lblCount;
	Stdctrls::TEdit* editCount;
	Stdctrls::TEdit* editNSections;
	Stdctrls::TLabel* lblNSections;
	void __fastcall FormClose(System::TObject* Sender, Forms::TCloseAction &Action);
	void __fastcall FormShow(System::TObject* Sender);
	void __fastcall btnClearClick(System::TObject* Sender);
	void __fastcall lbAreasClick(System::TObject* Sender);
	void __fastcall cbCommonClick(System::TObject* Sender);
	void __fastcall btnOkClick(System::TObject* Sender);
	void __fastcall FormCreate(System::TObject* Sender);
	void __fastcall UpdateAreaFormat(void);
	void __fastcall sbFormulaButtonClick(System::TObject* Sender);
	void __fastcall InitializeControls(bool OnOff);
	
public:
	Ucrpe32::TCrpe* Cr;
	short AreaIndex;
public:
	#pragma option push -w-inl
	/* TCustomForm.Create */ inline __fastcall virtual TCrpeAreaFormatDlg(Classes::TComponent* AOwner) : Forms::TForm(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.CreateNew */ inline __fastcall virtual TCrpeAreaFormatDlg(Classes::TComponent* AOwner, int Dummy) : Forms::TForm(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TCrpeAreaFormatDlg(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TCrpeAreaFormatDlg(HWND ParentWindow) : Forms::TForm(ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TCrpeAreaFormatDlg* CrpeAreaFormatDlg;
extern PACKAGE bool bAreaFormat;

}	/* namespace Udareaformat */
using namespace Udareaformat;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// UDAreaFormat
