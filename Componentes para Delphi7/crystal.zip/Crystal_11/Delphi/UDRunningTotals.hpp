// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'UDRunningTotals.pas' rev: 6.00

#ifndef UDRunningTotalsHPP
#define UDRunningTotalsHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <UCrpe32.hpp>	// Pascal unit
#include <Buttons.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Udrunningtotals
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TCrpeRunningTotalsDlg;
class PASCALIMPLEMENTATION TCrpeRunningTotalsDlg : public Forms::TForm 
{
	typedef Forms::TForm inherited;
	
__published:
	Extctrls::TPanel* pnlRunningTotals;
	Stdctrls::TLabel* lblNumber;
	Stdctrls::TListBox* lbNumbers;
	Stdctrls::TEdit* editCount;
	Stdctrls::TLabel* lblCount;
	Stdctrls::TGroupBox* gbFormat;
	Stdctrls::TEdit* editFieldName;
	Stdctrls::TLabel* lblFieldName;
	Stdctrls::TLabel* lblFieldType;
	Stdctrls::TEdit* editFieldType;
	Stdctrls::TLabel* lblFieldLength;
	Stdctrls::TEdit* editFieldLength;
	Stdctrls::TButton* btnBorder;
	Stdctrls::TButton* btnFont;
	Stdctrls::TButton* btnFormat;
	Stdctrls::TEdit* editTop;
	Stdctrls::TLabel* lblTop;
	Stdctrls::TLabel* lblLeft;
	Stdctrls::TEdit* editLeft;
	Stdctrls::TLabel* lblSection;
	Stdctrls::TEdit* editWidth;
	Stdctrls::TLabel* lblWidth;
	Stdctrls::TLabel* lblHeight;
	Stdctrls::TEdit* editHeight;
	Stdctrls::TComboBox* cbSection;
	Stdctrls::TButton* btnOk;
	Stdctrls::TButton* btnClear;
	Dialogs::TFontDialog* FontDialog1;
	Stdctrls::TEdit* editName;
	Stdctrls::TComboBox* cbSummaryType;
	Stdctrls::TEdit* editSummaryTypeN;
	Stdctrls::TComboBox* cbSummaryTypeField;
	Stdctrls::TComboBox* cbSummaryField;
	Stdctrls::TLabel* lblName;
	Extctrls::TBevel* lineSummary;
	Stdctrls::TLabel* lblSummary;
	Stdctrls::TLabel* lblSummaryField;
	Stdctrls::TLabel* lblSummaryType;
	Stdctrls::TLabel* lblSummaryTypeN;
	Stdctrls::TLabel* lblEvaluate;
	Extctrls::TBevel* lineEvaluate;
	Extctrls::TPanel* pnlEvaluate;
	Stdctrls::TRadioButton* rbEvalNoCondition;
	Stdctrls::TRadioButton* rbEvalOnChangeField;
	Stdctrls::TRadioButton* rbEvalOnChangeGroup;
	Stdctrls::TRadioButton* rbEvalOnFormula;
	Stdctrls::TComboBox* cbEvalField;
	Stdctrls::TComboBox* cbEvalGroup;
	Buttons::TSpeedButton* sbFormulaRed;
	Buttons::TSpeedButton* sbFormulaBlue;
	Buttons::TSpeedButton* sbEvalFormula;
	Stdctrls::TLabel* lblReset;
	Extctrls::TBevel* lineReset;
	Extctrls::TPanel* pnlReset;
	Buttons::TSpeedButton* sbResetFormula;
	Stdctrls::TRadioButton* rbResetNoCondition;
	Stdctrls::TRadioButton* rbResetOnChangeField;
	Stdctrls::TRadioButton* rbResetOnChangeGroup;
	Stdctrls::TRadioButton* rbResetOnFormula;
	Stdctrls::TComboBox* cbResetField;
	Stdctrls::TComboBox* cbResetGroup;
	Extctrls::TRadioGroup* rgUnits;
	Stdctrls::TButton* btnHiliteConditions;
	void __fastcall btnClearClick(System::TObject* Sender);
	void __fastcall lbNumbersClick(System::TObject* Sender);
	void __fastcall FormClose(System::TObject* Sender, Forms::TCloseAction &Action);
	void __fastcall FormShow(System::TObject* Sender);
	void __fastcall btnOkClick(System::TObject* Sender);
	void __fastcall FormCreate(System::TObject* Sender);
	void __fastcall btnFontClick(System::TObject* Sender);
	void __fastcall EditSizeEnter(System::TObject* Sender);
	void __fastcall EditSizeExit(System::TObject* Sender);
	void __fastcall cbSectionChange(System::TObject* Sender);
	void __fastcall btnBorderClick(System::TObject* Sender);
	void __fastcall rgUnitsClick(System::TObject* Sender);
	void __fastcall btnFormatClick(System::TObject* Sender);
	void __fastcall cbSummaryTypeChange(System::TObject* Sender);
	void __fastcall cbSummaryFieldChange(System::TObject* Sender);
	void __fastcall btnHiliteConditionsClick(System::TObject* Sender);
	void __fastcall rbEvalOnChangeFieldClick(System::TObject* Sender);
	void __fastcall rbEvalOnChangeGroupClick(System::TObject* Sender);
	void __fastcall rbEvalOnFormulaClick(System::TObject* Sender);
	void __fastcall rbResetNoConditionClick(System::TObject* Sender);
	void __fastcall rbEvalNoConditionClick(System::TObject* Sender);
	void __fastcall rbResetOnChangeFieldClick(System::TObject* Sender);
	void __fastcall rbResetOnChangeGroupClick(System::TObject* Sender);
	void __fastcall rbResetOnFormulaClick(System::TObject* Sender);
	void __fastcall editNameChange(System::TObject* Sender);
	void __fastcall cbSummaryTypeFieldChange(System::TObject* Sender);
	void __fastcall editSummaryTypeNChange(System::TObject* Sender);
	void __fastcall cbEvalFieldChange(System::TObject* Sender);
	void __fastcall cbEvalGroupChange(System::TObject* Sender);
	void __fastcall cbResetFieldChange(System::TObject* Sender);
	void __fastcall cbResetGroupChange(System::TObject* Sender);
	void __fastcall UpdateRunningTotals(void);
	void __fastcall InitializeControls(bool OnOff);
	void __fastcall InitializeFormatControls(bool OnOff);
	void __fastcall sbEvalFormulaClick(System::TObject* Sender);
	void __fastcall sbResetFormulaClick(System::TObject* Sender);
	
public:
	Ucrpe32::TCrpe* Cr;
	int RTIndex;
	AnsiString PrevSize;
public:
	#pragma option push -w-inl
	/* TCustomForm.Create */ inline __fastcall virtual TCrpeRunningTotalsDlg(Classes::TComponent* AOwner) : Forms::TForm(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.CreateNew */ inline __fastcall virtual TCrpeRunningTotalsDlg(Classes::TComponent* AOwner, int Dummy) : Forms::TForm(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TCrpeRunningTotalsDlg(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TCrpeRunningTotalsDlg(HWND ParentWindow) : Forms::TForm(ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TCrpeRunningTotalsDlg* CrpeRunningTotalsDlg;
extern PACKAGE bool bRunningTotals;

}	/* namespace Udrunningtotals */
using namespace Udrunningtotals;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// UDRunningTotals
