// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'UDGraphs.pas' rev: 6.00

#ifndef UDGraphsHPP
#define UDGraphsHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <UCrpe32.hpp>	// Pascal unit
#include <ImgList.hpp>	// Pascal unit
#include <ComCtrls.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <Buttons.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Udgraphs
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TCrpeGraphsDlg;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeGraphsDlg : public Forms::TForm 
{
	typedef Forms::TForm inherited;
	
__published:
	Stdctrls::TButton* btnOk;
	Stdctrls::TButton* btnClear;
	Controls::TImageList* ilSmall;
	Dialogs::TFontDialog* FontDialog1;
	Forms::TScrollBox* ScrollBox1;
	Extctrls::TImage* Bar1;
	Extctrls::TImage* Bar2;
	Extctrls::TImage* Bar3;
	Extctrls::TImage* Bar4;
	Extctrls::TImage* Bar5;
	Extctrls::TImage* Bar6;
	Extctrls::TImage* Line1;
	Extctrls::TImage* Line2;
	Extctrls::TImage* Line3;
	Extctrls::TImage* Line4;
	Extctrls::TImage* Line5;
	Extctrls::TImage* Line6;
	Extctrls::TImage* Area1;
	Extctrls::TImage* Area2;
	Extctrls::TImage* Area3;
	Extctrls::TImage* Area4;
	Extctrls::TImage* Area5;
	Extctrls::TImage* Area6;
	Extctrls::TImage* Pie1;
	Extctrls::TImage* Pie2;
	Extctrls::TImage* Pie3;
	Extctrls::TImage* Pie4;
	Extctrls::TImage* Doughnut1;
	Extctrls::TImage* Doughnut2;
	Extctrls::TImage* Doughnut3;
	Extctrls::TImage* ThreeDRiser1;
	Extctrls::TImage* ThreeDRiser2;
	Extctrls::TImage* ThreeDRiser3;
	Extctrls::TImage* ThreeDRiser4;
	Extctrls::TImage* ThreeDSurface1;
	Extctrls::TImage* ThreeDSurface2;
	Extctrls::TImage* ThreeDSurface3;
	Extctrls::TImage* XYScatter1;
	Extctrls::TImage* XYScatter2;
	Extctrls::TImage* XYScatter3;
	Extctrls::TImage* XYScatter4;
	Extctrls::TImage* Radar1;
	Extctrls::TImage* Radar2;
	Extctrls::TImage* Radar3;
	Extctrls::TImage* Bubble1;
	Extctrls::TImage* Bubble2;
	Extctrls::TImage* Stock1;
	Extctrls::TImage* Stock2;
	Extctrls::TImage* Stock3;
	Extctrls::TImage* Stock4;
	Extctrls::TImage* Stock5;
	Extctrls::TImage* Stock6;
	Extctrls::TPanel* pnlGraphs;
	Comctrls::TPageControl* pcGraphs;
	Comctrls::TTabSheet* tsTypeX;
	Extctrls::TPanel* pnlTypeX;
	Buttons::TSpeedButton* sb1;
	Buttons::TSpeedButton* sb2;
	Buttons::TSpeedButton* sb4;
	Buttons::TSpeedButton* sb5;
	Buttons::TSpeedButton* sb3;
	Buttons::TSpeedButton* sb6;
	Buttons::TSpeedButton* sb7;
	Comctrls::TTreeView* tvTypes;
	Comctrls::TTabSheet* tsText;
	Extctrls::TPanel* pnlText;
	Stdctrls::TLabel* lblTitle;
	Stdctrls::TLabel* lblSubTitle;
	Stdctrls::TLabel* lblFootnote;
	Stdctrls::TLabel* lblSeries;
	Stdctrls::TLabel* lblGroupsTitle;
	Stdctrls::TLabel* lblXAxisTitle;
	Stdctrls::TLabel* lblAxisTitle;
	Stdctrls::TLabel* lblZAxisTitle;
	Buttons::TSpeedButton* sbTitleFont;
	Buttons::TSpeedButton* sbSubTitleFont;
	Buttons::TSpeedButton* sbFootNoteFont;
	Buttons::TSpeedButton* sbGroupsTitleFont;
	Buttons::TSpeedButton* sbDataTitleFont;
	Buttons::TSpeedButton* sbLegendFont;
	Buttons::TSpeedButton* sbGroupLabelsFont;
	Buttons::TSpeedButton* sbDataLabelsFont;
	Stdctrls::TEdit* editTitle;
	Stdctrls::TEdit* editSubTitle;
	Stdctrls::TEdit* editFootnote;
	Stdctrls::TEdit* editSeriesTitle;
	Stdctrls::TEdit* editGroupsTitle;
	Stdctrls::TEdit* editXAxisTitle;
	Stdctrls::TEdit* editYAxisTitle;
	Stdctrls::TEdit* editZAxisTitle;
	Extctrls::TPanel* pnlTitleFont;
	Stdctrls::TLabel* lblTitleFont;
	Extctrls::TPanel* pnlSubTitleFont;
	Stdctrls::TLabel* lblSubTitleFont;
	Extctrls::TPanel* pnlFootNoteFont;
	Stdctrls::TLabel* lblFootNoteFont;
	Extctrls::TPanel* pnlGroupsTitleFont;
	Stdctrls::TLabel* lblGroupsTitleFont;
	Extctrls::TPanel* pnlDataTitleFont;
	Stdctrls::TLabel* lblDataTitleFont;
	Extctrls::TPanel* pnlLegendFont;
	Stdctrls::TLabel* lblLegendFont;
	Extctrls::TPanel* pnlGroupLabelsFont;
	Stdctrls::TLabel* lblGroupLabelsFont;
	Extctrls::TPanel* pnlDataLabelsFont;
	Stdctrls::TLabel* lblDataLabelsFont;
	Comctrls::TTabSheet* tsOptionInfo;
	Extctrls::TPanel* pnlOptionInfo;
	Stdctrls::TLabel* lblColor;
	Stdctrls::TLabel* lblLegend;
	Stdctrls::TLabel* lblPieSize;
	Stdctrls::TLabel* lblPieSlice;
	Stdctrls::TLabel* lblBarSize;
	Stdctrls::TLabel* lblBarDirection;
	Stdctrls::TLabel* lblMarkerSize;
	Stdctrls::TLabel* lblMarkerShape;
	Stdctrls::TLabel* lblViewingAngle;
	Stdctrls::TComboBox* cbColor;
	Stdctrls::TComboBox* cbLegend;
	Stdctrls::TComboBox* cbPieSize;
	Stdctrls::TComboBox* cbPieSlice;
	Stdctrls::TComboBox* cbBarSize;
	Stdctrls::TComboBox* cbBarDirection;
	Stdctrls::TComboBox* cbMarkerSize;
	Stdctrls::TComboBox* cbMarkerShape;
	Stdctrls::TGroupBox* gbDataPoints;
	Stdctrls::TLabel* lblNumberFormat2;
	Stdctrls::TRadioButton* rbNone;
	Stdctrls::TRadioButton* rbShowLabel;
	Stdctrls::TComboBox* cbNumberFormat;
	Stdctrls::TRadioButton* rbShowValue;
	Stdctrls::TComboBox* cbViewingAngle;
	Comctrls::TTabSheet* tsAxis;
	Extctrls::TPanel* pnlAxis;
	Stdctrls::TGroupBox* gbGridLines;
	Stdctrls::TLabel* lblGridLineX;
	Stdctrls::TLabel* lblGridLineY;
	Stdctrls::TLabel* lblMajor;
	Stdctrls::TLabel* lblMinor;
	Stdctrls::TLabel* lblGridLineY2;
	Stdctrls::TLabel* lblGridLineZ;
	Stdctrls::TCheckBox* cbMajorX;
	Stdctrls::TCheckBox* cbMajorY;
	Stdctrls::TCheckBox* cbMajorY2;
	Stdctrls::TCheckBox* cbMajorZ;
	Stdctrls::TCheckBox* cbMinorX;
	Stdctrls::TCheckBox* cbMinorY;
	Stdctrls::TCheckBox* cbMinorY2;
	Stdctrls::TCheckBox* cbMinorZ;
	Stdctrls::TGroupBox* gbDataValues;
	Stdctrls::TLabel* lblDataValuesY;
	Stdctrls::TLabel* lblDataValuesY2;
	Stdctrls::TLabel* lblAutoRange;
	Stdctrls::TLabel* lblDataValuesZ;
	Stdctrls::TLabel* lblMin;
	Stdctrls::TLabel* lblMax;
	Stdctrls::TLabel* lblNumberFormat;
	Stdctrls::TCheckBox* cbDataValuesY;
	Stdctrls::TCheckBox* cbDataValuesY2;
	Stdctrls::TCheckBox* cbDataValuesZ;
	Stdctrls::TEdit* editMinY;
	Stdctrls::TEdit* editMinY2;
	Stdctrls::TEdit* editMinZ;
	Stdctrls::TEdit* editMaxY;
	Stdctrls::TEdit* editMaxY2;
	Stdctrls::TEdit* editMaxZ;
	Stdctrls::TComboBox* cbNumberFormatY;
	Stdctrls::TComboBox* cbNumberFormatY2;
	Stdctrls::TComboBox* cbNumberFormatZ;
	Stdctrls::TGroupBox* gbDivisions;
	Stdctrls::TLabel* lblY;
	Stdctrls::TLabel* lblY2;
	Stdctrls::TLabel* lblZ;
	Stdctrls::TLabel* lblDivisions;
	Stdctrls::TLabel* lblDivisionType;
	Stdctrls::TEdit* editDivisionsY;
	Stdctrls::TEdit* editDivisionsY2;
	Stdctrls::TEdit* editDivisionsZ;
	Stdctrls::TComboBox* cbDivisionTypeY;
	Stdctrls::TComboBox* cbDivisionTypeY2;
	Stdctrls::TComboBox* cbDivisionTypeZ;
	Stdctrls::TLabel* lblNumber;
	Stdctrls::TListBox* lbNumbers;
	Stdctrls::TLabel* lblCount;
	Stdctrls::TEdit* editCount;
	Stdctrls::TGroupBox* GroupBox1;
	Stdctrls::TLabel* lblTop;
	Stdctrls::TLabel* lblLeft;
	Stdctrls::TLabel* Label1;
	Stdctrls::TLabel* lblWidth;
	Stdctrls::TLabel* lblHeight;
	Stdctrls::TButton* btnBorder;
	Stdctrls::TButton* btnFormat;
	Stdctrls::TEdit* editTop;
	Stdctrls::TEdit* editLeft;
	Stdctrls::TEdit* editWidth;
	Stdctrls::TEdit* editHeight;
	Stdctrls::TComboBox* cbSection;
	Extctrls::TRadioGroup* rgUnits;
	Stdctrls::TLabel* lblLegendLayout;
	Stdctrls::TComboBox* cbLegendLayout;
	Stdctrls::TRadioButton* rbShowLabelValue;
	void __fastcall FormShow(System::TObject* Sender);
	void __fastcall FormClose(System::TObject* Sender, Forms::TCloseAction &Action);
	void __fastcall btnClearClick(System::TObject* Sender);
	void __fastcall sbGraphTypeClick(System::TObject* Sender);
	void __fastcall tvTypesClick(System::TObject* Sender);
	void __fastcall btnOkClick(System::TObject* Sender);
	void __fastcall FormCreate(System::TObject* Sender);
	void __fastcall lbNumbersClick(System::TObject* Sender);
	void __fastcall InitializeControls(bool OnOff);
	void __fastcall UpdateGraphs(void);
	void __fastcall sbFontClick(System::TObject* Sender);
	void __fastcall editTitleChange(System::TObject* Sender);
	void __fastcall editSubTitleChange(System::TObject* Sender);
	void __fastcall editFootnoteChange(System::TObject* Sender);
	void __fastcall editGroupsTitleChange(System::TObject* Sender);
	void __fastcall editSeriesTitleChange(System::TObject* Sender);
	void __fastcall editXAxisTitleChange(System::TObject* Sender);
	void __fastcall editYAxisTitleChange(System::TObject* Sender);
	void __fastcall editZAxisTitleChange(System::TObject* Sender);
	void __fastcall cbColorChange(System::TObject* Sender);
	void __fastcall cbLegendChange(System::TObject* Sender);
	void __fastcall cbPieSizeChange(System::TObject* Sender);
	void __fastcall cbPieSliceChange(System::TObject* Sender);
	void __fastcall cbBarSizeChange(System::TObject* Sender);
	void __fastcall cbBarDirectionChange(System::TObject* Sender);
	void __fastcall cbViewingAngleChange(System::TObject* Sender);
	void __fastcall cbMarkerSizeChange(System::TObject* Sender);
	void __fastcall cbMarkerShapeChange(System::TObject* Sender);
	void __fastcall rbNoneClick(System::TObject* Sender);
	void __fastcall rbShowLabelClick(System::TObject* Sender);
	void __fastcall rbShowValueClick(System::TObject* Sender);
	void __fastcall cbNumberFormatChange(System::TObject* Sender);
	void __fastcall GraphAxisMajorGridLineClick(System::TObject* Sender);
	void __fastcall GraphAxisMinorGridLineClick(System::TObject* Sender);
	void __fastcall GraphAxisDivisionTypeChange(System::TObject* Sender);
	void __fastcall editDivisionsEnter(System::TObject* Sender);
	void __fastcall editDivisionsExit(System::TObject* Sender);
	void __fastcall DataValuesAutoRangeClick(System::TObject* Sender);
	void __fastcall MinEnter(System::TObject* Sender);
	void __fastcall MinExit(System::TObject* Sender);
	void __fastcall MaxEnter(System::TObject* Sender);
	void __fastcall MaxExit(System::TObject* Sender);
	void __fastcall NumberFormatChange(System::TObject* Sender);
	void __fastcall editEditKeyPress(System::TObject* Sender, char &Key);
	void __fastcall rgUnitsClick(System::TObject* Sender);
	void __fastcall editSizeEnter(System::TObject* Sender);
	void __fastcall editSizeExit(System::TObject* Sender);
	void __fastcall cbSectionChange(System::TObject* Sender);
	void __fastcall btnBorderClick(System::TObject* Sender);
	void __fastcall btnFormatClick(System::TObject* Sender);
	void __fastcall cbLegendLayoutChange(System::TObject* Sender);
	void __fastcall rbShowLabelValueClick(System::TObject* Sender);
	
public:
	Ucrpe32::TCrpe* Cr;
	short GIndex;
	AnsiString prevNum;
	AnsiString PrevSize;
public:
	#pragma option push -w-inl
	/* TCustomForm.Create */ inline __fastcall virtual TCrpeGraphsDlg(Classes::TComponent* AOwner) : Forms::TForm(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.CreateNew */ inline __fastcall virtual TCrpeGraphsDlg(Classes::TComponent* AOwner, int Dummy) : Forms::TForm(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TCrpeGraphsDlg(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TCrpeGraphsDlg(HWND ParentWindow) : Forms::TForm(ParentWindow) { }
	#pragma option pop
	
};

#pragma pack(pop)

//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TCrpeGraphsDlg* CrpeGraphsDlg;
extern PACKAGE bool bGraphs;

}	/* namespace Udgraphs */
using namespace Udgraphs;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// UDGraphs
