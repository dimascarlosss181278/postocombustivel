// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'UDPrintOptions.pas' rev: 6.00

#ifndef UDPrintOptionsHPP
#define UDPrintOptionsHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <UCrpe32.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Udprintoptions
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TCrpePrintOptionsDlg;
class PASCALIMPLEMENTATION TCrpePrintOptionsDlg : public Forms::TForm 
{
	typedef Forms::TForm inherited;
	
__published:
	Extctrls::TPanel* pnlPrintOptions;
	Stdctrls::TLabel* lblCopies;
	Stdctrls::TLabel* lblOutputFileName;
	Extctrls::TRadioGroup* rgPages;
	Stdctrls::TEdit* editStopPage1;
	Stdctrls::TEdit* editStartPage2;
	Stdctrls::TEdit* editStopPage2;
	Stdctrls::TCheckBox* cbCollation;
	Stdctrls::TEdit* editOutputFileName;
	Stdctrls::TButton* btnOk;
	Stdctrls::TButton* btnCancel;
	Stdctrls::TButton* btnClear;
	Stdctrls::TButton* btnPrompt;
	Stdctrls::TEdit* editCopies;
	void __fastcall FormShow(System::TObject* Sender);
	void __fastcall FormClose(System::TObject* Sender, Forms::TCloseAction &Action);
	void __fastcall editCopiesChange(System::TObject* Sender);
	void __fastcall cbCollationClick(System::TObject* Sender);
	void __fastcall rgPagesClick(System::TObject* Sender);
	void __fastcall editOutputFileNameChange(System::TObject* Sender);
	void __fastcall btnPromptClick(System::TObject* Sender);
	void __fastcall btnClearClick(System::TObject* Sender);
	void __fastcall UpdatePrintOptions(void);
	void __fastcall btnOkClick(System::TObject* Sender);
	void __fastcall FormCreate(System::TObject* Sender);
	void __fastcall btnCancelClick(System::TObject* Sender);
	void __fastcall editStartPage2Change(System::TObject* Sender);
	void __fastcall editStopPage2Change(System::TObject* Sender);
	void __fastcall editStopPage1Change(System::TObject* Sender);
	void __fastcall InitializeControls(bool OnOff);
	
public:
	Ucrpe32::TCrpe* Cr;
	bool rCollation;
	Word rCopies;
	AnsiString rOutputFileName;
	Word rStartPage;
	Word rStopPage;
public:
	#pragma option push -w-inl
	/* TCustomForm.Create */ inline __fastcall virtual TCrpePrintOptionsDlg(Classes::TComponent* AOwner) : Forms::TForm(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.CreateNew */ inline __fastcall virtual TCrpePrintOptionsDlg(Classes::TComponent* AOwner, int Dummy) : Forms::TForm(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TCrpePrintOptionsDlg(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TCrpePrintOptionsDlg(HWND ParentWindow) : Forms::TForm(ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TCrpePrintOptionsDlg* CrpePrintOptionsDlg;
extern PACKAGE bool bPrintOptions;

}	/* namespace Udprintoptions */
using namespace Udprintoptions;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// UDPrintOptions
