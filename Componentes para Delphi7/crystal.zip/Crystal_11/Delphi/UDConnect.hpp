// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'UDConnect.pas' rev: 6.00

#ifndef UDConnectHPP
#define UDConnectHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <UCrpe32.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Udconnect
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TCrpeConnectDlg;
class PASCALIMPLEMENTATION TCrpeConnectDlg : public Forms::TForm 
{
	typedef Forms::TForm inherited;
	
__published:
	Extctrls::TPanel* pnlConnect1;
	Stdctrls::TLabel* lblCServerName;
	Stdctrls::TLabel* lblCDatabaseName;
	Stdctrls::TLabel* lblCUserID;
	Stdctrls::TLabel* lblCPassword;
	Stdctrls::TEdit* editServerName;
	Stdctrls::TEdit* editDatabaseName;
	Stdctrls::TEdit* editUserID;
	Stdctrls::TEdit* editPassword;
	Stdctrls::TCheckBox* cbPropagate;
	Stdctrls::TButton* btnOk;
	Stdctrls::TButton* btnCancel;
	Stdctrls::TButton* btnClear;
	Stdctrls::TButton* btnTest;
	void __fastcall FormClose(System::TObject* Sender, Forms::TCloseAction &Action);
	void __fastcall FormShow(System::TObject* Sender);
	void __fastcall btnTestClick(System::TObject* Sender);
	void __fastcall btnClearClick(System::TObject* Sender);
	void __fastcall editServerNameChange(System::TObject* Sender);
	void __fastcall editUserIDChange(System::TObject* Sender);
	void __fastcall editPasswordChange(System::TObject* Sender);
	void __fastcall editDatabaseNameChange(System::TObject* Sender);
	void __fastcall cbPropagateClick(System::TObject* Sender);
	void __fastcall UpdateConnect(void);
	void __fastcall btnOkClick(System::TObject* Sender);
	void __fastcall FormCreate(System::TObject* Sender);
	void __fastcall btnCancelClick(System::TObject* Sender);
	void __fastcall InitializeControls(bool OnOff);
	
public:
	Ucrpe32::TCrpe* Cr;
	AnsiString rServerName;
	AnsiString rUserID;
	AnsiString rPassword;
	AnsiString rDatabaseName;
	bool rPropagate;
public:
	#pragma option push -w-inl
	/* TCustomForm.Create */ inline __fastcall virtual TCrpeConnectDlg(Classes::TComponent* AOwner) : Forms::TForm(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.CreateNew */ inline __fastcall virtual TCrpeConnectDlg(Classes::TComponent* AOwner, int Dummy) : Forms::TForm(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TCrpeConnectDlg(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TCrpeConnectDlg(HWND ParentWindow) : Forms::TForm(ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TCrpeConnectDlg* CrpeConnectDlg;
extern PACKAGE bool bConnect;

}	/* namespace Udconnect */
using namespace Udconnect;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// UDConnect
