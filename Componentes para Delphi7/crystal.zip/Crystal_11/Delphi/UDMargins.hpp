// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'UDMargins.pas' rev: 6.00

#ifndef UDMarginsHPP
#define UDMarginsHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <UCrpe32.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Udmargins
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TCrpeMarginsDlg;
class PASCALIMPLEMENTATION TCrpeMarginsDlg : public Forms::TForm 
{
	typedef Forms::TForm inherited;
	
__published:
	Extctrls::TPanel* pnlMargins;
	Extctrls::TRadioGroup* rgMarginScale;
	Extctrls::TPanel* pnlMargins2;
	Stdctrls::TEdit* editTop;
	Stdctrls::TEdit* editLeft;
	Stdctrls::TEdit* editRight;
	Stdctrls::TEdit* editBottom;
	Stdctrls::TButton* btnOk;
	Stdctrls::TButton* btnCancel;
	Stdctrls::TButton* btnClear;
	void __fastcall FormShow(System::TObject* Sender);
	void __fastcall FormClose(System::TObject* Sender, Forms::TCloseAction &Action);
	void __fastcall btnClearClick(System::TObject* Sender);
	void __fastcall rgMarginScaleClick(System::TObject* Sender);
	void __fastcall editTopChange(System::TObject* Sender);
	void __fastcall editRightChange(System::TObject* Sender);
	void __fastcall editLeftChange(System::TObject* Sender);
	void __fastcall editBottomChange(System::TObject* Sender);
	void __fastcall editMarginsKeyPress(System::TObject* Sender, char &Key);
	void __fastcall btnOkClick(System::TObject* Sender);
	void __fastcall btnCancelClick(System::TObject* Sender);
	void __fastcall FormCreate(System::TObject* Sender);
	void __fastcall InitializeControls(bool OnOff);
	void __fastcall UpdateMargins(void);
	
private:
	short crTop;
	short crLeft;
	short crBottom;
	short crRight;
	
public:
	Ucrpe32::TCrpe* Cr;
public:
	#pragma option push -w-inl
	/* TCustomForm.Create */ inline __fastcall virtual TCrpeMarginsDlg(Classes::TComponent* AOwner) : Forms::TForm(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.CreateNew */ inline __fastcall virtual TCrpeMarginsDlg(Classes::TComponent* AOwner, int Dummy) : Forms::TForm(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TCrpeMarginsDlg(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TCrpeMarginsDlg(HWND ParentWindow) : Forms::TForm(ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TCrpeMarginsDlg* CrpeMarginsDlg;
extern PACKAGE bool bMargins;

}	/* namespace Udmargins */
using namespace Udmargins;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// UDMargins
