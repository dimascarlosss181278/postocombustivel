// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'CRDynamic.pas' rev: 6.00

#ifndef CRDynamicHPP
#define CRDynamicHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Windows.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Crdynamic
{
//-- type declarations -------------------------------------------------------
typedef BOOL __stdcall (*TPEOpenEngine)(void);

typedef void __stdcall (*TPECloseEngine)(void);

typedef BOOL __stdcall (*TPECanCloseEngine)(void);

#pragma pack(push, 1)
struct PEEngineOptions
{
	Word structSize;
	Word openEngineType;
	BOOL multiThreadedClonedJobs;
	BOOL skipPerTaskInit;
	BOOL skipOleInit;
	Word maxNBackgroundThreads;
} ;
#pragma pack(pop)

typedef BOOL __stdcall (*TPEOpenEngineEx)(PEEngineOptions &EngineOptions);

typedef short __stdcall (*TPEOpenPrintJob)(char * reportFilePath);

typedef BOOL __stdcall (*TPEClosePrintJob)(short printJob);

typedef char PEDllNameType[128];

typedef char PEServerNameType[128];

typedef char PEDatabaseNameType[128];

typedef char PEUserIDType[128];

typedef char PEPasswordType[128];

typedef char PEServerType[128];

typedef Byte *crBytePointer;

#pragma pack(push, 1)
struct PETablePrivateInfo
{
	Word structSize;
	short nBytes;
	unsigned tag;
	void *dataPtr;
} ;
#pragma pack(pop)

typedef char PETableLocationType[256];

typedef char PEConnectBufferType[512];

#pragma pack(push, 1)
struct PETableInfo
{
	Word StructSize;
	short FileType;
	char Location[256];
	char SubLocation[256];
	char ConnectBuffer[512];
} ;
#pragma pack(pop)

typedef BOOL __stdcall (*TPESavePrintJob)(short printJob, char * reportFilePath);

typedef BOOL __stdcall (*TPESavePrintJobAs)(short printJob, char * reportFilePath, int saveAsFormat, void * reserved);

typedef BOOL __stdcall (*TPEStartPrintJob)(short printJob, BOOL waitUntilDone);

typedef void __stdcall (*TPECancelPrintJob)(short printJob);

typedef void __stdcall (*TPESetRefreshData)(short printJob, BOOL bUnknown);

typedef BOOL __stdcall (*TPEIsPrintJobFinished)(short printJob);

#pragma pack(push, 1)
struct PEJobInfo
{
	Word structSize;
	unsigned NumRecordsRead;
	unsigned NumRecordsSelected;
	unsigned NumRecordsPrinted;
	Word DisplayPageN;
	Word LatestPageN;
	Word StartPageN;
	BOOL PrintEnded;
} ;
#pragma pack(pop)

typedef short __stdcall (*TPEGetJobStatus)(short printJob, PEJobInfo &jobInfo);

typedef BOOL __stdcall (*TPESetTimeLimit)(short printJob, int timeLimit);

typedef int __stdcall (*TPEGetPercentCompleted)(short printJob);

typedef BOOL __stdcall (*TPESetReadRecordLimit)(short printJob, int recordsLimit);

typedef int __stdcall (*TPEGetReadPercentCompleted)(short printJob);

typedef BOOL __stdcall (*TPEIsJobPremature)(short printJob);

typedef BOOL __stdcall (*TPEGetStartPageNumber)(short printJob, int &pageN);

typedef BOOL __stdcall (*TPESetStartPageNumber)(short printJob, int pageN);

typedef short __stdcall (*TPEGetVersion)(short versionRequested);

typedef short __stdcall (*TPEGetErrorCode)(short printJob);

typedef BOOL __stdcall (*TPEGetErrorText)(short printJob, HWND &textHandle, short &textLength);

typedef BOOL __stdcall (*TPEGetHandleString)(HWND textHandle, char * buffer, short bufferLength);

typedef BOOL __stdcall (*TPEGetStringHandle)(char * inStr, HWND &outStrHandle, unsigned &outStrLength);

typedef BOOL __stdcall (*TPEGetStringHandleExW)(const wchar_t * inStr, HWND &outStrHandle, unsigned &outStrLength);

typedef short __stdcall (*TPEPrintReport)(char * reportFilePath, BOOL toDefaultPrinter, BOOL toWindow, char * title, int left, int top, int width, int height, unsigned style, HWND parentWindow);

#pragma pack(push, 1)
struct PEVersionInfo
{
	Word StructSize;
	Word major;
	Word minor;
	char letter;
} ;
#pragma pack(pop)

typedef BOOL __stdcall (*TPEGetReportVersion)(short printJob, PEVersionInfo &VersionInfo);

#pragma pack(push, 1)
struct PEReportOptions
{
	Word structSize;
	short saveDataWithReport;
	short saveSummariesWithReport;
	short useIndexForSpeed;
	short translateDOSStrings;
	short translateDOSMemos;
	short convertDateTimeType;
	short convertNullFieldToDefault;
	short morePrintEngineErrorMessages;
	short caseInsensitiveSQLData;
	short verifyOnEveryPrint;
	short zoomMode;
	short hasGroupTree;
	short dontGenerateDataForHiddenObjects;
	short performGroupingOnServer;
	short doAsyncQuery;
	short promptMode;
	short selectDistinctRecords;
	short alwaysSortLocally;
	short isReadOnly;
	short canSelectDistinctRecords;
	short useDummyData;
	short convertOtherNullsToDefault;
	short verifyStoredProceduresOnFirstRefresh;
	short keepImageColourDepth;
} ;
#pragma pack(pop)

typedef BOOL __stdcall (*TPEGetReportOptions)(short printJob, PEReportOptions &ReportOptions);

typedef BOOL __stdcall (*TPESetReportOptions)(short printJob, PEReportOptions &ReportOptions);

#pragma pack(push, 1)
struct PEGlobalOptions
{
	Word StructSize;
	short morePrintEngineErrorMessages;
	short matchLogOnInfo;
	short use70TextCompatibility;
	short disableThumbnailUpdates;
	short verifyWhenDatabaseDriverUpgraded;
} ;
#pragma pack(pop)

typedef BOOL __stdcall (*TPESetGlobalOptions)(PEGlobalOptions &globalOptions);

typedef short __stdcall (*TPEOpenSubreport)(short printJob, char * ReportName);

typedef BOOL __stdcall (*TPECloseSubreport)(short printJob);

typedef short __stdcall (*TPEGetNSubreportsInSection)(short printJob, short sectionCode);

typedef unsigned __stdcall (*TPEGetNthSubreportInSection)(short printJob, short sectionCode, short subreportN);

typedef char PESubreportNameType[128];

#pragma pack(push, 1)
struct PESubreportInfo
{
	Word StructSize;
	char subreportName[128];
	short NLinks;
	short IsOnDemand;
	short IsExternal;
	short reimportOption;
} ;
#pragma pack(pop)

typedef BOOL __stdcall (*TPEGetSubreportInfo)(short printJob, unsigned subreportHandle, PESubreportInfo &subreportInfo);

typedef BOOL __stdcall (*TPESetDialogParentWindow)(short printJob, HWND parentWindow);

typedef BOOL __stdcall (*TPEEnableProgressDialog)(short printJob, BOOL enable);

typedef BOOL __stdcall (*TPEGetAllowPromptDialog)(short printJob);

typedef BOOL __stdcall (*TPESetAllowPromptDialog)(short printJob, BOOL showPromptDialog);

typedef BOOL __stdcall (*TPEGetPrintDate)(short printJob, short &year, short &month, short &day);

typedef BOOL __stdcall (*TPESetPrintDate)(short printJob, short year, short month, short day);

typedef short __stdcall (*TPEGetNGroups)(short printJob);

typedef BOOL __stdcall (*TPEGetGroupCondition)(short printJob, short sectionCode, HWND &conditionFieldHandle, short &conditionFieldLength, short &condition, short &sortDirection);

typedef BOOL __stdcall (*TPESetGroupCondition)(short printJob, short sectionCode, char * conditionField, short condition, short sortDirection);

typedef BOOL __stdcall (*TPESwapGroups)(short printJob, short sourceGroupN, short targetGroupN);

typedef char PEFieldNameType[512];

#pragma pack(push, 1)
struct PEGroupOptions
{
	Word structSize;
	short condition;
	char FieldName[512];
	short sortDirection;
	short repeatGroupHeader;
	short keepGroupTogether;
	short topOrBottomNGroups;
	char topOrBottomNSortFieldName[512];
	short nTopOrBottomGroups;
	short discardOtherGroups;
	short ignored;
	short hierarchicalSorting;
	char instanceIDField[512];
	char parentIDField[512];
	int groupIndent;
	short customizeGroupName;
	char notInTopOrBottomNName[512];
} ;
#pragma pack(pop)

typedef BOOL __stdcall (*TPEGetGroupOptions)(short printJob, short groupN, PEGroupOptions &groupOptions);

typedef BOOL __stdcall (*TPESetGroupOptions)(short printJob, short groupN, PEGroupOptions &groupOptions);

typedef short __stdcall (*TPEGetNSections)(short printJob);

typedef short __stdcall (*TPEGetNSectionsInArea)(short printJob, short areaCode);

typedef short __stdcall (*TPEGetSectionCode)(short printJob, short nSection);

typedef BOOL __stdcall (*TPEGetMinimumSectionHeight)(short printJob, short sectionCode, short &minimumHeight);

typedef BOOL __stdcall (*TPESetMinimumSectionHeight)(short printJob, short sectionCode, short minimumHeight);

typedef BOOL __stdcall (*TPEGetSectionHeight)(short printJob, short sectionCode, short &Height);

typedef BOOL __stdcall (*TPESetSectionHeight)(short printJob, short sectionCode, short Height);

typedef BOOL __stdcall (*TPEGetSectionWidth)(short printJob, short sectionCode, short &width);

#pragma pack(push, 1)
struct PESectionOptions
{
	Word structSize;
	short Visible;
	short newPageBefore;
	short newPageAfter;
	short keepTogether;
	short suppressBlankSection;
	short resetPageNAfter;
	short printAtBottomOfPage;
	unsigned backgroundColor;
	short underlaySection;
	short showArea;
	short freeFormPlacement;
	short reserveMinimumPageFooter;
	HWND hCssClass;
	short cssClassLen;
} ;
#pragma pack(pop)

typedef BOOL __stdcall (*TPEGetSectionFormat)(short printJob, short sectionCode, PESectionOptions &options);

typedef BOOL __stdcall (*TPESetSectionFormat)(short printJob, short sectionCode, PESectionOptions &options);

typedef BOOL __stdcall (*TPEGetAreaFormat)(short printJob, short areaCode, PESectionOptions &options);

typedef BOOL __stdcall (*TPESetAreaFormat)(short printJob, short areaCode, PESectionOptions &options);

typedef BOOL __stdcall (*TPESetFont)(short printJob, short sectionCode, short scopeCode, char * faceName, short fontFamily, short fontPitch, short charSet, short pointSize, short isItalic, short isUnderlined, short isStruckOut, short weight);

#pragma pack(push, 1)
struct PEGraphTypeInfo
{
	Word structSize;
	short graphType;
	short graphSubtype;
} ;
#pragma pack(pop)

typedef BOOL __stdcall (*TPEGetGraphTypeInfo)(short printJob, short sectionN, short graphN, PEGraphTypeInfo &graphTypeInfo);

typedef BOOL __stdcall (*TPESetGraphTypeInfo)(short printJob, short sectionN, short graphN, PEGraphTypeInfo &graphTypeInfo);

typedef BOOL __stdcall (*TPEGetGraphTextInfo)(short printJob, short sectionN, short graphN, Word titleType, HWND &title, short &titleLength);

typedef BOOL __stdcall (*TPESetGraphTextInfo)(short printJob, short sectionN, short graphN, Word titleType, char * title);

typedef char PEFaceNameType[64];

#pragma pack(push, 1)
struct PEFontColorInfo
{
	Word structSize;
	char faceName[64];
	short fontFamily;
	short fontPitch;
	short charSet;
	short pointSize;
	short isItalic;
	short isUnderlined;
	short isStruckOut;
	short weight;
	unsigned color;
	short twipSize;
} ;
#pragma pack(pop)

typedef BOOL __stdcall (*TPEGetGraphFontInfo)(short printJob, short sectionN, short graphN, Word titleFontType, PEFontColorInfo &fontColorInfo);

typedef BOOL __stdcall (*TPESetGraphFontInfo)(short printJob, short sectionN, short graphN, Word titleFontType, PEFontColorInfo &fontColorInfo);

#pragma pack(push, 1)
struct PEGraphOptionInfo
{
	Word structSize;
	short graphColor;
	short showLegend;
	short legendPosition;
	short pieSize;
	short detachedPieSlice;
	short barSize;
	short verticalBars;
	short markerSize;
	short markerShape;
	short dataPoints;
	short dataValueNumberFormat;
	short viewingAngle;
	short legendLayout;
} ;
#pragma pack(pop)

typedef BOOL __stdcall (*TPEGetGraphOptionInfo)(short printJob, short sectionN, short graphN, PEGraphOptionInfo &graphOptionInfo);

typedef BOOL __stdcall (*TPESetGraphOptionInfo)(short printJob, short sectionN, short graphN, PEGraphOptionInfo &graphOptionInfo);

#pragma pack(push, 1)
struct PEGraphAxisInfo
{
	Word structSize;
	short groupAxisGridLine;
	short dataAxisYGridLine;
	short dataAxisY2GridLine;
	short seriesAxisGridline;
	double dataAxisYMinValue;
	double dataAxisYMaxValue;
	double dataAxisY2MinValue;
	double dataAxisY2MaxValue;
	double seriesAxisMinValue;
	double seriesAxisMaxValue;
	short dataAxisYNumberFormat;
	short dataAxisY2NumberFormat;
	short seriesAxisNumberFormat;
	short dataAxisYAutoRange;
	short dataAxisY2AutoRange;
	short seriesAxisAutoRange;
	short dataAxisYAutomaticDivision;
	short dataAxisY2AutomaticDivision;
	short seriesAxisAutomaticDivision;
	int dataAxisYManualDivision;
	int dataAxisY2ManualDivision;
	int seriesAxisManualDivision;
	short dataAxisYAutoScale;
	short dataAxisY2AutoScale;
	short seriesAxisAutoScale;
} ;
#pragma pack(pop)

typedef BOOL __stdcall (*TPEGetGraphAxisInfo)(short printJob, short sectionN, short graphN, PEGraphAxisInfo &graphAxisInfo);

typedef BOOL __stdcall (*TPESetGraphAxisInfo)(short printJob, short sectionN, short graphN, PEGraphAxisInfo &graphAxisInfo);

typedef short __stdcall (*TPEGetNFormulas)(short printJob);

typedef BOOL __stdcall (*TPEGetNthFormula)(short printJob, short formulaN, HWND &nameHandle, short &nameLength, HWND &textHandle, short &textLength);

typedef BOOL __stdcall (*TPEGetFormula)(short printJob, char * formulaName, HWND &textHandle, short &textLength);

typedef BOOL __stdcall (*TPESetFormula)(short printJob, char * formulaName, char * formulaString);

typedef BOOL __stdcall (*TPECheckFormula)(short printJob, char * formulaName);

typedef BOOL __stdcall (*TPEGetSelectionFormula)(short printJob, HWND &textHandle, short &textLength);

typedef BOOL __stdcall (*TPESetSelectionFormula)(short printJob, char * formulaString);

typedef BOOL __stdcall (*TPECheckSelectionFormula)(short printJob);

typedef BOOL __stdcall (*TPEGetGroupSelectionFormula)(short printJob, HWND &textHandle, short &textLength);

typedef BOOL __stdcall (*TPESetGroupSelectionFormula)(short printJob, char * formulaString);

typedef BOOL __stdcall (*TPECheckGroupSelectionFormula)(short printJob);

typedef BOOL __stdcall (*TPEGetSectionFormatFormula)(short printJob, short sectionCode, short formulaName, HWND &textHandle, short &textLength);

typedef BOOL __stdcall (*TPESetSectionFormatFormula)(short printJob, short sectionCode, short formulaName, char * formulaString);

typedef BOOL __stdcall (*TPEGetAreaFormatFormula)(short printJob, short areaCode, short formulaName, HWND &textHandle, short &textLength);

typedef BOOL __stdcall (*TPESetAreaFormatFormula)(short printJob, short areaCode, short formulaName, char * formulaString);

typedef short __stdcall (*TPEGetNSQLExpressions)(short printJob);

typedef BOOL __stdcall (*TPEGetNthSQLExpression)(short printJob, short expressionN, HWND &nameHandle, short &nameLength, HWND &textHandle, short &textLength);

typedef BOOL __stdcall (*TPEGetSQLExpression)(short printJob, const char * expressionName, HWND &textHandle, short &textLength);

typedef BOOL __stdcall (*TPESetSQLExpression)(short printJob, const char * expressionName, const char * expressionString);

typedef BOOL __stdcall (*TPECheckSQLExpression)(short printJob, const char * expressionName);

typedef char PEProcParamNameType[128];

#pragma pack(push, 1)
struct PEParameterInfo
{
	Word structSize;
	short paramType;
	char Name[128];
} ;
#pragma pack(pop)

typedef char PEPFReportNameType[128];

typedef char PEPFNameType[256];

typedef char PEPFPromptType[256];

typedef char PEPFValueType[256];

typedef char PEPFEditMaskType[256];

#pragma pack(push, 1)
struct PEParameterFieldInfo
{
	Word structSize;
	Word ValueType;
	Word DefaultValueSet;
	Word CurrentValueSet;
	char Name[256];
	char Prompt[256];
	char DefaultValue[256];
	char CurrentValue[256];
	char ReportName[128];
	Word needsCurrentValue;
	Word isLimited;
	double MinSize;
	double MaxSize;
	char EditMask[256];
	Word isHidden;
	Word isLinked;
} ;
#pragma pack(pop)

typedef short __stdcall (*TPEGetNParameterFields)(short printJob);

typedef BOOL __stdcall (*TPEGetNthParameterField)(short printJob, short parameterN, PEParameterFieldInfo &parameterInfo);

typedef BOOL __stdcall (*TPESetNthParameterField)(short printJob, short parameterN, PEParameterFieldInfo &parameterInfo);

typedef char PEVIStringType[256];

typedef short PEVIDateOrTimeType[3];

typedef short PEVIDateTimeType[6];

#pragma pack(push, 1)
struct PEValueInfo
{
	Word structSize;
	Word valueType;
	double viNumber;
	double viCurrency;
	BOOL viBoolean;
	char viString[256];
	short viDate[3];
	short viDateTime[6];
	short viTime[3];
	unsigned viColor;
	short viInteger;
	char viC;
	char ignored;
	unsigned viLong;
} ;
#pragma pack(pop)

typedef wchar_t PEVIStringWType[256];

#pragma pack(push, 1)
struct PEValueInfoW
{
	Word structSize;
	Word valueType;
	double viNumber;
	double viCurrency;
	BOOL viBoolean;
	wchar_t viString[256];
	short viDate[3];
	short viDateTime[6];
	short viTime[3];
	unsigned viColor;
	short viInteger;
	char viC;
	char ignored;
	unsigned viLong;
	HWND viHandle;
} ;
#pragma pack(pop)

typedef BOOL __stdcall (*TPEConvertPFInfoToVInfo)(char * value, short valueType, PEValueInfo &valueInfo);

typedef BOOL __stdcall (*TPEConvertVInfoToPFInfo)(PEValueInfo &valueInfo, Word &valueType, char * value);

typedef short __stdcall (*TPEGetNParameterDefaultValues)(short printJob, const char * parameterFieldName, const char * reportName);

typedef BOOL __stdcall (*TPEGetNthParameterDefaultValue)(short printJob, const char * parameterFieldName, const char * reportName, short index, PEValueInfo &valueInfo);

typedef BOOL __stdcall (*TPESetNthParameterDefaultValue)(short printJob, const char * parameterFieldName, const char * reportName, short index, PEValueInfo &valueInfo);

typedef BOOL __stdcall (*TPEAddParameterDefaultValue)(short printJob, const char * parameterFieldName, const char * reportName, PEValueInfo &valueInfo);

typedef BOOL __stdcall (*TPEDeleteNthParameterDefaultValue)(short printJob, const char * parameterFieldName, const char * reportName, short index);

typedef BOOL __stdcall (*TPEGetParameterMinMaxValue)(short printJob, const char * parameterFieldName, const char * reportName, PEValueInfo &valueMin, PEValueInfo &valueMax);

typedef BOOL __stdcall (*TPESetParameterMinMaxValue)(short printJob, const char * parameterFieldName, const char * reportName, PEValueInfo &valueMin, PEValueInfo &valueMax);

typedef BOOL __stdcall (*TPEGetNthParameterValueDescription)(short printJob, char * parameterFieldName, char * reportName, short index, HWND &valueDesc, short &valueDescLength);

typedef BOOL __stdcall (*TPESetNthParameterValueDescription)(short printJob, char * parameterFieldName, char * reportName, short index, char * valueDesc);

#pragma pack(push, 1)
struct PEParameterPickListOption
{
	Word structSize;
	short showDescOnly;
	short sortMethod;
	short sortBasedOnDesc;
} ;
#pragma pack(pop)

typedef BOOL __stdcall (*TPEGetParameterPickListOption)(short printJob, char * parameterFieldName, char * reportName, PEParameterPickListOption &pickListOption);

typedef BOOL __stdcall (*TPESetParameterPickListOption)(short printJob, char * parameterFieldName, char * reportName, PEParameterPickListOption &pickListOption);

#pragma pack(push, 1)
struct PEParameterValueInfo
{
	Word structSize;
	short isNullable;
	short disallowEditing;
	short allowMultipleValues;
	short hasDiscreteValues;
	short partOfGroup;
	short groupNum;
	short mutuallyExclusiveGroup;
} ;
#pragma pack(pop)

typedef BOOL __stdcall (*TPEGetParameterValueInfo)(short printJob, const char * parameterFieldName, const char * reportName, PEParameterValueInfo &valueInfo);

typedef BOOL __stdcall (*TPESetParameterValueInfo)(short printJob, const char * parameterFieldName, const char * reportName, PEParameterValueInfo &valueInfo);

typedef short __stdcall (*TPEGetNParameterCurrentValues)(short printJob, const char * parameterFieldName, const char * reportName);

typedef BOOL __stdcall (*TPEGetNthParameterCurrentValue)(short printJob, const char * parameterFieldName, const char * reportName, short index, PEValueInfo &currentValue);

typedef BOOL __stdcall (*TPEAddParameterCurrentValue)(short printJob, const char * parameterFieldName, const char * reportName, PEValueInfo &currentValue);

typedef BOOL __stdcall (*TPEAddParameterCurrentValueW)(short printJob, const wchar_t * parameterFieldName, const wchar_t * reportName, PEValueInfoW &currentValue);

typedef short __stdcall (*TPEGetNParameterCurrentRanges)(short printJob, const char * parameterFieldName, const char * reportName);

typedef BOOL __stdcall (*TPEGetNthParameterCurrentRange)(short printJob, const char * parameterFieldName, const char * reportName, short index, PEValueInfo &rangeStart, PEValueInfo &rangeEnd, short &rangeInfo);

typedef BOOL __stdcall (*TPEAddParameterCurrentRange)(short printJob, const char * parameterFieldName, const char * reportName, PEValueInfo &rangeStart, PEValueInfo &rangeEnd, short rangeInfo);

typedef BOOL __stdcall (*TPEAddParameterCurrentRangeW)(short printJob, const wchar_t * parameterFieldName, const wchar_t * reportName, PEValueInfoW &rangeStart, PEValueInfoW &rangeEnd, short rangeInfo);

typedef BOOL __stdcall (*TPEClearParameterCurrentValuesAndRanges)(short printJob, const char * parameterFieldName, const char * reportName);

typedef short __stdcall (*TPEGetNthParameterType)(short printJob, short index);

typedef short __stdcall (*TPEGetNSortFields)(short printJob);

typedef BOOL __stdcall (*TPEGetNthSortField)(short printJob, short sortFieldN, HWND &nameHandle, short &nameLength, short &direction);

typedef BOOL __stdcall (*TPESetNthSortField)(short printJob, short sortFieldN, char * Name, short direction);

typedef BOOL __stdcall (*TPEDeleteNthSortField)(short printJob, short sortFieldN);

typedef short __stdcall (*TPEGetNGroupSortFields)(short printJob);

typedef BOOL __stdcall (*TPEGetNthGroupSortField)(short printJob, short sortFieldN, HWND &nameHandle, short &nameLength, short &direction);

typedef BOOL __stdcall (*TPESetNthGroupSortField)(short printJob, short sortFieldN, char * Name, short direction);

typedef BOOL __stdcall (*TPEDeleteNthGroupSortField)(short printJob, short sortFieldN);

typedef short __stdcall (*TPEGetNTables)(short printJob);

typedef char PEDllNameType2[64];

typedef wchar_t PEDllNameTypeW[64];

typedef char PEFullNameType[256];

#pragma pack(push, 1)
struct PETableType
{
	Word structSize;
	char DLLName[64];
	char DescriptiveName[256];
	Word DBType;
	BOOL notUsed;
} ;
#pragma pack(pop)

typedef BOOL __stdcall (*TPEGetNthTableType)(short printJob, short tableN, PETableType &tableType);

typedef char PESesPassType[128];

#pragma pack(push, 1)
struct PESessionInfo
{
	Word structSize;
	char UserID[128];
	char Password[128];
	unsigned SessionHandle;
} ;
#pragma pack(pop)

typedef BOOL __stdcall (*TPEGetNthTableSessionInfo)(short printJob, short tableN, PESessionInfo &sessionInfo);

typedef BOOL __stdcall (*TPESetNthTableSessionInfo)(short printJob, short tableN, PESessionInfo &sessionInfo, BOOL propagateAcrossTables);

typedef char PELogonServerType[128];

typedef char PELogonDbType[128];

typedef char PELogonUserType[128];

typedef char PELogonPassType[128];

#pragma pack(push, 1)
struct PELogOnInfo
{
	Word structSize;
	char ServerName[128];
	char DatabaseName[128];
	char UserId[128];
	char Password[128];
} ;
#pragma pack(pop)

typedef BOOL __stdcall (*TPEGetNthTableLogOnInfo)(short printJob, short tableN, PELogOnInfo &logOnInfo);

typedef BOOL __stdcall (*TPESetNthTableLogOnInfo)(short printJob, short tableN, PELogOnInfo &logOnInfo, BOOL propagateAcrossTables);

#pragma pack(push, 1)
struct PETableLocation
{
	Word structSize;
	char Location[256];
	char SubLocation[256];
	char ConnectBuffer[512];
} ;
#pragma pack(pop)

typedef BOOL __stdcall (*TPEGetNthTableLocation)(short printJob, short tableN, PETableLocation &location);

typedef BOOL __stdcall (*TPESetNthTableLocation)(short printJob, short tableN, PETableLocation &location);

typedef BOOL __stdcall (*TPEGetNthTablePrivateInfo)(short printJob, short tableN, PETablePrivateInfo &privateInfo);

typedef BOOL __stdcall (*TPESetNthTablePrivateInfo)(short printJob, short tableN, PETablePrivateInfo &privateInfo);

typedef BOOL __stdcall (*TPETestNthTableConnectivity)(short printJob, short tableN);

typedef BOOL __stdcall (*TPELogOnServer)(char * dllName, PELogOnInfo &logOnInfo);

typedef BOOL __stdcall (*TPELogOffServer)(char * dllName, PELogOnInfo &logOnInfo);

typedef BOOL __stdcall (*TPELogOnSQLServerWithPrivateInfo)(char * dllName, void * privateInfo);

typedef BOOL __stdcall (*TPEVerifyDatabase)(short printJob);

#pragma pack(push, 1)
struct PETableDifferenceInfo
{
	Word structSize;
	unsigned tableDifferences;
	unsigned reserved1;
	unsigned reserved2;
} ;
#pragma pack(pop)

typedef BOOL __stdcall (*TPECheckNthTableDifferences)(short printJob, short tableN, PETableDifferenceInfo &tableDifferenceInfo);

typedef BOOL __stdcall (*TPEGetSQLQuery)(short printJob, HWND &textHandle, short &textLength);

typedef BOOL __stdcall (*TPESetSQLQuery)(short printJob, char * queryString);

typedef BOOL __stdcall (*TPEHasSavedData)(short printJob, BOOL &hasSavedData);

typedef BOOL __stdcall (*TPEDiscardSavedData)(short printJob);

typedef BOOL __stdcall (*TPEGetReportTitle)(short printJob, HWND &titleHandle, short &titleLength);

typedef BOOL __stdcall (*TPESetReportTitle)(short printJob, char * title);

typedef BOOL __stdcall (*TPEOutputToWindow)(short printJob, char * title, unsigned left, unsigned top, unsigned width, unsigned height, unsigned style, HWND parentWindow);

typedef HWND __stdcall (*TPEGetWindowHandle)(short printJob);

typedef void __stdcall (*TPECloseWindow)(short printJob);

#pragma pack(push, 1)
struct PEWindowOptions
{
	Word structSize;
	short hasGroupTree;
	short canDrillDown;
	short hasNavigationControls;
	short hasCancelButton;
	short hasPrintButton;
	short hasExportButton;
	short hasZoomControl;
	short hasCloseButton;
	short hasProgressControls;
	short hasSearchButton;
	short hasPrintSetupButton;
	short hasRefreshButton;
	short showToolbarTips;
	short showDocumentTips;
	short hasLaunchButton;
} ;
#pragma pack(pop)

typedef BOOL __stdcall (*TPEGetWindowOptions)(short printJob, PEWindowOptions &options);

typedef BOOL __stdcall (*TPESetWindowOptions)(short printJob, PEWindowOptions &options);

typedef BOOL __stdcall (*TPEShowPrintControls)(short printJob, BOOL showPrintControls);

typedef BOOL __stdcall (*TPEPrintControlsShowing)(short printJob, BOOL &controlsShowing);

typedef BOOL __stdcall (*TPEShowFirstPage)(short printJob);

typedef BOOL __stdcall (*TPEShowNextPage)(short printJob);

typedef BOOL __stdcall (*TPEShowPreviousPage)(short printJob);

typedef BOOL __stdcall (*TPEShowLastPage)(short printJob);

typedef short __stdcall (*TPEGetNPages)(short printJob);

typedef BOOL __stdcall (*TPEShowNthPage)(short printJob, short pageN);

typedef BOOL __stdcall (*TPEZoomPreviewWindow)(short printJob, short level);

typedef BOOL __stdcall (*TPENextPrintWindowMagnification)(short printJob);

typedef BOOL __stdcall (*TPEPrintWindow)(short printJob, BOOL waitUntilDone);

typedef BOOL __stdcall (*TPEExportPrintWindow)(short printJob, BOOL toMail, BOOL waitUntilDone);

typedef BOOL __stdcall (*TPEOutputToPrinter)(short printJob, short nCopies);

typedef BOOL __stdcall (*TPESelectPrinter)(short printJob, char * driverName, char * printerName, char * portName, Windows::PDeviceModeA mode);

typedef BOOL __stdcall (*TPESelectPrinterW)(short printJob, wchar_t * driverName, wchar_t * printerName, wchar_t * portName, Windows::PDeviceModeW mode);

typedef BOOL __stdcall (*TPEGetSelectedPrinter)(short printJob, HWND &driverHandle, short &driverLength, HWND &printerHandle, short &printerLength, HWND &portHandle, short &portLength, Windows::PDeviceModeA &mode);

typedef BOOL __stdcall (*TPEGetNDetailCopies)(short printJob, short &nCopies);

typedef BOOL __stdcall (*TPESetNDetailCopies)(short printJob, short nCopies);

typedef char PEOutputFileNameType[512];

#pragma pack(push, 1)
struct PEPrintOptions
{
	Word structSize;
	Word StartPageN;
	Word StopPageN;
	Word nReportCopies;
	Word Collation;
	char outputFileName[512];
} ;
#pragma pack(pop)

typedef BOOL __stdcall (*TPEGetPrintOptions)(short printJob, PEPrintOptions &options);

typedef BOOL __stdcall (*TPESetPrintOptions)(short printJob, PEPrintOptions &options);

#pragma pack(push, 1)
struct PEExportOptions
{
	Word structSize;
	char formatDLLName[64];
	unsigned formatType;
	void *formatOptions;
	char destinationDLLName[64];
	unsigned destinationType;
	void *destinationOptions;
	Word nFormatOptionsBytes;
	Word nDestinationOptionsBytes;
	BOOL unicodeFormatOptions;
	BOOL unicodeDestinationOptions;
} ;
#pragma pack(pop)

#pragma pack(push, 1)
struct PEExportOptionsW
{
	Word structSize;
	wchar_t formatDLLName[64];
	unsigned formatType;
	void *formatOptions;
	wchar_t destinationDLLName[64];
	unsigned destinationType;
	void *destinationOptions;
	unsigned nFormatOptionsBytes;
	unsigned nDestinationOptionsBytes;
	BOOL unicodeFormatOptions;
	BOOL unicodeDestinationOptions;
} ;
#pragma pack(pop)

typedef BOOL __stdcall (*TPEGetExportOptions)(short printJob, PEExportOptions &options);

typedef BOOL __stdcall (*TPEGetExportOptionsW)(short printJob, PEExportOptionsW &options);

typedef BOOL __stdcall (*TPEExportTo)(short printJob, PEExportOptions &options);

#pragma pack(push, 1)
struct UXDNotesOptions
{
	Word structSize;
	char *szDBName;
	char *szFormName;
	char *szComments;
} ;
#pragma pack(pop)

#pragma pack(push, 1)
struct UXDMAPIOptions
{
	Word structSize;
	char *toList;
	char *ccList;
	char *subject;
	char *mailmessage;
	Word nRecipients;
	void *recipients;
	char *userName;
	char *password;
	Word nEncodedBytes;
} ;
#pragma pack(pop)

#pragma pack(push, 1)
struct UXDVIMOptions
{
	Word structSize;
	char *toList;
	char *ccList;
	char *bccList;
	char *subject;
	char *mailmessage;
	char *username;
	char *password;
	Word nEncodedBytes;
} ;
#pragma pack(pop)

#pragma pack(push, 1)
struct UXDPostFolderOptions
{
	Word structSize;
	char *pszProfile;
	char *pszPassword;
	Word wDestType;
	char *pszFolderPath;
	Word nEncodedBytes;
} ;
#pragma pack(pop)

#pragma pack(push, 1)
struct UXDApplicationOptions
{
	Word structSize;
	char *fileName;
} ;
#pragma pack(pop)

#pragma pack(push, 1)
struct UXDDiskOptions
{
	Word structSize;
	char *fileName;
} ;
#pragma pack(pop)

#pragma pack(push, 1)
struct UXFXlsOptions
{
	Word structSize;
	BOOL bColumnHeadings;
	BOOL bUseConstColWidth;
	double fConstColWidth;
	BOOL bTabularFormat;
	Word baseAreaType;
	Word baseAreaGroupNum;
	BOOL bUseWorksheetFunc;
	BOOL bExportPageBreaks;
	BOOL bCnvrtDateValToStr;
	BOOL bExportAllPages;
	Word wReserved1;
	Word wReserved2;
	BOOL bExportPageHeaders;
	unsigned dwStartPageNumber32;
	unsigned dwEndPageNumber32;
	BOOL bChopPageHeader;
	BOOL bExportImagesInDataOnly;
	BOOL bUseFormatInDataOnly;
	BOOL bMaintainColumnAlignment;
	BOOL bMaintainRelativeObjectPosition;
	BOOL bShowGridlines;
	Word wExportPageAreaPair;
} ;
#pragma pack(pop)

#pragma pack(push, 1)
struct UXFPaginatedTextOptions
{
	Word structSize;
	Word nLinesPerPage;
	BOOL useDefaultCPI;
	unsigned userDefinedCPI;
} ;
#pragma pack(pop)

#pragma pack(push, 1)
struct UXFRecordStyleOptions
{
	Word structSize;
	BOOL useReportNumberFormat;
	BOOL useReportDateFormat;
} ;
#pragma pack(pop)

#pragma pack(push, 1)
struct UXFCharCommaTabSeparatedOptions
{
	Word structSize;
	BOOL useReportNumberFormat;
	BOOL useReportDateFormat;
	char stringDelimiter;
	char *fieldDelimiter;
	Word nEncodedBytes;
} ;
#pragma pack(pop)

#pragma pack(push, 1)
struct UXFODBCOptions
{
	Word structSize;
	char *dataSourceName;
	char *dataSourceUserID;
	char *dataSourcePassword;
	char *exportTableName;
	Word nEncodedBytes;
} ;
#pragma pack(pop)

typedef unsigned PEDWordArray[3];

typedef unsigned *PPEDWordArray;

#pragma pack(push, 1)
struct UXFHTML3Options
{
	Word structSize;
	char *fileName;
	BOOL pageNavigator;
	BOOL separatePages;
	Word imageExtStyle;
	Word nPageRanges;
	unsigned *pfirstPageNo;
	unsigned *plastPageNo;
} ;
#pragma pack(pop)

#pragma pack(push, 1)
struct UXFPDFFormatOptions
{
	unsigned structSize;
	BOOL exportPageRange;
	Word reserved1;
	Word reserved2;
	Word reserved3;
	Word reserved4;
	unsigned firstPageNo;
	unsigned lastPageNo;
} ;
#pragma pack(pop)

#pragma pack(push, 1)
struct UXFERTFFormatOptions
{
	unsigned structSize;
	BOOL exportPageRange;
	Word reserved1;
	Word reserved2;
	Word reserved3;
	Word reserved4;
	unsigned firstPageNo;
	unsigned lastPageNo;
} ;
#pragma pack(pop)

#pragma pack(push, 1)
struct UXFEditableRTFFormatOptions
{
	unsigned structSize;
	BOOL exportPageRange;
	unsigned firstPageNo;
	unsigned lastPageNo;
	BOOL exportPageBreaks;
} ;
#pragma pack(pop)

#pragma pack(push, 1)
struct UXFXMLOptions
{
	Word structSize;
	char *fileName;
	short allowMultipleFiles;
} ;
#pragma pack(pop)

#pragma pack(push, 1)
struct UXFEDOCFormatOptions
{
	unsigned structSize;
	BOOL exportPageRange;
	Word reserved1;
	Word reserved2;
	Word reserved3;
	Word reserved4;
	unsigned firstPageNo;
	unsigned lastPageNo;
} ;
#pragma pack(pop)

typedef BOOL __stdcall (*TPEGetMargins)(short printJob, Word &left, Word &right, Word &top, Word &bottom);

typedef BOOL __stdcall (*TPESetMargins)(short printJob, Word left, Word right, Word top, Word bottom);

typedef char PEApplicationNameType[128];

typedef char PETitleType[128];

typedef char PESubjectType[128];

typedef char PEAuthorType[128];

typedef char PEKeywordsType[128];

typedef char PECommentsType[512];

typedef char PEReportTemplateType[128];

#pragma pack(push, 1)
struct PEReportSummaryInfo
{
	Word structSize;
	char applicationName[128];
	char title[128];
	char subject[128];
	char author[128];
	char keywords[128];
	char comments[512];
	char reportTemplate[128];
	short savePreviewPicture;
} ;
#pragma pack(pop)

typedef BOOL __stdcall (*TPEGetReportSummaryInfo)(short printJob, PEReportSummaryInfo &summaryInfo);

typedef BOOL __stdcall (*TPESetReportSummaryInfo)(short printJob, PEReportSummaryInfo &summaryInfo);

#pragma pack(push, 1)
struct PEEnableEventInfo
{
	Word structSize;
	short startStopEvent;
	short readingRecordEvent;
	short printWindowButtonEvent;
	short drillEvent;
	short closePrintWindowEvent;
	short activatePrintWindowEvent;
	short fieldMappingEvent;
	short mouseClickEvent;
	short hyperlinkEvent;
	short launchSeagateAnalysisEvent;
	short formattingEvent;
} ;
#pragma pack(pop)

typedef BOOL __stdcall (*TPEEnableEvent)(short printJob, PEEnableEventInfo &enableEventInfo);

typedef BOOL __stdcall (*TPEGetEnableEventInfo)(short printJob, PEEnableEventInfo &enableEventInfo);

typedef BOOL __stdcall (*TPESetEventCallback)(short printJob, void * callbackProc, void * userData);

#pragma pack(push, 1)
struct PEGeneralPrintWindowEventInfo
{
	Word structSize;
	Word ignored;
	HWND windowHandle;
} ;
#pragma pack(pop)

#pragma pack(push, 1)
struct PEStartEventInfo
{
	Word structSize;
	Word destination;
} ;
#pragma pack(pop)

#pragma pack(push, 1)
struct PEStopEventInfo
{
	Word structSize;
	Word destination;
	Word jobStatus;
} ;
#pragma pack(pop)

#pragma pack(push, 1)
struct PEReadingRecordsEventInfo
{
	Word structSize;
	short cancelled;
	unsigned recordsRead;
	unsigned recordsSelected;
	short done;
} ;
#pragma pack(pop)

#pragma pack(push, 1)
struct PEZoomLevelChangingEventInfo
{
	Word structSize;
	Word zoomLevel;
	HWND windowHandle;
} ;
#pragma pack(pop)

#pragma pack(push, 1)
struct PECloseButtonClickedEventInfo
{
	Word structSize;
	Word viewIndex;
	HWND windowHandle;
} ;
#pragma pack(pop)

typedef wchar_t PESearchStringType[128];

#pragma pack(push, 1)
struct PESearchButtonClickedEventInfo
{
	HWND windowHandle;
	wchar_t searchString[128];
	Word structSize;
} ;
#pragma pack(pop)

#pragma pack(push, 1)
struct PEGroupTreeButtonClickedEventInfo
{
	Word structSize;
	short Visible;
	HWND windowHandle;
} ;
#pragma pack(pop)

typedef wchar_t *PEGroupArray[1];

typedef wchar_t * *PPEGroupArray;

#pragma pack(push, 1)
struct PEShowGroupEventInfo
{
	Word structSize;
	Word groupLevel;
	HWND windowHandle;
	wchar_t * *groupList;
} ;
#pragma pack(pop)

#pragma pack(push, 1)
struct PEDrillOnGroupEventInfo
{
	Word structSize;
	Word drillType;
	HWND windowHandle;
	wchar_t * *groupList;
	Word groupLevel;
} ;
#pragma pack(pop)

typedef PEDrillOnGroupEventInfo *PPEDrillOnGroupEventInfo;

typedef wchar_t PEDrillVIStringType[256];

#pragma pack(push, 1)
struct PEDrillValueInfo
{
	Word structSize;
	Word valueType;
	double viNumber;
	double viCurrency;
	BOOL viBoolean;
	wchar_t viString[256];
	short viDate[3];
	short viDateTime[6];
	short viTime[3];
	unsigned viColor;
	short viInteger;
	char viC;
	char ignored;
	unsigned viLong;
} ;
#pragma pack(pop)

typedef wchar_t PEDrillDetailFieldNameType[512];

#pragma pack(push, 1)
struct PEFieldValueInfo
{
	Word structSize;
	Word ignored;
	wchar_t fieldName[512];
	PEDrillValueInfo fieldValue;
	Word reserved1;
	Word reserved2;
} ;
#pragma pack(pop)

typedef PEFieldValueInfo *PPEFieldValueInfo;

typedef PEFieldValueInfo *PEFieldValueInfoArray[1];

typedef PPEFieldValueInfo *PPEFieldValueInfoArray;

#pragma pack(push, 1)
struct PEDrillOnDetailEventInfo
{
	Word structSize;
	short selectedFieldIndex;
	HWND windowHandle;
	PPEFieldValueInfo *fieldValueList;
	short nFieldValue;
} ;
#pragma pack(pop)

#pragma pack(push, 1)
struct PEMouseClickEventInfo
{
	Word structSize;
	HWND windowHandle;
	int clickAction;
	int clickFlags;
	int xOffset;
	int yOffset;
	PEDrillValueInfo fieldValue;
	Word reserved1;
	unsigned objectHandle;
	Word reserved2;
	short sectionCode;
} ;
#pragma pack(pop)

typedef BOOL __stdcall (*TPEGetFieldMappingType)(short printJob, Word &mappingType);

typedef BOOL __stdcall (*TPESetFieldMappingType)(short printJob, Word mappingType);

typedef char PETableAliasNameType[128];

typedef char PEDatabaseFieldNameType[128];

#pragma pack(push, 1)
struct PEReportFieldMappingInfo
{
	Word structSize;
	Word valueType;
	char tableAliasName[128];
	char databaseFieldName[128];
	int mappingTo;
} ;
#pragma pack(pop)

typedef PEReportFieldMappingInfo *PPEReportFieldMappingInfo;

typedef PEReportFieldMappingInfo *PEMappingInfoArray[1];

typedef PPEReportFieldMappingInfo *PPEMappingInfoArray;

#pragma pack(push, 1)
struct PEFieldMappingEventInfo
{
	Word structSize;
	PPEReportFieldMappingInfo *reportFields;
	Word nReportFields;
	PPEReportFieldMappingInfo *databaseFields;
	Word nDatabaseFields;
} ;
#pragma pack(pop)

#pragma pack(push, 1)
struct PEHyperlinkEventInfo
{
	Word StructSize;
	Word ignored;
	HWND windowHandle;
	wchar_t *hyperlinkText;
} ;
#pragma pack(pop)

#pragma pack(push, 1)
struct PELaunchSeagateAnalysisEventInfo
{
	Word StructSize;
	Word ignored;
	HWND windowHandle;
	wchar_t *pathFile;
} ;
#pragma pack(pop)

#pragma pack(push, 1)
struct PETrackCursorInfo
{
	Word structSize;
	short groupAreaCursor;
	short groupAreaFieldCursor;
	short detailAreaCursor;
	short detailAreaFieldCursor;
	short graphCursor;
	unsigned groupAreaCursorHandle;
	unsigned groupAreaFieldCursorHandle;
	unsigned detailAreaCursorHandle;
	unsigned detailAreaFieldCursorHandle;
	unsigned graphCursorHandle;
	short ondemandSubreportCursor;
	short hyperlinkCursor;
} ;
#pragma pack(pop)

typedef BOOL __stdcall (*TPEGetTrackCursorInfo)(short printJob, PETrackCursorInfo &cursorInfo);

typedef BOOL __stdcall (*TPESetTrackCursorInfo)(short printJob, PETrackCursorInfo &cursorInfo);

typedef short __stdcall (*TPEGetNObjectsInSection)(short printJob, short sectionCode);

typedef unsigned __stdcall (*TPEGetNthObjectInSection)(short printJob, short sectionCode, short objectN);

typedef BOOL __stdcall (*TPEGetObjectFormat)(short printJob, unsigned objectHandle, short objectFormatName, PEValueInfo &valueInfo);

typedef BOOL __stdcall (*TPESetObjectFormat)(short printJob, unsigned objectHandle, short objectFormatName, PEValueInfo &valueInfo);

#pragma pack(push, 1)
struct PEObjectInfo
{
	Word StructSize;
	Word objectType;
	int xOffset;
	int yOffset;
	int width;
	int height;
	short sectionCode;
	short repositoryURILength;
	HWND hRepositoryURI;
} ;
#pragma pack(pop)

typedef BOOL __stdcall (*TPEGetObjectInfo)(short printJob, unsigned objectHandle, PEObjectInfo &objectInfo);

typedef BOOL __stdcall (*TPESetObjectInfo)(short printJob, unsigned objectHandle, PEObjectInfo &objectInfo);

typedef char PEOleObjectPathType[256];

#pragma pack(push, 1)
struct PEOleObjectInfo
{
	Word StructSize;
	Word oleObjectType;
	char linkSource[256];
	Word updateType;
} ;
#pragma pack(pop)

typedef BOOL __stdcall (*TPEGetOleObjectInfo)(short printJob, unsigned objectHandle, PEOleObjectInfo &oleObjectInfo);

typedef BOOL __stdcall (*TPEGetObjectFontColor)(short printJob, unsigned objectHandle, PEFontColorInfo &fontColorInfo);

typedef BOOL __stdcall (*TPESetObjectFontColor)(short printJob, unsigned objectHandle, PEFontColorInfo &fontColorInfo);

typedef unsigned __stdcall (*TPEChangeSummaryType)(short printJob, char * summarizedFieldName, short groupN, short oldSummaryType, short newSummaryType);

#pragma pack(push, 1)
struct PEFieldObjectInfo
{
	Word StructSize;
	short fieldType;
	Word valueType;
	Word nBytes;
	char fieldName[512];
} ;
#pragma pack(pop)

typedef BOOL __stdcall (*TPEGetFieldObjectInfo)(short printJob, unsigned fieldObjectHandle, PEFieldObjectInfo &fieldObjectInfo);

typedef short __stdcall (*TPEGetNParagraphs)(short printJob, unsigned textObjectHandle);

#pragma pack(push, 1)
struct PEParagraphInfo
{
	Word StructSize;
	short alignment;
	int firstLineIndent;
	int leftIndent;
	int rightIndent;
	int startText;
	int endText;
} ;
#pragma pack(pop)

typedef BOOL __stdcall (*TPEGetNthParagraphInfo)(short printJob, unsigned textObjectHandle, short paragraphN, PEParagraphInfo &paragraphInfo);

typedef BOOL __stdcall (*TPESetNthParagraphInfo)(short printJob, unsigned textObjectHandle, short paragraphN, PEParagraphInfo &paragraphInfo);

typedef short __stdcall (*TPEGetNTabStopsInParagraph)(short printJob, unsigned textObjectHandle, short paragraphN);

#pragma pack(push, 1)
struct PETabStopInfo
{
	Word StructSize;
	short alignment;
	int xOffset;
} ;
#pragma pack(pop)

typedef BOOL __stdcall (*TPEGetNthTabStopInfo)(short printJob, unsigned textObjectHandle, short paragraphN, short tabStopN, PETabStopInfo &tabStopInfo);

typedef BOOL __stdcall (*TPESetNthTabStopInfo)(short printJob, unsigned textObjectHandle, short paragraphN, short tabStopN, PETabStopInfo &tabStopInfo);

typedef BOOL __stdcall (*TPEAddTabStop)(short printJob, unsigned textObjectHandle, short paragraphN, PETabStopInfo &tabStopInfo);

typedef BOOL __stdcall (*TPEDeleteNthTabStop)(short printJob, unsigned textObjectHandle, short paragraphN, short tabStopN);

typedef short __stdcall (*TPEGetNEmbeddedFields)(short printJob, unsigned textObjectHandle);

#pragma pack(push, 1)
struct PEEmbeddedFieldInfo
{
	Word StructSize;
	Word fieldType;
	char fieldName[512];
	int startText;
	int endText;
} ;
#pragma pack(pop)

typedef BOOL __stdcall (*TPEGetNthEmbeddedFieldInfo)(short printJob, unsigned textObjectHandle, short embeddedFieldN, PEEmbeddedFieldInfo &embeddedFieldInfo);

typedef BOOL __stdcall (*TPEGetNthEmbeddedFieldFormat)(short printJob, unsigned textObjectHandle, short embeddedFieldN, short objectFormatName, PEValueInfo &valueInfo);

typedef BOOL __stdcall (*TPESetNthEmbeddedFieldFormat)(short printJob, unsigned textObjectHandle, short embeddedFieldN, short objectFormatName, PEValueInfo &valueInfo);

typedef BOOL __stdcall (*TPEGetNthEmbeddedFieldFormatFormula)(short printJob, unsigned textObjectHandle, short embeddedFieldN, short formulaName, HWND &textHandle, short &textLength);

typedef BOOL __stdcall (*TPESetNthEmbeddedFieldFormatFormula)(short printJob, unsigned textObjectHandle, short embeddedFieldN, short formulaName, char * formulaString);

typedef BOOL __stdcall (*TPEDeleteNthEmbeddedField)(short printJob, unsigned textObjectHandle, short embeddedFieldN);

typedef BOOL __stdcall (*TPEInsertEmbeddedField)(short printJob, unsigned textObjectHandle, int position, char * fieldName);

typedef BOOL __stdcall (*TPEGetTextFontColor)(short printJob, unsigned textObjectHandle, int position, PEFontColorInfo &fontColorInfo);

typedef BOOL __stdcall (*TPESetTextFontColor)(short printJob, unsigned textObjectHandle, int startPosition, int endPosition, PEFontColorInfo &fontColorInfo);

typedef int __stdcall (*TPEGetTextSize)(short printJob, unsigned textObjectHandle);

typedef int __stdcall (*TPEGetTextHeight)(short printJob, unsigned textObjectHandle);

typedef BOOL __stdcall (*TPEGetText)(short printJob, unsigned textObjectHandle, HWND &textHandle, short &textLength);

typedef BOOL __stdcall (*TPEInsertText)(short printJob, unsigned textObjectHandle, int position, char * text);

typedef BOOL __stdcall (*TPEDeleteText)(short printJob, unsigned textObjectHandle, int startText, int endText);

typedef char PEFilePathType[512];

#pragma pack(push, 1)
struct PEInsertTextInfo
{
	Word structSize;
	unsigned textObjectHandle;
	int position;
	unsigned reserved1;
	unsigned reserved2;
	HWND memoryHandle;
	char pathFile[512];
} ;
#pragma pack(pop)

typedef BOOL __stdcall (*TPEInsertTextEx)(short printJob, PEInsertTextInfo &insertTextInfo);

#pragma pack(push, 1)
struct PESubreportLinkInfo
{
	Word StructSize;
	char mainReportFieldName[512];
	char subreportFieldName[512];
	char promptVarFieldName[512];
} ;
#pragma pack(pop)

typedef BOOL __stdcall (*TPEGetNthSubreportLink)(short printJob, unsigned subreportHandle, short subreportLinkN, HWND mainReportFieldNameHandle, short mainReportFieldNameLength, HWND promptVarFieldNameHandle, short promptVarFieldNameLength);

typedef BOOL __stdcall (*TPEGetNthSubreportLinkEx)(short printJob, unsigned subreportHandle, short subreportLinkN, PESubreportLinkInfo &subreportLinkInfo);

typedef BOOL __stdcall (*TPEReimportSubreport)(short printJob, unsigned subreportHandle, BOOL &linkChanged, BOOL &reimported);

#pragma pack(push, 1)
struct PELineObjectInfo
{
	Word StructSize;
	short startSectionCode;
	short endSectionCode;
	short lineStyle;
	int leftXOffset;
	int topYOffset;
	int lineWidth;
	int rightXOffset;
	int bottomYOffset;
	unsigned lineColor;
	short expandToNextSection;
} ;
#pragma pack(pop)

typedef BOOL __stdcall (*TPEGetLineObjectInfo)(short printJob, unsigned lineObjectHandle, PELineObjectInfo &lineObjectInfo);

typedef BOOL __stdcall (*TPESetLineObjectInfo)(short printJob, unsigned lineObjectHandle, PELineObjectInfo &lineObjectInfo);

#pragma pack(push, 1)
struct PEBoxObjectInfo
{
	Word StructSize;
	short topLeftSectionCode;
	int leftXOffset;
	int topYOffset;
	short bottomRightSectionCode;
	short lineStyle;
	int rightXOffset;
	int bottomYOffset;
	int lineWidth;
	unsigned lineColor;
	unsigned fillColor;
	short dropShadow;
	short topBottomClose;
	short expandToNextSection;
	int cornerEllipseHeight;
	int cornerEllipseWidth;
} ;
#pragma pack(pop)

typedef BOOL __stdcall (*TPEGetBoxObjectInfo)(short printJob, unsigned boxObjectHandle, PEBoxObjectInfo &boxObjectInfo);

typedef BOOL __stdcall (*TPESetBoxObjectInfo)(short printJob, unsigned boxObjectHandle, PEBoxObjectInfo &boxObjectInfo);

#pragma pack(push, 1)
struct PEPictureFormatInfo
{
	Word StructSize;
	Word ignored;
	int leftCropping;
	int rightCropping;
	int topCropping;
	int bottomCropping;
	double xScaling;
	double yScaling;
} ;
#pragma pack(pop)

typedef BOOL __stdcall (*TPEGetPictureFormatInfo)(short printJob, unsigned objectHandle, PEPictureFormatInfo &pictureFormatInfo);

typedef BOOL __stdcall (*TPESetPictureFormatInfo)(short printJob, unsigned objectHandle, PEPictureFormatInfo &pictureFormatInfo);

#pragma pack(push, 1)
struct PECrossTabOptions
{
	Word StructSize;
	short showCellMargins;
	short suppressEmptyRows;
	short suppressEmptyCols;
	short keepColsTogether;
	short repeatRowLabels;
	short suppressRowGrandTotals;
	short suppressColGrandTotals;
	unsigned colorRowGrandTotals;
	unsigned colorColGrandTotals;
	short showGrid;
} ;
#pragma pack(pop)

typedef BOOL __stdcall (*TPEGetCrossTabOptions)(short printJob, unsigned hObject, PECrossTabOptions &crossTabOptions);

typedef short __stdcall (*TPEGetNSummariesInCrossTabObject)(short printJob, unsigned crossTabObjectHandle);

#pragma pack(push, 1)
struct PECrossTabSummaryFieldInfo
{
	Word StructSize;
	short summaryType;
	Word valueType;
	Word nBytes;
	char summarizedFieldName[512];
	unsigned crossTabObjectHandle;
	char secondSummarizedFieldName[512];
	short summaryParameter;
	short hierarchicalSummaryType;
} ;
#pragma pack(pop)

typedef BOOL __stdcall (*TPEGetNthSummaryInfoInCrossTabObject)(short printJob, unsigned crossTabObjectHandle, short summaryN, PECrossTabSummaryFieldInfo &summaryInfo);

#pragma pack(push, 1)
struct PECrossTabGroupOptions
{
	Word StructSize;
	short condition;
	short sortDirection;
	short showGrid;
	char fieldName[512];
	unsigned backColor;
	short suppressSubtotal;
	short suppressLabel;
} ;
#pragma pack(pop)

typedef short __stdcall (*TPEGetNGroupsInCrossTabObject)(short printJob, unsigned crossTabObjectHandle, short rowCol);

typedef BOOL __stdcall (*TPEGetNthCrossTabGroupOptions)(short printJob, unsigned crossTabObjectHandle, short rowCol, short rowColN, PECrossTabGroupOptions &crossTabGroupOptions);

typedef BOOL __stdcall (*TPEGetGraphNumber)(short printJob, unsigned graphObjectHandle, short &sectionCode, short &graphN);

#pragma pack(push, 1)
struct PEGraphDataTypeInfo
{
	Word StructSize;
	short graphDataType;
	unsigned crossTabObjectHandle;
} ;
#pragma pack(pop)

typedef BOOL __stdcall (*TPEGetGraphDataType)(short printJob, short sectionCode, short graphN, PEGraphDataTypeInfo &graphDataTypeInfo);

typedef BOOL __stdcall (*TPEGetObjectFormatFormula)(short printJob, unsigned objectHandle, short formulaName, HWND &textHandle, short &textLength);

typedef BOOL __stdcall (*TPESetObjectFormatFormula)(short printJob, unsigned objectHandle, short formulaName, char * formulaString);

typedef BOOL __stdcall (*TPEGetParameterBrowseField)(short printJob, char * parameterFieldName, char * reportName, HWND &textHandle, short &textLength);

typedef BOOL __stdcall (*TPESetParameterBrowseField)(short printJob, char * parameterFieldName, char * reportName, char * browseTableField);

typedef BOOL __stdcall (*TPEInsertSortField)(short printJob, short sortFieldN, char * name, short direction);

typedef BOOL __stdcall (*TPESwapSortFields)(short printJob, short sourceSortN, short targetSortN);

typedef short __stdcall (*TPEGetNLogicalTables)(short printJob);

typedef BOOL __stdcall (*TPEGetNthTableAliasName)(short printJob, short tableN, HWND &textHandle, short &textLength);

typedef BOOL __stdcall (*TPESetNthTableAliasName)(short printJob, short tableN, char * tableAliasName);

#pragma pack(push, 1)
struct PEServerTypeInfo
{
	Word StructSize;
	Word DBType;
	char ServerType[128];
} ;
#pragma pack(pop)

typedef BOOL __stdcall (*TPESetNthTableServerType)(short printJob, short tableN, PEServerTypeInfo &serverType, BOOL propagateAcrossTables);

typedef short __stdcall (*TPEGetNDatabaseFields)(short printJob, short tableN);

typedef char PETableNameType[128];

typedef char PEField_DescriptionType[128];

#pragma pack(push, 1)
struct PEDatabaseFieldInfo
{
	Word StructSize;
	Word valueType;
	char tableAliasName[128];
	char databaseFieldName[128];
	Word nBytes;
	char fieldDescription[128];
} ;
#pragma pack(pop)

typedef BOOL __stdcall (*TPEGetNthDatabaseFieldInfo)(short printJob, short tableN, short fieldN, PEDatabaseFieldInfo &fieldInfo);

typedef short PEFieldIndexArrayType[32];

#pragma pack(push, 1)
struct PEDatabaseLinkInfo
{
	Word StructSize;
	short srcTableN;
	short destTableN;
	short joinType;
	short lookUpType;
	short indexInUse;
	short srcFieldsIndex[32];
	short destFieldsIndex[32];
	short nIndexSrcFields;
	short nIndexDestFields;
	short partialMatch;
} ;
#pragma pack(pop)

typedef short __stdcall (*TPEGetNDatabaseLinks)(short printJob);

typedef BOOL __stdcall (*TPEGetNthDatabaseLinkInfo)(short printJob, short databaseLinkN, PEDatabaseLinkInfo &databaseLinkInfo);

typedef BOOL __stdcall (*TPESetDatabaseLinkInfo)(short printJob, PEDatabaseLinkInfo &databaseLinkInfo);

typedef BOOL __stdcall (*TPEConvertDatabaseDriver)(short printJob, char * toDllName, BOOL doConvert);

typedef BOOL __stdcall (*TPEFreeDevMode)(short printJob, Windows::PDeviceModeA pMode);

#pragma pack(push, 1)
struct PEDictionaryInfo
{
	Word StructSize;
	Word DictType;
	Word FromInfoView;
	Word HasRowRestrictions;
} ;
#pragma pack(pop)

typedef BOOL __stdcall (*TPEGetDictionaryInfo)(short printJob, PEDictionaryInfo &dictInfo);

typedef BOOL __stdcall (*TPEGetDictionaryLocation)(short printJob, PETableLocation &dictLocation);

typedef BOOL __stdcall (*TPEGetDirectoryUserId)(short printJob, HWND &textHandle, short &textLength);

typedef char PEFormulaNameType[128];

typedef char PEFormulaTextType[1024];

typedef char PESQLExpressionNameType[128];

typedef char PESQLExpressionTextType[1024];

#pragma pack(push, 1)
struct PEFieldDefinitionInfo
{
	Word StructSize;
	Word fieldType;
	char fieldName[512];
	Word valueType;
	Word nBytes;
	char tableAliasName[128];
	char databaseFieldName[128];
	char formulaFieldName[128];
	char formulaText[1024];
	char summarizedFieldName[512];
	Word summaryType;
	short headerAreaCode;
	short footerAreaCode;
	short groupN;
	Word specialVarType;
	char SQLExpressionFieldName[128];
	char SQLExpressionText[1024];
	short useCount;
	char secondSummarizedFieldName[512];
	short summaryParameter;
	short hierarchicalSummaryType;
} ;
#pragma pack(pop)

typedef BOOL __stdcall (*TPEGetFieldDefinitionInfo)(short printJob, char * fieldName, PEFieldDefinitionInfo &fieldDefinitionInfo);

typedef BOOL __stdcall (*TPEGetFormulaFieldInfo)(short printJob, char * formula, PEFieldDefinitionInfo &fieldDefinitionInfo);

typedef BOOL __stdcall (*TPEGetSQLExpressionFieldInfo)(short printJob, char * expression, PEFieldDefinitionInfo &fieldDefinitionInfo);

typedef short __stdcall (*TPEGetNSummaryFields)(short printJob);

#pragma pack(push, 1)
struct PESummaryFieldInfo
{
	Word StructSize;
	short summaryType;
	char fieldName[512];
	char summarizedFieldName[512];
	short headerAreaCode;
	short footerAreaCode;
	char secondSummarizedFieldName[512];
	short summaryParameter;
	short hierarchicalSummaryType;
} ;
#pragma pack(pop)

typedef BOOL __stdcall (*TPEGetNthSummaryFieldInfo)(short printJob, short summaryN, PESummaryFieldInfo &summaryFieldInfo);

typedef Word __stdcall (*TPEGetReportStyle)(short printJob);

typedef BOOL __stdcall (*TPESetReportStyle)(short printJob, Word style);

typedef char PEOlapConnectionStringType[1024];

typedef char PEOlapCubeNameType[128];

#pragma pack(push, 1)
struct PEOLAPLogOnInfo
{
	Word StructSize;
	char ServerName[128];
	char DatabaseName[128];
	char ConnectionString[1024];
	char CubeName[128];
	char UserID[128];
	char Password[128];
} ;
#pragma pack(pop)

typedef short __stdcall (*TPEGetNOLAPCubes)(short printJob);

typedef BOOL __stdcall (*TPEGetNthOLAPCubeLogOnInfo)(short printJob, short cubeN, PEOLAPLogOnInfo &logOnInfo);

typedef BOOL __stdcall (*TPESetNthOLAPCubeLogOnInfo)(short printJob, short cubeN, PEOLAPLogOnInfo &logOnInfo);

typedef BOOL __stdcall (*TPETestNthOlapCubeConnectivity)(short printJob, short cubeN);

#pragma pack(push, 1)
struct PENewGraphDataInfo
{
	Word StructSize;
	Word graphDataType;
	short forEachRecord;
	short dontSummarizeValues;
	short sectionCode;
} ;
#pragma pack(pop)

typedef BOOL __stdcall (*TPEGetGraphDataInfo)(short printJob, short sectionN, short graphN, PENewGraphDataInfo &graphDataInfo);

typedef short __stdcall (*TPEGetNGraphConditionFields)(short printJob, short sectionN, short graphN);

typedef BOOL __stdcall (*TPEGetNthGraphConditionField)(short printJob, short sectionN, short graphN, short condFieldN, HWND &fieldNameHandle, short &fieldNameLength);

typedef BOOL __stdcall (*TPESetNthGraphConditionField)(short printJob, short graphN, short condFieldN, char * fieldName);

typedef short __stdcall (*TPEGetNGraphSummaryFields)(short printJob, short sectionN, short graphN);

typedef BOOL __stdcall (*TPEGetNthGraphSummaryFieldInfo)(short printJob, short graphN, short fieldN, PEFieldDefinitionInfo &summaryFieldInfo);

typedef BOOL __stdcall (*TPEGetGraphTextDefaultOption)(short printJob, short sectionN, short graphN, Word titleType, BOOL &useDefault);

typedef BOOL __stdcall (*TPESetGraphTextDefaultOption)(short printJob, short sectionN, short graphN, Word titleType, BOOL useDefault);

#pragma pack(push, 1)
struct PEObjectHiliteInfo
{
	Word StructSize;
	short rangeCondition;
	double leftEndpoint;
	double rightEndpoint;
	unsigned fontColor;
	unsigned bkColor;
	short borderStyle;
	short fontStyle;
} ;
#pragma pack(pop)

typedef short __stdcall (*TPEGetObjectNHiliteConditions)(short printJob, unsigned hObject);

typedef BOOL __stdcall (*TPESetObjectNthHiliteCondition)(short printJob, unsigned hObject, short nHilite, PEObjectHiliteInfo &hiliteInfo);

typedef BOOL __stdcall (*TPEGetObjectNthHiliteCondition)(short printJob, unsigned hObject, short nHilite, PEObjectHiliteInfo &hiliteInfo);

typedef BOOL __stdcall (*TPEAddObjectHiliteCondition)(short printJob, unsigned hObject, PEObjectHiliteInfo &hiliteInfo);

typedef BOOL __stdcall (*TPERemoveObjectNthHiliteCondition)(short printJob, unsigned hObject, short nHilite);

typedef BOOL __stdcall (*TPEClearObjectHiliteConditions)(short printJob, unsigned hObject);

typedef BOOL __stdcall (*TPESetObjectNthHiliteConditionPriority)(short printJob, unsigned hObject, short nHilite, short newPriority);

#pragma pack(push, 1)
struct PERunningTotalInfo
{
	Word StructSize;
	short summaryOperation;
	short summaryOperationParameter;
	short evalCondition;
	short evalGroupN;
	short resetCondition;
	short resetGroupN;
} ;
#pragma pack(pop)

typedef short __stdcall (*TPEGetNRunningTotals)(short printJob);

typedef BOOL __stdcall (*TPEGetNthRunningTotalName)(short printJob, short runningtotalN, HWND &nameHandle, short &nameLength);

typedef BOOL __stdcall (*TPEGetRunningTotalInfo)(short printJob, char * rtName, PERunningTotalInfo &rtInfo);

typedef BOOL __stdcall (*TPEGetRunningTotalConditionField)(short printJob, char * rtName, HWND &hEvalField, short &evalLength, HWND &hResetField, short &resetLength);

typedef BOOL __stdcall (*TPEGetRunningTotalConditionFormula)(short printJob, char * rtName, HWND &hEvalFormula, short &evalLength, HWND &hResetFormula, short &resetLength);

typedef BOOL __stdcall (*TPEGetRunningTotalSummaryField)(short printJob, char * rtName, HWND &summaryFieldName, short &summaryLength, HWND &secondFieldName, short &secondLength);

#pragma pack(push, 1)
struct PEMapDataInfo
{
	Word StructSize;
	short sectionCode;
	short layout;
	short dontSummarizeValues;
} ;
#pragma pack(pop)

#pragma pack(push, 1)
struct PEMapStyle
{
	Word StructSize;
	Word ignored;
	short themeType;
	short themeSize;
	short themeStyle;
	short distributionMethod;
	unsigned colorLowestInterval;
	unsigned colorHighestInterval;
	short legendType;
	short legendTitleType;
} ;
#pragma pack(pop)

typedef BOOL __stdcall (*TPEGetMapDataInfo)(short printJob, unsigned hObject, PEMapDataInfo &mapInfo);

typedef BOOL __stdcall (*TPESetMapDataInfo)(short printJob, unsigned hObject, PEMapDataInfo &mapInfo);

typedef BOOL __stdcall (*TPEGetMapStyle)(short printJob, unsigned hObject, PEMapStyle &mapStyle);

typedef BOOL __stdcall (*TPESetMapStyle)(short printJob, unsigned hObject, PEMapStyle &mapStyle);

typedef short __stdcall (*TPEGetNMapSummaryFields)(short printJob, unsigned hObject);

typedef BOOL __stdcall (*TPEGetNthMapSummaryField)(short printJob, unsigned hObject, short nSummaryField, HWND &summaryField, short &summaryLength);

typedef BOOL __stdcall (*TPESetNthMapSummaryField)(short printJob, unsigned hObject, short nSummaryField, char * summaryField);

typedef short __stdcall (*TPEGetNMapConditionFields)(short printJob, unsigned hObject);

typedef BOOL __stdcall (*TPEGetNthMapConditionField)(short printJob, unsigned hObject, short condFieldN, HWND &conditionField, short &conditionLength);

typedef BOOL __stdcall (*TPESetNthMapConditionField)(short printJob, unsigned hObject, short condFieldN, char * fieldName);

#pragma pack(push, 1)
struct PEMapCondition
{
	Word StructSize;
	short orientation;
	short groupSelected;
} ;
#pragma pack(pop)

typedef BOOL __stdcall (*TPEGetMapConditions)(short printJob, unsigned hObject, PEMapCondition &mapCondition);

typedef BOOL __stdcall (*TPESetMapConditions)(short printJob, unsigned hObject, PEMapCondition &mapCondition);

typedef BOOL __stdcall (*TPEGetMapTitle)(short printJob, unsigned hObject, HWND &mapTitle, short &titleLength);

typedef BOOL __stdcall (*TPESetMapTitle)(short printJob, unsigned hObject, char * mapTitle);

typedef BOOL __stdcall (*TPEGetMapLegendTitle)(short printJob, unsigned hObject, HWND &legendTitle, short &legendLength);

typedef BOOL __stdcall (*TPESetMapLegendTitle)(short printJob, unsigned hObject, char * legendTitle);

typedef BOOL __stdcall (*TPEGetMapLegendSubtitle)(short printJob, unsigned hObject, HWND &legendSubtitle, short &legendLength);

typedef BOOL __stdcall (*TPESetMapLegendSubtitle)(short printJob, unsigned hObject, char * legendSubtitle);

typedef short PEFormulaSyntaxType[2];

#pragma pack(push, 1)
struct PEFormulaSyntax
{
	Word StructSize;
	short formulaSyntax[2];
} ;
#pragma pack(pop)

typedef BOOL __stdcall (*TPEGetFormulaSyntax)(short printJob, PEFormulaSyntax &formulaSyntax);

typedef BOOL __stdcall (*TPESetFormulaSyntax)(short printJob, PEFormulaSyntax &formulaSyntax);

#pragma pack(push, 1)
struct PEReportAlertInfo
{
	Word StructSize;
	short nameLength;
	HWND name;
	short isEnabled;
	short alertConditionLength;
	HWND alertConditionFormula;
	unsigned nTriggeredInstances;
	short alertMessageLength;
	short defaultAlertMessageLength;
	HWND alertMessageFormula;
	HWND defaultAlertMessage;
	short alertConditionFormulaSyntax;
	short alertMessageFormulaSyntax;
	short fromMainDocument;
	short alertReportNameLength;
	HWND alertReportName;
} ;
#pragma pack(pop)

#pragma pack(push, 1)
struct PEAlertInstanceInfo
{
	Word StructSize;
	short alertMessageLength;
	HWND alertMessage;
} ;
#pragma pack(pop)

typedef short __stdcall (*TPEGetNReportAlerts)(short printJob);

typedef BOOL __stdcall (*TPEGetNthReportAlert)(short printJob, short alertN, PEReportAlertInfo &reportAlertInfo);

typedef BOOL __stdcall (*TPEGetNthAlertInstanceInfo)(short printJob, short alertN, unsigned instanceN, PEAlertInstanceInfo &alertInstanceInfo);

typedef BOOL __stdcall (*TPESetNthAlertConditionFormula)(short printJob, short alertN, char * &formula);

typedef BOOL __stdcall (*TPESetNthAlertMessageFormula)(short printJob, short alertN, char * &formula);

typedef BOOL __stdcall (*TPESetNthAlertDefaultMessage)(short printJob, short alertN, char * &text);

typedef BOOL __stdcall (*TPEEnableNthAlert)(short printJob, short alertN, BOOL enabled);

typedef unsigned __stdcall (*TPEGetObjectByName)(short printJob, char * name);

typedef BOOL __stdcall (*TPEGetObjectName)(short printJob, unsigned objectHandle, HWND &objectNameHandle, short &objectNameLength);

typedef short __stdcall (*TPEGetSectionByName)(short printJob, char * name);

typedef short __stdcall (*TPEGetAreaByName)(short printJob, char * name);

typedef BOOL __stdcall (*TPEGetAreaName)(short printJob, short areaCode, HWND &nameHandle, short &nameLength);

typedef void __stdcall (*TPESetTempFilePath)(char * Path);

typedef BOOL __stdcall (*TPEGetNthGroupNameFormula)(short printJob, short groupN, HWND &textHandle, short &textLength);

typedef BOOL __stdcall (*TPESetNthGroupNameFormula)(short printJob, short groupN, char * fString);

class DELPHICLASS TCrpeEngine;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeEngine : public System::TObject 
{
	typedef System::TObject inherited;
	
private:
	void __fastcall CRDEngineError(const AnsiString sMessage);
	
public:
	BOOL __fastcall PELoadCrpeDll(const AnsiString CrpeLocation);
	BOOL __fastcall PEUnloadCrpeDll(void);
	BOOL __fastcall PEOpenEngine(void);
	BOOL __fastcall PEOpenEngineEx(PEEngineOptions &EngineOptions);
	void __fastcall PECloseEngine(void);
	BOOL __fastcall PECanCloseEngine(void);
	short __fastcall PEOpenPrintJob(char * reportFilePath);
	BOOL __fastcall PEClosePrintJob(short printJob);
	BOOL __fastcall PESavePrintJob(short printJob, char * reportFilePath);
	BOOL __fastcall PESavePrintJobAs(short printJob, char * reportFilePath, int saveAsFormat, void * reserved);
	BOOL __fastcall PEStartPrintJob(short printJob, BOOL waitUntilDone);
	void __fastcall PECancelPrintJob(short printJob);
	void __fastcall PESetRefreshData(short printJob, BOOL bUnknown);
	BOOL __fastcall PEIsPrintJobFinished(short printJob);
	short __fastcall PEGetJobStatus(short printJob, PEJobInfo &jobInfo);
	BOOL __fastcall PESetTimeLimit(short printJob, int timeLimit);
	int __fastcall PEGetPercentCompleted(short printJob);
	BOOL __fastcall PESetReadRecordLimit(short printJob, int recordsLimit);
	int __fastcall PEGetReadPercentCompleted(short printJob);
	BOOL __fastcall PEIsJobPremature(short printJob);
	BOOL __fastcall PEGetStartPageNumber(short printJob, int &pageN);
	BOOL __fastcall PESetStartPageNumber(short printJob, int pageN);
	short __fastcall PEGetVersion(short versionRequested);
	short __fastcall PEGetErrorCode(short printJob);
	BOOL __fastcall PEGetErrorText(short printJob, HWND &textHandle, short &textLength);
	BOOL __fastcall PEGetHandleString(HWND textHandle, char * buffer, short bufferLength);
	BOOL __fastcall PEGetStringHandle(const char * inStr, HWND &outStrHandle, unsigned &outStrLength);
	BOOL __fastcall PEGetStringHandleExW(const wchar_t * inStr, HWND &outStrHandle, unsigned &outStrLength);
	short __fastcall PEPrintReport(char * reportFilePath, BOOL toDefaultPrinter, BOOL toWindow, char * title, int left, int top, int width, int height, unsigned style, HWND parentWindow);
	BOOL __fastcall PEGetReportVersion(short printJob, PEVersionInfo &VersionInfo);
	BOOL __fastcall PEGetReportOptions(short printJob, PEReportOptions &reportOptions);
	BOOL __fastcall PESetReportOptions(short printJob, PEReportOptions &reportOptions);
	BOOL __fastcall PESetGlobalOptions(PEGlobalOptions &globalOptions);
	short __fastcall PEOpenSubreport(short parentJob, char * subreportName);
	BOOL __fastcall PECloseSubreport(short printJob);
	short __fastcall PEGetNSubreportsInSection(short printJob, short sectionCode);
	unsigned __fastcall PEGetNthSubreportInSection(short printJob, short sectionCode, short subreportN);
	BOOL __fastcall PEGetSubreportInfo(short printJob, unsigned subreportHandle, PESubreportInfo &subreportInfo);
	BOOL __fastcall PESetDialogParentWindow(short printJob, HWND parentWindow);
	BOOL __fastcall PEEnableProgressDialog(short printJob, BOOL enable);
	BOOL __fastcall PEGetAllowPromptDialog(short printJob);
	BOOL __fastcall PESetAllowPromptDialog(short printJob, BOOL showPromptDialog);
	BOOL __fastcall PEGetPrintDate(short printJob, short &year, short &month, short &day);
	BOOL __fastcall PESetPrintDate(short printJob, short year, short month, short day);
	short __fastcall PEGetNGroups(short printJob);
	BOOL __fastcall PEGetGroupCondition(short printJob, short sectionCode, HWND &conditionFieldHandle, short &conditionFieldLength, short &condition, short &sortDirection);
	BOOL __fastcall PESetGroupCondition(short printJob, short sectionCode, char * conditionField, short condition, short sortDirection);
	BOOL __fastcall PESwapGroups(short printJob, short sourceGroupN, short targetGroupN);
	BOOL __fastcall PEGetGroupOptions(short printJob, short groupN, PEGroupOptions &groupOptions);
	BOOL __fastcall PESetGroupOptions(short printJob, short groupN, PEGroupOptions &groupOptions);
	short __fastcall PEGetNSections(short printJob);
	short __fastcall PEGetNSectionsInArea(short printJob, short areaCode);
	short __fastcall PEGetSectionCode(short printJob, short sectionN);
	BOOL __fastcall PEGetMinimumSectionHeight(short printJob, short sectionCode, short &minimumHeight);
	BOOL __fastcall PESetMinimumSectionHeight(short printJob, short sectionCode, short minimumHeight);
	BOOL __fastcall PEGetSectionHeight(short printJob, short sectionCode, short &Height);
	BOOL __fastcall PESetSectionHeight(short printJob, short sectionCode, short Height);
	BOOL __fastcall PEGetSectionWidth(short printJob, short sectionCode, short &width);
	BOOL __fastcall PEGetSectionFormat(short printJob, short sectionCode, PESectionOptions &options);
	BOOL __fastcall PESetSectionFormat(short printJob, short sectionCode, PESectionOptions &options);
	BOOL __fastcall PEGetAreaFormat(short printJob, short areaCode, PESectionOptions &options);
	BOOL __fastcall PESetAreaFormat(short printJob, short areaCode, PESectionOptions &options);
	BOOL __fastcall PESetFont(short printJob, short sectionCode, short scopeCode, char * faceName, short fontFamily, short fontPitch, short charSet, short pointSize, short isItalic, short isUnderlined, short isStruckOut, short weight);
	BOOL __fastcall PEGetGraphTypeInfo(short printJob, short sectionN, short graphN, PEGraphTypeInfo &graphTypeInfo);
	BOOL __fastcall PESetGraphTypeInfo(short printJob, short sectionN, short graphN, PEGraphTypeInfo &graphTypeInfo);
	BOOL __fastcall PEGetGraphTextInfo(short printJob, short sectionN, short graphN, Word titleType, HWND &title, short &titleLength);
	BOOL __fastcall PESetGraphTextInfo(short printJob, short sectionN, short graphN, Word titleType, char * title);
	BOOL __fastcall PEGetGraphFontInfo(short printJob, short sectionN, short graphN, Word titleFontType, PEFontColorInfo &fontColorInfo);
	BOOL __fastcall PESetGraphFontInfo(short printJob, short sectionN, short graphN, Word titleFontType, PEFontColorInfo &fontColorInfo);
	BOOL __fastcall PEGetGraphOptionInfo(short printJob, short sectionN, short graphN, PEGraphOptionInfo &graphOptionInfo);
	BOOL __fastcall PESetGraphOptionInfo(short printJob, short sectionN, short graphN, PEGraphOptionInfo &graphOptionInfo);
	BOOL __fastcall PEGetGraphAxisInfo(short printJob, short sectionN, short graphN, PEGraphAxisInfo &graphAxisInfo);
	BOOL __fastcall PESetGraphAxisInfo(short printJob, short sectionN, short graphN, PEGraphAxisInfo &graphAxisInfo);
	short __fastcall PEGetNFormulas(short printJob);
	BOOL __fastcall PEGetNthFormula(short printJob, short formulaN, HWND &nameHandle, short &nameLength, HWND &textHandle, short &textLength);
	BOOL __fastcall PEGetFormula(short printJob, char * formulaName, HWND &textHandle, short &textLength);
	BOOL __fastcall PESetFormula(short printJob, char * formulaName, char * formulaString);
	BOOL __fastcall PECheckFormula(short printJob, char * formulaName);
	BOOL __fastcall PEGetSelectionFormula(short printJob, HWND &textHandle, short &textLength);
	BOOL __fastcall PESetSelectionFormula(short printJob, char * formulaString);
	BOOL __fastcall PECheckSelectionFormula(short printJob);
	BOOL __fastcall PEGetGroupSelectionFormula(short printJob, HWND &textHandle, short &textLength);
	BOOL __fastcall PESetGroupSelectionFormula(short printJob, char * formulaString);
	BOOL __fastcall PECheckGroupSelectionFormula(short printJob);
	BOOL __fastcall PEGetSectionFormatFormula(short printJob, short sectionCode, short formulaName, HWND &textHandle, short &textLength);
	BOOL __fastcall PESetSectionFormatFormula(short printJob, short sectionCode, short formulaName, char * formulaString);
	BOOL __fastcall PEGetAreaFormatFormula(short printJob, short areaCode, short formulaName, HWND &textHandle, short &textLength);
	BOOL __fastcall PESetAreaFormatFormula(short printJob, short areaCode, short formulaName, char * formulaString);
	short __fastcall PEGetNSQLExpressions(short printJob);
	BOOL __fastcall PEGetNthSQLExpression(short printJob, short expressionN, HWND &nameHandle, short &nameLength, HWND &textHandle, short &textLength);
	BOOL __fastcall PEGetSQLExpression(short printJob, const char * expressionName, HWND &textHandle, short &textLength);
	BOOL __fastcall PESetSQLExpression(short printJob, const char * expressionName, const char * expressionString);
	BOOL __fastcall PECheckSQLExpression(short printJob, const char * expressionName);
	short __fastcall PEGetNParameterFields(short printJob);
	BOOL __fastcall PEGetNthParameterField(short printJob, short parameterN, PEParameterFieldInfo &parameterInfo);
	BOOL __fastcall PESetNthParameterField(short printJob, short parameterN, PEParameterFieldInfo &parameterInfo);
	BOOL __fastcall PEConvertPFInfoToVInfo(char * value, short valueType, PEValueInfo &valueInfo);
	BOOL __fastcall PEConvertVInfoToPFInfo(PEValueInfo &valueInfo, Word &valueType, char * value);
	short __fastcall PEGetNParameterDefaultValues(short printJob, const char * parameterFieldName, const char * reportName);
	BOOL __fastcall PEGetNthParameterDefaultValue(short printJob, const char * parameterFieldName, const char * reportName, short index, PEValueInfo &valueInfo);
	BOOL __fastcall PESetNthParameterDefaultValue(short printJob, const char * parameterFieldName, const char * reportName, short index, PEValueInfo &valueInfo);
	BOOL __fastcall PEAddParameterDefaultValue(short printJob, const char * parameterFieldName, const char * reportName, PEValueInfo &valueInfo);
	BOOL __fastcall PEDeleteNthParameterDefaultValue(short printJob, const char * parameterFieldName, const char * reportName, short index);
	BOOL __fastcall PEGetParameterMinMaxValue(short printJob, const char * parameterFieldName, const char * reportName, PEValueInfo &valueMin, PEValueInfo &valueMax);
	BOOL __fastcall PESetParameterMinMaxValue(short printJob, const char * parameterFieldName, const char * reportName, PEValueInfo &valueMin, PEValueInfo &valueMax);
	BOOL __fastcall PEGetNthParameterValueDescription(short printJob, char * parameterFieldName, char * reportName, short index, HWND &valueDesc, short &valueDescLength);
	BOOL __fastcall PESetNthParameterValueDescription(short printJob, char * parameterFieldName, char * reportName, short index, char * valueDesc);
	BOOL __fastcall PEGetParameterPickListOption(short printJob, char * parameterFieldName, char * reportName, PEParameterPickListOption &pickListOption);
	BOOL __fastcall PESetParameterPickListOption(short printJob, char * parameterFieldName, char * reportName, PEParameterPickListOption &pickListOption);
	BOOL __fastcall PEGetParameterValueInfo(short printJob, const char * parameterFieldName, const char * reportName, PEParameterValueInfo &valueInfo);
	BOOL __fastcall PESetParameterValueInfo(short printJob, const char * parameterFieldName, const char * reportName, PEParameterValueInfo &valueInfo);
	short __fastcall PEGetNParameterCurrentValues(short printJob, const char * parameterFieldName, const char * reportName);
	BOOL __fastcall PEGetNthParameterCurrentValue(short printJob, const char * parameterFieldName, const char * reportName, short index, PEValueInfo &currentValue);
	BOOL __fastcall PEAddParameterCurrentValue(short printJob, const char * parameterFieldName, const char * reportName, PEValueInfo &currentValue);
	BOOL __fastcall PEAddParameterCurrentValueW(short printJob, const wchar_t * parameterFieldName, const wchar_t * reportName, PEValueInfoW &currentValue);
	short __fastcall PEGetNParameterCurrentRanges(short printJob, const char * parameterFieldName, const char * reportName);
	BOOL __fastcall PEGetNthParameterCurrentRange(short printJob, const char * parameterFieldName, const char * reportName, short index, PEValueInfo &rangeStart, PEValueInfo &rangeEnd, short &rangeInfo);
	BOOL __fastcall PEAddParameterCurrentRange(short printJob, const char * parameterFieldName, const char * reportName, PEValueInfo &rangeStart, PEValueInfo &rangeEnd, short rangeInfo);
	BOOL __fastcall PEAddParameterCurrentRangeW(short printJob, const wchar_t * parameterFieldName, const wchar_t * reportName, PEValueInfoW &rangeStart, PEValueInfoW &rangeEnd, short rangeInfo);
	BOOL __fastcall PEClearParameterCurrentValuesAndRanges(short printJob, const char * parameterFieldName, const char * reportName);
	short __fastcall PEGetNthParameterType(short printJob, short index);
	short __fastcall PEGetNSortFields(short printJob);
	BOOL __fastcall PEGetNthSortField(short printJob, short sortFieldN, HWND &nameHandle, short &nameLength, short &direction);
	BOOL __fastcall PESetNthSortField(short printJob, short sortFieldN, char * Name, short direction);
	BOOL __fastcall PEDeleteNthSortField(short printJob, short sortFieldN);
	short __fastcall PEGetNGroupSortFields(short printJob);
	BOOL __fastcall PEGetNthGroupSortField(short printJob, short sortFieldN, HWND &nameHandle, short &nameLength, short &direction);
	BOOL __fastcall PESetNthGroupSortField(short printJob, short sortFieldN, char * Name, short direction);
	BOOL __fastcall PEDeleteNthGroupSortField(short printJob, short sortFieldN);
	short __fastcall PEGetNTables(short printJob);
	BOOL __fastcall PEGetNthTableType(short printJob, short tableN, PETableType &tableType);
	BOOL __fastcall PEGetNthTableSessionInfo(short printJob, short tableN, PESessionInfo &sessionInfo);
	BOOL __fastcall PESetNthTableSessionInfo(short printJob, short tableN, PESessionInfo &sessionInfo, BOOL propagateAcrossTables);
	BOOL __fastcall PEGetNthTableLogOnInfo(short printJob, short tableN, PELogOnInfo &logOnInfo);
	BOOL __fastcall PESetNthTableLogOnInfo(short printJob, short tableN, PELogOnInfo &logOnInfo, BOOL propagateAcrossTables);
	BOOL __fastcall PEGetNthTableLocation(short printJob, short tableN, PETableLocation &location);
	BOOL __fastcall PESetNthTableLocation(short printJob, short tableN, PETableLocation &location);
	BOOL __fastcall PEGetNthTablePrivateInfo(short printJob, short tableN, PETablePrivateInfo &privateInfo);
	BOOL __fastcall PESetNthTablePrivateInfo(short printJob, short tableN, PETablePrivateInfo &privateInfo);
	BOOL __fastcall PETestNthTableConnectivity(short printJob, short tableN);
	BOOL __fastcall PELogOnServer(char * dllName, PELogOnInfo &logOnInfo);
	BOOL __fastcall PELogOffServer(char * dllName, PELogOnInfo &logOnInfo);
	BOOL __fastcall PELogOnSQLServerWithPrivateInfo(char * dllName, void * privateInfo);
	BOOL __fastcall PEVerifyDatabase(short printJob);
	BOOL __fastcall PECheckNthTableDifferences(short printJob, short tableN, PETableDifferenceInfo &tableDifferenceInfo);
	BOOL __fastcall PEGetSQLQuery(short printJob, HWND &textHandle, short &textLength);
	BOOL __fastcall PESetSQLQuery(short printJob, char * queryString);
	BOOL __fastcall PEDiscardSavedData(short printJob);
	BOOL __fastcall PEHasSavedData(short printJob, BOOL &hasSavedData);
	BOOL __fastcall PEGetReportTitle(short printJob, HWND &titleHandle, short &titleLength);
	BOOL __fastcall PESetReportTitle(short printJob, char * title);
	BOOL __fastcall PEOutputToWindow(short printJob, char * title, unsigned left, unsigned top, unsigned width, unsigned height, unsigned style, HWND parentWindow);
	HWND __fastcall PEGetWindowHandle(short printJob);
	void __fastcall PECloseWindow(short printJob);
	BOOL __fastcall PEGetWindowOptions(short printJob, PEWindowOptions &options);
	BOOL __fastcall PESetWindowOptions(short printJob, PEWindowOptions &options);
	BOOL __fastcall PEShowPrintControls(short printJob, BOOL showPrintControls);
	BOOL __fastcall PEPrintControlsShowing(short printJob, BOOL &controlsShowing);
	BOOL __fastcall PEShowFirstPage(short printJob);
	BOOL __fastcall PEShowNextPage(short printJob);
	BOOL __fastcall PEShowPreviousPage(short printJob);
	BOOL __fastcall PEShowLastPage(short printJob);
	short __fastcall PEGetNPages(short printJob);
	BOOL __fastcall PEShowNthPage(short printJob, short pageN);
	BOOL __fastcall PEZoomPreviewWindow(short printJob, short level);
	BOOL __fastcall PENextPrintWindowMagnification(short printJob);
	BOOL __fastcall PEPrintWindow(short printJob, BOOL waitUntilDone);
	BOOL __fastcall PEExportPrintWindow(short printJob, BOOL toMail, BOOL waitUntilDone);
	BOOL __fastcall PEOutputToPrinter(short printJob, short nCopies);
	BOOL __fastcall PESelectPrinter(short printJob, char * driverName, char * printerName, char * portName, Windows::PDeviceModeA mode);
	BOOL __fastcall PESelectPrinterW(short printJob, wchar_t * driverName, wchar_t * printerName, wchar_t * portName, Windows::PDeviceModeW mode);
	BOOL __fastcall PEGetSelectedPrinter(short printJob, HWND &driverHandle, short &driverLength, HWND &printerHandle, short &printerLength, HWND &portHandle, short &portLength, Windows::PDeviceModeA &mode);
	BOOL __fastcall PEGetNDetailCopies(short printJob, short &nCopies);
	BOOL __fastcall PESetNDetailCopies(short printJob, short nCopies);
	BOOL __fastcall PEGetPrintOptions(short printJob, PEPrintOptions &options);
	BOOL __fastcall PESetPrintOptions(short printJob, PEPrintOptions &options);
	BOOL __fastcall PEGetExportOptions(short printJob, PEExportOptions &options);
	BOOL __fastcall PEGetExportOptionsW(short printJob, PEExportOptionsW &options);
	BOOL __fastcall PEExportTo(short printJob, PEExportOptions &options);
	BOOL __fastcall PEGetMargins(short printJob, Word &left, Word &right, Word &top, Word &bottom);
	BOOL __fastcall PESetMargins(short printJob, Word left, Word right, Word top, Word bottom);
	BOOL __fastcall PEGetReportSummaryInfo(short printJob, PEReportSummaryInfo &summaryInfo);
	BOOL __fastcall PESetReportSummaryInfo(short printJob, PEReportSummaryInfo &summaryInfo);
	BOOL __fastcall PEEnableEvent(short printJob, PEEnableEventInfo &enableEventInfo);
	BOOL __fastcall PEGetEnableEventInfo(short printJob, PEEnableEventInfo &enableEventInfo);
	BOOL __fastcall PESetEventCallback(short printJob, void * callbackProc, void * userData);
	BOOL __fastcall PEGetFieldMappingType(short printJob, Word &mappingType);
	BOOL __fastcall PESetFieldMappingType(short printJob, Word mappingType);
	BOOL __fastcall PEGetTrackCursorInfo(short printJob, PETrackCursorInfo &cursorInfo);
	BOOL __fastcall PESetTrackCursorInfo(short printJob, PETrackCursorInfo &cursorInfo);
	short __fastcall PEGetNObjectsInSection(short printJob, short sectionCode);
	unsigned __fastcall PEGetNthObjectInSection(short printJob, short sectionCode, short objectN);
	BOOL __fastcall PEGetObjectFormat(short printJob, unsigned objectHandle, short objectFormatName, PEValueInfo &valueInfo);
	BOOL __fastcall PESetObjectFormat(short printJob, unsigned objectHandle, short objectFormatName, PEValueInfo &valueInfo);
	BOOL __fastcall PEGetObjectInfo(short printJob, unsigned objectHandle, PEObjectInfo &objectInfo);
	BOOL __fastcall PESetObjectInfo(short printJob, unsigned objectHandle, PEObjectInfo &objectInfo);
	BOOL __fastcall PEGetOleObjectInfo(short printJob, unsigned objectHandle, PEOleObjectInfo &oleObjectInfo);
	BOOL __fastcall PEGetObjectFontColor(short printJob, unsigned objectHandle, PEFontColorInfo &fontColorInfo);
	BOOL __fastcall PESetObjectFontColor(short printJob, unsigned objectHandle, PEFontColorInfo &fontColorInfo);
	unsigned __fastcall PEChangeSummaryType(short printJob, char * summarizedFieldName, short groupN, short oldSummaryType, short newSummaryType);
	BOOL __fastcall PEGetFieldObjectInfo(short printJob, unsigned fieldObjectHandle, PEFieldObjectInfo &fieldObjectInfo);
	short __fastcall PEGetNParagraphs(short printJob, unsigned textObjectHandle);
	BOOL __fastcall PEGetNthParagraphInfo(short printJob, unsigned textObjectHandle, short paragraphN, PEParagraphInfo &paragraphInfo);
	BOOL __fastcall PESetNthParagraphInfo(short printJob, unsigned textObjectHandle, short paragraphN, PEParagraphInfo &paragraphInfo);
	short __fastcall PEGetNTabStopsInParagraph(short printJob, unsigned textObjectHandle, short paragraphN);
	BOOL __fastcall PEGetNthTabStopInfo(short printJob, unsigned textObjectHandle, short paragraphN, short tabStopN, PETabStopInfo &tabStopInfo);
	BOOL __fastcall PESetNthTabStopInfo(short printJob, unsigned textObjectHandle, short paragraphN, short tabStopN, PETabStopInfo &tabStopInfo);
	BOOL __fastcall PEAddTabStop(short printJob, unsigned textObjectHandle, short paragraphN, PETabStopInfo &tabStopInfo);
	BOOL __fastcall PEDeleteNthTabStop(short printJob, unsigned textObjectHandle, short paragraphN, short tabStopN);
	short __fastcall PEGetNEmbeddedFields(short printJob, unsigned textObjectHandle);
	BOOL __fastcall PEGetNthEmbeddedFieldInfo(short printJob, unsigned textObjectHandle, short embeddedFieldN, PEEmbeddedFieldInfo &embeddedFieldInfo);
	BOOL __fastcall PEGetNthEmbeddedFieldFormat(short printJob, unsigned textObjectHandle, short embeddedFieldN, short objectFormatName, PEValueInfo &valueInfo);
	BOOL __fastcall PESetNthEmbeddedFieldFormat(short printJob, unsigned textObjectHandle, short embeddedFieldN, short objectFormatName, PEValueInfo &valueInfo);
	BOOL __fastcall PEGetNthEmbeddedFieldFormatFormula(short printJob, unsigned textObjectHandle, short embeddedFieldN, short formulaName, HWND &textHandle, short &textLength);
	BOOL __fastcall PESetNthEmbeddedFieldFormatFormula(short printJob, unsigned textObjectHandle, short embeddedFieldN, short formulaName, char * formulaString);
	BOOL __fastcall PEDeleteNthEmbeddedField(short printJob, unsigned textObjectHandle, short embeddedFieldN);
	BOOL __fastcall PEInsertEmbeddedField(short printJob, unsigned textObjectHandle, int position, char * fieldName);
	BOOL __fastcall PEGetTextFontColor(short printJob, unsigned textObjectHandle, int position, PEFontColorInfo &fontColorInfo);
	BOOL __fastcall PESetTextFontColor(short printJob, unsigned textObjectHandle, int startPosition, int endPosition, PEFontColorInfo &fontColorInfo);
	int __fastcall PEGetTextSize(short printJob, unsigned textObjectHandle);
	int __fastcall PEGetTextHeight(short printJob, unsigned textObjectHandle);
	BOOL __fastcall PEGetText(short printJob, unsigned textObjectHandle, HWND &textHandle, short &textLength);
	BOOL __fastcall PEInsertText(short printJob, unsigned textObjectHandle, int position, char * text);
	BOOL __fastcall PEDeleteText(short printJob, unsigned textObjectHandle, int startText, int endText);
	BOOL __fastcall PEInsertTextEx(short printJob, PEInsertTextInfo &insertTextInfo);
	BOOL __fastcall PEGetNthSubreportLink(short printJob, unsigned subreportHandle, short subreportLinkN, HWND mainReportFieldNameHandle, short mainReportFieldNameLength, HWND promptVarFieldNameHandle, short promptVarFieldNameLength);
	BOOL __fastcall PEGetNthSubreportLinkEx(short printJob, unsigned subreportHandle, short subreportLinkN, PESubreportLinkInfo &subreportLinkInfo);
	BOOL __fastcall PEReimportSubreport(short printJob, unsigned subreportHandle, BOOL &linkChanged, BOOL &reimported);
	BOOL __fastcall PEGetLineObjectInfo(short printJob, unsigned lineObjectHandle, PELineObjectInfo &lineObjectInfo);
	BOOL __fastcall PESetLineObjectInfo(short printJob, unsigned lineObjectHandle, PELineObjectInfo &lineObjectInfo);
	BOOL __fastcall PEGetBoxObjectInfo(short printJob, unsigned boxObjectHandle, PEBoxObjectInfo &boxObjectInfo);
	BOOL __fastcall PESetBoxObjectInfo(short printJob, unsigned boxObjectHandle, PEBoxObjectInfo &boxObjectInfo);
	BOOL __fastcall PEGetPictureFormatInfo(short printJob, unsigned objectHandle, PEPictureFormatInfo &pictureFormatInfo);
	BOOL __fastcall PESetPictureFormatInfo(short printJob, unsigned objectHandle, PEPictureFormatInfo &pictureFormatInfo);
	BOOL __fastcall PEGetCrossTabOptions(short printJob, unsigned hObject, PECrossTabOptions &crossTabOptions);
	short __fastcall PEGetNSummariesInCrossTabObject(short printJob, unsigned crossTabObjectHandle);
	BOOL __fastcall PEGetNthSummaryInfoInCrossTabObject(short printJob, unsigned crossTabObjectHandle, short summaryN, PECrossTabSummaryFieldInfo &summaryInfo);
	short __fastcall PEGetNGroupsInCrossTabObject(short printJob, unsigned crossTabObjectHandle, short rowCol);
	BOOL __fastcall PEGetNthCrossTabGroupOptions(short printJob, unsigned crossTabObjectHandle, short rowCol, short rowColN, PECrossTabGroupOptions &crossTabGroupOptions);
	BOOL __fastcall PEGetGraphNumber(short printJob, unsigned graphObjectHandle, short &sectionCode, short &graphN);
	BOOL __fastcall PEGetGraphDataType(short printJob, short sectionCode, short graphN, PEGraphDataTypeInfo &graphDataTypeInfo);
	BOOL __fastcall PEGetObjectFormatFormula(short printJob, unsigned objectHandle, short formulaName, HWND &textHandle, short &textLength);
	BOOL __fastcall PESetObjectFormatFormula(short printJob, unsigned objectHandle, short formulaName, char * formulaString);
	BOOL __fastcall PEGetParameterBrowseField(short printJob, char * parameterFieldName, char * reportName, HWND &textHandle, short &textLength);
	BOOL __fastcall PESetParameterBrowseField(short printJob, char * parameterFieldName, char * reportName, char * browseTableField);
	short __fastcall PEGetNLogicalTables(short printJob);
	BOOL __fastcall PEInsertSortField(short printJob, short sortFieldN, char * name, short direction);
	BOOL __fastcall PESwapSortFields(short printJob, short sourceSortN, short targetSortN);
	BOOL __fastcall PEGetNthTableAliasName(short printJob, short tableN, HWND &textHandle, short &textLength);
	BOOL __fastcall PESetNthTableAliasName(short printJob, short tableN, char * tableAliasName);
	BOOL __fastcall PESetNthTableServerType(short printJob, short tableN, PEServerTypeInfo &serverType, BOOL propagateAcrossTables);
	short __fastcall PEGetNDatabaseFields(short printJob, short tableN);
	BOOL __fastcall PEGetNthDatabaseFieldInfo(short printJob, short tableN, short fieldN, PEDatabaseFieldInfo &fieldInfo);
	short __fastcall PEGetNDatabaseLinks(short printJob);
	BOOL __fastcall PEGetNthDatabaseLinkInfo(short printJob, short databaseLinkN, PEDatabaseLinkInfo &databaseLinkInfo);
	BOOL __fastcall PESetDatabaseLinkInfo(short printJob, PEDatabaseLinkInfo &databaseLinkInfo);
	BOOL __fastcall PEConvertDatabaseDriver(short printJob, char * toDllName, BOOL doConvert);
	BOOL __fastcall PEFreeDevMode(short printJob, Windows::PDeviceModeA pMode);
	BOOL __fastcall PEGetDictionaryInfo(short printJob, PEDictionaryInfo &dictInfo);
	BOOL __fastcall PEGetDictionaryLocation(short printJob, PETableLocation &dictLocation);
	BOOL __fastcall PEGetDirectoryUserId(short printJob, HWND &textHandle, short &textLength);
	BOOL __fastcall PEGetFieldDefinitionInfo(short printJob, char * fieldName, PEFieldDefinitionInfo &fieldDefinitionInfo);
	BOOL __fastcall PEGetFormulaFieldInfo(short printJob, char * formula, PEFieldDefinitionInfo &fieldDefinitionInfo);
	BOOL __fastcall PEGetSQLExpressionFieldInfo(short printJob, char * expression, PEFieldDefinitionInfo &fieldDefinitionInfo);
	short __fastcall PEGetNSummaryFields(short printJob);
	BOOL __fastcall PEGetNthSummaryFieldInfo(short printJob, short summaryN, PESummaryFieldInfo &summaryFieldInfo);
	Word __fastcall PEGetReportStyle(short printJob);
	BOOL __fastcall PESetReportStyle(short printJob, Word style);
	short __fastcall PEGetNOLAPCubes(short printJob);
	BOOL __fastcall PEGetNthOLAPCubeLogOnInfo(short printJob, short cubeN, PEOLAPLogOnInfo &logOnInfo);
	BOOL __fastcall PESetNthOLAPCubeLogOnInfo(short printJob, short cubeN, PEOLAPLogOnInfo &logOnInfo);
	BOOL __fastcall PETestNthOlapCubeConnectivity(short printJob, short cubeN);
	BOOL __fastcall PEGetGraphDataInfo(short printJob, short sectionN, short graphN, PENewGraphDataInfo &graphDataInfo);
	short __fastcall PEGetNGraphConditionFields(short printJob, short sectionN, short graphN);
	BOOL __fastcall PEGetNthGraphConditionField(short printJob, short sectionN, short graphN, short condFieldN, HWND &fieldNameHandle, short &fieldNameLength);
	BOOL __fastcall PESetNthGraphConditionField(short printJob, short graphN, short condFieldN, char * fieldName);
	short __fastcall PEGetNGraphSummaryFields(short printJob, short sectionN, short graphN);
	BOOL __fastcall PEGetNthGraphSummaryFieldInfo(short printJob, short graphN, short fieldN, PEFieldDefinitionInfo &summaryFieldInfo);
	BOOL __fastcall PEGetGraphTextDefaultOption(short printJob, short sectionN, short graphN, Word titleType, BOOL &useDefault);
	BOOL __fastcall PESetGraphTextDefaultOption(short printJob, short sectionN, short graphN, Word titleType, BOOL useDefault);
	short __fastcall PEGetObjectNHiliteConditions(short printJob, unsigned hObject);
	BOOL __fastcall PESetObjectNthHiliteCondition(short printJob, unsigned hObject, short nHilite, PEObjectHiliteInfo &hiliteInfo);
	BOOL __fastcall PEGetObjectNthHiliteCondition(short printJob, unsigned hObject, short nHilite, PEObjectHiliteInfo &hiliteInfo);
	BOOL __fastcall PEAddObjectHiliteCondition(short printJob, unsigned hObject, PEObjectHiliteInfo &hiliteInfo);
	BOOL __fastcall PERemoveObjectNthHiliteCondition(short printJob, unsigned hObject, short nHilite);
	BOOL __fastcall PEClearObjectHiliteConditions(short printJob, unsigned hObject);
	BOOL __fastcall PESetObjectNthHiliteConditionPriority(short printJob, unsigned hObject, short nHilite, short newPriority);
	short __fastcall PEGetNRunningTotals(short printJob);
	BOOL __fastcall PEGetNthRunningTotalName(short printJob, short runningtotalN, HWND &nameHandle, short &nameLength);
	BOOL __fastcall PEGetRunningTotalInfo(short printJob, char * rtName, PERunningTotalInfo &rtInfo);
	BOOL __fastcall PEGetRunningTotalConditionField(short printJob, char * rtName, HWND &hEvalField, short &evalLength, HWND &hResetField, short &resetLength);
	BOOL __fastcall PEGetRunningTotalConditionFormula(short printJob, char * rtName, HWND &hEvalFormula, short &evalLength, HWND &hResetFormula, short &resetLength);
	BOOL __fastcall PEGetRunningTotalSummaryField(short printJob, char * rtName, HWND &summaryFieldName, short &summaryLength, HWND &secondFieldName, short &secondLength);
	BOOL __fastcall PEGetMapDataInfo(short printJob, unsigned hObject, PEMapDataInfo &mapInfo);
	BOOL __fastcall PESetMapDataInfo(short printJob, unsigned hObject, PEMapDataInfo &mapInfo);
	BOOL __fastcall PEGetMapStyle(short printJob, unsigned hObject, PEMapStyle &mapStyle);
	BOOL __fastcall PESetMapStyle(short printJob, unsigned hObject, PEMapStyle &mapStyle);
	short __fastcall PEGetNMapSummaryFields(short printJob, unsigned hObject);
	BOOL __fastcall PEGetNthMapSummaryField(short printJob, unsigned hObject, short nSummaryField, HWND &summaryField, short &summaryLength);
	BOOL __fastcall PESetNthMapSummaryField(short printJob, unsigned hObject, short nSummaryField, char * summaryField);
	short __fastcall PEGetNMapConditionFields(short printJob, unsigned hObject);
	BOOL __fastcall PEGetNthMapConditionField(short printJob, unsigned hObject, short condFieldN, HWND &conditionField, short &conditionLength);
	BOOL __fastcall PESetNthMapConditionField(short printJob, unsigned hObject, short condFieldN, char * fieldName);
	BOOL __fastcall PEGetMapConditions(short printJob, unsigned hObject, PEMapCondition &mapCondition);
	BOOL __fastcall PESetMapConditions(short printJob, unsigned hObject, PEMapCondition &mapCondition);
	BOOL __fastcall PEGetMapTitle(short printJob, unsigned hObject, HWND &mapTitle, short &titleLength);
	BOOL __fastcall PESetMapTitle(short printJob, unsigned hObject, char * mapTitle);
	BOOL __fastcall PEGetMapLegendTitle(short printJob, unsigned hObject, HWND &legendTitle, short &legendLength);
	BOOL __fastcall PESetMapLegendTitle(short printJob, unsigned hObject, char * legendTitle);
	BOOL __fastcall PEGetMapLegendSubtitle(short printJob, unsigned hObject, HWND &legendSubtitle, short &legendLength);
	BOOL __fastcall PESetMapLegendSubtitle(short printJob, unsigned hObject, char * legendSubtitle);
	BOOL __fastcall PEGetFormulaSyntax(short printJob, PEFormulaSyntax &formulaSyntax);
	BOOL __fastcall PESetFormulaSyntax(short printJob, PEFormulaSyntax &formulaSyntax);
	short __fastcall PEGetNReportAlerts(short printJob);
	BOOL __fastcall PEGetNthReportAlert(short printJob, short alertN, PEReportAlertInfo &reportAlertInfo);
	BOOL __fastcall PEGetNthAlertInstanceInfo(short printJob, short alertN, unsigned instanceN, PEAlertInstanceInfo &alertInstanceInfo);
	BOOL __fastcall PESetNthAlertConditionFormula(short printJob, short alertN, char * &formula);
	BOOL __fastcall PESetNthAlertMessageFormula(short printJob, short alertN, char * &formula);
	BOOL __fastcall PESetNthAlertDefaultMessage(short printJob, short alertN, char * &text);
	BOOL __fastcall PEEnableNthAlert(short printJob, short alertN, BOOL enabled);
	unsigned __fastcall PEGetObjectByName(short printJob, char * name);
	BOOL __fastcall PEGetObjectName(short printJob, unsigned objectHandle, HWND &objectNameHandle, short &objectNameLength);
	short __fastcall PEGetSectionByName(short printJob, char * name);
	short __fastcall PEGetAreaByName(short printJob, char * name);
	BOOL __fastcall PEGetAreaName(short printJob, short areaCode, HWND &nameHandle, short &nameLength);
	void __fastcall PESetTempFilePath(char * Path);
	BOOL __fastcall PEGetNthGroupNameFormula(short printJob, short groupN, HWND &textHandle, short &textLength);
	BOOL __fastcall PESetNthGroupNameFormula(short printJob, short groupN, char * fString);
	HWND CRDEngine;
	AnsiString CRDErrorStr;
	int CRDVerMajor;
	int CRDVerMinor;
	int CRDVerRelease;
	int CRDVerBuild;
	bool CRDShowErrors;
public:
	#pragma option push -w-inl
	/* TObject.Create */ inline __fastcall TCrpeEngine(void) : System::TObject() { }
	#pragma option pop
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~TCrpeEngine(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

//-- var, const, procedure ---------------------------------------------------
static const Shortint PE_BYTE_LEN = 0x1;
static const Shortint PE_CHAR_LEN = 0x1;
static const Shortint PE_WORD_LEN = 0x2;
static const Shortint PE_DWORD_LEN = 0x4;
static const Shortint PE_SMALLINT_LEN = 0x2;
static const Shortint PE_BOOL_LEN = 0x2;
static const Shortint PE_LONGINT_LEN = 0x8;
static const Shortint PE_LONGPTR_LEN = 0x4;
static const Shortint PE_UNCHANGED = 0xffffffff;
static const Shortint PE_UNCHANGED_COLOR = 0xfffffffe;
static const unsigned PE_NO_COLOR = 0xffffffff;
static const Shortint PE_ERR_NOERROR = 0x0;
static const Word PE_ERR_NOTENOUGHMEMORY = 0x1f4;
static const Word PE_ERR_INVALIDJOBNO = 0x1f5;
static const Word PE_ERR_INVALIDHANDLE = 0x1f6;
static const Word PE_ERR_STRINGTOOLONG = 0x1f7;
static const Word PE_ERR_NOSUCHREPORT = 0x1f8;
static const Word PE_ERR_NODESTINATION = 0x1f9;
static const Word PE_ERR_BADFILENUMBER = 0x1fa;
static const Word PE_ERR_BADFILENAME = 0x1fb;
static const Word PE_ERR_BADFIELDNUMBER = 0x1fc;
static const Word PE_ERR_BADFIELDNAME = 0x1fd;
static const Word PE_ERR_BADFORMULANAME = 0x1fe;
static const Word PE_ERR_BADSORTDIRECTION = 0x1ff;
static const Word PE_ERR_ENGINENOTOPEN = 0x200;
static const Word PE_ERR_INVALIDPRINTER = 0x201;
static const Word PE_ERR_PRINTFILEEXISTS = 0x202;
static const Word PE_ERR_BADFORMULATEXT = 0x203;
static const Word PE_ERR_BADGROUPSECTION = 0x204;
static const Word PE_ERR_ENGINEBUSY = 0x205;
static const Word PE_ERR_BADSECTION = 0x206;
static const Word PE_ERR_NOPRINTWINDOW = 0x207;
static const Word PE_ERR_JOBALREADYSTARTED = 0x208;
static const Word PE_ERR_BADSUMMARYFIELD = 0x209;
static const Word PE_ERR_NOTENOUGHSYSRES = 0x20a;
static const Word PE_ERR_BADGROUPCONDITION = 0x20b;
static const Word PE_ERR_JOBBUSY = 0x20c;
static const Word PE_ERR_BADREPORTFILE = 0x20d;
static const Word PE_ERR_NODEFAULTPRINTER = 0x20e;
static const Word PE_ERR_SQLSERVERERROR = 0x20f;
static const Word PE_ERR_BADLINENUMBER = 0x210;
static const Word PE_ERR_DISKFULL = 0x211;
static const Word PE_ERR_FILEERROR = 0x212;
static const Word PE_ERR_INCORRECTPASSWORD = 0x213;
static const Word PE_ERR_BADDATABASEDLL = 0x214;
static const Word PE_ERR_BADDATABASEFILE = 0x215;
static const Word PE_ERR_ERRORINDATABASEDLL = 0x216;
static const Word PE_ERR_DATABASESESSION = 0x217;
static const Word PE_ERR_DATABASELOGON = 0x218;
static const Word PE_ERR_DATABASELOCATION = 0x219;
static const Word PE_ERR_BADSTRUCTSIZE = 0x21a;
static const Word PE_ERR_BADDATE = 0x21b;
static const Word PE_ERR_BADEXPORTDLL = 0x21c;
static const Word PE_ERR_ERRORINEXPORTDLL = 0x21d;
static const Word PE_ERR_PREVATFIRSTPAGE = 0x21e;
static const Word PE_ERR_NEXTATLASTPAGE = 0x21f;
static const Word PE_ERR_CANNOTACCESSREPORT = 0x220;
static const Word PE_ERR_USERCANCELLED = 0x221;
static const Word PE_ERR_OLE2NOTLOADED = 0x222;
static const Word PE_ERR_BADCROSSTABGROUP = 0x223;
static const Word PE_ERR_NOCTSUMMARIZEDFIELD = 0x224;
static const Word PE_ERR_DESTINATIONNOTEXPORT = 0x225;
static const Word PE_ERR_INVALIDPAGENUMBER = 0x226;
static const Word PE_ERR_BADLABELNUMBER = 0x227;
static const Word PE_ERR_NOTSTOREDPROCEDURE = 0x228;
static const Word PE_ERR_INVALIDPARAMETER = 0x229;
static const Word PE_ERR_GRAPHNOTFOUND = 0x22a;
static const Word PE_ERR_INVALIDGRAPHTYPE = 0x22b;
static const Word PE_ERR_INVALIDGRAPHDATA = 0x22c;
static const Word PE_ERR_CANNOTMOVEGRAPH = 0x22d;
static const Word PE_ERR_INVALIDGRAPHTEXT = 0x22e;
static const Word PE_ERR_INVALIDGRAPHOPT = 0x22f;
static const Word PE_ERR_BADSECTIONHEIGHT = 0x230;
static const Word PE_ERR_BADVALUETYPE = 0x231;
static const Word PE_ERR_INVALIDSUBREPORTNAME = 0x232;
static const Word PE_ERR_FIELDEXIST = 0x233;
static const Word PE_ERR_NOPARENTWINDOW = 0x234;
static const Word PE_ERR_INVALIDZOOMFACTOR = 0x235;
static const Word PE_ERR_INVALIDLABELINFO = 0x236;
static const Word PE_ERR_PAGESIZEOVERFLOW = 0x237;
static const Word PE_ERR_LOWSYSTEMRESOURCES = 0x238;
static const Word PE_ERR_NOTUSINGDICTIONARY = 0x239;
static const Word PE_ERR_BADGROUPNUMBER = 0x23a;
static const Word PE_ERR_INVALIDOBJECTFORMATNAME = 0x23b;
static const Word PE_ERR_INVALIDNEGATIVEVALUE = 0x23c;
static const Word PE_ERR_INVALIDMEMORYPOINTER = 0x23d;
static const Word PE_ERR_INVALIDOBJECTTYPE = 0x23e;
static const Word PE_ERR_INVALIDLINESTYLE = 0x23f;
static const Word PE_ERR_INVALIDCROSSTABROWORCOL = 0x240;
static const Word PE_ERR_INVALIDGRAPHDATATYPE = 0x241;
static const Word PE_ERR_INVALIDPARAGRAPHNUMBER = 0x242;
static const Word PE_ERR_INVALIDALIGNMENT = 0x243;
static const Word PE_ERR_INVALIDTABSTOPNUMBER = 0x244;
static const Word PE_ERR_INVALIDEMBEDDEDFIELDNUMBER = 0x245;
static const Word PE_ERR_INVALIDSUBREPORTLINKNUMBER = 0x246;
static const Word PE_ERR_SUBREPORTLINKEXIST = 0x247;
static const Word PE_ERR_BADROWCOLVALUE = 0x248;
static const Word PE_ERR_INVALIDSUMMARYNUMBER = 0x249;
static const Word PE_ERR_INVALIDGRAPHDATAFIELDNUMBER = 0x24a;
static const Word PE_ERR_INVALIDSUBREPORTNUMBER = 0x24b;
static const Word PE_ERR_INVALIDFIELDSCOPE = 0x24c;
static const Word PE_ERR_INVALIDREPORTTYPE = 0x24d;
static const Word PE_ERR_FIELDINUSE = 0x24e;
static const Word PE_ERR_INVALIDFILETYPE = 0x24f;
static const Word PE_ERR_INVALIDTABLEALIASNAME = 0x250;
static const Word PE_ERR_INVALIDSPECIALVARTYPE = 0x251;
static const Word PE_ERR_INVALIDPARAMETERNUMBER = 0x252;
static const Word PE_ERR_INVALIDPAGEMARGINS = 0x253;
static const Word PE_ERR_REPORTONSECUREQUERY = 0x254;
static const Word PE_ERR_CANNOTOPENSECUREQUERY = 0x255;
static const Word PE_ERR_INVALIDSECTIONNUMBER = 0x256;
static const Word PE_ERR_SQLSERVERNOTOPENED = 0x257;
static const Word PE_ERR_INVALIDSUMMARYTYPE = 0x25b;
static const Word PE_ERR_INVALIDDATABASELINKNUMBER = 0x25c;
static const Word PE_ERR_NOTTOPLEVELJOB = 0x25d;
static const Word PE_ERR_TABLENAMEEXIST = 0x25e;
static const Word PE_ERR_INVALIDCURSOR = 0x25f;
static const Word PE_ERR_FIRSTPASSNOTFINISHED = 0x260;
static const Word PE_ERR_CREATEDATASOURCE = 0x261;
static const Word PE_ERR_CREATEDRILLDOWNPARAMETERS = 0x262;
static const Word PE_ERR_ENCAPSULATINGPAGE = 0x263;
static const Word PE_ERR_ENCAPSULATINGTOTALLER = 0x264;
static const Word PE_ERR_CHECKFORDATASOURCECHANGES = 0x265;
static const Word PE_ERR_STARTBACKGROUNDPROCESSING = 0x266;
static const Word PE_ERR_DRILLONGRAPH = 0x267;
static const Word PE_ERR_GETLASTPAGEN = 0x268;
static const Word PE_ERR_GETPAGENFORGROUP = 0x269;
static const Word PE_ERR_GETACTUALPAGENUMBER = 0x26a;
static const Word PE_ERR_SQLSERVERINUSE = 0x26b;
static const Word PE_ERR_GROUPSORTFIELDNOTSET = 0x26c;
static const Word PE_ERR_CANNOTSETSAVESUMMARIES = 0x26d;
static const Word PE_ERR_LOADOLAPDATABASEMANAGER = 0x26e;
static const Word PE_ERR_OPENOLAPCUBE = 0x26f;
static const Word PE_ERR_READOLAPCUBEDATA = 0x270;
static const Word PE_ERR_CANNOTSAVEQUERY = 0x272;
static const Word PE_ERR_CANNOTREADQUERYDATA = 0x273;
static const Word PE_ERR_NDAYSOUTOFRANGE = 0x274;
static const Word PE_ERR_MAINREPORTFIELDLINKED = 0x275;
static const Word PE_ERR_INVALIDMAPPINGTYPEVALUE = 0x276;
static const Word PE_ERR_HITTESTFAILED = 0x27c;
static const Word PE_ERR_BADSQLEXPRESSIONNAME = 0x27d;
static const Word PE_ERR_BADSQLEXPRESSIONNUMBER = 0x27e;
static const Word PE_ERR_BADSQLEXPRESSIONTEXT = 0x27f;
static const Word PE_ERR_INVALIDDEFAULTVALUEINDEX = 0x281;
static const Word PE_ERR_NOMINMAXVALUE = 0x282;
static const Word PE_ERR_INCONSISTANTTYPES = 0x283;
static const Word PE_ERR_HASNOBROWSEFIELD = 0x284;
static const Word PE_ERR_CANNOTLINKTABLES = 0x285;
static const Word PE_ERR_CREATEROUTER = 0x286;
static const Word PE_ERR_INVALIDFIELDINDEX = 0x287;
static const Word PE_ERR_INVALIDGRAPHTITLETYPE = 0x288;
static const Word PE_ERR_INVALIDGRAPHTITLEFONTTYPE = 0x289;
static const Word PE_ERR_PARAMTYPEDIFFERENT = 0x28a;
static const Word PE_ERR_INCONSISTANTRANGETYPES = 0x28b;
static const Word PE_ERR_RANGEORDISCRETE = 0x28c;
static const Word PE_ERR_NOTMAINREPORT = 0x28e;
static const Word PE_ERR_INVALIDCURRENTVALUEINDEX = 0x28f;
static const Word PE_ERR_LINKEDPARAMVALUE = 0x290;
static const Word PE_ERR_PROCESSINGLIMITREACHED = 0x291;
static const Word PE_ERR_INVALIDHILITEINDEX = 0x292;
static const Word PE_ERR_INVALIDHILITERANGECONDITION = 0x293;
static const Word PE_ERR_INVALIDHILITEBORDERSTYLE = 0x294;
static const Word PE_ERR_INVALIDRUNNINGTOTALINDEX = 0x295;
static const Word PE_ERR_INVALIDRUNNINGTOTALNAME = 0x296;
static const Word PE_ERR_INVALIDRUNNINGTOTALCOND = 0x297;
static const Word PE_ERR_RUNNINGTOTALCONDMISMATCH = 0x298;
static const Word PE_ERR_INVALIDSUMMARYPARAMETER = 0x299;
static const Word PE_ERR_INVALIDMAPTHEMETYPE = 0x29a;
static const Word PE_ERR_INVALIDMAPTHEMESIZE = 0x29b;
static const Word PE_ERR_INVALIDMAPDISTRIBUTIONMETHOD = 0x29c;
static const Word PE_ERR_INVALIDMAPLEGENDTYPE = 0x29d;
static const Word PE_ERR_INVALIDMAPLEGENDTITLETYPE = 0x29e;
static const Word PE_ERR_INVALIDMAPTYPE = 0x29f;
static const Word PE_ERR_INVALIDPARAMETERRANGEINFO = 0x2a0;
static const Word PE_ERR_INVALIDOLAPCUBEINDEX = 0x2a1;
static const Word PE_ERR_INVALIDSORTMETHODINDEX = 0x2a2;
static const Word PE_ERR_INVALIDGRAPHSUBTYPE = 0x2a3;
static const Word PE_ERR_BADGRAPHOPTIONINFO = 0x2a4;
static const Word PE_ERR_BADGRAPHAXISINFO = 0x2a5;
static const Word PE_ERR_INVALIDMAPORIENT = 0x2a6;
static const Word PE_ERR_INVALIDSPPARAMETEROPERATION = 0x2a7;
static const Word PE_ERR_NOTEXTERNALSUBREPORT = 0x2a8;
static const Word PE_ERR_BADFIELDINDEXNUMBER = 0x2a9;
static const Word PE_ERR_BACKGROUNDPROCESSINGERROR = 0x2ad;
static const Word PE_ERR_MOREBACKGROUNDPROCESSINGREQUIRED = 0x2ae;
static const Word PE_ERR_INVALIDPARAMETERVALUE = 0x2af;
static const Word PE_ERR_INVALIDFORMULASYNTAXTYPE = 0x2b0;
static const Word PE_ERR_INVALIDCROPVALUE = 0x2b1;
static const Word PE_ERR_INVALIDCOLLATIONVALUE = 0x2b2;
static const Word PE_ERR_STARTPAGEGREATERSTOPPAGE = 0x2b3;
static const Word PE_ERR_INVALIDEXPORTFORMAT = 0x2b4;
static const Word PE_ERR_BADALERTINGFIELDNUMBER = 0x2b7;
static const Word PE_ERR_NORANGEFORPASSWORDPARAMETER = 0x2b8;
static const Word PE_ERR_NOMUTEXGROUPBOOLWITHALLFALSE = 0x2ba;
static const Word PE_ERR_CANTCHANGEALLOWEDITINGOPTION = 0x2bb;
static const Word PE_ERR_READONLYPARAMETEROPTION = 0x2bc;
static const Word PE_ERR_MINGREATERTHANMAX = 0x2be;
static const Word PE_ERR_INVALIDSTARTPAGE = 0x2bf;
static const Word PE_ERR_INVALIDHILITEFONTSTYLE = 0x2c0;
static const Word PE_ERR_HIERARCHICALSUMMARYTYPE = 0x2c1;
static const Word PE_ERR_UNKNOWNQUERYENGINEERROR = 0x2c2;
static const Word PE_ERR_QUERYENGINEERROR = 0x2c3;
static const Word PE_ERR_DATABASEFIELDNOTEXIST = 0x2c4;
static const Word PE_ERR_TABLENOTEXIST = 0x2c5;
static const Word PE_ERR_PARAMETERDOESNOTEXIST = 0x2c6;
static const Word PE_ERR_ALIASEXIST = 0x2c7;
static const Word PE_ERR_SQLEXPRESSIONSNOTSUPPORTED = 0x2c8;
static const Word PE_ERR_LOGONFAILED = 0x2c9;
static const Word PE_ERR_TABLEINUSE = 0x2ca;
static const Word PE_ERR_SAVEDATABASE = 0x2cb;
static const Word PE_ERR_SAVEQESESSION = 0x2cc;
static const Word PE_ERR_LOADDATABASE = 0x2cd;
static const Word PE_ERR_LOADQESESSION = 0x2ce;
static const Word PE_ERR_PROCESSINGLIMIT = 0x2cf;
static const Word PE_ERR_QEINITIALIZE = 0x2d0;
static const Word PE_ERR_SMARTLINKING = 0x2d1;
static const Word PE_ERR_ROWSETCOLUMNNOTFOUND = 0x2d2;
static const Word PE_ERR_OPENROWSET = 0x2d3;
static const Word PE_ERR_CONNECTIONNOTFOUND = 0x2d4;
static const Word PE_ERR_CREATELINK = 0x2d5;
static const Word PE_ERR_DICTIONARYINTEGRITY = 0x2d6;
static const Word PE_ERR_DICTIONARYINTEGRITY2 = 0x2d7;
static const Word PE_ERR_CREATEQUERYENGINE = 0x2d8;
static const Word PE_ERR_CANTCHANGEBOOLEANDEFAULT = 0x2d9;
static const Word PE_ERR_CANTTAKELIMITWITHBOOL = 0x2da;
static const Word PE_ERR_CANTTAKELIMITWITHMASK = 0x2db;
static const Word PE_ERR_NONZEROMINMAXWITHLIMIT = 0x2dc;
static const Word PE_ERR_CANTSHOWDESCRIPTIONWITHMASK = 0x2dd;
static const Word PE_ERR_INVALIDVALUEOPTIONSFORBOOLEAN = 0x2de;
static const Word PE_ERR_INVALIDVALUEOPTIONSFORNONBOOLEAN = 0x2df;
static const Word PE_ERR_INVALIDMULTIPLEVALUE = 0x2e0;
static const Word PE_ERR_SAVEASLATESTVERSION = 0x2e1;
static const Word PE_ERR_DBDLLNOTSUPPORTED = 0x2e2;
static const Word PE_ERR_NOPASSWORDFORNONREPORTPARAM = 0x2e3;
static const Word PE_ERR_REPORTPARTNOTFOUND = 0x2e4;
static const Word PE_ERR_MODIFYTEXT = 0x2e5;
static const Word PE_ERR_INVALIDQEPROPERTY = 0x2e6;
static const Word PE_ERR_QEPROEPRTYCANNOTBECHANGED = 0x2e7;
static const Word PE_ERR_INVALIDREPORTPARTDATACONTEXT = 0x2e8;
static const Word PE_ERR_REPORTPARTINFONOTMATCH = 0x2e9;
static const Word PE_ERR_PRINTJOBLIMITEXCEED = 0x2ea;
static const Word PE_ERR_MISSUFMANGERDLL = 0x2eb;
static const Word PE_ERR_DATACONTEXTNOTFOUND = 0x2ec;
static const Word PE_ERR_INVALIDREADINGORDER = 0x2ed;
static const Word PE_ERR_INVALIDLINESPACINGTYPE = 0x2ee;
static const Word PE_ERR_OBJECTNAME = 0x2ef;
static const Word PE_ERR_REPOSITORYNOTFOUND = 0x2f0;
static const Word PE_ERR_REPOSITORYLOGONFAILED = 0x2f1;
static const Word PE_ERR_OTHERREPOSITORYERRROR = 0x2f2;
static const Word PE_ERR_MBCS2UNICODE = 0x3e2;
static const Word PE_ERR_UNICODE2MBCS = 0x3e3;
static const Word PE_ERR_INVALID_PEENUM = 0x3e4;
static const Word PE_ERR_OTHERERROR = 0x3e5;
static const Word PE_ERR_INTERNALERROR = 0x3e6;
static const Word PE_ERR_NOTIMPLEMENTED = 0x3e7;
static const Shortint PE_OE_SINGLE_THREADED = 0x0;
static const Shortint PE_OE_MULTI_THREADED = 0x1;
static const Word PE_OE_USE_BACKGROUND_THREADS = 0x4000;
static const Word PE_OE_LIMITED_FREE_THREADED_MODE = 0x8000;
static const Word PE_OE_RESERVED = 0x8000;
static const Byte PE_DLLNAME_LEN = 0x80;
static const Byte PE_SERVERNAME_LEN = 0x80;
static const Byte PE_DATABASENAME_LEN = 0x80;
static const Byte PE_USERID_LEN = 0x80;
static const Byte PE_PASSWORD_LEN = 0x80;
static const Byte PE_SERVERTYPE_LEN = 0x80;
static const int PE_SIZEOF_TABLE_PRIVATE_INFO = 0xc;
static const Word PE_TABLE_LOCATION_LEN = 0x100;
static const Word PE_CONNECTION_BUFFER_LEN = 0x200;
static const int PE_SIZEOF_TABLE_INFO = 0x404;
static const Word PE_FILE_PATH_LEN = 0x200;
static const int PE_SAVEAS_FORMAT_SCRDEFAULT = 0x0;
static const int PE_SAVEAS_FORMAT_VSNet = 0x1000;
static const Shortint PE_JOBNOTSTARTED = 0x1;
static const Shortint PE_JOBINPROGRESS = 0x2;
static const Shortint PE_JOBCOMPLETED = 0x3;
static const Shortint PE_JOBFAILED = 0x4;
static const Shortint PE_JOBCANCELLED = 0x5;
static const Shortint PE_JOBHALTED = 0x6;
static const int PE_SIZEOF_JOB_INFO = 0x18;
static const Shortint PE_GV_DLL = 0x64;
static const Byte PE_GV_ENGINE = 0xc8;
static const int PE_SIZEOF_VERSION_INFO = 0x7;
static const Shortint PE_RPTOPT_CVTDATETIMETOSTR = 0x0;
static const Shortint PE_RPTOPT_CVTDATETIMETODATE = 0x1;
static const Shortint PE_RPTOPT_KEEPDATETIMETYPE = 0x2;
static const Shortint PE_RPTOPT_PROMPT_NONE = 0x0;
static const Shortint PE_RPTOPT_PROMPT_NORMAL = 0x1;
static const Shortint PE_RPTOPT_PROMPT_ALWAYS = 0x2;
static const int PE_SIZEOF_REPORT_OPTIONS = 0x32;
static const int PE_SIZEOF_GLOBAL_OPTIONS = 0xc;
static const Byte PE_SUBREPORT_NAME_LEN = 0x80;
static const int PE_SIZEOF_SUBREPORT_INFO = 0x8a;
static const Shortint PE_SECT_REPORT_HEADER = 0x1;
static const Shortint PE_SECT_PAGE_HEADER = 0x2;
static const Shortint PE_SECT_GROUP_HEADER = 0x3;
static const Shortint PE_SECT_DETAIL = 0x4;
static const Shortint PE_SECT_GROUP_FOOTER = 0x5;
static const Shortint PE_SECT_PAGE_FOOTER = 0x7;
static const Shortint PE_SECT_REPORT_FOOTER = 0x8;
static const Byte PE_SECT_WHOLE_REPORT = 0xff;
static const Shortint PE_ALLSECTIONS = 0x0;
static const Word PE_HEADERSECTION = 0x7d0;
static const Word PE_FOOTERSECTION = 0x1b58;
static const Word PE_TITLESECTION = 0x3e8;
static const Word PE_SUMMARYSECTION = 0x1f40;
static const Word PE_GROUPHEADER = 0xbb8;
static const Word PE_GROUPFOOTER = 0x1388;
static const Word PE_DETAILSECTION = 0xfa0;
static const Word PE_GRANDTOTALSECTION = 0x1f40;
static const Shortint PE_SF_MAX_NAME_LENGTH = 0x32;
static const Shortint PE_SF_DESCENDING = 0x0;
static const Shortint PE_SF_ASCENDING = 0x1;
static const Shortint PE_SF_ORIGINAL = 0x2;
static const Shortint PE_SF_SPECIFIED = 0x3;
static const Byte PE_GC_CONDITIONMASK = 0xff;
static const Word PE_GC_TYPEMASK = 0xf00;
static const Shortint PE_GC_TYPEOTHER = 0x0;
static const Word PE_GC_TYPEDATE = 0x200;
static const Word PE_GC_TYPEBOOLEAN = 0x400;
static const Word PE_GC_TYPETIME = 0x800;
static const Word PE_GC_TYPEDATETIME = 0xa00;
static const Shortint PE_GC_ANYCHANGE = 0x0;
static const Shortint PE_GC_DAILY = 0x0;
static const Shortint PE_GC_WEEKLY = 0x1;
static const Shortint PE_GC_BIWEEKLY = 0x2;
static const Shortint PE_GC_SEMIMONTHLY = 0x3;
static const Shortint PE_GC_MONTHLY = 0x4;
static const Shortint PE_GC_QUARTERLY = 0x5;
static const Shortint PE_GC_SEMIANNUALLY = 0x6;
static const Shortint PE_GC_ANNUALLY = 0x7;
static const Shortint PE_GC_BYSECOND = 0x8;
static const Shortint PE_GC_BYMINUTE = 0x9;
static const Shortint PE_GC_BYHOUR = 0xa;
static const Shortint PE_GC_BYAMPM = 0xb;
static const Shortint PE_GC_TOYES = 0x1;
static const Shortint PE_GC_TONO = 0x2;
static const Shortint PE_GC_EVERYYES = 0x3;
static const Shortint PE_GC_EVERYNO = 0x4;
static const Shortint PE_GC_NEXTISYES = 0x5;
static const Shortint PE_GC_NEXTISNO = 0x6;
static const Word PE_FIELD_NAME_LEN = 0x200;
static const Shortint PE_GO_TBN_ALL_GROUPS_UNSORTED = 0x0;
static const Shortint PE_GO_TBN_ALL_GROUPS_SORTED = 0x1;
static const Shortint PE_GO_TBN_TOP_N_GROUPS = 0x2;
static const Shortint PE_GO_TBN_BOTTOM_N_GROUPS = 0x3;
static const int PE_SIZEOF_GROUP_OPTIONS = 0xa1a;
static const int PE_SIZEOF_SECTION_OPTIONS = 0x22;
extern PACKAGE short PE_FIELDS;
extern PACKAGE short PE_TEXT;
static const Shortint PE_GT_BARCHART = 0x0;
static const Shortint PE_GT_LINECHART = 0x1;
static const Shortint PE_GT_AREACHART = 0x2;
static const Shortint PE_GT_PIECHART = 0x3;
static const Shortint PE_GT_DOUGHNUTCHART = 0x4;
static const Shortint PE_GT_THREEDRISERCHART = 0x5;
static const Shortint PE_GT_THREEDSURFACECHART = 0x6;
static const Shortint PE_GT_SCATTERCHART = 0x7;
static const Shortint PE_GT_RADARCHART = 0x8;
static const Shortint PE_GT_BUBBLECHART = 0x9;
static const Shortint PE_GT_STOCKCHART = 0xa;
static const Shortint PE_GT_USERDEFINEDCHART = 0x32;
static const Shortint PE_GT_UNKNOWNTYPECHART = 0x64;
static const Shortint PE_GST_SIDEBYSIDEBARCHART = 0x0;
static const Shortint PE_GST_STACKEDBARCHART = 0x1;
static const Shortint PE_GST_PERCENTBARCHART = 0x2;
static const Shortint PE_GST_FAKED3DSIDEBYSIDEBARCHART = 0x3;
static const Shortint PE_GST_FAKED3DSTACKEDBARCHART = 0x4;
static const Shortint PE_GST_FAKED3DPERCENTBARCHART = 0x5;
static const Shortint PE_GST_REGULARLINECHART = 0xa;
static const Shortint PE_GST_STACKEDLINECHART = 0xb;
static const Shortint PE_GST_PERCENTAGELINECHART = 0xc;
static const Shortint PE_GST_LINECHARTWITHMARKERS = 0xd;
static const Shortint PE_GST_STACKEDLINECHARTWITHMARKERS = 0xe;
static const Shortint PE_GST_PERCENTAGELINECHARTWITHMARKERS = 0xf;
static const Shortint PE_GST_ABSOLUTEAREACHART = 0x14;
static const Shortint PE_GST_STACKEDAREACHART = 0x15;
static const Shortint PE_GST_PERCENTAREACHART = 0x16;
static const Shortint PE_GST_FAKED3DABSOLUTEAREACHART = 0x17;
static const Shortint PE_GST_FAKED3DSTACKEDAREACHART = 0x18;
static const Shortint PE_GST_FAKED3DPERCENTAREACHART = 0x19;
static const Shortint PE_GST_REGULARPIECHART = 0x1e;
static const Shortint PE_GST_FAKED3DREGULARPIECHART = 0x1f;
static const Shortint PE_GST_MULTIPLEPIECHART = 0x20;
static const Shortint PE_GST_MULTIPLEPROPORTIONALPIECHART = 0x21;
static const Shortint PE_GST_REGULARDOUGHNUTCHART = 0x28;
static const Shortint PE_GST_MULTIPLEDOUGHNUTCHART = 0x29;
static const Shortint PE_GST_MULTIPLEPROPORTIONALDOUGHNUTCHART = 0x2a;
static const Shortint PE_GST_THREEDREGULARCHART = 0x32;
static const Shortint PE_GST_THREEDPYRAMIDCHART = 0x33;
static const Shortint PE_GST_THREEDOCTAGONCHART = 0x34;
static const Shortint PE_GST_THREEDCUTCORNERSCHART = 0x35;
static const Shortint PE_GST_THREEDSURFACEREGULARCHART = 0x3c;
static const Shortint PE_GST_THREEDSURFACEWITHSIDESCHART = 0x3d;
static const Shortint PE_GST_THREEDSURFACEHONEYCOMBCHART = 0x3e;
static const Shortint PE_GST_XYSCATTERCHART = 0x46;
static const Shortint PE_GST_XYSCATTERDUALAXISCHART = 0x47;
static const Shortint PE_GST_XYSCATTERWITHLABELSCHART = 0x48;
static const Shortint PE_GST_XYSCATTERDUALAXISWITHLABELSCHART = 0x49;
static const Shortint PE_GST_REGULARRADARCHART = 0x50;
static const Shortint PE_GST_STACKEDRADARCHART = 0x51;
static const Shortint PE_GST_RADARDUALAXISCHART = 0x52;
static const Shortint PE_GST_REGULARBUBBLECHART = 0x5a;
static const Shortint PE_GST_DUALAXISBUBBLECHART = 0x5b;
static const Shortint PE_GST_HIGHLOWCHART = 0x64;
static const Shortint PE_GST_HIGHLOWDUALAXISCHART = 0x65;
static const Shortint PE_GST_HIGHLOWOPENCHART = 0x66;
static const Shortint PE_GST_HIGHLOWOPENDUALAXISCHART = 0x67;
static const Shortint PE_GST_HIGHLOWOPENCLOSECHART = 0x68;
static const Shortint PE_GST_HIGHLOWOPENCLOSEDUALAXISCHART = 0x69;
static const Word PE_GST_UNKNOWNSUBTYPECHART = 0x3e8;
static const int PE_SIZEOF_GRAPH_TYPE_INFO = 0x6;
static const Shortint PE_GTT_TITLE = 0x0;
static const Shortint PE_GTT_SUBTITLE = 0x1;
static const Shortint PE_GTT_FOOTNOTE = 0x2;
static const Shortint PE_GTT_SERIESTITLE = 0x3;
static const Shortint PE_GTT_GROUPSTITLE = 0x4;
static const Shortint PE_GTT_XAXISTITLE = 0x5;
static const Shortint PE_GTT_YAXISTITLE = 0x6;
static const Shortint PE_GTT_ZAXISTITLE = 0x7;
static const Shortint PE_GTF_TITLEFONT = 0x0;
static const Shortint PE_GTF_SUBTITLEFONT = 0x1;
static const Shortint PE_GTF_FOOTNOTEFONT = 0x2;
static const Shortint PE_GTF_GROUPSTITLEFONT = 0x3;
static const Shortint PE_GTF_DATATITLEFONT = 0x4;
static const Shortint PE_GTF_LEGENDFONT = 0x5;
static const Shortint PE_GTF_GROUPLABELSFONT = 0x6;
static const Shortint PE_GTF_DATALABELSFONT = 0x7;
static const Shortint PE_FACE_NAME_LEN = 0x40;
static const int PE_SIZEOF_FONT_COLOR_INFO = 0x58;
static const Shortint PE_GLP_PLACEUPPERRIGHT = 0x0;
static const Shortint PE_GLP_PLACEBOTTOMCENTER = 0x1;
static const Shortint PE_GLP_PLACETOPCENTER = 0x2;
static const Shortint PE_GLP_PLACERIGHT = 0x3;
static const Shortint PE_GLP_PLACELEFT = 0x4;
static const Shortint PE_GLL_PERCENTAGE = 0x0;
static const Shortint PE_GLL_AMOUNT = 0x1;
static const Shortint PE_GLL_CUSTOM = 0x2;
static const Shortint PE_GBS_MINIMUMBARSIZE = 0x0;
static const Shortint PE_GBS_SMALLBARSIZE = 0x1;
static const Shortint PE_GBS_AVERAGEBARSIZE = 0x2;
static const Shortint PE_GBS_LARGEBARSIZE = 0x3;
static const Shortint PE_GBS_MAXIMUMBARSIZE = 0x4;
static const Shortint PE_GPS_MINIMUMPIESIZE = 0x40;
static const Shortint PE_GPS_SMALLPIESIZE = 0x30;
static const Shortint PE_GPS_AVERAGEPIESIZE = 0x20;
static const Shortint PE_GPS_LARGEPIESIZE = 0x10;
static const Shortint PE_GPS_MAXIMUMPIESIZE = 0x0;
static const Shortint PE_GDPS_NODETACHMENT = 0x0;
static const Shortint PE_GDPS_SMALLESTSLICE = 0x1;
static const Shortint PE_GDPS_LARGESTSLICE = 0x2;
static const Shortint PE_GMS_SMALLMARKERS = 0x0;
static const Shortint PE_GMS_MEDIUMSMALLMARKERS = 0x1;
static const Shortint PE_GMS_MEDIUMMARKERS = 0x2;
static const Shortint PE_GMS_MEDIUMLARGEMARKERS = 0x3;
static const Shortint PE_GMS_LARGEMARKERS = 0x4;
static const Shortint PE_GMSP_RECTANGLESHAPE = 0x1;
static const Shortint PE_GMSP_CIRCLESHAPE = 0x4;
static const Shortint PE_GMSP_DIAMONDSHAPE = 0x5;
static const Shortint PE_GMSP_TRIANGLESHAPE = 0x8;
static const Shortint PE_GCR_COLORCHART = 0x0;
static const Shortint PE_GCR_BLACKANDWHITECHART = 0x1;
static const Shortint PE_GDP_NONE = 0x0;
static const Shortint PE_GDP_SHOWLABEL = 0x1;
static const Shortint PE_GDP_SHOWVALUE = 0x2;
static const Shortint PE_GDP_SHOWLABELVALUE = 0x3;
static const Shortint PE_GNF_NODECIMAL = 0x0;
static const Shortint PE_GNF_ONEDECIMAL = 0x1;
static const Shortint PE_GNF_TWODECIMAL = 0x2;
static const Shortint PE_GNF_UNKNOWNTYPE = 0x3;
static const Shortint PE_GNF_CURRENCYTWODECIMAL = 0x4;
static const Shortint PE_GNF_PERCENTNODECIMAL = 0x5;
static const Shortint PE_GNF_PERCENTONEDECIMAL = 0x6;
static const Shortint PE_GNF_PERCENTTWODECIMAL = 0x7;
static const Shortint PE_GNF_OTHER = 0x8;
static const Shortint PE_GVA_STANDARDVIEW = 0x1;
static const Shortint PE_GVA_TALLVIEW = 0x2;
static const Shortint PE_GVA_TOPVIEW = 0x3;
static const Shortint PE_GVA_DISTORTEDVIEW = 0x4;
static const Shortint PE_GVA_SHORTVIEW = 0x5;
static const Shortint PE_GVA_GROUPEYEVIEW = 0x6;
static const Shortint PE_GVA_GROUPEMPHASISVIEW = 0x7;
static const Shortint PE_GVA_FEWSERIESVIEW = 0x8;
static const Shortint PE_GVA_FEWGROUPSVIEW = 0x9;
static const Shortint PE_GVA_DISTORTEDSTDVIEW = 0xa;
static const Shortint PE_GVA_THICKGROUPSVIEW = 0xb;
static const Shortint PE_GVA_SHORTERVIEW = 0xc;
static const Shortint PE_GVA_THICKSERIESVIEW = 0xd;
static const Shortint PE_GVA_THICKSTDVIEW = 0xe;
static const Shortint PE_GVA_BIRDSEYEVIEW = 0xf;
static const Shortint PE_GVA_MAXVIEW = 0x10;
static const int PE_SIZEOF_GRAPH_OPTION_INFO = 0x1c;
static const Shortint PE_GGT_NOGRIDLINES = 0x0;
static const Shortint PE_GGT_MINORGRIDLINES = 0x1;
static const Shortint PE_GGT_MAJORGRIDLINES = 0x2;
static const Shortint PE_GGT_MAJORANDMINORGRIDLINES = 0x3;
static const Shortint PE_ADM_AUTOMATIC = 0x0;
static const Shortint PE_ADM_MANUAL = 0x1;
static const int PE_SIZEOF_GRAPH_AXIS_INFO = 0x5e;
static const Shortint SECTION_VISIBILITY = 0x3a;
static const Shortint NEW_PAGE_BEFORE = 0x3c;
static const Shortint NEW_PAGE_AFTER = 0x3d;
static const Shortint KEEP_SECTION_TOGETHER = 0x3e;
static const Shortint SUPPRESS_BLANK_SECTION = 0x3f;
static const Shortint RESET_PAGE_N_AFTER = 0x40;
static const Shortint PRINT_AT_BOTTOM_OF_PAGE = 0x41;
static const Shortint UNDERLAY_SECTION = 0x42;
static const Shortint SECTION_BACK_COLOUR = 0x43;
static const Shortint PE_FFN_AREASECTION_VISIBILITY = 0x3a;
static const Shortint PE_FFN_SECTION_VISIBILITY = 0x3a;
static const Shortint PE_FFN_SHOW_AREA = 0x3b;
static const Shortint PE_FFN_NEW_PAGE_BEFORE = 0x3c;
static const Shortint PE_FFN_NEW_PAGE_AFTER = 0x3d;
static const Shortint PE_FFN_KEEP_SECTION_TOGETHER = 0x3e;
static const Shortint PE_FFN_SUPPRESS_BLANK_SECTION = 0x3f;
static const Shortint PE_FFN_RESET_PAGE_N_AFTER = 0x40;
static const Shortint PE_FFN_PRINT_AT_BOTTOM_OF_PAGE = 0x41;
static const Shortint PE_FFN_UNDERLAY_SECTION = 0x42;
static const Shortint PE_FFN_SECTION_BACK_COLOUR = 0x43;
static const Byte PE_PARAMETER_NAME_LEN = 0x80;
static const Shortint PE_PT_LONGVARCHAR = 0xffffffff;
static const Shortint PE_PT_BINARY = 0xfffffffe;
static const Shortint PE_PT_VARBINARY = 0xfffffffd;
static const Shortint PE_PT_LONGVARBINARY = 0xfffffffc;
static const Shortint PE_PT_BIGINT = 0xfffffffb;
static const Shortint PE_PT_TINYINT = 0xfffffffa;
static const Shortint PE_PT_BIT = 0xfffffff9;
static const Shortint PE_PT_CHAR = 0x1;
static const Shortint PE_PT_NUMERIC = 0x2;
static const Shortint PE_PT_DECIMAL = 0x3;
static const Shortint PE_PT_INTEGER = 0x4;
static const Shortint PE_PT_SMALLINT = 0x5;
static const Shortint PE_PT_FLOAT = 0x6;
static const Shortint PE_PT_REAL = 0x7;
static const Shortint PE_PT_DOUBLE = 0x8;
static const Shortint PE_PT_DATE = 0x9;
static const Shortint PE_PT_TIME = 0xa;
static const Shortint PE_PT_TIMESTAMP = 0xb;
static const Shortint PE_PT_VARCHAR = 0xc;
static const Byte PE_PF_REPORT_NAME_LEN = 0x80;
static const Word PE_PF_NAME_LEN = 0x100;
static const Word PE_PF_PROMPT_LEN = 0x100;
static const Word PE_PF_VALUE_LEN = 0x100;
static const Word PE_PF_EDITMASK_LEN = 0x100;
static const Shortint PE_PF_NUMBER = 0x0;
static const Shortint PE_PF_CURRENCY = 0x1;
static const Shortint PE_PF_BOOLEAN = 0x2;
static const Shortint PE_PF_DATE = 0x3;
static const Shortint PE_PF_STRING = 0x4;
static const Shortint PE_PF_DATETIME = 0x5;
static const Shortint PE_PF_TIME = 0x6;
static const Shortint PE_PF_INTEGER = 0x7;
static const Shortint PE_PF_COLOR = 0x8;
static const Shortint PE_PF_CHAR = 0x9;
static const Shortint PE_PF_LONG = 0xa;
static const Shortint PE_PF_STRINGHANDLE = 0xb;
static const Shortint PE_PF_NOVALUE = 0x64;
static const int PE_SIZEOF_PARAMETER_FIELD_INFO = 0x5a0;
static const int PE_SIZEOF_VARINFO_TYPE = 0x5a0;
static const Shortint PE_VI_NUMBER = 0x0;
static const Shortint PE_VI_CURRENCY = 0x1;
static const Shortint PE_VI_BOOLEAN = 0x2;
static const Shortint PE_VI_DATE = 0x3;
static const Shortint PE_VI_STRING = 0x4;
static const Shortint PE_VI_DATETIME = 0x5;
static const Shortint PE_VI_TIME = 0x6;
static const Shortint PE_VI_INTEGER = 0x7;
static const Shortint PE_VI_COLOR = 0x8;
static const Shortint PE_VI_CHAR = 0x9;
static const Shortint PE_VI_LONG = 0xa;
static const Shortint PE_VI_STRINGHANDLE = 0xb;
static const Shortint PE_VI_HANDLE = 0xc;
static const Shortint PE_VI_LONGSTRINGHANDLE = 0xd;
static const Shortint PE_VI_NOVALUE = 0x64;
static const Word PE_VI_STRING_LEN = 0x100;
static const Shortint PE_VI_DATE_OR_TIME_LEN = 0x3;
static const Shortint PE_VI_DATETIME_LEN = 0x6;
static const int PE_SIZEOF_VALUE_INFO = 0x13c;
static const int PE_SIZEOF_VALUE_INFOW = 0x240;
static const Shortint PE_OR_NO_SORT = 0x0;
static const Shortint PE_OR_ALPHANUMERIC_ASCENDING = 0x1;
static const Shortint PE_OR_ALPHANUMERIC_DESCENDING = 0x2;
static const Shortint PE_OR_NUMERIC_ASCENDING = 0x3;
static const Shortint PE_OR_NUMERIC_DESCENDING = 0x4;
static const int PE_SIZEOF_PICK_LIST_OPTION = 0x8;
static const int PE_SIZEOF_PARAMETER_VALUE_INFO = 0x10;
static const Shortint PE_RI_INCLUDEUPPERBOUND = 0x1;
static const Shortint PE_RI_INCLUDELOWERBOUND = 0x2;
static const Shortint PE_RI_NOUPPERBOUND = 0x4;
static const Shortint PE_RI_NOLOWERBOUND = 0x8;
static const Shortint PE_DR_HASRANGE = 0x0;
static const Shortint PE_DR_HASDISCRETE = 0x1;
static const Shortint PE_DR_HASDISCRETEANDRANGE = 0x2;
static const Shortint PE_PO_REPORT = 0x0;
static const Shortint PE_PO_STOREDPROC = 0x1;
static const Shortint PE_PO_QUERY = 0x2;
static const Shortint PE_DLL_NAME_LEN = 0x40;
static const Word PE_FULL_NAME_LEN = 0x100;
static const Shortint PE_DT_STANDARD = 0x1;
static const Shortint PE_DT_SQL = 0x2;
static const Shortint PE_DT_SQL_STORED_PROCEDURE = 0x3;
static const int PE_SIZEOF_TABLE_TYPE = 0x148;
static const Byte PE_SESS_USERID_LEN = 0x80;
static const Byte PE_SESS_PASSWORD_LEN = 0x80;
static const int PE_SIZEOF_SESSION_INFO = 0x106;
static const int PE_SIZEOF_LOGON_INFO = 0x202;
static const int PE_SIZEOF_TABLE_LOCATION = 0x402;
static const Shortint PE_TCD_OKAY = 0x0;
static const Shortint PE_TCD_DATABASENOTFOUND = 0x1;
static const Shortint PE_TCD_SERVERNOTFOUND = 0x2;
static const Shortint PE_TCD_SERVERNOTOPENED = 0x4;
static const Shortint PE_TCD_ALIASCHANGED = 0x8;
static const Shortint PE_TCD_INDEXESCHANGED = 0x10;
static const Shortint PE_TCD_DRIVERCHANGED = 0x20;
static const Shortint PE_TCD_DICTIONARYCHANGED = 0x40;
static const Byte PE_TCD_FILETYPECHANGED = 0x80;
static const Word PE_TCD_RECORDSIZECHANGED = 0x100;
static const Word PE_TCD_ACCESSCHANGED = 0x200;
static const Word PE_TCD_PARAMETERSCHANGED = 0x400;
static const Word PE_TCD_LOCATIONCHANGED = 0x800;
static const Word PE_TCD_DATABASEOTHER = 0x1000;
static const int PE_TCD_NUMFIELDSCHANGED = 0x10000;
static const int PE_TCD_FIELDOTHER = 0x20000;
static const int PE_TCD_FIELDNAMECHANGED = 0x40000;
static const int PE_TCD_FIELDDESCCHANGED = 0x80000;
static const int PE_TCD_FIELDTYPECHANGED = 0x100000;
static const int PE_TCD_FIELDSIZECHANGED = 0x200000;
static const int PE_TCD_NATIVEFIELDTYPECHANGED = 0x400000;
static const int PE_TCD_NATIVEFIELDOFFSETCHANGED = 0x800000;
static const int PE_TCD_NATIVEFIELDSIZECHANGED = 0x1000000;
static const int PE_TCD_FIELDDECPLACESCHANGED = 0x2000000;
static const int PE_SIZEOF_TABLE_DIFFERENCE_INFO = 0xe;
static const int PE_SIZEOF_WINDOW_OPTIONS = 0x20;
static const Shortint PE_ZOOM_FULL_SIZE = 0x0;
static const Shortint PE_ZOOM_SIZE_FIT_ONE_SIDE = 0x1;
static const Shortint PE_ZOOM_SIZE_FIT_BOTH_SIDES = 0x2;
static const Word PE_MAXPAGEN = 0xffff;
static const Shortint PE_UNCOLLATED = 0x0;
static const Shortint PE_COLLATED = 0x1;
static const Shortint PE_DEFAULTCOLLATION = 0x2;
static const Shortint UXFCrystalReportType = 0x0;
static const Shortint UXFReportDefinitionType = 0x0;
static const int PE_SIZEOF_EXPORT_OPTIONS = 0x9e;
static const int PE_SIZEOF_EXPORT_OPTIONSW = 0x122;
static const Shortint UXDNotesType = 0x3;
static const int UXDNotesOptionsSize = 0xe;
static const Shortint UXDMAPIType = 0x0;
static const int UXDMAPIOptionsSize = 0x22;
static const Shortint UXDVIMType = 0x0;
static const int UXDVIMOptionsSize = 0x20;
static const Shortint UXDExchFolderType = 0x0;
static const Word UXDPostDocMessage = 0x3f3;
static const int UXDPostFolderOptionsSize = 0x12;
static const Shortint UXDApplicationType = 0x0;
static const int UXDApplicationOptionsSize = 0x6;
static const Shortint UXDDiskType = 0x0;
static const Word UXDCurVersion = 0x100;
static const int UXDDiskOptionsSize = 0x6;
static const Shortint DEFAULT_COLUMN_WIDTH = 0x9;
static const Word DEFAULT_COLUMN_WIDTH_IN_TWIPS = 0x2d0;
static const Byte MIN_CONST_COL_WIDTH_IN_TWIPS = 0xc8;
static const Word MAX_CONST_COL_WIDTH_IN_TWIPS = 0x1680;
static const Shortint UXFXl97Type = 0x9;
static const Shortint UXFXlRecDumpType = 0xa;
static const int UXFXlsOptionsSize = 0x54;
static const Shortint UXFTextType = 0x0;
static const Shortint UXFTabbedTextType = 0x1;
static const Shortint UXFPaginatedTextType = 0x2;
static const int UXFPaginatedTextOptionsSize = 0xc;
static const Shortint UXFRecordType = 0x0;
static const Shortint UXFRecord6Type = 0x1;
static const Word UXFCurVersion = 0x100;
static const int UXFRecordStyleOptionsSize = 0xa;
static const Shortint UXFCommaSeparatedType = 0x0;
static const Shortint UXFTabSeparatedType = 0x1;
static const Shortint UXFCharSeparatedType = 0x2;
static const Shortint UXFSeparatedValuesType = 0x3;
static const int UXFCharCommaTabSeparatedOptionsSize = 0x11;
static const Shortint MAX_ODBC_SOURCES = 0x64;
static const Shortint UXFODBCType = 0x65;
static const int UXFODBCOptionsSize = 0x14;
static const Shortint UXFHTML32StdType = 0x2;
static const Shortint UXFHTML40Type = 0x3;
static const Shortint UXFDHTMLType = 0x3;
static const Shortint UXFJPGExtensionStyle = 0x0;
static const int UXFHTML3OptionsSize = 0x1a;
static const Word EncodedOptionsMask = 0x8000;
static const Shortint UXFPortableDocumentFormat = 0x0;
static const int UXFPDFFormatOptionsSize = 0x18;
static const Shortint UXFExactRichTextFormatType = 0x0;
static const int UXFERTFFormatOptionsSize = 0x18;
static const Shortint UFXEditableRTFFormatType = 0x1;
static const int UXFEditableRTFFormatOptionsSize = 0x14;
static const Shortint UXFXMLType = 0x0;
static const int UXFXmlOptionsSize = 0x8;
static const Shortint UXFExactDocFormatType = 0x0;
static const Shortint UXFWordWinType = 0x0;
static const int UXFEDOCFormatOptionsSize = 0x18;
static const Word PE_SM_DEFAULT = 0x8000;
static const Byte PE_SI_APPLICATION_NAME_LEN = 0x80;
static const Byte PE_SI_TITLE_LEN = 0x80;
static const Byte PE_SI_SUBJECT_LEN = 0x80;
static const Byte PE_SI_AUTHOR_LEN = 0x80;
static const Byte PE_SI_KEYWORDS_LEN = 0x80;
static const Word PE_SI_COMMENTS_LEN = 0x200;
static const Byte PE_SI_REPORT_TEMPLATE_LEN = 0x80;
static const int PE_SIZEOF_REPORT_SUMMARY_INFO = 0x504;
static const Shortint PE_CLOSE_PRINT_WINDOW_EVENT = 0x1;
static const Shortint PE_ACTIVATE_PRINT_WINDOW_EVENT = 0x2;
static const Shortint PE_DEACTIVATE_PRINT_WINDOW_EVENT = 0x3;
static const Shortint PE_PRINT_BUTTON_CLICKED_EVENT = 0x4;
static const Shortint PE_EXPORT_BUTTON_CLICKED_EVENT = 0x5;
static const Shortint PE_ZOOM_CONTROL_SELECTED_EVENT = 0x6;
static const Shortint PE_FIRST_PAGE_BUTTON_CLICKED_EVENT = 0x7;
static const Shortint PE_PREVIOUS_PAGE_BUTTON_CLICKED_EVENT = 0x8;
static const Shortint PE_NEXT_PAGE_BUTTON_CLICKED_EVENT = 0x9;
static const Shortint PE_LAST_PAGE_BUTTON_CLICKED_EVENT = 0xa;
static const Shortint PE_CANCEL_BUTTON_CLICKED_EVENT = 0xb;
static const Shortint PE_CLOSE_BUTTON_CLICKED_EVENT = 0xc;
static const Shortint PE_SEARCH_BUTTON_CLICKED_EVENT = 0xd;
static const Shortint PE_GROUPTREE_BUTTON_CLICKED_EVENT = 0xe;
static const Shortint PE_PRINT_SETUP_BUTTON_CLICKED_EVENT = 0xf;
static const Shortint PE_REFRESH_BUTTON_CLICKED_EVENT = 0x10;
static const Shortint PE_SHOW_GROUP_EVENT = 0x11;
static const Shortint PE_DRILL_ON_GROUP_EVENT = 0x12;
static const Shortint PE_DRILL_ON_DETAIL_EVENT = 0x13;
static const Shortint PE_READING_RECORDS_EVENT = 0x14;
static const Shortint PE_START_EVENT = 0x15;
static const Shortint PE_STOP_EVENT = 0x16;
static const Shortint PE_MAPPING_FIELD_EVENT = 0x17;
static const Shortint PE_RIGHT_CLICK_EVENT = 0x18;
static const Shortint PE_LEFT_CLICK_EVENT = 0x19;
static const Shortint PE_MIDDLE_CLICK_EVENT = 0x1a;
static const Shortint PE_DRILL_ON_HYPERLINK_EVENT = 0x1b;
static const Shortint PE_LAUNCH_SEAGATE_ANALYSIS_EVENT = 0x1c;
static const int PE_SIZEOF_ENABLE_EVENT_INFO = 0x18;
static const int PE_SIZEOF_GENERAL_PRINT_WINDOW_EVENT_INFO = 0x8;
static const Shortint PE_TO_NOWHERE = 0x0;
static const Shortint PE_TO_WINDOW = 0x1;
static const Shortint PE_TO_PRINTER = 0x2;
static const Shortint PE_TO_EXPORT = 0x3;
static const Shortint PE_FROM_QUERY = 0x4;
static const Shortint PE_TO_FAX = 0x5;
static const int PE_SIZEOF_START_EVENT_INFO = 0x4;
static const int PE_SIZEOF_STOP_EVENT_INFO = 0x6;
static const int PE_SIZEOF_READING_RECORDS_EVENT_INFO = 0xe;
static const int PE_SIZEOF_ZOOM_LEVEL_CHANGING_EVENT_INFO = 0x8;
static const int PE_SIZEOF_CLOSE_BUTTON_CLICKED_EVENT_INFO = 0x8;
static const Byte PE_SEARCH_STRING_LEN = 0x80;
static const int PE_SIZEOF_SEARCH_BUTTON_CLICKED_EVENT_INFO = 0x106;
static const int PE_SIZEOF_GROUP_TREE_BUTTON_CLICKED_EVENT_INFO = 0x8;
static const int PE_SIZEOF_SHOW_GROUP_EVENT_INFO = 0xc;
static const Shortint PE_DE_ON_GROUP = 0x0;
static const Shortint PE_DE_ON_GROUPTREE = 0x1;
static const Shortint PE_DE_ON_GRAPH = 0x2;
static const Shortint PE_DE_ON_MAP = 0x3;
static const Shortint PE_DE_ON_SUBREPORT = 0x4;
static const int PE_SIZEOF_DRILL_ON_GROUP_EVENT_INFO = 0xe;
static const int PE_SIZEOF_FIELD_VALUE_INFO = 0x644;
static const int PE_SIZEOF_DRILL_ON_DETAIL_EVENT_INFO = 0xe;
static const Shortint PE_MOUSE_NOTSUPPORTED = 0x0;
static const Shortint PE_MOUSE_DOWN = 0x1;
static const Shortint PE_MOUSE_UP = 0x2;
static const Shortint PE_MOUSE_DOUBLE_CLICK = 0x3;
static const Shortint PE_CF_NONE = 0x0;
static const Shortint PE_CF_LBUTTON = 0x1;
static const Shortint PE_CF_RBUTTON = 0x2;
static const Shortint PE_CF_SHIFTKEY = 0x4;
static const Shortint PE_CF_CONTROLKEY = 0x8;
static const Shortint PE_CF_MBUTTON = 0x10;
static const int PE_SIZEOF_MOUSE_CLICK_EVENT_INFO = 0x25c;
static const Byte PE_TABLE_NAME_LEN = 0x80;
static const Byte PE_DATABASE_FIELD_NAME_LEN = 0x80;
static const Byte PE_FIELD_DESCRIPTION_LEN = 0x80;
static const Shortint PE_FVT_INT8SFIELD = 0x1;
static const Shortint PE_FVT_INT8UFIELD = 0x2;
static const Shortint PE_FVT_INT16SFIELD = 0x3;
static const Shortint PE_FVT_INT16UFIELD = 0x4;
static const Shortint PE_FVT_INT32SFIELD = 0x5;
static const Shortint PE_FVT_INT32UFIELD = 0x6;
static const Shortint PE_FVT_NUMBERFIELD = 0x7;
static const Shortint PE_FVT_CURRENCYFIELD = 0x8;
static const Shortint PE_FVT_BOOLEANFIELD = 0x9;
static const Shortint PE_FVT_DATEFIELD = 0xa;
static const Shortint PE_FVT_TIMEFIELD = 0xb;
static const Shortint PE_FVT_STRINGFIELD = 0xc;
static const Shortint PE_FVT_TRANSIENTMEMOFIELD = 0xd;
static const Shortint PE_FVT_PERSISTENTMEMOFIELD = 0xe;
static const Shortint PE_FVT_BLOBFIELD = 0xf;
static const Shortint PE_FVT_DATETIMEFIELD = 0x10;
static const Shortint PE_FVT_BITMAPFIELD = 0x11;
static const Shortint PE_FVT_ICONFIELD = 0x12;
static const Shortint PE_FVT_PICTUREFIELD = 0x13;
static const Shortint PE_FVT_OLEFIELD = 0x14;
static const Shortint PE_FVT_GRAPHFIELD = 0x15;
static const Shortint PE_FVT_UNKNOWNFIELD = 0x16;
static const Shortint PE_FM_AUTO_FLD_MAP = 0x0;
static const Shortint PE_FM_CRPE_PROMPT_FLD_MAP = 0x1;
static const Shortint PE_FM_EVENT_DEFINED_FLD_MAP = 0x2;
static const int PE_SIZEOF_REPORT_FIELDMAPPING_INFO = 0x108;
static const int PE_SIZEOF_FIELDMAPPING_EVENT_INFO = 0xe;
static const int PE_SIZEOF_HYPERLINK_EVENT_INFO = 0xc;
static const int PE_SIZEOF_LAUNCH_SEAGATE_ANALYSIS_EVENT_INFO = 0xc;
static const Shortint PE_TC_DEFAULT_CURSOR = 0x0;
static const Shortint PE_TC_ARROW_CURSOR = 0x1;
static const Shortint PE_TC_CROSS_CURSOR = 0x2;
static const Shortint PE_TC_IBEAM_CURSOR = 0x3;
static const Shortint PE_TC_UPARROW_CURSOR = 0x4;
static const Shortint PE_TC_SIZEALL_CURSOR = 0x5;
static const Shortint PE_TC_SIZENWSE_CURSOR = 0x6;
static const Shortint PE_TC_SIZENESW_CURSOR = 0x7;
static const Shortint PE_TC_SIZEWE_CURSOR = 0x8;
static const Shortint PE_TC_SIZENS_CURSOR = 0x9;
static const Shortint PE_TC_NO_CURSOR = 0xa;
static const Shortint PE_TC_WAIT_CURSOR = 0xb;
static const Shortint PE_TC_APPSTARTING_CURSOR = 0xc;
static const Shortint PE_TC_HELP_CURSOR = 0xd;
static const Shortint PE_TC_SIZE_CURSOR = 0xe;
static const Shortint PE_TC_ICON_CURSOR = 0xf;
static const Shortint PE_TC_BACKGROUND_PROCESS_CURSOR = 0x5e;
static const Shortint PE_TC_GRAB_HAND_CURSOR = 0x5f;
static const Shortint PE_TC_ZOOM_IN_CURSOR = 0x60;
static const Shortint PE_TC_REPORT_SECTION_CURSOR = 0x61;
static const Shortint PE_TC_HAND_CURSOR = 0x62;
static const Shortint PE_TC_MAGNIFY_CURSOR = 0x63;
static const int PE_SIZEOF_TRACK_CURSOR_INFO = 0x24;
static const Shortint PE_AL_DEFAULT_ALIGN = 0x0;
static const Shortint PE_AL_LEFT_ALIGN = 0x1;
static const Shortint PE_AL_CENTER_ALIGN = 0x2;
static const Shortint PE_AL_RIGHT_ALIGN = 0x3;
static const Shortint PE_AL_JUSTIFIED = 0x4;
static const Shortint PE_AL_DECIMAL = 0x5;
static const Shortint PE_AL_TOP_ALIGN = 0x6;
static const Shortint PE_AL_BOTTOM_ALIGN = 0x7;
static const Shortint PE_AL_VCENTER_ALIGN = 0x8;
static const Shortint PE_LS_NO_LINE = 0x0;
static const Shortint PE_LS_SINGLE_LINE = 0x1;
static const Shortint PE_LS_DOUBLE_LINE = 0x2;
static const Shortint PE_LS_DASH_LINE = 0x3;
static const Shortint PE_LS_DOT_LINE = 0x4;
static const Shortint PE_NNT_NOT_NEGATIVE = 0x0;
static const Shortint PE_NNT_LEADING_MINUS = 0x1;
static const Shortint PE_NNT_TRAILING_MINUS = 0x2;
static const Shortint PE_NNT_BRACKETED = 0x3;
static const Shortint PE_NRT_ROUND_TO_TEN_BILLIONTH = 0x1;
static const Shortint PE_NRT_ROUND_TO_BILLIONTH = 0x2;
static const Shortint PE_NRT_ROUND_TO_HUNDRED_MILLIONTH = 0x3;
static const Shortint PE_NRT_ROUND_TO_TEN_MILLIONTH = 0x4;
static const Shortint PE_NRT_ROUND_TO_MILLIONTH = 0x5;
static const Shortint PE_NRT_ROUND_TO_HUNDRED_THOUSANDTH = 0x6;
static const Shortint PE_NRT_ROUND_TO_TEN_THOUSANDTH = 0x7;
static const Shortint PE_NRT_ROUND_TO_THOUSANDTH = 0x8;
static const Shortint PE_NRT_ROUND_TO_HUNDREDTH = 0x9;
static const Shortint PE_NRT_ROUND_TO_TENTH = 0xa;
static const Shortint PE_NRT_ROUND_TO_UNIT = 0xb;
static const Shortint PE_NRT_ROUND_TO_TEN = 0xc;
static const Shortint PE_NRT_ROUND_TO_HUNDRED = 0xd;
static const Shortint PE_NRT_ROUND_TO_THOUSAND = 0xe;
static const Shortint PE_NRT_ROUND_TO_TENTHOUSAND = 0xf;
static const Shortint PE_NRT_ROUND_TO_HUNDREDTHOUSAND = 0x10;
static const Shortint PE_NRT_ROUND_TO_MILLION = 0x11;
static const Shortint PE_CST_NO_SYMBOL = 0x0;
static const Shortint PE_CST_FIXED_SYMBOL = 0x1;
static const Shortint PE_CST_FLOATING_SYMBOL = 0x2;
static const Shortint PE_CPT_LEADING_CURRENCY_INSIDE_NEGATIVE = 0x1;
static const Shortint PE_CPT_LEADING_CURRENCY_OUTSIDE_NEGATIVE = 0x0;
static const Shortint PE_CPT_TRAILING_CURRENCY_INSIDE_NEGATIVE = 0x3;
static const Shortint PE_CPT_TRAILING_CURRENCY_OUTSIDE_NEGATIVE = 0x2;
static const Shortint PE_BOT_TRUE_OR_FALSE = 0x0;
static const Shortint PE_BOT_T_OR_F = 0x1;
static const Shortint PE_BOT_YES_OR_NO = 0x2;
static const Shortint PE_BOT_Y_OR_N = 0x3;
static const Shortint PE_BOT_ONE_OR_ZERO = 0x4;
static const Shortint PE_DWDT_USE_WINDOWS_LONG_DATE = 0x0;
static const Shortint PE_DWDT_USE_WINDOWS_SHORT_DATE = 0x1;
static const Shortint PE_DWDT_NOT_USING_WINDOWS_DEFAULTS = 0x2;
static const Shortint PE_DO_YEAR_MONTH_DAY = 0x0;
static const Shortint PE_DO_DAY_MONTH_YEAR = 0x1;
static const Shortint PE_DO_MONTH_DAY_YEAR = 0x2;
static const Shortint PE_DYT_SHORT_YEAR = 0x0;
static const Shortint PE_DYT_LONG_YEAR = 0x1;
static const Shortint PE_DYT_NO_YEAR = 0x2;
static const Shortint PE_DMT_NUMERIC_MONTH = 0x0;
static const Shortint PE_DMT_LEADING_ZERO_NUMERIC_MONTH = 0x1;
static const Shortint PE_DMT_SHORT_MONTH = 0x2;
static const Shortint PE_DMT_LONG_MONTH = 0x3;
static const Shortint PE_DMT_NO_MONTH = 0x4;
static const Shortint PE_DDT_NUMERIC_DAY = 0x0;
static const Shortint PE_DDT_LEADING_ZERO_NUMERIC_DAY = 0x1;
static const Shortint PE_DDT_NO_DAY = 0x2;
static const Shortint PE_DOWT_SHORT_DAY_OF_WEEK = 0x0;
static const Shortint PE_DOWT_LONG_DAY_OF_WEEK = 0x1;
static const Shortint PE_DOWT_NO_DAY_OF_WEEK = 0x2;
static const Shortint PE_DOWP_LEADING_DAY_OF_WEEK = 0x0;
static const Shortint PE_DOWP_TRAILING_DAY_OF_WEEK = 0x1;
static const Shortint PE_DOWE_NONE = 0x0;
static const Shortint PE_DOWE_PARENTHESES = 0x1;
static const Shortint PE_DOWE_FWPARENTHESES = 0x2;
static const Shortint PE_DOWE_SQUARE_BRACKETS = 0x3;
static const Shortint PE_DOWE_FWSQUARE_BRACKETS = 0x4;
static const Shortint PE_DET_SHORT_ERA = 0x0;
static const Shortint PE_DET_LONG_ERA = 0x1;
static const Shortint PE_DET_NO_ERA = 0x2;
static const Shortint PE_DCT_GREGORIANCALENDAR = 0x1;
static const Shortint PE_DCT_GREGORIANUSCALENDAR = 0x2;
static const Shortint PE_DCT_JAPANESECALENDAR = 0x3;
static const Shortint PE_DCT_TAIWANESECALENDAR = 0x4;
static const Shortint PE_DCT_KOREANCALENDAR = 0x5;
static const Shortint PE_DCT_HIJRICALENDAR = 0x6;
static const Shortint PE_DCT_THAICALENDAR = 0x7;
static const Shortint PE_DCT_HEBREWCALENDAR = 0x8;
static const Shortint PE_DCT_GREGORIANMEFRENCHCALENDAR = 0x9;
static const Shortint PE_DCT_GREGORIANARABICCALENDAR = 0xa;
static const Shortint PE_DCT_GREGORIANXLITENGLISHCALENDAR = 0xb;
static const Shortint PE_DCT_GREGORIANXLITFRENCHCALENDAR = 0xc;
static const Shortint PE_TB_12_HOUR = 0x0;
static const Shortint PE_TB_24_HOUR = 0x1;
static const Shortint PE_TAPT_AM_PM_BEFORE = 0x0;
static const Shortint PE_TAPT_AM_PM_AFTER = 0x1;
static const Shortint PE_THT_NUMERIC_HOUR = 0x0;
static const Shortint PE_THT_NUMBERIC_HOUR_NO_LEADING_ZERO = 0x1;
static const Shortint PE_THT_NO_HOUR = 0x2;
static const Shortint PE_TMT_NUMERIC_MINUTE = 0x0;
static const Shortint PE_TMT_NUMERIC_MINUTE_NO_LEADING_ZERO = 0x1;
static const Shortint PE_TMT_NO_MINUTE = 0x2;
static const Shortint PE_TST_NUMERIC_SECOND = 0x0;
static const Shortint PE_TST_NUMERIC_SECOND_NO_LEADING_ZERO = 0x1;
static const Shortint PE_TST_NUMERIC_NO_SECOND = 0x2;
static const Shortint PE_DTO_DATE_THEN_TIME = 0x0;
static const Shortint PE_DTO_TIME_THEN_DATE = 0x1;
static const Shortint PE_DTO_DATE_ONLY = 0x2;
static const Shortint PE_DTO_TIME_ONLY = 0x3;
static const Shortint PE_NO_LINE_WIDTH = 0x0;
static const Shortint PE_SINGLE_LINE_WIDTH = 0x14;
static const Shortint PE_DOUBLE_LINE_WIDTH = 0x3c;
static const Shortint PE_DASH_LINE_WIDTH = 0x14;
static const Shortint PE_DOT_LINE_WIDTH = 0x14;
static const Shortint PE_DROP_SHADOW_WIDTH = 0x3c;
static const Shortint PE_TI_NONE = 0x0;
static const Shortint PE_TI_RTF = 0x1;
static const Shortint PE_TI_HTML = 0x2;
static const Shortint PE_LSPC_MULTIPLE = 0x0;
static const Shortint PE_LSPC_EXACT = 0x1;
static const Shortint PE_OFN_VISIBLE = 0x1;
static const Shortint PE_OFN_HORALIGNMENT = 0x2;
static const Shortint PE_OFN_VERALIGNMENT = 0x3;
static const Shortint PE_OFN_KEEP_OBJECT_TOGETHER = 0x4;
static const Shortint PE_OFN_SPLIT_ADORNMENT = 0x5;
static const Shortint PE_OFN_EXPAND = 0x6;
static const Shortint PE_OFN_LEFT_LINE_STYLE = 0x7;
static const Shortint PE_OFN_RIGHT_LINE_STYLE = 0x8;
static const Shortint PE_OFN_TOP_LINE_STYLE = 0x9;
static const Shortint PE_OFN_BOTTOM_LINE_STYLE = 0xa;
static const Shortint PE_OFN_TIGHT_HORIZONTAL = 0xb;
static const Shortint PE_OFN_TIGHT_VERTICAL = 0xc;
static const Shortint PE_OFN_DROP_SHADOW = 0xd;
static const Shortint PE_OFN_FORE_COLOR = 0xe;
static const Shortint PE_OFN_BACK_COLOR = 0xf;
static const Shortint PE_OFN_SUPPRESS_IF_DUPLICATED = 0x10;
static const Shortint PE_OFN_USE_SYSTEM_DEFAULT_FORMATTING = 0x11;
static const Shortint PE_OFN_SUPPRESS_IF_ZERO = 0x12;
static const Shortint PE_OFN_NEGATIVE_TYPE = 0x13;
static const Shortint PE_OFN_USE_THOUSANDSSEPARATORS = 0x14;
static const Shortint PE_OFN_USE_LEAD_ZERO = 0x15;
static const Shortint PE_OFN_N_DECIMAL_PLACES = 0x16;
static const Shortint PE_OFN_ROUNDING_TYPE = 0x17;
static const Shortint PE_OFN_REVERSE_SIGN_FOR_DISPLAY = 0x3f;
static const Shortint PE_OFN_USE_ACCOUNTING_FORMAT = 0x40;
static const Shortint PE_OFN_CURRENCY_SYMBOL = 0x1d;
static const Shortint PE_OFN_CURRENCY_SYMBOL_TYPE = 0x18;
static const Shortint PE_OFN_USE_ONE_CURRENCY_SYMBOL_PER_PAGE = 0x19;
static const Shortint PE_OFN_CURRENCY_POSITION_TYPE = 0x1a;
static const Shortint PE_OFN_THOUSAND_SYMBOL = 0x1b;
static const Shortint PE_OFN_DECIMAL_SYMBOL = 0x1c;
static const Shortint PE_OFN_SHOW_ZERO_VALUE_AS = 0x41;
static const Shortint PE_OFN_ALLOW_FIELD_CLIPPING = 0x1e;
static const Shortint PE_OFN_BOOLEAN_OUPUT_TYPE = 0x1f;
static const Shortint PE_OFN_DATE_WINDOWS_DEFAULT_TYPE = 0x20;
static const Shortint PE_OFN_DATE_ORDER = 0x21;
static const Shortint PE_OFN_YEAR_TYPE = 0x22;
static const Shortint PE_OFN_MONTH_TYPE = 0x23;
static const Shortint PE_OFN_DAY_TYPE = 0x24;
static const Shortint PE_OFN_DAY_OF_WEEK_TYPE = 0x25;
static const Shortint PE_OFN_DATE_FIRST_SEPARATOR = 0x26;
static const Shortint PE_OFN_DATE_SECOND_SEPARATOR = 0x27;
static const Shortint PE_OFN_DAY_OF_WEEK_SEPARATOR = 0x28;
static const Shortint PE_OFN_DAY_OF_WEEK_POSITION = 0x39;
static const Shortint PE_OFN_DATE_ERA_TYPE = 0x3a;
static const Shortint PE_OFN_DATE_CALENDAR_TYPE = 0x3b;
static const Shortint PE_OFN_DATE_PREFIX_SEPARATOR = 0x3c;
static const Shortint PE_OFN_DATE_SUFFIX_SEPARATOR = 0x3d;
static const Shortint PE_OFN_DAY_OF_WEEK_ENCLOSURE = 0x3e;
static const Shortint PE_OFN_TIME_BASE = 0x29;
static const Shortint PE_OFN_AM_PM_TYPE = 0x2a;
static const Shortint PE_OFN_HOUR_TYPE = 0x2b;
static const Shortint PE_OFN_MINUTE_TYPE = 0x2c;
static const Shortint PE_OFN_SECOND_TYPE = 0x2d;
static const Shortint PE_OFN_PM_STRING = 0x2e;
static const Shortint PE_OFN_AM_STRING = 0x2f;
static const Shortint PE_OFN_MINUTE_SECOND_SEPARATOR = 0x30;
static const Shortint PE_OFN_HOUR_MINUTE_SEPARATOR = 0x31;
static const Shortint PE_OFN_DATE_TIME_ORDER = 0x32;
static const Shortint PE_OFN_DATE_TIME_SEPARATOR_STRING = 0x33;
static const Shortint PE_OFN_WORD_WRAP = 0x34;
static const Shortint PE_OFN_FIRST_LINE_INDENT = 0x35;
static const Shortint PE_OFN_LEFT_INDENT = 0x36;
static const Shortint PE_OFN_RIGHT_INDENT = 0x37;
static const Shortint PE_OFN_MAX_N_LINES = 0x38;
static const Shortint PE_OFN_TEXT_INTERPRETATION = 0x42;
static const Shortint PE_OFN_LINE_SPACING_TYPE = 0x43;
static const Shortint PE_OFN_LINE_SPACING = 0x44;
static const Shortint PE_OFN_CHARACTER_SPACING = 0x45;
static const Shortint PE_OFN_TEXT_ROTATION = 0x46;
static const Shortint PE_OI_FIELDOBJECT = 0x1;
static const Shortint PE_OI_TEXTOBJECT = 0x2;
static const Shortint PE_OI_LINEOBJECT = 0x3;
static const Shortint PE_OI_BOXOBJECT = 0x4;
static const Shortint PE_OI_SUBREPORTOBJECT = 0x5;
static const Shortint PE_OI_OLEOBJECT = 0x6;
static const Shortint PE_OI_GRAPHOBJECT = 0x7;
static const Shortint PE_OI_CROSSTABOBJECT = 0x8;
static const Shortint PE_OI_BLOBFIELDOBJECT = 0x9;
static const Shortint PE_OI_MAPOBJECT = 0xa;
static const Shortint PE_OI_OLAPGRIDOBJECT = 0xb;
static const int PE_SIZEOF_OBJECT_INFO = 0x1c;
static const Shortint PE_OOI_LINKEDOBJECT = 0x1;
static const Shortint PE_OOI_EMBEDDEDOBJECT = 0x2;
static const Shortint PE_OOI_STATICOBJECT = 0x3;
static const Shortint PE_OOI_AUTOUPDATE = 0x1;
static const Shortint PE_OOI_MANUALUPDATE = 0x3;
static const Word PE_OOI_PATHLEN = 0x100;
static const int PE_SIZEOF_OLE_OBJECT_INFO = 0x106;
static const Shortint PE_ST_SUM = 0x0;
static const Shortint PE_ST_AVERAGE = 0x1;
static const Shortint PE_ST_SAMPLEVARIANCE = 0x2;
static const Shortint PE_ST_SAMPLESTDDEV = 0x3;
static const Shortint PE_ST_MAXIMUM = 0x4;
static const Shortint PE_ST_MINIMUM = 0x5;
static const Shortint PE_ST_COUNT = 0x6;
static const Shortint PE_ST_POPVARIANCE = 0x7;
static const Shortint PE_ST_POPSTDDEV = 0x8;
static const Shortint PE_ST_DISTINCTCOUNT = 0x9;
static const Shortint PE_ST_CORRELATION = 0xa;
static const Shortint PE_ST_COVARIANCE = 0xb;
static const Shortint PE_ST_WEIGHTEDAVG = 0xc;
static const Shortint PE_ST_MEDIAN = 0xd;
static const Shortint PE_ST_PERCENTILE = 0xe;
static const Shortint PE_ST_NTHLARGEST = 0xf;
static const Shortint PE_ST_NTHSMALLEST = 0x10;
static const Shortint PE_ST_MODE = 0x11;
static const Shortint PE_ST_NTHMOSTFREQUENT = 0x12;
static const Shortint PE_ST_PERCENTAGE = 0x13;
static const Shortint PE_SVT_PRINTDATE = 0x0;
static const Shortint PE_SVT_PRINTTIME = 0x1;
static const Shortint PE_SVT_MODIFICATIONDATE = 0x2;
static const Shortint PE_SVT_MODIFICATIONTIME = 0x3;
static const Shortint PE_SVT_DATADATE = 0x4;
static const Shortint PE_SVT_DATATIME = 0x5;
static const Shortint PE_SVT_RECORDNUMBER = 0x6;
static const Shortint PE_SVT_PAGENUMBER = 0x7;
static const Shortint PE_SVT_GROUPNUMBER = 0x8;
static const Shortint PE_SVT_TOTALPAGECOUNT = 0x9;
static const Shortint PE_SVT_REPORTTITLE = 0xa;
static const Shortint PE_SVT_REPORTCOMMENTS = 0xb;
static const Shortint PE_SVT_RECORDSELECTION = 0xc;
static const Shortint PE_SVT_GROUPSELECTION = 0xd;
static const Shortint PE_SVT_FILENAME = 0xe;
static const Shortint PE_SVT_FILEAUTHOR = 0xf;
static const Shortint PE_SVT_FILECREATIONDATE = 0x10;
static const Shortint PE_SVT_PAGENOFM = 0x11;
static const Shortint PE_FIET_DATABASE = 0x1;
static const Shortint PE_FIET_FORMULA = 0x2;
static const Shortint PE_FIET_SUMMARY = 0x3;
static const Shortint PE_FIET_SPECIALVAR = 0x4;
static const Shortint PE_FIET_GROUPNAME = 0x5;
static const Shortint PE_FIET_PARAMETER = 0x6;
static const Shortint PE_FIET_SQLEXPRESSION = 0x7;
static const Shortint PE_FIET_RUNNINGTOTAL = 0x8;
static const int PE_SIZEOF_FIELD_OBJECT_INFO = 0x208;
static const int PE_SIZEOF_PARAGRAPH_INFO = 0x18;
static const int PE_SIZEOF_TABSTOP_INFO = 0x8;
static const int PE_SIZEOF_EMBEDDED_FIELD_INFO = 0x20c;
static const int PE_SIZEOF_INSERT_TEXT_INFO = 0x216;
static const int PE_SIZEOF_SUBREPORT_LINK_INFO = 0x602;
static const Shortint PE_SRI_UNDEFINED = 0xffffffff;
static const Shortint PE_SRI_ONOPENJOB = 0x0;
static const Shortint PE_SRI_ONFUNCTIONCALL = 0x1;
static const int PE_SIZEOF_LINE_OBJECT_INFO = 0x22;
static const int PE_SIZEOF_BOX_OBJECT_INFO = 0x32;
static const int PE_SIZEOF_PICTURE_FORMAT_INFO = 0x24;
static const int PE_SIZEOF_CROSSTABOPTIONS = 0x1a;
static const int PE_SIZEOF_CROSSTAB_SUMMARY_FIELD_INFO = 0x410;
static const int PE_SIZEOF_CROSS_TAB_GROUP_OPTIONS = 0x210;
static const Shortint PE_CTRC_ROW = 0x0;
static const Shortint PE_CTRC_COL = 0x1;
static const Shortint PE_GDT_GROUP_GRAPH = 0x0;
static const Shortint PE_GDT_DETAIL_GRAPH = 0x1;
static const Shortint PE_GDT_CROSSTAB_GRAPH = 0x2;
static const Shortint PE_GDT_OLAPGRIDGRAPH = 0x3;
static const int PE_SIZEOF_GRAPH_DATA_TYPE_INFO = 0x8;
static const Shortint PE_FFN_OBJECT_VISIBILITY = 0x34;
static const Shortint PE_FFN_HOR_ALIGNMENT = 0x35;
static const Shortint PE_FFN_KEEP_OBJECT_TOGETHER = 0x37;
static const Shortint PE_FFN_SPLIT_ADORNMENT = 0x38;
static const Shortint PE_FFN_EXPAND = 0x39;
static const Shortint PE_FFN_KEEP_TOGETHER = 0x3e;
static const Shortint PE_FFN_SUPPRESS_IF_DUPLICATE = 0x1;
static const Shortint PE_FFN_SUPPRESS_IF_ZERO = 0x2;
static const Shortint PE_FFN_NEGATIVE_TYPE = 0x3;
static const Shortint PE_FFN_USE_THOUSANDS_SEPARATORS = 0x4;
static const Shortint PE_FFN_USE_LEADING_ZERO = 0x5;
static const Shortint PE_FFN_N_DECIMAL_PLACES = 0x6;
static const Shortint PE_FFN_ROUNDING_TYPE = 0x7;
static const Shortint PE_FFN_CURRENCY_SYMBOL_TYPE = 0x8;
static const Shortint PE_FFN_USE_ONE_CURRENCY_SYMBOL_PER_PAGE = 0x9;
static const Shortint PE_FFN_CURRENCY_POSITION_TYPE = 0xa;
static const Shortint PE_FFN_THOUSAND_SYMBOL = 0xb;
static const Shortint PE_FFN_DECIMAL_SYMBOL = 0xc;
static const Shortint PE_FFN_CURRENCY_SYMBOL = 0xd;
static const Shortint PE_FFN_REVERSE_SIGN_FOR_DISPLAY = 0x4f;
static const Shortint PE_FFN_ALLOW_FIELD_CLIPPING = 0xe;
static const Shortint PE_FFN_BOOLEAN_OUTPUT_TYPE = 0xf;
static const Shortint PE_FFN_DATE_WINDOWS_DEFAULT_TYPE = 0x10;
static const Shortint PE_FFN_DATE_ORDER = 0x11;
static const Shortint PE_FFN_YEAR_TYPE = 0x12;
static const Shortint PE_FFN_MONTH_TYPE = 0x13;
static const Shortint PE_FFN_DAY_TYPE = 0x14;
static const Shortint PE_FFN_DATE_FIRST_SEPARATOR = 0x15;
static const Shortint PE_FFN_DATE_SECOND_SEPARATOR = 0x16;
static const Shortint PE_FFN_DAY_OF_WEEK_TYPE = 0x17;
static const Shortint PE_FFN_DAY_OF_WEEK_SEPARATOR = 0x18;
static const Shortint PE_FFN_DAY_OF_WEEK_POSITION = 0x45;
static const Shortint PE_FFN_DATE_ERA_TYPE = 0x46;
static const Shortint PE_FFN_DATE_CALENDAR_TYPE = 0x47;
static const Shortint PE_FFN_DATE_PREFIX_SEPARATOR = 0x48;
static const Shortint PE_FFN_DATE_SUFFIX_SEPARATOR = 0x49;
static const Shortint PE_FFN_DAY_OF_WEEK_ENCLOSURE = 0x4e;
static const Shortint PE_FFN_TIME_BASE = 0x19;
static const Shortint PE_FFN_AM_PM_TYPE = 0x1a;
static const Shortint PE_FFN_HOUR_TYPE = 0x1b;
static const Shortint PE_FFN_MINUTE_TYPE = 0x1c;
static const Shortint PE_FFN_SECOND_TYPE = 0x1d;
static const Shortint PE_FFN_HOUR_MINUTE_SEPARATOR = 0x1e;
static const Shortint PE_FFN_MINUTE_SECOND_SEPARATOR = 0x1f;
static const Shortint PE_FFN_AM_STRING = 0x20;
static const Shortint PE_FFN_PM_STRING = 0x21;
static const Shortint PE_FFN_DATE_TIME_ORDER = 0x22;
static const Shortint PE_FFN_DATE_TIME_SEPARATOR_STRING = 0x23;
static const Shortint PE_FFN_FIRST_LINE_INDENT = 0x25;
static const Shortint PE_FFN_LEFT_INDENT = 0x26;
static const Shortint PE_FFN_RIGHT_INDENT = 0x27;
static const Shortint PE_FFN_MAX_N_LINES = 0x28;
static const Shortint PE_FFN_FONT_COLOR = 0x44;
static const Shortint PE_FFN_TEXT_INTERPRETATION = 0x50;
static const Shortint PE_FFN_LEFT_LINE_STYLE = 0x29;
static const Shortint PE_FFN_RIGHT_LINE_STYLE = 0x2a;
static const Shortint PE_FFN_TOP_LINE_STYLE = 0x2b;
static const Shortint PE_FFN_BOTTOM_LINE_STYLE = 0x2c;
static const Shortint PE_FFN_TIGHT_HORIZONTAL = 0x2d;
static const Shortint PE_FFN_DROP_SHADOW = 0x2f;
static const Shortint PE_FFN_FORE_COLOR = 0x30;
static const Shortint PE_FFN_BACK_COLOR = 0x31;
static const Shortint PE_FFN_TOOL_TIP_TEXT = 0x4a;
static const Shortint PE_FFN_CAPTION_ODS = 0x4b;
static const Shortint PE_FFN_CAPTION_PREVIEWTAB = 0x4c;
static const Shortint PE_FFN_HYPERLINK = 0x4d;
static const int PE_SIZEOF_SERVER_TYPE_INFO = 0x84;
static const int PE_SIZEOF_DATABASE_FIELD_INFO = 0x186;
static const Shortint PE_JT_EQUAL = 0x4;
static const Shortint PE_JT_LEFT_OUTER = 0x5;
static const Shortint PE_JT_RIGHT_OUTER = 0x6;
static const Shortint PE_JT_OUTER = 0x7;
static const Shortint PE_JT_GREATER_THAN = 0x8;
static const Shortint PE_JT_LESS_THAN = 0x9;
static const Shortint PE_JT_GREATER_OR_EQUAL = 0xa;
static const Shortint PE_JT_LESS_OR_EQUAL = 0xb;
static const Shortint PE_JT_NOT_EQUAL = 0xc;
static const Shortint PE_LT_LOOKUP_PARALLEL = 0x1;
static const Shortint PE_LT_LOOKUP_PRODUCT = 0x2;
static const Shortint PE_LT_LOOKUP_SERIES = 0x3;
static const Shortint PE_FI_FIELD_INDEX_ARRAY_LEN = 0x20;
static const int PE_SIZEOF_DATABASE_LINK_INFO = 0x92;
static const Shortint PE_DICT_TYPE_DCT = 0x1;
static const Shortint PE_DICT_TYPE_DC5 = 0x2;
static const Shortint PE_DICT_TYPE_QRY = 0x3;
static const Shortint PE_DICT_TYPE_CIV = 0x4;
static const Shortint PE_DICT_TYPE_UNKNOWN = 0x63;
static const int PE_SIZEOF_DICTIONARY_INFO = 0x8;
static const Byte PE_FORMULA_NAME_LEN = 0x80;
static const Word PE_FORMULA_TEXT_LEN = 0x400;
static const Byte PE_SQLEXPRESSION_NAME_LEN = 0x80;
static const Word PE_SQLEXPRESSION_TEXT_LEN = 0x400;
static const int PE_SIZEOF_FIELD_DEFINITION_INFO = 0x1018;
static const int PE_SIZEOF_SUMMARY_FIELD_INFO = 0x60c;
static const Shortint PE_STYLE_STANDARD1 = 0x0;
static const Shortint PE_STYLE_STANDARD2 = 0x1;
static const Shortint PE_STYLE_STANDARD3 = 0x2;
static const Shortint PE_STYLE_TABLE1 = 0x3;
static const Shortint PE_STYLE_TABLE2 = 0x4;
static const Shortint PE_STYLE_EXECUTIVE = 0x5;
static const Shortint PE_STYLE_SHADOWED = 0x6;
static const Shortint PE_STYLE_GRAY = 0x7;
static const Shortint PE_STYLE_COLOR1 = 0x8;
static const Shortint PE_STYLE_COLOR2 = 0x9;
static const Word PE_OLAP_CONNECTION_STRING_LEN = 0x400;
static const Byte PE_OLAP_CUBENAME_LEN = 0x80;
static const int PE_SIZEOF_OLAP_LOGON_INFO = 0x682;
static const int PE_SIZEOF_NEW_GRAPH_DATA_INFO = 0xa;
static const Shortint PE_HE_RC_EQUALTO = 0x0;
static const Shortint PE_HE_RC_NOTEQUALTO = 0x1;
static const Shortint PE_HE_RC_LESSTHAN = 0x2;
static const Shortint PE_HE_RC_LESSTHANOREQUALTO = 0x3;
static const Shortint PE_HE_RC_GREATERTHAN = 0x4;
static const Shortint PE_HE_RC_GREATERTHANOREQUALTO = 0x5;
static const Shortint PE_HE_RC_BETWEEN = 0x6;
static const Shortint PE_HE_RC_NOTBETWEEN = 0x7;
static const Shortint PE_HE_BORDER_DEFAULTBORDERSTYLE = 0x0;
static const Shortint PE_HE_BORDER_NONE = 0x1;
static const Shortint PE_HE_BORDER_SINGLEBOX = 0x2;
static const Shortint PE_HE_BORDER_DOUBLEBOX = 0x3;
static const Shortint PE_HE_BORDER_SINGLEUNDERLINE = 0x4;
static const Shortint PE_HE_BORDER_DOUBLEUNDERLINE = 0x5;
static const Shortint PE_HE_BORDER_SINGLEOVERLINE = 0x6;
static const Shortint PE_HE_BORDER_DOUBLEOVERLINE = 0x7;
static const Shortint PE_HE_BORDER_SINGLEBOXWITHDOUBLEUNDERLINE = 0x8;
static const Shortint PE_HE_FONTSTYLE_DEFAULTFONTSTYLE = 0x0;
static const Shortint PE_HE_FONTSTYLE_REGULAR = 0x1;
static const Shortint PE_HE_FONTSTYLE_ITALIC = 0x2;
static const Shortint PE_HE_FONTSTYLE_BOLD = 0x3;
static const Shortint PE_HE_FONTSTYLE_BOLDITALIC = 0x4;
static const int PE_SIZEOF_OBJECTHILITEINFO = 0x20;
static const Shortint PE_RT_TOTAL_NOCONDITION = 0x0;
static const Shortint PE_RT_TOTAL_ONCHANGEOFFIELD = 0x1;
static const Shortint PE_RT_TOTAL_ONCHANGEOFGROUP = 0x2;
static const Shortint PE_RT_TOTAL_ONFORMULA = 0x3;
static const int PE_SIZEOF_RUNNINGTOTALINFO = 0xe;
static const Shortint PE_MAP_LAYOUT_DETAIL = 0x0;
static const Shortint PE_MAP_LAYOUT_GROUP = 0x1;
static const Shortint PE_MAP_LAYOUT_CROSSTAB = 0x2;
static const Shortint PE_MAP_LAYOUT_OLAP = 0x3;
static const int PE_SIZEOF_MAPDATAINFO = 0x8;
static const Shortint PE_MAP_TT_RANGED = 0x0;
static const Shortint PE_MAP_TT_DOTDENSITY = 0x1;
static const Shortint PE_MAP_TT_GRADUATED = 0x2;
static const Shortint PE_MAP_TT_PIECHART = 0x3;
static const Shortint PE_MAP_TT_BARCHART = 0x4;
static const Shortint PE_MAP_TT_INDIVIDUALVALUE = 0x5;
static const Shortint PE_MAP_DM_EQUALCOUNT = 0x0;
static const Shortint PE_MAP_DM_EQUALRANGES = 0x1;
static const Shortint PE_MAP_DM_NATURALBREAK = 0x2;
static const Shortint PE_MAP_DM_STDDEV = 0x3;
static const Shortint PE_MAP_LEGENDTYPE_FULL = 0x0;
static const Shortint PE_MAP_LEGENDTYPE_COMPACT = 0x1;
static const Shortint PE_MAP_LEGENDTYPE_NONE = 0x2;
static const Shortint PE_MAP_LTT_AUTO = 0x0;
static const Shortint PE_MAP_LTT_SPECIFIC = 0x1;
static const int PE_SIZEOF_MAPSTYLE = 0x18;
static const Shortint PE_MAP_ORIENT_ROWSONLY = 0x0;
static const Shortint PE_MAP_ORIENT_COLSONLY = 0x1;
static const Shortint PE_MAP_ORIENT_MIXEDROWCOL = 0x2;
static const Shortint PE_MAP_ORIENT_MIXEDCOLROW = 0x3;
static const int PE_SIZEOF_MAPCONDITION = 0x6;
static const Shortint PE_FST_CRYSTAL = 0x0;
static const Shortint PE_FST_BASIC = 0x1;
static const Shortint PE_FST_SIZE = 0x2;
static const int PE_SIZEOF_FORMULA_SYNTAX = 0x6;
static const int PE_SIZEOF_REPORT_ALERT_INFO = 0x2c;
static const int PE_SIZEOF_ALERT_INSTANCE_INFO = 0x8;
#define CRD_ERROR_LOADING "Error loading library: CRPE32.DLL"
#define CRD_ERROR_FREEING "Error freeing library: CRPE32.DLL"
#define CRD_ENGINE_NOT_LOADED "CRPE32.DLL is not loaded"
#define CRD_ERROR_LOADING_FUNCTION "Error loading function: "
extern PACKAGE short __fastcall PE_SECTION_CODE(short sectionType, short groupN, short sectionN);
extern PACKAGE short __fastcall PE_AREA_CODE(short sectionType, short groupN);
extern PACKAGE short __fastcall PE_SECTION_TYPE(short sectionCode);
extern PACKAGE short __fastcall PE_GROUP_N(short sectionCode);
extern PACKAGE short __fastcall PE_SECTION_N(short sectionCode);

}	/* namespace Crdynamic */
using namespace Crdynamic;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// CRDynamic
