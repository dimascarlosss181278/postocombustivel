File Name: TABCNTRL.EXE    

Contents:  Tab Control Demo Application (Delphi)
           HotKey Demo Application (Delphi)
           Preview Window KeyStrokes PDF (Adobe Acrobat)

Description: 
------------
These files demonstrate and explain two methods of trapping key
strokes over the Crystal Reports runtime Preview Window. The 
applications come with source code and are written in Delphi
using the Crystal Reports VCL component.  However, the methods
used could be implemented by other programming languages as well. 

The TabControl demo is more effective and uses a more dependable
method of trapping key strokes than the HotKey demo.  The method
used in the TabControl demo is outlined in the Preview Window
Keystrokes doc enclosed.

=======================================================================