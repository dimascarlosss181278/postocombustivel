________________________________________________________________ 

Crystal VCL Mailing List: 
http://crystalvcl.listbot.com

Crystal VCL Programmer Website: 
http://users.uniserve.ca/~zimmerman/delphi.htm

Crystal VCL Programmer Email:
zimmerman@uniserve.com
________________________________________________________________ 

DESCRIPTION

This is a demo application created using the new TCrpeDS VCL
component.  This component works with the TCrpe VCL to allow 
any Crystal Report created with Active Data to hook up to a 
Delphi TDataset (or descendant), or a user-defined source of 
data, or a mixture of both.

In this applicaton (PicViewer.Exe), the user-defined source
of data is a directory of Bitmap pictures on the computer's 
hard-drive.
________________________________________________________________ 


Frank Zimmerman
Crystal VCL Programmer
March 4, 2001