This demo application illustrates a simple way to create
an MDI application in Delphi using the Crystal VCL.