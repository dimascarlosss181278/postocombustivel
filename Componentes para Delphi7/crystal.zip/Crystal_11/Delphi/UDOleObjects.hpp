// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'UDOleObjects.pas' rev: 6.00

#ifndef UDOleObjectsHPP
#define UDOleObjectsHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <UCrpe32.hpp>	// Pascal unit
#include <Buttons.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Udoleobjects
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TCrpeOleObjectsDlg;
class PASCALIMPLEMENTATION TCrpeOleObjectsDlg : public Forms::TForm 
{
	typedef Forms::TForm inherited;
	
__published:
	Extctrls::TPanel* pnlOleObjects;
	Stdctrls::TLabel* lblNumber;
	Stdctrls::TListBox* lbNumbers;
	Stdctrls::TEdit* editCount;
	Stdctrls::TLabel* lblCount;
	Stdctrls::TButton* btnOk;
	Stdctrls::TButton* btnClear;
	Stdctrls::TLabel* lblOleType;
	Stdctrls::TLabel* lblUpdateType;
	Stdctrls::TLabel* lblLinkSource;
	Stdctrls::TEdit* editLinkSource;
	Extctrls::TRadioGroup* rgUnits;
	Stdctrls::TLabel* lblTop;
	Stdctrls::TLabel* lblLeft;
	Stdctrls::TLabel* lblWidth;
	Stdctrls::TLabel* lblHeight;
	Stdctrls::TEdit* editTop;
	Stdctrls::TEdit* editLeft;
	Stdctrls::TEdit* editWidth;
	Stdctrls::TEdit* editHeight;
	Stdctrls::TLabel* lblSection;
	Stdctrls::TComboBox* cbSection;
	Stdctrls::TButton* btnBorder;
	Stdctrls::TButton* btnFormat;
	Stdctrls::TEdit* editOleType;
	Stdctrls::TEdit* editUpdateType;
	void __fastcall btnClearClick(System::TObject* Sender);
	void __fastcall lbNumbersClick(System::TObject* Sender);
	void __fastcall FormClose(System::TObject* Sender, Forms::TCloseAction &Action);
	void __fastcall FormShow(System::TObject* Sender);
	void __fastcall UpdateOleObjects(void);
	void __fastcall btnOkClick(System::TObject* Sender);
	void __fastcall FormCreate(System::TObject* Sender);
	void __fastcall EditSizeEnter(System::TObject* Sender);
	void __fastcall EditSizeExit(System::TObject* Sender);
	void __fastcall cbSectionChange(System::TObject* Sender);
	void __fastcall btnBorderClick(System::TObject* Sender);
	void __fastcall InitializeControls(bool OnOff);
	void __fastcall rgUnitsClick(System::TObject* Sender);
	void __fastcall btnFormatClick(System::TObject* Sender);
	
public:
	Ucrpe32::TCrpe* Cr;
	short OIndex;
	AnsiString PrevSize;
public:
	#pragma option push -w-inl
	/* TCustomForm.Create */ inline __fastcall virtual TCrpeOleObjectsDlg(Classes::TComponent* AOwner) : Forms::TForm(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.CreateNew */ inline __fastcall virtual TCrpeOleObjectsDlg(Classes::TComponent* AOwner, int Dummy) : Forms::TForm(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TCrpeOleObjectsDlg(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TCrpeOleObjectsDlg(HWND ParentWindow) : Forms::TForm(ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TCrpeOleObjectsDlg* CrpeOleObjectsDlg;
extern PACKAGE bool bOleObjects;

}	/* namespace Udoleobjects */
using namespace Udoleobjects;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// UDOleObjects
