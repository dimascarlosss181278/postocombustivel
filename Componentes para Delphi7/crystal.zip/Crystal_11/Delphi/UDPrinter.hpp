// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'UDPrinter.pas' rev: 6.00

#ifndef UDPrinterHPP
#define UDPrinterHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <UCrpe32.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Udprinter
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TCrpePrinterDlg;
class PASCALIMPLEMENTATION TCrpePrinterDlg : public Forms::TForm 
{
	typedef Forms::TForm inherited;
	
__published:
	Extctrls::TPanel* pnlPrinter1;
	Stdctrls::TLabel* lblPrinterNames;
	Stdctrls::TLabel* lblPrinterDriver;
	Stdctrls::TLabel* lblPrinterName;
	Stdctrls::TLabel* lblPrinterPort;
	Stdctrls::TLabel* lblPMode;
	Stdctrls::TLabel* lblMode;
	Stdctrls::TListBox* lbPrinterNames;
	Stdctrls::TEdit* editPrinterName;
	Stdctrls::TEdit* editPrinterDriver;
	Stdctrls::TEdit* editPrinterPort;
	Stdctrls::TEdit* editPrinterPMode;
	Stdctrls::TButton* btnPrompt;
	Stdctrls::TEdit* editPrinterMode;
	Extctrls::TRadioGroup* rgOrientation;
	Stdctrls::TGroupBox* gbPreserveRpt;
	Stdctrls::TCheckBox* cbOrientation;
	Stdctrls::TCheckBox* cbPaperSize;
	Stdctrls::TCheckBox* cbPaperSource;
	Stdctrls::TButton* btnOk;
	Stdctrls::TButton* btnCancel;
	Stdctrls::TButton* btnPrint;
	Stdctrls::TButton* btnClear;
	Stdctrls::TButton* btnRetrieve;
	Stdctrls::TButton* btnSend;
	Stdctrls::TButton* btnPrintOptions;
	Stdctrls::TButton* btnFreeDevMode;
	Stdctrls::TCheckBox* cbProgressDialog;
	void __fastcall FormShow(System::TObject* Sender);
	void __fastcall FormClose(System::TObject* Sender, Forms::TCloseAction &Action);
	void __fastcall lbPrinterNamesClick(System::TObject* Sender);
	void __fastcall editPrinterNameChange(System::TObject* Sender);
	void __fastcall editPrinterDriverChange(System::TObject* Sender);
	void __fastcall editPrinterPortChange(System::TObject* Sender);
	void __fastcall btnPromptClick(System::TObject* Sender);
	void __fastcall rgOrientationClick(System::TObject* Sender);
	void __fastcall cbOrientationClick(System::TObject* Sender);
	void __fastcall cbPaperSizeClick(System::TObject* Sender);
	void __fastcall cbPaperSourceClick(System::TObject* Sender);
	void __fastcall btnPrintClick(System::TObject* Sender);
	void __fastcall btnClearClick(System::TObject* Sender);
	void __fastcall btnRetrieveClick(System::TObject* Sender);
	void __fastcall UpdatePrinter(void);
	void __fastcall btnSendClick(System::TObject* Sender);
	void __fastcall FormCreate(System::TObject* Sender);
	void __fastcall btnOkClick(System::TObject* Sender);
	void __fastcall btnCancelClick(System::TObject* Sender);
	void __fastcall btnPrintOptionsClick(System::TObject* Sender);
	void __fastcall InitializeControls(bool OnOff);
	void __fastcall btnFreeDevModeClick(System::TObject* Sender);
	void __fastcall cbProgressDialogClick(System::TObject* Sender);
	
public:
	Ucrpe32::TCrpe* Cr;
	AnsiString rName;
	AnsiString rDriver;
	AnsiString rPort;
	bool rIsNil;
	#pragma pack(push, 1)
	_devicemodeA rDevMode;
	#pragma pack(pop)
	
	short rOrientation;
	bool rPrOrientation;
	bool rPrPaperSize;
	bool rPrPaperSource;
public:
	#pragma option push -w-inl
	/* TCustomForm.Create */ inline __fastcall virtual TCrpePrinterDlg(Classes::TComponent* AOwner) : Forms::TForm(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.CreateNew */ inline __fastcall virtual TCrpePrinterDlg(Classes::TComponent* AOwner, int Dummy) : Forms::TForm(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TCrpePrinterDlg(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TCrpePrinterDlg(HWND ParentWindow) : Forms::TForm(ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TCrpePrinterDlg* CrpePrinterDlg;
extern PACKAGE bool bPrinter;

}	/* namespace Udprinter */
using namespace Udprinter;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// UDPrinter
