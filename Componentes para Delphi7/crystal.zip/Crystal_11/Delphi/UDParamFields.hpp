// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'UDParamFields.pas' rev: 6.00

#ifndef UDParamFieldsHPP
#define UDParamFieldsHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <UCrpe32.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Udparamfields
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TCrpeParamFieldsDlg;
class PASCALIMPLEMENTATION TCrpeParamFieldsDlg : public Forms::TForm 
{
	typedef Forms::TForm inherited;
	
__published:
	Extctrls::TPanel* pnlParamFields;
	Stdctrls::TLabel* lblName;
	Stdctrls::TListBox* lbNames;
	Stdctrls::TButton* btnOk;
	Stdctrls::TButton* btnClear;
	Stdctrls::TButton* btnRanges;
	Stdctrls::TLabel* lblPrompt;
	Stdctrls::TLabel* lblPromptValue;
	Stdctrls::TLabel* lblCurrentValue;
	Stdctrls::TEdit* editPrompt;
	Stdctrls::TCheckBox* cbShowDialog;
	Stdctrls::TEdit* editPromptValue;
	Stdctrls::TEdit* editCurrentValue;
	Stdctrls::TLabel* lblValueMin;
	Stdctrls::TLabel* lblValueMax;
	Stdctrls::TCheckBox* cbValueLimit;
	Stdctrls::TEdit* editValueMin;
	Stdctrls::TEdit* editValueMax;
	Stdctrls::TLabel* lblEditMask;
	Stdctrls::TEdit* editEditMask;
	Stdctrls::TGroupBox* gbInfo;
	Stdctrls::TLabel* lblValueType;
	Stdctrls::TLabel* lblGroupNum;
	Stdctrls::TCheckBox* cbAllowNull;
	Stdctrls::TCheckBox* cbAllowEditing;
	Stdctrls::TCheckBox* cbAllowMultipleValues;
	Stdctrls::TCheckBox* cbPartOfGroup;
	Stdctrls::TCheckBox* cbMutuallyExclusiveGroup;
	Stdctrls::TComboBox* cbValueType;
	Stdctrls::TEdit* editGroupNum;
	Stdctrls::TButton* btnPromptValues;
	Stdctrls::TButton* btnPromptValue;
	Stdctrls::TButton* btnCurrentValue;
	Stdctrls::TButton* btnCurrentValues;
	Stdctrls::TCheckBox* cbAllowDialog;
	Stdctrls::TGroupBox* gbFormat;
	Stdctrls::TLabel* lblFieldName;
	Stdctrls::TLabel* lblFieldType;
	Stdctrls::TLabel* lblFieldLength;
	Stdctrls::TLabel* lblTop;
	Stdctrls::TLabel* lblLeft;
	Stdctrls::TLabel* lblSection;
	Stdctrls::TLabel* lblWidth;
	Stdctrls::TLabel* lblHeight;
	Stdctrls::TEdit* editFieldName;
	Stdctrls::TEdit* editFieldType;
	Stdctrls::TEdit* editFieldLength;
	Stdctrls::TButton* btnBorder;
	Stdctrls::TButton* btnFont;
	Stdctrls::TButton* btnFormat;
	Stdctrls::TEdit* editTop;
	Stdctrls::TEdit* editLeft;
	Stdctrls::TEdit* editWidth;
	Stdctrls::TEdit* editHeight;
	Stdctrls::TComboBox* cbSection;
	Dialogs::TFontDialog* FontDialog1;
	Stdctrls::TCheckBox* cbNeedsCurrentValue;
	Stdctrls::TEdit* editReportName;
	Stdctrls::TLabel* lblReportName;
	Stdctrls::TEdit* editParamSource;
	Stdctrls::TLabel* lblParamSource;
	Stdctrls::TEdit* editParamType;
	Stdctrls::TLabel* lblParamType;
	Stdctrls::TLabel* lblCount;
	Stdctrls::TEdit* editCount;
	Extctrls::TRadioGroup* rgUnits;
	Stdctrls::TButton* btnHiliteConditions;
	Stdctrls::TEdit* editBrowseField;
	Stdctrls::TLabel* lblBrowseField;
	Stdctrls::TCheckBox* cbObjectPropertiesActive;
	Stdctrls::TCheckBox* cbIsLinked;
	void __fastcall UpdateParamFields(void);
	void __fastcall lbNamesClick(System::TObject* Sender);
	void __fastcall editPromptChange(System::TObject* Sender);
	void __fastcall editEditMaskChange(System::TObject* Sender);
	void __fastcall cbShowDialogClick(System::TObject* Sender);
	void __fastcall cbValueLimitClick(System::TObject* Sender);
	void __fastcall editValueMinExit(System::TObject* Sender);
	void __fastcall editValueMaxExit(System::TObject* Sender);
	void __fastcall btnRangesClick(System::TObject* Sender);
	void __fastcall btnClearClick(System::TObject* Sender);
	void __fastcall editGroupNumExit(System::TObject* Sender);
	void __fastcall cbAllowNullClick(System::TObject* Sender);
	void __fastcall cbAllowEditingClick(System::TObject* Sender);
	void __fastcall cbAllowMultipleValuesClick(System::TObject* Sender);
	void __fastcall cbPartOfGroupClick(System::TObject* Sender);
	void __fastcall cbMutuallyExclusiveGroupClick(System::TObject* Sender);
	void __fastcall cbValueTypeChange(System::TObject* Sender);
	void __fastcall FormShow(System::TObject* Sender);
	void __fastcall FormClose(System::TObject* Sender, Forms::TCloseAction &Action);
	void __fastcall btnOkClick(System::TObject* Sender);
	void __fastcall FormCreate(System::TObject* Sender);
	void __fastcall btnPromptValueClick(System::TObject* Sender);
	void __fastcall btnCurrentValueClick(System::TObject* Sender);
	void __fastcall btnCurrentValuesClick(System::TObject* Sender);
	void __fastcall btnPromptValuesClick(System::TObject* Sender);
	void __fastcall cbAllowDialogClick(System::TObject* Sender);
	void __fastcall editSizeEnter(System::TObject* Sender);
	void __fastcall editSizeExit(System::TObject* Sender);
	void __fastcall btnBorderClick(System::TObject* Sender);
	void __fastcall btnFontClick(System::TObject* Sender);
	void __fastcall cbSectionChange(System::TObject* Sender);
	void __fastcall EnableControl(Classes::TComponent* Control, bool Enable);
	void __fastcall rgUnitsClick(System::TObject* Sender);
	void __fastcall btnFormatClick(System::TObject* Sender);
	void __fastcall btnHiliteConditionsClick(System::TObject* Sender);
	void __fastcall InitializeControls(bool OnOff);
	void __fastcall InitializeFormatControls(bool OnOff);
	void __fastcall editPromptValueExit(System::TObject* Sender);
	void __fastcall editCurrentValueExit(System::TObject* Sender);
	void __fastcall editBrowseFieldExit(System::TObject* Sender);
	void __fastcall cbObjectPropertiesActiveClick(System::TObject* Sender);
	
public:
	Ucrpe32::TCrpe* Cr;
	short PIndex;
	AnsiString PrevSize;
public:
	#pragma option push -w-inl
	/* TCustomForm.Create */ inline __fastcall virtual TCrpeParamFieldsDlg(Classes::TComponent* AOwner) : Forms::TForm(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.CreateNew */ inline __fastcall virtual TCrpeParamFieldsDlg(Classes::TComponent* AOwner, int Dummy) : Forms::TForm(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TCrpeParamFieldsDlg(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TCrpeParamFieldsDlg(HWND ParentWindow) : Forms::TForm(ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TCrpeParamFieldsDlg* CrpeParamFieldsDlg;
extern PACKAGE bool bParamFields;

}	/* namespace Udparamfields */
using namespace Udparamfields;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// UDParamFields
