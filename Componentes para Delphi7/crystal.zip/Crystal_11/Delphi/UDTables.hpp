// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'UDTables.pas' rev: 6.00

#ifndef UDTablesHPP
#define UDTablesHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <UCrpe32.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Udtables
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TCrpeTablesDlg;
class PASCALIMPLEMENTATION TCrpeTablesDlg : public Forms::TForm 
{
	typedef Forms::TForm inherited;
	
__published:
	Stdctrls::TButton* btnOk;
	Stdctrls::TButton* btnClear;
	Extctrls::TPanel* pnlTables;
	Stdctrls::TLabel* lblNumber;
	Stdctrls::TLabel* lblName;
	Stdctrls::TLabel* lblPath;
	Stdctrls::TLabel* lblPassword;
	Stdctrls::TLabel* lblTableType;
	Stdctrls::TLabel* lblDLLName;
	Stdctrls::TLabel* lblServerType;
	Stdctrls::TLabel* lblSubName;
	Stdctrls::TLabel* lblConnectBuffer;
	Stdctrls::TListBox* lbNumbers;
	Stdctrls::TEdit* editName;
	Stdctrls::TButton* btnName;
	Stdctrls::TEdit* editPath;
	Stdctrls::TButton* btnPath;
	Stdctrls::TCheckBox* cbPropagate;
	Stdctrls::TEdit* editPassword;
	Stdctrls::TEdit* editTableType;
	Stdctrls::TEdit* editDLLName;
	Stdctrls::TEdit* editServerType;
	Stdctrls::TButton* btnCheckDifferences;
	Stdctrls::TEdit* editSubName;
	Stdctrls::TEdit* editConnectBuffer;
	Stdctrls::TButton* btnTest;
	Dialogs::TOpenDialog* OpenDialog1;
	Stdctrls::TButton* btnVerify;
	Stdctrls::TCheckBox* cbVerifyFix;
	Stdctrls::TLabel* lblFieldMapping;
	Stdctrls::TComboBox* cbFieldMapping;
	Stdctrls::TLabel* lblAliasName;
	Stdctrls::TEdit* editAliasName;
	Stdctrls::TButton* btnFields;
	Stdctrls::TLabel* lblCount;
	Stdctrls::TEdit* editCount;
	Stdctrls::TButton* btnConvertDriver;
	void __fastcall btnNameClick(System::TObject* Sender);
	void __fastcall btnPathClick(System::TObject* Sender);
	void __fastcall btnClearClick(System::TObject* Sender);
	void __fastcall UpdateTables(void);
	void __fastcall lbNumbersClick(System::TObject* Sender);
	void __fastcall editNameChange(System::TObject* Sender);
	void __fastcall editPasswordChange(System::TObject* Sender);
	void __fastcall cbPropagateClick(System::TObject* Sender);
	void __fastcall FormShow(System::TObject* Sender);
	void __fastcall FormClose(System::TObject* Sender, Forms::TCloseAction &Action);
	void __fastcall editSubNameChange(System::TObject* Sender);
	void __fastcall editConnectBufferChange(System::TObject* Sender);
	void __fastcall btnCheckDifferencesClick(System::TObject* Sender);
	void __fastcall btnTestClick(System::TObject* Sender);
	void __fastcall btnOkClick(System::TObject* Sender);
	void __fastcall FormCreate(System::TObject* Sender);
	void __fastcall cbFieldMappingChange(System::TObject* Sender);
	void __fastcall cbVerifyFixClick(System::TObject* Sender);
	void __fastcall btnVerifyClick(System::TObject* Sender);
	void __fastcall editAliasNameChange(System::TObject* Sender);
	void __fastcall InitializeControls(bool OnOff);
	void __fastcall btnConvertDriverClick(System::TObject* Sender);
	void __fastcall btnFieldsClick(System::TObject* Sender);
	void __fastcall editServerTypeChange(System::TObject* Sender);
	void __fastcall editPathExit(System::TObject* Sender);
	
public:
	Ucrpe32::TCrpe* Cr;
	short TableIndex;
	void __fastcall OpenFieldsDlg(void);
public:
	#pragma option push -w-inl
	/* TCustomForm.Create */ inline __fastcall virtual TCrpeTablesDlg(Classes::TComponent* AOwner) : Forms::TForm(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.CreateNew */ inline __fastcall virtual TCrpeTablesDlg(Classes::TComponent* AOwner, int Dummy) : Forms::TForm(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TCrpeTablesDlg(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TCrpeTablesDlg(HWND ParentWindow) : Forms::TForm(ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TCrpeTablesDlg* CrpeTablesDlg;
extern PACKAGE bool bTables;

}	/* namespace Udtables */
using namespace Udtables;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// UDTables
