// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'UDDesignControls.pas' rev: 6.00

#ifndef UDDesignControlsHPP
#define UDDesignControlsHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <UCrpe32.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Buttons.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Uddesigncontrols
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TCrpeDesignControlsDlg;
class PASCALIMPLEMENTATION TCrpeDesignControlsDlg : public Forms::TForm 
{
	typedef Forms::TForm inherited;
	
__published:
	Extctrls::TPanel* pnlBBar;
	Extctrls::TPanel* pnlBBar2;
	Buttons::TSpeedButton* sbOpen;
	Buttons::TSpeedButton* sbClose;
	Buttons::TSpeedButton* sbDiscardSavedData;
	Buttons::TSpeedButton* sbQuickPreview;
	Buttons::TSpeedButton* sbPreview;
	Buttons::TSpeedButton* sbPrint;
	Buttons::TSpeedButton* sbExport;
	Buttons::TSpeedButton* sbCloseWindow;
	Buttons::TSpeedButton* sbFirst;
	Buttons::TSpeedButton* sbPrevious;
	Buttons::TSpeedButton* sbNext;
	Buttons::TSpeedButton* sbLast;
	Buttons::TSpeedButton* sbCancel;
	Buttons::TSpeedButton* sbZoom;
	void __fastcall sbOpenClick(System::TObject* Sender);
	void __fastcall sbCloseClick(System::TObject* Sender);
	void __fastcall sbDiscardSavedDataClick(System::TObject* Sender);
	void __fastcall sbQuickPreviewClick(System::TObject* Sender);
	void __fastcall sbPreviewClick(System::TObject* Sender);
	void __fastcall sbPrintClick(System::TObject* Sender);
	void __fastcall sbExportClick(System::TObject* Sender);
	void __fastcall sbCloseWindowClick(System::TObject* Sender);
	void __fastcall sbFirstClick(System::TObject* Sender);
	void __fastcall sbPreviousClick(System::TObject* Sender);
	void __fastcall sbNextClick(System::TObject* Sender);
	void __fastcall sbLastClick(System::TObject* Sender);
	void __fastcall sbCancelClick(System::TObject* Sender);
	void __fastcall sbZoomClick(System::TObject* Sender);
	void __fastcall SetButtonState(int BtnSet, bool OnOff);
	void __fastcall FormClose(System::TObject* Sender, Forms::TCloseAction &Action);
	void __fastcall FormCreate(System::TObject* Sender);
	
public:
	Ucrpe32::TCrpe* Cr;
public:
	#pragma option push -w-inl
	/* TCustomForm.Create */ inline __fastcall virtual TCrpeDesignControlsDlg(Classes::TComponent* AOwner) : Forms::TForm(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.CreateNew */ inline __fastcall virtual TCrpeDesignControlsDlg(Classes::TComponent* AOwner, int Dummy) : Forms::TForm(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TCrpeDesignControlsDlg(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TCrpeDesignControlsDlg(HWND ParentWindow) : Forms::TForm(ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TCrpeDesignControlsDlg* CrpeDesignControlsDlg;
extern PACKAGE bool bDesignControls;

}	/* namespace Uddesigncontrols */
using namespace Uddesigncontrols;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// UDDesignControls
