// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'UCrpe32.pas' rev: 6.00

#ifndef UCrpe32HPP
#define UCrpe32HPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <UCrpeClasses.hpp>	// Pascal unit
#include <UCrpeUtl.hpp>	// Pascal unit
#include <CRDynamic.hpp>	// Pascal unit
#include <Registry.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Ucrpe32
{
//-- type declarations -------------------------------------------------------
typedef AnsiString TCrAboutBox;

#pragma option push -b-
enum TCrState { crsSetup, crsInit };
#pragma option pop

#pragma option push -b-
enum TCrErrorResult { errIgnore, errAbort, errRaise };
#pragma option pop

#pragma option push -b-
enum TCrBoolean { cFalse, cTrue, cDefault };
#pragma option pop

typedef AnsiString TCrReportName;

typedef AnsiString TCrDesignControls;

#pragma option push -b-
enum TCrOutput { toWindow, toPrinter, toExport };
#pragma option pop

#pragma option push -b-
enum TCrError { errVCL, errEngine };
#pragma option pop

#pragma option push -b-
enum TCrErrorOption { errNoOption, errFormula, errPaging, errCancelDialog, errFormatFormulaName, errLinkedParameter, errMinMaxParameter, errCRPEBugs };
#pragma option pop

#pragma option push -b-
enum TCrStatus { crsNotOpen, crsJobNotStarted, crsJobInProgress, crsJobCompleted, crsJobFailed, crsJobCancelled, crsExceededTimeLimit, crsUnknown };
#pragma option pop

typedef void __fastcall (__closure *TCrpeCancelEvent)(System::TObject* Sender, bool &Cancel);

typedef void __fastcall (__closure *TCrpeJobNumEvent)(System::TObject* Sender, const Word JobNum);

typedef void __fastcall (__closure *TCrpePrinterEvent)(System::TObject* Sender, Windows::PDeviceModeA &PDMode, bool &Cancel);

typedef void __fastcall (__closure *TCrpeVersionEvent)(System::TObject* Sender, int &Major, int &Minor, int &Release, int &Build);

typedef void __fastcall (__closure *TCrpeErrorEvent)(System::TObject* Sender, const short ErrorNum, const AnsiString ErrorString, TCrErrorResult &IgnoreError);

#pragma option push -b-
enum TCrDateTimeType { ToString, ToDate, ToDateTime };
#pragma option pop

#pragma option push -b-
enum TCrPromptMode { pmNone, pmNormal, pmAlways };
#pragma option pop

#pragma option push -b-
enum TCrTableType { ttUnknown, ttStandard, ttSQL, ttStoredProcedure };
#pragma option pop

#pragma option push -b-
enum TCrPreserveRptSet { prOrientation, prPaperSize, prPaperSource };
#pragma option pop

typedef Set<TCrPreserveRptSet, prOrientation, prPaperSource>  TCrPreserveRptSettings;

#pragma option push -b-
enum TCrOrientation { orDefault, orPortrait, orLandscape };
#pragma option pop

typedef AnsiString TCrExportAppName;

typedef AnsiString TCrExportFileName;

#pragma option push -b-
enum TCrExportDestination { toFile, toEmailViaMapi, toEmailViaVIM, toMSExchange, toLotusNotes, toApplication };
#pragma option pop

#pragma option push -b-
enum TCrExportType { AdobeAcrobatPDF, CrystalReportRPT, EditableWord, HTML32, HTML40, MSExcel, MSWord, ODBCTable, Records, ReportDefinition, RichText, SeparatedValues, TabSeparatedText, TextFormat, XML1 };
#pragma option pop

#pragma option push -b-
enum TCrSortDirection { sdDescending, sdAscending };
#pragma option pop

#pragma option push -b-
enum TCrGroupCondition { AnyChange, dateDaily, dateWeekly, dateBiWeekly, dateSemiMonthly, dateMonthly, dateQuarterly, dateSemiAnnually, dateAnnually, boolToYes, boolToNo, boolEveryYes, boolEveryNo, boolNextIsYes, boolNextIsNo, timeBySecond, timeByMinute, timeByHour, timeByAMPM };
#pragma option pop

#pragma option push -b-
enum TCrGroupDirection { gdDescending, gdAscending, gdOriginal, gdSpecified };
#pragma option pop

#pragma option push -b-
enum TCrGroupType { gtOther, gtDate, gtBoolean, gtTime, gtDateTime };
#pragma option pop

#pragma option push -b-
enum TCrTopNSortType { tnUnsorted, tnSortAll, tnTopN, tnBottomN };
#pragma option pop

#pragma option push -b-
enum TCrFontScope { fsFields, fsText, fsBoth };
#pragma option pop

#pragma option push -b-
enum TCrFontFamily { ffDefault, ffRoman, ffSwiss, ffModern, ffScript, ffDecorative };
#pragma option pop

#pragma option push -b-
enum TCrFontCharSet { fcAnsi, fcDefault, fcSymbol, fcShiftJis, fcHangeul, fcChineseBig5, fcOEM };
#pragma option pop

#pragma option push -b-
enum TCrFontWeight { fwDefault, fwThin, fwExtraLight, fwLight, fwNormal, fwMedium, fwSemiBold, fwBold, fwExtraBold, fwHeavy };
#pragma option pop

#pragma option push -b-
enum TCrParamFieldType { pfNumber, pfCurrency, pfBoolean, pfDate, pfString, pfDateTime, pfTime, pfInteger, pfColor, pfChar, pfLong, pfStringHandle, pfNoValue };
#pragma option pop

#pragma option push -b-
enum TCrParamInfoValueType { vtRange, vtDiscrete, vtDiscreteAndRange };
#pragma option pop

#pragma option push -b-
enum TCrRangeBounds { IncludeStartAndEnd, IncludeStartOnly, IncludeEndOnly, ExcludeStartAndEnd };
#pragma option pop

#pragma option push -b-
enum TCrParamFieldSource { psReport, psStoredProc, psQuery };
#pragma option pop

#pragma option push -b-
enum TCrPickListSortMethod { psmNoSort, psmAlphaNumericAscending, psmAlphaNumericDescending, psmNumericAscending, psmNumericDescending };
#pragma option pop

#pragma option push -b-
enum TCrOleObjectType { ootLinked, ootEmbedded, ootStatic };
#pragma option pop

#pragma option push -b-
enum TCrOleUpdateType { AutoUpdate, ManualUpdate };
#pragma option pop

#pragma option push -b-
enum TCrSummaryType { stSum, stAverage, stSampleVariance, stSampleStdDev, stMaximum, stMinimum, stCount, stPopVariance, stPopStdDev, stDistinctCount, stCorrelation, stCoVariance, stWeightedAvg, stMedian, stPercentile, stNthLargest, stNthSmallest, stMode, stNthMostFrequent, stPercentage };
#pragma option pop

#pragma option push -b-
enum TCrRunningTotalCondition { rtcNoCondition, rtcOnChangeField, rtcOnChangeGroup, rtcOnFormula };
#pragma option pop

#pragma option push -b-
enum TCrCrossTabGroupPlacement { gpRow, gpCol };
#pragma option pop

#pragma option push -b-
enum TCrMapLayout { mlDetail, mlGroup, mlCrossTab, mlOlap };
#pragma option pop

#pragma option push -b-
enum TCrMapType { mttRanged, mttBarChart, mttPieChart, mttGraduated, mttDotDensity, mttIndividualValue };
#pragma option pop

#pragma option push -b-
enum TCrMapDistributionMethod { mdmEqualCount, mdmEqualRanges, mdmNaturalBreak, mdmStdDev };
#pragma option pop

#pragma option push -b-
enum TCrMapLegend { mlFull, mlCompact, mlNone };
#pragma option pop

#pragma option push -b-
enum TCrMapLegendTitle { mltAuto, mltSpecific };
#pragma option pop

#pragma option push -b-
enum TCrMapOrientation { moRowsOnly, moColsOnly, moMixedRowCol, moMixedColRow };
#pragma option pop

#pragma option push -b-
enum TCrFormulaSyntax { fsCrystal, fsBasic };
#pragma option pop

#pragma option push -b-
enum TCrReportStyle { rsStandard, rsLeadingBreak, rsTrailingBreak, rsTable, rsDropTable, rsExecutiveLeadingBreak, rsExecutiveTrailingBreak, rsShading, rsRedBlueBorder, rsMaroonTealBox };
#pragma option pop

typedef TWinControl TCrWinControl;
;

#pragma option push -b-
enum TCrZoomPreview { pwNormal, pwPageWidth, pwWholePage, pwDefault };
#pragma option pop

typedef short TCrZoomMagnification;

typedef Forms::TFormBorderStyle TCrFormBorderStyle;

#pragma option push -b-
enum TCrWindowCursor { wcDefault, wcArrow, wcCross, wcIBeam, wcUpArrow, wcSizeAll, wcSizeNWSE, wcSizeNESW, wcSizeWE, wcSizeNS, wcNo, wcWait, wcAppStart, wcHelp, wcMagnify, wcBackgroundProcess, wcGrabHand, wcZoomIn, wcReportSection, wcHand };
#pragma option pop

#pragma option push -b-
enum TCrGraphType { barSideBySide, barStacked, barPercent, bar3DSideBySide, bar3DStacked, bar3DPercent, lineRegular, lineStacked, linePercent, lineWithMarkers, lineStackedWithMarkers, linePercentWithMarkers, areaAbsolute, areaStacked, areaPercent, area3DAbsolute, area3DStacked, area3DPercent, pieRegular, pie3DRegular, pieMultiple, pieMultiProp, doughnutRegular, doughnutMultiple, doughnutMultiProp, ThreeDRegular, ThreeDPyramid, ThreeDOctagon, ThreeDCutCorners, ThreeDSurfaceRegular, ThreeDSurfaceWithSides, ThreeDSurfaceHoneyComb, XYScatter, XYScatterDualAxis, XYScatterLabeled, XYScatterDualAxisLabeled, radarRegular, radarStacked, radarDualAxis, bubbleRegular, bubbleDualAxis, stockHiLo, stockHiLoDualAxis, stockHiLoOpen, stockHiLoOpenDualAxis, stockHiLoOpenClose, stockHiLoOpenCloseDualAxis, userDefinedGraph, unknownBar, unknownLine, unknownArea, unknownPie, unknownDoughnut, unknown3DRiser, unknown3DSurface, unknownXYScatter, unknownRadar, unknownBubble, unknownStockHiLo, unknownGraphType };
#pragma option pop

#pragma option push -b-
enum TCrGraphDirection { Rows, Cols, RowCol, ColRow, Unknown };
#pragma option pop

#pragma option push -b-
enum TCrGraphGridLines { gglNone, gglMinor, gglMajor, gglMajorAndMinor };
#pragma option pop

#pragma option push -b-
enum TCrGraphDVType { gdvAutomatic, gdvManual };
#pragma option pop

#pragma option push -b-
enum TCrGraphBarDirection { bdHorizontal, bdVertical };
#pragma option pop

#pragma option push -b-
enum TCrGraphColor { gcColor, gcMonochrome };
#pragma option pop

#pragma option push -b-
enum TCrGraphLegend { glNone, glUpperRight, glBottomCenter, glTopCenter, glRight, glLeft, glCustom };
#pragma option pop

#pragma option push -b-
enum TCrGraphLegendLayout { gllPercentage, gllAmount, gllCustom };
#pragma option pop

#pragma option push -b-
enum TCrGraphPieSize { gpsMinimum, gpsSmall, gpsAverage, gpsLarge, gpsMaximum };
#pragma option pop

#pragma option push -b-
enum TCrGraphPieSlice { gslNone, gslSmall, gslLarge };
#pragma option pop

#pragma option push -b-
enum TCrGraphBarSize { gbsMinimum, gbsSmall, gbsAverage, gbsLarge, gbsMaximum };
#pragma option pop

#pragma option push -b-
enum TCrGraphMarkerSize { gmsSmall, gmsMediumSmall, gmsMedium, gmsMediumLarge, gmsLarge };
#pragma option pop

#pragma option push -b-
enum TCrGraphMarkerShape { gshRectangle, gshCircle, gshDiamond, gshTriangle };
#pragma option pop

#pragma option push -b-
enum TCrGraphDataPoints { gdpNone, gdpShowLabel, gdpShowValue, gdpShowLabelValue };
#pragma option pop

#pragma option push -b-
enum TCrGraphNumberFormat { gnfNoDecimal, gnfOneDecimal, gnfTwoDecimal, gnfUnknownType, gnfCurrencyTwoDecimal, gnfPercentNoDecimal, gnfPercentOneDecimal, gnfPercentTwoDecimal, gnfOther };
#pragma option pop

#pragma option push -b-
enum TCrGraphViewingAngle { gvaStandard, gvaTall, gvaTop, gvaDistorted, gvaShort, gvaGroupEye, gvaGroupEmphasis, gvaFewSeries, gvaFewGroups, gvaDistortedStd, gvaThickGroups, gvaShorter, gvaThickSeries, gvaThickStd, gvaBirdsEye, gvaMax };
#pragma option pop

#pragma option push -b-
enum TCrFieldMappingType { fmAuto, fmPrompt, fmEvent };
#pragma option pop

#pragma pack(push, 1)
struct TCrFieldInfo
{
	AnsiString TableName;
	AnsiString FieldName;
	int TableIndex;
	int FieldIndex;
	Ucrpeclasses::TCrFieldValueType FieldType;
	int FieldLength;
} ;
#pragma pack(pop)

#pragma option push -b-
enum TCrStartEventDestination { seNoWhere, seToWindow, seToPrinter, seToExport, seFromQuery };
#pragma option pop

#pragma option push -b-
enum TCrStopEventJobStatus { seUndefined, seNotStarted, seInProgress, seCompleted, seFailed, seCancelled, seHalted };
#pragma option pop

#pragma option push -b-
enum TCrDrillDownType { ddOnGroup, ddOnGroupTree, ddOnGraph, ddOnMap, ddOnSubreport };
#pragma option pop

typedef void __fastcall (__closure *TCrpeGeneralPrintWindowEvent)(HWND WindowHandle, bool &Cancel);

typedef void __fastcall (__closure *TCrpeZoomLevelChangingEvent)(HWND WindowHandle, Word ZoomLevel, bool &Cancel);

typedef void __fastcall (__closure *TCrpeCloseButtonClickedEvent)(HWND WindowHandle, Word ViewIndex, bool &Cancel);

typedef void __fastcall (__closure *TCrpeSearchButtonClickedEvent)(HWND WindowHandle, AnsiString SearchString, bool &Cancel);

typedef void __fastcall (__closure *TCrpeGroupTreeButtonClickedEvent)(HWND WindowHandle, bool Visible, bool &Cancel);

typedef void __fastcall (__closure *TCrpeReadingRecordsEvent)(bool Cancelled, int RecordsRead, int RecordsSelected, bool Done, bool &Cancel);

typedef void __fastcall (__closure *TCrpeStartEvent)(TCrStartEventDestination Destination, bool &Cancel);

typedef void __fastcall (__closure *TCrpeStopEvent)(TCrStartEventDestination Destination, TCrStopEventJobStatus JobStatus, bool &Cancel);

typedef void __fastcall (__closure *TCrpeShowGroupEvent)(HWND WindowHandle, Word NGroupLevel, Classes::TStringList* GroupList, bool &Cancel);

typedef void __fastcall (__closure *TCrpeDrillOnGroupEvent)(HWND WindowHandle, Word NGroupLevel, TCrDrillDownType DrillType, Classes::TStringList* GroupList, bool &Cancel);

typedef void __fastcall (__closure *TCrpeDrillOnDetailEvent)(HWND WindowHandle, short NSelectedField, short NFields, Classes::TStringList* FieldNames, Classes::TStringList* FieldValues, bool &Cancel);

typedef void __fastcall (__closure *TCrpeOnDrillHyperLinkEvent)(HWND WindowHandle, AnsiString HyperLinkText, bool &Cancel);

typedef void __fastcall (__closure *TCrpeOnLaunchSeagateAnalysisEvent)(HWND WindowHandle, AnsiString FilePath, bool &Cancel);

class DELPHICLASS ECrpeError;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION ECrpeError : public Sysutils::Exception 
{
	typedef Sysutils::Exception inherited;
	
public:
	int ErrorNo;
	__fastcall ECrpeError(const int nNo, const AnsiString sMsg);
public:
	#pragma option push -w-inl
	/* Exception.CreateFmt */ inline __fastcall ECrpeError(const AnsiString Msg, const System::TVarRec * Args, const int Args_Size) : Sysutils::Exception(Msg, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateRes */ inline __fastcall ECrpeError(int Ident)/* overload */ : Sysutils::Exception(Ident) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmt */ inline __fastcall ECrpeError(int Ident, const System::TVarRec * Args, const int Args_Size)/* overload */ : Sysutils::Exception(Ident, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateHelp */ inline __fastcall ECrpeError(const AnsiString Msg, int AHelpContext) : Sysutils::Exception(Msg, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmtHelp */ inline __fastcall ECrpeError(const AnsiString Msg, const System::TVarRec * Args, const int Args_Size, int AHelpContext) : Sysutils::Exception(Msg, Args, Args_Size, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResHelp */ inline __fastcall ECrpeError(int Ident, int AHelpContext)/* overload */ : Sysutils::Exception(Ident, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmtHelp */ inline __fastcall ECrpeError(System::PResStringRec ResStringRec, const System::TVarRec * Args, const int Args_Size, int AHelpContext)/* overload */ : Sysutils::Exception(ResStringRec, Args, Args_Size, AHelpContext) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~ECrpeError(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

class DELPHICLASS TCrFieldMappingInfo;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrFieldMappingInfo : public Classes::TPersistent 
{
	typedef Classes::TPersistent inherited;
	
private:
	AnsiString FTableName;
	AnsiString FFieldName;
	Ucrpeclasses::TCrFieldValueType FFieldType;
	int FMapTo;
	
public:
	__property AnsiString TableName = {read=FTableName, write=FTableName};
	__property AnsiString FieldName = {read=FFieldName, write=FFieldName};
	__property Ucrpeclasses::TCrFieldValueType FieldType = {read=FFieldType, write=FFieldType, nodefault};
	__property int MapTo = {read=FMapTo, write=FMapTo, nodefault};
public:
	#pragma option push -w-inl
	/* TPersistent.Destroy */ inline __fastcall virtual ~TCrFieldMappingInfo(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TObject.Create */ inline __fastcall TCrFieldMappingInfo(void) : Classes::TPersistent() { }
	#pragma option pop
	
};

#pragma pack(pop)

typedef void __fastcall (__closure *TCrpeFieldMappingEvent)(Classes::TList* &ReportFields, Classes::TList* &DatabaseFields, bool &Cancel);

#pragma option push -b-
enum TCrMouseClickAction { mbNotSupported, mbDown, mbUp, mbDoubleClick };
#pragma option pop

#pragma option push -b-
enum TCrMouseClickType { mcNone, mcLeft, mcRight, mcMiddle };
#pragma option pop

#pragma pack(push, 1)
struct TCrMouseInfo
{
	TCrMouseClickAction Action;
	TCrMouseClickType Button;
	bool ShiftKey;
	bool ControlKey;
	int x;
	int y;
} ;
#pragma pack(pop)

typedef void __fastcall (__closure *TCrpeMouseClickEvent)(HWND WindowHandle, const TCrMouseInfo &MouseInfo, AnsiString FieldValue, TCrParamFieldType FieldType, AnsiString Section, HWND ObjectHandle, bool &Cancel);

class DELPHICLASS TCrpe;
class DELPHICLASS TCrpeExportOptions;
class DELPHICLASS TCrpePersistentX;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpePersistentX : public Ucrpeclasses::TCrpePersistent 
{
	typedef Ucrpeclasses::TCrpePersistent inherited;
	
public:
	TCrpe* __fastcall Cr(void);
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Create */ inline __fastcall TCrpePersistentX(void) : Ucrpeclasses::TCrpePersistent() { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpePersistentX(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

class DELPHICLASS TCrpeExportEmail;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeExportEmail : public TCrpePersistentX 
{
	typedef TCrpePersistentX inherited;
	
private:
	AnsiString FCCList;
	AnsiString FMessage;
	AnsiString FSubject;
	AnsiString FToList;
	AnsiString FBCCList;
	AnsiString FUserName;
	AnsiString FPassword;
	
__published:
	__property AnsiString CCList = {read=FCCList, write=FCCList};
	__property AnsiString Message = {read=FMessage, write=FMessage};
	__property AnsiString Subject = {read=FSubject, write=FSubject};
	__property AnsiString ToList = {read=FToList, write=FToList};
	__property AnsiString BCCList = {read=FBCCList, write=FBCCList};
	__property AnsiString UserName = {read=FUserName, write=FUserName};
	__property AnsiString Password = {read=FPassword, write=FPassword};
	
public:
	void __fastcall Clear(void);
	__fastcall TCrpeExportEmail(void);
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpeExportEmail(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

class DELPHICLASS TCrpeExportExchange;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeExportExchange : public TCrpePersistentX 
{
	typedef TCrpePersistentX inherited;
	
private:
	AnsiString FFolder;
	AnsiString FPassword;
	AnsiString FProfile;
	
__published:
	__property AnsiString Folder = {read=FFolder, write=FFolder};
	__property AnsiString Password = {read=FPassword, write=FPassword};
	__property AnsiString Profile = {read=FProfile, write=FProfile};
	
public:
	void __fastcall Clear(void);
	__fastcall TCrpeExportExchange(void);
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpeExportExchange(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

class DELPHICLASS TCrpeExportODBC;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeExportODBC : public TCrpePersistentX 
{
	typedef TCrpePersistentX inherited;
	
private:
	bool FPrompt;
	AnsiString FPassword;
	AnsiString FSource;
	AnsiString FTable;
	AnsiString FUser;
	
__published:
	__property bool Prompt = {read=FPrompt, write=FPrompt, default=0};
	__property AnsiString Password = {read=FPassword, write=FPassword};
	__property AnsiString Source = {read=FSource, write=FSource};
	__property AnsiString Table = {read=FTable, write=FTable};
	__property AnsiString User = {read=FUser, write=FUser};
	
public:
	void __fastcall Clear(void);
	__fastcall TCrpeExportODBC(void);
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpeExportODBC(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

class DELPHICLASS TCrpeExportExcel;
#pragma option push -b-
enum TCrColumnWidth { ByArea, ByConstant };
#pragma option pop

#pragma option push -b-
enum TCrExportExcelPageAreaPair { DoNotExportPHOrPF, PHPFOncePerReport, PHPFOnEachPage };
#pragma option pop

#pragma option push -b-
enum TCrExportExcelType { ExcelStandard, ExcelDataOnly };
#pragma option pop

#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeExportExcel : public TCrpePersistentX 
{
	typedef TCrpePersistentX inherited;
	
private:
	TCrColumnWidth FColumnWidth;
	double FConstant;
	AnsiString FArea;
	bool FWorksheetFunctions;
	bool FCreatePageBreaks;
	bool FConvertDatesToStrings;
	bool FUsePageRange;
	unsigned FFirstPage;
	unsigned FLastPage;
	bool FExportHeaderFooter;
	bool FChopPageHeader;
	bool FExportImagesInDataOnly;
	bool FUseFormatInDataOnly;
	bool FMaintainColumnAlignment;
	bool FMaintainRelativeObjPosition;
	bool FShowGridlines;
	TCrExportExcelPageAreaPair FExportPageAreaPair;
	TCrExportExcelType FXlsType;
	
__published:
	__property TCrColumnWidth ColumnWidth = {read=FColumnWidth, write=FColumnWidth, default=0};
	__property double Constant = {read=FConstant, write=FConstant};
	__property AnsiString Area = {read=FArea, write=FArea};
	__property bool WorksheetFunctions = {read=FWorksheetFunctions, write=FWorksheetFunctions, default=1};
	__property bool CreatePageBreaks = {read=FCreatePageBreaks, write=FCreatePageBreaks, default=0};
	__property bool ConvertDatesToStrings = {read=FConvertDatesToStrings, write=FConvertDatesToStrings, default=0};
	__property bool UsePageRange = {read=FUsePageRange, write=FUsePageRange, default=0};
	__property unsigned FirstPage = {read=FFirstPage, write=FFirstPage, default=0};
	__property unsigned LastPage = {read=FLastPage, write=FLastPage, default=0};
	__property bool ExportHeaderFooter = {read=FExportHeaderFooter, write=FExportHeaderFooter, default=1};
	__property bool ChopPageHeader = {read=FChopPageHeader, write=FChopPageHeader, default=1};
	__property bool ExportImagesInDataOnly = {read=FExportImagesInDataOnly, write=FExportImagesInDataOnly, default=0};
	__property bool ExportObjectFormattingInDataOnly = {read=FUseFormatInDataOnly, write=FUseFormatInDataOnly, default=0};
	__property bool MaintainColumnAlignmentInDataOnly = {read=FMaintainColumnAlignment, write=FMaintainColumnAlignment, default=0};
	__property bool MaintainRelativeObjPositionInDataOnly = {read=FMaintainRelativeObjPosition, write=FMaintainRelativeObjPosition, default=0};
	__property bool ShowGridlines = {read=FShowGridlines, write=FShowGridlines, default=0};
	__property TCrExportExcelType XlsType = {read=FXlsType, write=FXlsType, default=0};
	__property TCrExportExcelPageAreaPair ExportHeaderFooterEx = {read=FExportPageAreaPair, write=FExportPageAreaPair, default=1};
	
public:
	void __fastcall Clear(void);
	__fastcall TCrpeExportExcel(void);
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpeExportExcel(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

class DELPHICLASS TCrpeExportLotusNotes;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeExportLotusNotes : public TCrpePersistentX 
{
	typedef TCrpePersistentX inherited;
	
private:
	AnsiString FDBName;
	AnsiString FFormName;
	AnsiString FComments;
	
__published:
	__property AnsiString DBName = {read=FDBName, write=FDBName};
	__property AnsiString FormName = {read=FFormName, write=FFormName};
	__property AnsiString Comments = {read=FComments, write=FComments};
	
public:
	void __fastcall Clear(void);
	__fastcall TCrpeExportLotusNotes(void);
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpeExportLotusNotes(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

class DELPHICLASS TCrpeExportHTML;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeExportHTML : public TCrpePersistentX 
{
	typedef TCrpePersistentX inherited;
	
private:
	bool FPageNavigator;
	bool FSeparatePages;
	bool FUsePageRange;
	unsigned FFirstPage;
	unsigned FLastPage;
	
__published:
	__property bool PageNavigator = {read=FPageNavigator, write=FPageNavigator, nodefault};
	__property bool SeparatePages = {read=FSeparatePages, write=FSeparatePages, nodefault};
	__property bool UsePageRange = {read=FUsePageRange, write=FUsePageRange, default=0};
	__property unsigned FirstPage = {read=FFirstPage, write=FFirstPage, default=0};
	__property unsigned LastPage = {read=FLastPage, write=FLastPage, default=0};
	
public:
	void __fastcall Clear(void);
	__fastcall TCrpeExportHTML(void);
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpeExportHTML(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

class DELPHICLASS TCrpeExportRTF;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeExportRTF : public TCrpePersistentX 
{
	typedef TCrpePersistentX inherited;
	
private:
	bool FPrompt;
	bool FUsePageRange;
	Word FFirstPage;
	Word FLastPage;
	bool FIncludePgBreaks;
	
__published:
	__property bool Prompt = {read=FPrompt, write=FPrompt, default=0};
	__property bool UsePageRange = {read=FUsePageRange, write=FUsePageRange, default=0};
	__property Word FirstPage = {read=FFirstPage, write=FFirstPage, default=0};
	__property Word LastPage = {read=FLastPage, write=FLastPage, default=0};
	__property bool InsertPageBreaks = {read=FIncludePgBreaks, write=FIncludePgBreaks, default=0};
	
public:
	void __fastcall Clear(void);
	__fastcall TCrpeExportRTF(void);
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpeExportRTF(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

class DELPHICLASS TCrpeExportWord;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeExportWord : public TCrpePersistentX 
{
	typedef TCrpePersistentX inherited;
	
private:
	bool FPrompt;
	bool FUsePageRange;
	Word FFirstPage;
	Word FLastPage;
	
__published:
	__property bool Prompt = {read=FPrompt, write=FPrompt, default=0};
	__property bool UsePageRange = {read=FUsePageRange, write=FUsePageRange, default=0};
	__property Word FirstPage = {read=FFirstPage, write=FFirstPage, default=0};
	__property Word LastPage = {read=FLastPage, write=FLastPage, default=0};
	
public:
	void __fastcall Clear(void);
	__fastcall TCrpeExportWord(void);
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpeExportWord(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

class DELPHICLASS TCrpeExportPDF;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeExportPDF : public TCrpePersistentX 
{
	typedef TCrpePersistentX inherited;
	
private:
	bool FPrompt;
	bool FUsePageRange;
	Word FFirstPage;
	Word FLastPage;
	
__published:
	__property bool Prompt = {read=FPrompt, write=FPrompt, default=0};
	__property bool UsePageRange = {read=FUsePageRange, write=FUsePageRange, default=0};
	__property Word FirstPage = {read=FFirstPage, write=FFirstPage, default=0};
	__property Word LastPage = {read=FLastPage, write=FLastPage, default=0};
	
public:
	void __fastcall Clear(void);
	__fastcall TCrpeExportPDF(void);
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpeExportPDF(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

class DELPHICLASS TCrpeExportText;
#pragma option push -b-
enum TCrRecordsType { ColumnsWithSpaces, ColumnsNoSpaces };
#pragma option pop

#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeExportText : public TCrpePersistentX 
{
	typedef TCrpePersistentX inherited;
	
private:
	bool FUseRptNumberFmt;
	bool FUseRptDateFmt;
	char FStringDelimiter;
	AnsiString FFieldSeparator;
	Word FLinesPerPage;
	Word FCharPerInch;
	TCrRecordsType FRecordsType;
	
__published:
	__property bool UseRptNumberFmt = {read=FUseRptNumberFmt, write=FUseRptNumberFmt, default=0};
	__property bool UseRptDateFmt = {read=FUseRptDateFmt, write=FUseRptDateFmt, default=0};
	__property char StringDelimiter = {read=FStringDelimiter, write=FStringDelimiter, nodefault};
	__property AnsiString FieldSeparator = {read=FFieldSeparator, write=FFieldSeparator};
	__property Word LinesPerPage = {read=FLinesPerPage, write=FLinesPerPage, default=60};
	__property Word CharPerInch = {read=FCharPerInch, write=FCharPerInch, default=0};
	__property TCrRecordsType RecordsType = {read=FRecordsType, write=FRecordsType, default=0};
	
public:
	void __fastcall Clear(void);
	__fastcall TCrpeExportText(void);
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpeExportText(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

class DELPHICLASS TCrpeExportXML;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeExportXML : public TCrpePersistentX 
{
	typedef TCrpePersistentX inherited;
	
private:
	bool FPrompt;
	bool FSeparatePages;
	
__published:
	__property bool Prompt = {read=FPrompt, write=FPrompt, default=0};
	__property bool SeparatePages = {read=FSeparatePages, write=FSeparatePages, default=1};
	
public:
	void __fastcall Clear(void);
	__fastcall TCrpeExportXML(void);
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpeExportXML(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeExportOptions : public TCrpePersistentX 
{
	typedef TCrpePersistentX inherited;
	
private:
	AnsiString FAppName;
	AnsiString FFileName;
	TCrExportType FFileType;
	TCrExportDestination FDestination;
	TCrpeExportEmail* FEmail;
	TCrpeExportExchange* FExchange;
	TCrpeExportODBC* FODBC;
	TCrpeExportExcel* FExcel;
	TCrpeExportLotusNotes* FLotusNotes;
	TCrpeExportHTML* FHTML;
	TCrpeExportRTF* FRTF;
	TCrpeExportWord* FWord;
	TCrpeExportPDF* FPDF;
	TCrpeExportText* FText;
	TCrpeExportXML* FXML;
	bool FPromptForOptions;
	bool FPromptOnOverwrite;
	
__published:
	__property AnsiString AppName = {read=FAppName, write=FAppName};
	__property AnsiString FileName = {read=FFileName, write=FFileName};
	__property TCrExportType FileType = {read=FFileType, write=FFileType, default=13};
	__property TCrExportDestination Destination = {read=FDestination, write=FDestination, default=0};
	__property TCrpeExportEmail* Email = {read=FEmail, write=FEmail};
	__property TCrpeExportExchange* Exchange = {read=FExchange, write=FExchange};
	__property TCrpeExportODBC* ODBC = {read=FODBC, write=FODBC};
	__property TCrpeExportExcel* Excel = {read=FExcel, write=FExcel};
	__property TCrpeExportLotusNotes* LotusNotes = {read=FLotusNotes, write=FLotusNotes};
	__property TCrpeExportHTML* HTML = {read=FHTML, write=FHTML};
	__property TCrpeExportRTF* RTF = {read=FRTF, write=FRTF};
	__property TCrpeExportWord* Word = {read=FWord, write=FWord};
	__property TCrpeExportPDF* PDF = {read=FPDF, write=FPDF};
	__property TCrpeExportText* Text = {read=FText, write=FText};
	__property TCrpeExportXML* XML = {read=FXML, write=FXML};
	__property bool PromptForOptions = {read=FPromptForOptions, write=FPromptForOptions, default=0};
	__property bool PromptOnOverwrite = {read=FPromptOnOverwrite, write=FPromptOnOverwrite, default=0};
	
public:
	#pragma pack(push, 1)
	Crdynamic::PEExportOptions PEExpOptions;
	#pragma pack(pop)
	
	#pragma pack(push, 1)
	Crdynamic::UXFPDFFormatOptions UXFPDF;
	#pragma pack(pop)
	
	#pragma pack(push, 1)
	Crdynamic::UXFHTML3Options UXFHTML;
	#pragma pack(pop)
	
	#pragma pack(push, 1)
	Crdynamic::UXFXlsOptions UXFXls;
	#pragma pack(pop)
	
	#pragma pack(push, 1)
	Crdynamic::UXFEDOCFormatOptions UXFWord;
	#pragma pack(pop)
	
	#pragma pack(push, 1)
	Crdynamic::UXFODBCOptions UXFODBC;
	#pragma pack(pop)
	
	#pragma pack(push, 1)
	Crdynamic::UXFRecordStyleOptions UXFRec;
	#pragma pack(pop)
	
	#pragma pack(push, 1)
	Crdynamic::UXFERTFFormatOptions UXFRTF;
	#pragma pack(pop)
	
	#pragma pack(push, 1)
	Crdynamic::UXFEditableRTFFormatOptions UXFEditableRTF;
	#pragma pack(pop)
	
	#pragma pack(push, 1)
	Crdynamic::UXFCharCommaTabSeparatedOptions UXFSepVal;
	#pragma pack(pop)
	
	#pragma pack(push, 1)
	Crdynamic::UXFPaginatedTextOptions UXFPagText;
	#pragma pack(pop)
	
	#pragma pack(push, 1)
	Crdynamic::UXFXMLOptions UXFXML;
	#pragma pack(pop)
	
	#pragma pack(push, 1)
	Crdynamic::UXDDiskOptions UXDDisk;
	#pragma pack(pop)
	
	#pragma pack(push, 1)
	Crdynamic::UXDMAPIOptions UXDMapi;
	#pragma pack(pop)
	
	#pragma pack(push, 1)
	Crdynamic::UXDVIMOptions UXDVIM;
	#pragma pack(pop)
	
	#pragma pack(push, 1)
	Crdynamic::UXDPostFolderOptions UXDExchange;
	#pragma pack(pop)
	
	#pragma pack(push, 1)
	Crdynamic::UXDNotesOptions UXDNotes;
	#pragma pack(pop)
	
	#pragma pack(push, 1)
	Crdynamic::UXDApplicationOptions UXDApp;
	#pragma pack(pop)
	
	AnsiString UXDAppFileName;
	void *pFormat;
	void *pDisk;
	void __fastcall Clear(void);
	bool __fastcall Send(void);
	__fastcall TCrpeExportOptions(void);
	__fastcall virtual ~TCrpeExportOptions(void);
};

#pragma pack(pop)

class DELPHICLASS TCrpeVersion;
class DELPHICLASS TCrpeEngineVersion;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeEngineVersion : public TCrpePersistentX 
{
	typedef TCrpePersistentX inherited;
	
private:
	AnsiString FDLL;
	AnsiString FEngine;
	AnsiString FFileVersion;
	int FMajor;
	int FMinor;
	int FRelease;
	int FBuild;
	
protected:
	AnsiString __fastcall GetDLL();
	void __fastcall SetDLL(const AnsiString Value);
	AnsiString __fastcall GetEngine();
	void __fastcall SetEngine(const AnsiString Value);
	AnsiString __fastcall GetFileVersion();
	void __fastcall SetFileVersion(const AnsiString Value);
	int __fastcall GetMajor(void);
	void __fastcall SetMajor(const int Value);
	int __fastcall GetMinor(void);
	void __fastcall SetMinor(const int Value);
	int __fastcall GetRelease(void);
	void __fastcall SetRelease(const int Value);
	int __fastcall GetBuild(void);
	void __fastcall SetBuild(const int Value);
	
__published:
	__property AnsiString DLL = {read=GetDLL, write=SetDLL};
	__property AnsiString Engine = {read=GetEngine, write=SetEngine};
	__property AnsiString FileVersion = {read=GetFileVersion, write=SetFileVersion};
	__property int Major = {read=GetMajor, write=SetMajor, nodefault};
	__property int Minor = {read=GetMinor, write=SetMinor, nodefault};
	__property int Release = {read=GetRelease, write=SetRelease, nodefault};
	__property int Build = {read=GetBuild, write=SetBuild, nodefault};
	
public:
	void __fastcall Clear(void);
	__fastcall TCrpeEngineVersion(void);
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpeEngineVersion(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

class DELPHICLASS TCrpeReportVersion;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeReportVersion : public TCrpePersistentX 
{
	typedef TCrpePersistentX inherited;
	
private:
	Word FMajor;
	Word FMinor;
	AnsiString FLetter;
	
protected:
	Word __fastcall GetMajor(void);
	void __fastcall SetMajor(const Word Value);
	Word __fastcall GetMinor(void);
	void __fastcall SetMinor(const Word Value);
	AnsiString __fastcall GetLetter();
	void __fastcall SetLetter(const AnsiString Value);
	
__published:
	__property Word Major = {read=GetMajor, write=SetMajor, nodefault};
	__property Word Minor = {read=GetMinor, write=SetMinor, nodefault};
	__property AnsiString Letter = {read=GetLetter, write=SetLetter};
	
public:
	void __fastcall Clear(void);
	__fastcall TCrpeReportVersion(void);
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpeReportVersion(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

class DELPHICLASS TCrpeWindowsVersion;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeWindowsVersion : public TCrpePersistentX 
{
	typedef TCrpePersistentX inherited;
	
private:
	AnsiString FPlatform;
	unsigned FMajor;
	unsigned FMinor;
	AnsiString FBuild;
	
protected:
	AnsiString __fastcall GetPlatform();
	void __fastcall SetPlatform(const AnsiString Value);
	unsigned __fastcall GetMinor(void);
	void __fastcall SetMinor(const unsigned Value);
	unsigned __fastcall GetMajor(void);
	void __fastcall SetMajor(const unsigned Value);
	AnsiString __fastcall GetBuild();
	void __fastcall SetBuild(const AnsiString Value);
	
__published:
	__property AnsiString Platform = {read=GetPlatform, write=SetPlatform};
	__property unsigned Major = {read=GetMajor, write=SetMajor, nodefault};
	__property unsigned Minor = {read=GetMinor, write=SetMinor, nodefault};
	__property AnsiString Build = {read=GetBuild, write=SetBuild};
	
public:
	void __fastcall Clear(void);
	__fastcall TCrpeWindowsVersion(void);
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpeWindowsVersion(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeVersion : public TCrpePersistentX 
{
	typedef TCrpePersistentX inherited;
	
private:
	TCrpeEngineVersion* FCrpe;
	TCrpeReportVersion* FReport;
	TCrpeWindowsVersion* FWindows;
	
__published:
	__property TCrpeEngineVersion* Crpe = {read=FCrpe, write=FCrpe};
	__property TCrpeReportVersion* Report = {read=FReport, write=FReport};
	__property TCrpeWindowsVersion* Windows = {read=FWindows, write=FWindows};
	
public:
	void __fastcall Clear(void);
	__fastcall TCrpeVersion(void);
	__fastcall virtual ~TCrpeVersion(void);
};

#pragma pack(pop)

class DELPHICLASS TCrpePrintDate;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpePrintDate : public TCrpePersistentX 
{
	typedef TCrpePersistentX inherited;
	
private:
	short FDay;
	short FMonth;
	short FYear;
	
protected:
	short __fastcall GetDay(void);
	void __fastcall SetDay(const short Value);
	short __fastcall GetMonth(void);
	void __fastcall SetMonth(const short Value);
	short __fastcall GetYear(void);
	void __fastcall SetYear(const short Value);
	
__published:
	__property short Day = {read=GetDay, write=SetDay, nodefault};
	__property short Month = {read=GetMonth, write=SetMonth, nodefault};
	__property short Year = {read=GetYear, write=SetYear, nodefault};
	
public:
	void __fastcall Clear(void);
	__fastcall TCrpePrintDate(void);
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpePrintDate(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

class DELPHICLASS TCrpeSubreports;
class DELPHICLASS TCrpeObjectContainerAX;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeObjectContainerAX : public Ucrpeclasses::TCrpeObjectContainerA 
{
	typedef Ucrpeclasses::TCrpeObjectContainerA inherited;
	
public:
	TCrpe* __fastcall Cr(void);
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Create */ inline __fastcall TCrpeObjectContainerAX(void) : Ucrpeclasses::TCrpeObjectContainerA() { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpeObjectContainerAX(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

class DELPHICLASS TCrpeSubreportsItem;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeSubreports : public TCrpeObjectContainerAX 
{
	typedef TCrpeObjectContainerAX inherited;
	
public:
	TCrpeSubreportsItem* operator[](int nIndex) { return Items[nIndex]; }
	
private:
	AnsiString FName;
	Classes::TStrings* FNames;
	bool FSubExecute;
	
protected:
	void __fastcall SetName(const AnsiString Value);
	HIDESBASE void __fastcall SetIndex(int nIndex);
	TCrpeSubreportsItem* __fastcall GetItems(int nIndex);
	TCrpeSubreportsItem* __fastcall GetItem(void);
	void __fastcall SetItem(const TCrpeSubreportsItem* nItem);
	
__published:
	__property int Number = {read=FIndex, write=SetIndex, nodefault};
	__property AnsiString Name = {read=FName, write=SetName};
	__property bool SubExecute = {read=FSubExecute, write=FSubExecute, default=0};
	__property TCrpeSubreportsItem* Item = {read=GetItem, write=SetItem};
	
public:
	__property int ItemIndex = {read=FIndex, write=SetIndex, nodefault};
	__property TCrpeSubreportsItem* Items[int nIndex] = {read=GetItems/*, default*/};
	Classes::TStrings* __fastcall Names(void);
	virtual int __fastcall Count(void);
	void __fastcall Clear(void);
	int __fastcall IndexOf(AnsiString SubreportName);
	TCrpeSubreportsItem* __fastcall ByName(AnsiString SubreportName);
	__fastcall TCrpeSubreports(void);
	__fastcall virtual ~TCrpeSubreports(void);
};

#pragma pack(pop)

class DELPHICLASS TCrpeLogOnServer;
class DELPHICLASS TCrpeContainerX;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeContainerX : public Ucrpeclasses::TCrpeContainer 
{
	typedef Ucrpeclasses::TCrpeContainer inherited;
	
public:
	TCrpe* __fastcall Cr(void);
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Create */ inline __fastcall TCrpeContainerX(void) : Ucrpeclasses::TCrpeContainer() { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpeContainerX(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

class DELPHICLASS TCrpeLogOnServerItem;
class DELPHICLASS TCrpeItemX;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeItemX : public Ucrpeclasses::TCrpeItem 
{
	typedef Ucrpeclasses::TCrpeItem inherited;
	
public:
	TCrpe* __fastcall Cr(void);
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Create */ inline __fastcall TCrpeItemX(void) : Ucrpeclasses::TCrpeItem() { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpeItemX(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeLogOnServerItem : public TCrpeItemX 
{
	typedef TCrpeItemX inherited;
	
private:
	AnsiString FServerName;
	AnsiString FUserID;
	AnsiString FPassword;
	AnsiString FDatabaseName;
	AnsiString FDLLName;
	int FLogNumber;
	
protected:
	void __fastcall SetServerName(const AnsiString Value);
	void __fastcall SetUserID(const AnsiString Value);
	void __fastcall SetPassword(const AnsiString Value);
	void __fastcall SetDatabaseName(const AnsiString Value);
	void __fastcall SetDLLName(const AnsiString Value);
	
__published:
	__property AnsiString ServerName = {read=FServerName, write=SetServerName};
	__property AnsiString UserID = {read=FUserID, write=SetUserID};
	__property AnsiString Password = {read=FPassword, write=SetPassword};
	__property AnsiString DatabaseName = {read=FDatabaseName, write=SetDatabaseName};
	__property AnsiString DLLName = {read=FDLLName, write=SetDLLName};
	
public:
	__property int LogNumber = {read=FLogNumber, nodefault};
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	bool __fastcall IsLoggedOn(void);
	void __fastcall Clear(void);
	bool __fastcall LogOn(void);
	bool __fastcall LogOff(void);
	__fastcall TCrpeLogOnServerItem(void);
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpeLogOnServerItem(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeLogOnServer : public TCrpeContainerX 
{
	typedef TCrpeContainerX inherited;
	
public:
	TCrpeLogOnServerItem* operator[](int nIndex) { return Items[nIndex]; }
	
private:
	Classes::TList* FList;
	TCrpeLogOnServerItem* FItem;
	
protected:
	void __fastcall SetIndex(int nIndex);
	TCrpeLogOnServerItem* __fastcall GetItems(int nIndex);
	TCrpeLogOnServerItem* __fastcall GetItem(void);
	
__published:
	__property int Number = {read=FIndex, write=SetIndex, default=-1};
	__property TCrpeLogOnServerItem* Item = {read=GetItem, write=FItem};
	
public:
	__property int ItemIndex = {read=FIndex, write=SetIndex, nodefault};
	__property TCrpeLogOnServerItem* Items[int nIndex] = {read=GetItems/*, default*/};
	void __fastcall Clear(void);
	int __fastcall Add(AnsiString ServerName);
	void __fastcall Delete(int nIndex);
	virtual int __fastcall Count(void);
	bool __fastcall Retrieve(void);
	int __fastcall IndexOf(AnsiString ServerName);
	int __fastcall IndexOfLogNumber(int LogN);
	__fastcall TCrpeLogOnServer(void);
	__fastcall virtual ~TCrpeLogOnServer(void);
};

#pragma pack(pop)

class DELPHICLASS TCrpeRecords;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeRecords : public TCrpePersistentX 
{
	typedef TCrpePersistentX inherited;
	
public:
	int __fastcall Printed(void);
	int __fastcall Selected(void);
	int __fastcall Read(void);
	int __fastcall PercentRead(void);
	int __fastcall PercentCompleted(void);
	void __fastcall SetRecordLimit(const int Value);
	void __fastcall SetTimeLimit(const int Value);
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Create */ inline __fastcall TCrpeRecords(void) : TCrpePersistentX() { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpeRecords(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

class DELPHICLASS TCrpePages;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpePages : public TCrpePersistentX 
{
	typedef TCrpePersistentX inherited;
	
public:
	AnsiString operator[](int nIndex) { return Items[nIndex]; }
	
private:
	int FStartPageNumber;
	
protected:
	int __fastcall GetStartPageNumber(void);
	void __fastcall SetStartPageNumber(const int Value);
	int __fastcall GetIndex(void);
	void __fastcall SetIndex(int nIndex);
	AnsiString __fastcall GetItem(int nIndex);
	
__published:
	__property int StartPageNumber = {read=GetStartPageNumber, write=SetStartPageNumber, default=1};
	
public:
	__property int ItemIndex = {read=GetIndex, write=SetIndex, nodefault};
	__property AnsiString Items[int nIndex] = {read=GetItem/*, default*/};
	Word __fastcall GetDisplayed(void);
	Word __fastcall GetLatest(void);
	Word __fastcall GetStart(void);
	short __fastcall Count(void);
	void __fastcall First(void);
	void __fastcall Next(void);
	void __fastcall Previous(void);
	void __fastcall Last(void);
	void __fastcall GoToPage(const short Value);
	__fastcall TCrpePages(void);
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpePages(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

class DELPHICLASS TCrpePrinter;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpePrinter : public TCrpePersistentX 
{
	typedef TCrpePersistentX inherited;
	
private:
	AnsiString FName;
	AnsiString FDriver;
	AnsiString FPort;
	unsigned FMode;
	_devicemodeA *FPMode;
	TCrOrientation FOrientation;
	TCrPreserveRptSettings FPreserveRptSettings;
	
protected:
	void __fastcall SetMode(const unsigned Value);
	void __fastcall SetPMode(const Windows::PDeviceModeA Value);
	bool __fastcall GetPrinterInfoFromName(AnsiString PrtName);
	Windows::PDeviceModeA __fastcall GetDMPointerFromHandle(unsigned xHandle);
	
__published:
	__property AnsiString Name = {read=FName, write=FName};
	__property AnsiString Driver = {read=FDriver, write=FDriver};
	__property AnsiString Port = {read=FPort, write=FPort};
	__property TCrOrientation Orientation = {read=FOrientation, write=FOrientation, default=0};
	__property TCrPreserveRptSettings PreserveRptSettings = {read=FPreserveRptSettings, write=FPreserveRptSettings, default=0};
	
public:
	__property unsigned Mode = {read=FMode, write=SetMode, nodefault};
	__property Windows::PDeviceModeA PMode = {read=FPMode, write=SetPMode};
	bool __fastcall Retrieve(void);
	bool __fastcall RetrieveFromReport(AnsiString &sName, AnsiString &sDriver, AnsiString &sPort, Windows::PDeviceModeA &pxDevMode);
	bool __fastcall GetCurrent(bool PreserveDevMode);
	bool __fastcall SetCurrent(void);
	void __fastcall GetPrinterNames(Classes::TStrings* List);
	bool __fastcall Prompt(void);
	void __fastcall Clear(void);
	bool __fastcall Send(void);
	void __fastcall FreeDevMode(void);
	__fastcall TCrpePrinter(void);
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpePrinter(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

class DELPHICLASS TCrpePrintOptions;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpePrintOptions : public TCrpePersistentX 
{
	typedef TCrpePersistentX inherited;
	
private:
	bool FCollation;
	Word FCopies;
	Word FStartPage;
	Word FStopPage;
	AnsiString FOutputFileName;
	
protected:
	bool __fastcall GetCollation(void);
	void __fastcall SetCollation(const bool Value);
	Word __fastcall GetCopies(void);
	void __fastcall SetCopies(const Word Value);
	Word __fastcall GetStartPage(void);
	void __fastcall SetStartPage(const Word Value);
	Word __fastcall GetStopPage(void);
	void __fastcall SetStopPage(const Word Value);
	AnsiString __fastcall GetOutputFileName();
	void __fastcall SetOutputFileName(const AnsiString Value);
	
__published:
	__property Word Copies = {read=GetCopies, write=SetCopies, default=1};
	__property bool Collation = {read=GetCollation, write=SetCollation, default=1};
	__property Word StartPage = {read=GetStartPage, write=SetStartPage, default=0};
	__property Word StopPage = {read=GetStopPage, write=SetStopPage, default=0};
	__property AnsiString OutputFileName = {read=FOutputFileName, write=SetOutputFileName};
	
public:
	bool __fastcall Prompt(void);
	void __fastcall Clear(void);
	__fastcall TCrpePrintOptions(void);
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpePrintOptions(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

class DELPHICLASS TCrpeSummaryInfo;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeSummaryInfo : public TCrpePersistentX 
{
	typedef TCrpePersistentX inherited;
	
private:
	AnsiString FAppName;
	AnsiString FTitle;
	AnsiString FSubject;
	AnsiString FAuthor;
	AnsiString FKeywords;
	Classes::TStrings* FComments;
	Classes::TStrings* xComments;
	AnsiString FTemplate;
	bool FSavePreviewPicture;
	
protected:
	AnsiString __fastcall GetTitle();
	void __fastcall SetTitle(const AnsiString Value);
	AnsiString __fastcall GetSubject();
	void __fastcall SetSubject(const AnsiString Value);
	AnsiString __fastcall GetAuthor();
	void __fastcall SetAuthor(const AnsiString Value);
	AnsiString __fastcall GetKeywords();
	void __fastcall SetKeywords(const AnsiString Value);
	Classes::TStrings* __fastcall GetComments(void);
	void __fastcall SetComments(Classes::TStrings* ListVar);
	AnsiString __fastcall GetTemplate();
	void __fastcall SetTemplate(const AnsiString Value);
	AnsiString __fastcall GetAppName();
	void __fastcall SetAppName(const AnsiString Value);
	bool __fastcall GetSavePreviewPicture(void);
	void __fastcall SetSavePreviewPicture(const bool Value);
	void __fastcall OnChangeStrings(System::TObject* Sender);
	
__published:
	__property AnsiString Title = {read=GetTitle, write=SetTitle};
	__property AnsiString Subject = {read=GetSubject, write=SetSubject};
	__property AnsiString Author = {read=GetAuthor, write=SetAuthor};
	__property AnsiString Keywords = {read=GetKeywords, write=SetKeywords};
	__property Classes::TStrings* Comments = {read=GetComments, write=SetComments};
	__property AnsiString Template = {read=GetTemplate, write=SetTemplate};
	__property AnsiString AppName = {read=GetAppName, write=SetAppName};
	__property bool SavePreviewPicture = {read=GetSavePreviewPicture, write=SetSavePreviewPicture, nodefault};
	
public:
	void __fastcall Clear(void);
	__fastcall TCrpeSummaryInfo(void);
	__fastcall virtual ~TCrpeSummaryInfo(void);
};

#pragma pack(pop)

class DELPHICLASS TCrpeReportOptions;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeReportOptions : public TCrpePersistentX 
{
	typedef TCrpePersistentX inherited;
	
private:
	bool FSaveDataWithReport;
	bool FSaveSummariesWithReport;
	bool FUseIndexForSpeed;
	bool FConvertNullFieldToDefault;
	bool FPrintEngineErrorMessages;
	bool FCaseInsensitiveSQLData;
	bool FVerifyOnEveryPrint;
	bool FCreateGroupTree;
	bool FNoDataForHiddenObjects;
	bool FPerformGroupingOnServer;
	TCrDateTimeType FConvertDateTimeType;
	TCrZoomPreview FZoomMode;
	bool FAsyncQuery;
	TCrPromptMode FPromptMode;
	bool FSelectDistinctRecords;
	bool FAlwaysSortLocally;
	bool FIsReadOnly;
	bool FCanSelectDistinctRecords;
	bool FUseDummyData;
	bool FConvertOtherNullsToDefault;
	bool FVerifyStoredProcOnRefresh;
	bool FRetainImageColourDepth;
	
protected:
	bool __fastcall GetSaveDataWithReport(void);
	void __fastcall SetSaveDataWithReport(const bool Value);
	bool __fastcall GetSaveSummariesWithReport(void);
	void __fastcall SetSaveSummariesWithReport(const bool Value);
	bool __fastcall GetUseIndexForSpeed(void);
	void __fastcall SetUseIndexForSpeed(const bool Value);
	bool __fastcall GetConvertNullFieldToDefault(void);
	void __fastcall SetConvertNullFieldToDefault(const bool Value);
	bool __fastcall GetPrintEngineErrorMessages(void);
	void __fastcall SetPrintEngineErrorMessages(const bool Value);
	bool __fastcall GetCaseInsensitiveSQLData(void);
	void __fastcall SetCaseInsensitiveSQLData(const bool Value);
	bool __fastcall GetVerifyOnEveryPrint(void);
	void __fastcall SetVerifyOnEveryPrint(const bool Value);
	bool __fastcall GetCreateGroupTree(void);
	void __fastcall SetCreateGroupTree(const bool Value);
	bool __fastcall GetNoDataForHiddenObjects(void);
	void __fastcall SetNoDataForHiddenObjects(const bool Value);
	bool __fastcall GetPerformGroupingOnServer(void);
	void __fastcall SetPerformGroupingOnServer(const bool Value);
	TCrDateTimeType __fastcall GetConvertDateTimeType(void);
	void __fastcall SetConvertDateTimeType(const TCrDateTimeType Value);
	TCrZoomPreview __fastcall GetZoomMode(void);
	void __fastcall SetZoomMode(const TCrZoomPreview Value);
	bool __fastcall GetAsyncQuery(void);
	void __fastcall SetAsyncQuery(const bool Value);
	TCrPromptMode __fastcall GetPromptMode(void);
	void __fastcall SetPromptMode(const TCrPromptMode Value);
	bool __fastcall GetSelectDistinctRecords(void);
	void __fastcall SetSelectDistinctRecords(const bool Value);
	bool __fastcall GetAlwaysSortLocally(void);
	void __fastcall SetAlwaysSortLocally(const bool Value);
	bool __fastcall GetIsReadOnly(void);
	void __fastcall SetIsReadOnly(const bool Value);
	bool __fastcall GetCanSelectDistinctRecords(void);
	void __fastcall SetCanSelectDistinctRecords(const bool Value);
	bool __fastcall GetUseDummyData(void);
	void __fastcall SetUseDummyData(const bool Value);
	bool __fastcall GetConvertOtherNullsToDefault(void);
	void __fastcall SetConvertOtherNullsToDefault(const bool Value);
	bool __fastcall GetVerifyStoredProcOnRefresh(void);
	void __fastcall SetVerifyStoredProcOnRefresh(const bool Value);
	bool __fastcall GetRetainImageColourDepth(void);
	void __fastcall SetRetainImageColourDepth(const bool Value);
	
__published:
	__property bool SaveDataWithReport = {read=GetSaveDataWithReport, write=SetSaveDataWithReport, default=1};
	__property bool SaveSummariesWithReport = {read=GetSaveSummariesWithReport, write=SetSaveSummariesWithReport, default=1};
	__property bool UseIndexForSpeed = {read=GetUseIndexForSpeed, write=SetUseIndexForSpeed, default=1};
	__property bool ConvertNullFieldToDefault = {read=GetConvertNullFieldToDefault, write=SetConvertNullFieldToDefault, default=0};
	__property bool PrintEngineErrorMessages = {read=GetPrintEngineErrorMessages, write=SetPrintEngineErrorMessages, default=1};
	__property bool CaseInsensitiveSQLData = {read=GetCaseInsensitiveSQLData, write=SetCaseInsensitiveSQLData, default=1};
	__property bool VerifyOnEveryPrint = {read=GetVerifyOnEveryPrint, write=SetVerifyOnEveryPrint, default=0};
	__property bool CreateGroupTree = {read=GetCreateGroupTree, write=SetCreateGroupTree, default=1};
	__property bool NoDataForHiddenObjects = {read=GetNoDataForHiddenObjects, write=SetNoDataForHiddenObjects, default=0};
	__property bool PerformGroupingOnServer = {read=GetPerformGroupingOnServer, write=SetPerformGroupingOnServer, default=0};
	__property TCrDateTimeType ConvertDateTimeType = {read=GetConvertDateTimeType, write=SetConvertDateTimeType, default=2};
	__property TCrZoomPreview ZoomMode = {read=GetZoomMode, write=SetZoomMode, default=0};
	__property bool AsyncQuery = {read=GetAsyncQuery, write=SetAsyncQuery, default=0};
	__property TCrPromptMode PromptMode = {read=GetPromptMode, write=SetPromptMode, default=1};
	__property bool SelectDistinctRecords = {read=GetSelectDistinctRecords, write=SetSelectDistinctRecords, default=0};
	__property bool AlwaysSortLocally = {read=GetAlwaysSortLocally, write=SetAlwaysSortLocally, default=1};
	__property bool IsReadOnly = {read=GetIsReadOnly, write=SetIsReadOnly, default=0};
	__property bool CanSelectDistinctRecords = {read=GetCanSelectDistinctRecords, write=SetCanSelectDistinctRecords, default=1};
	__property bool UseDummyData = {read=GetUseDummyData, write=SetUseDummyData, default=0};
	__property bool ConvertOtherNullsToDefault = {read=GetConvertOtherNullsToDefault, write=SetConvertOtherNullsToDefault, default=0};
	__property bool VerifyStoredProcOnRefresh = {read=GetVerifyStoredProcOnRefresh, write=SetVerifyStoredProcOnRefresh, default=0};
	__property bool RetainImageColourDepth = {read=GetRetainImageColourDepth, write=SetRetainImageColourDepth, default=0};
	
public:
	void __fastcall Clear(void);
	__fastcall TCrpeReportOptions(void);
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpeReportOptions(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

class DELPHICLASS TCrpeGlobalOptions;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeGlobalOptions : public TCrpePersistentX 
{
	typedef TCrpePersistentX inherited;
	
private:
	TCrBoolean FMorePrintEngineErrorMessages;
	TCrBoolean FMatchLogOnInfo;
	TCrBoolean FUse70TextCompatibility;
	TCrBoolean FDisableThumbnailUpdates;
	TCrBoolean FVerifyWhenDatabaseDriverUpgraded;
	
protected:
	TCrBoolean __fastcall GetDefault(void);
	void __fastcall SetMorePrintEngineErrorMessages(const TCrBoolean Value);
	void __fastcall SetMatchLogOnInfo(const TCrBoolean Value);
	void __fastcall SetUse70TextCompatibility(const TCrBoolean Value);
	void __fastcall SetDisableThumbnailUpdates(const TCrBoolean Value);
	void __fastcall SetVerifyWhenDatabaseDriverUpgraded(const TCrBoolean Value);
	
__published:
	__property TCrBoolean MorePrintEngineErrorMessages = {read=GetDefault, write=SetMorePrintEngineErrorMessages, default=2};
	__property TCrBoolean MatchLogOnInfo = {read=GetDefault, write=SetMatchLogOnInfo, default=2};
	__property TCrBoolean Use70TextCompatibility = {read=GetDefault, write=SetUse70TextCompatibility, default=2};
	__property TCrBoolean DisableThumbnailUpdates = {read=GetDefault, write=SetDisableThumbnailUpdates, default=2};
	__property TCrBoolean VerifyWhenDatabaseDriverUpgraded = {read=GetDefault, write=SetVerifyWhenDatabaseDriverUpgraded, default=2};
	
public:
	void __fastcall Clear(void);
	__fastcall TCrpeGlobalOptions(void);
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpeGlobalOptions(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

class DELPHICLASS TCrpeWindowButtonBar;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeWindowButtonBar : public TCrpePersistentX 
{
	typedef TCrpePersistentX inherited;
	
private:
	bool FVisible;
	bool FAllowDrillDown;
	bool FCancelBtn;
	bool FCloseBtn;
	bool FExportBtn;
	bool FGroupTree;
	bool FNavigationCtls;
	bool FPrintBtn;
	bool FPrintSetupBtn;
	bool FProgressCtls;
	bool FRefreshBtn;
	bool FSearchBtn;
	bool FZoomCtl;
	bool FToolbarTips;
	bool FDocumentTips;
	bool FLaunchBtn;
	
protected:
	bool __fastcall GetVisible(void);
	void __fastcall SetVisible(const bool Value);
	bool __fastcall GetAllowDrillDown(void);
	void __fastcall SetAllowDrillDown(const bool Value);
	bool __fastcall GetCancelBtn(void);
	void __fastcall SetCancelBtn(const bool Value);
	bool __fastcall GetCloseBtn(void);
	void __fastcall SetCloseBtn(const bool Value);
	bool __fastcall GetExportBtn(void);
	void __fastcall SetExportBtn(const bool Value);
	bool __fastcall GetGroupTree(void);
	void __fastcall SetGroupTree(const bool Value);
	bool __fastcall GetNavigationCtls(void);
	void __fastcall SetNavigationCtls(const bool Value);
	bool __fastcall GetPrintBtn(void);
	void __fastcall SetPrintBtn(const bool Value);
	bool __fastcall GetPrintSetupBtn(void);
	void __fastcall SetPrintSetupBtn(const bool Value);
	bool __fastcall GetProgressCtls(void);
	void __fastcall SetProgressCtls(const bool Value);
	bool __fastcall GetRefreshBtn(void);
	void __fastcall SetRefreshBtn(const bool Value);
	bool __fastcall GetSearchBtn(void);
	void __fastcall SetSearchBtn(const bool Value);
	bool __fastcall GetZoomCtl(void);
	void __fastcall SetZoomCtl(const bool Value);
	bool __fastcall GetToolbarTips(void);
	void __fastcall SetToolbarTips(const bool Value);
	bool __fastcall GetDocumentTips(void);
	void __fastcall SetDocumentTips(const bool Value);
	bool __fastcall GetLaunchBtn(void);
	void __fastcall SetLaunchBtn(const bool Value);
	
__published:
	__property bool Visible = {read=GetVisible, write=SetVisible, default=1};
	__property bool AllowDrillDown = {read=GetAllowDrillDown, write=SetAllowDrillDown, default=0};
	__property bool CancelBtn = {read=GetCancelBtn, write=SetCancelBtn, default=0};
	__property bool CloseBtn = {read=GetCloseBtn, write=SetCloseBtn, default=0};
	__property bool ExportBtn = {read=GetExportBtn, write=SetExportBtn, default=1};
	__property bool GroupTree = {read=GetGroupTree, write=SetGroupTree, default=0};
	__property bool NavigationCtls = {read=GetNavigationCtls, write=SetNavigationCtls, default=1};
	__property bool PrintBtn = {read=GetPrintBtn, write=SetPrintBtn, default=1};
	__property bool PrintSetupBtn = {read=GetPrintSetupBtn, write=SetPrintSetupBtn, default=0};
	__property bool ProgressCtls = {read=GetProgressCtls, write=SetProgressCtls, default=1};
	__property bool RefreshBtn = {read=GetRefreshBtn, write=SetRefreshBtn, default=0};
	__property bool SearchBtn = {read=GetSearchBtn, write=SetSearchBtn, default=0};
	__property bool ZoomCtl = {read=GetZoomCtl, write=SetZoomCtl, default=1};
	__property bool ToolbarTips = {read=GetToolbarTips, write=SetToolbarTips, default=1};
	__property bool DocumentTips = {read=GetDocumentTips, write=SetDocumentTips, default=0};
	__property bool LaunchBtn = {read=GetLaunchBtn, write=SetLaunchBtn, default=0};
	
public:
	void __fastcall Clear(void);
	void __fastcall ActivateAll(void);
	void __fastcall Send(void);
	__fastcall TCrpeWindowButtonBar(void);
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpeWindowButtonBar(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

class DELPHICLASS TCrpeWindowCursor;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeWindowCursor : public TCrpePersistentX 
{
	typedef TCrpePersistentX inherited;
	
private:
	TCrWindowCursor FGroupArea;
	TCrWindowCursor FGroupAreaField;
	TCrWindowCursor FDetailArea;
	TCrWindowCursor FDetailAreaField;
	TCrWindowCursor FGraph;
	TCrWindowCursor FOnDemandSubreport;
	TCrWindowCursor FHyperLink;
	
protected:
	TCrWindowCursor __fastcall GetGroupArea(void);
	void __fastcall SetGroupArea(const TCrWindowCursor Value);
	TCrWindowCursor __fastcall GetGroupAreaField(void);
	void __fastcall SetGroupAreaField(const TCrWindowCursor Value);
	TCrWindowCursor __fastcall GetDetailArea(void);
	void __fastcall SetDetailArea(const TCrWindowCursor Value);
	TCrWindowCursor __fastcall GetDetailAreaField(void);
	void __fastcall SetDetailAreaField(const TCrWindowCursor Value);
	TCrWindowCursor __fastcall GetGraph(void);
	void __fastcall SetGraph(const TCrWindowCursor Value);
	TCrWindowCursor __fastcall GetOnDemandSubreport(void);
	void __fastcall SetOnDemandSubreport(const TCrWindowCursor Value);
	TCrWindowCursor __fastcall GetHyperLink(void);
	void __fastcall SetHyperLink(const TCrWindowCursor Value);
	TCrWindowCursor __fastcall ConvertCursorType(short rptCursor);
	
__published:
	__property TCrWindowCursor GroupArea = {read=GetGroupArea, write=SetGroupArea, nodefault};
	__property TCrWindowCursor GroupAreaField = {read=GetGroupAreaField, write=SetGroupAreaField, nodefault};
	__property TCrWindowCursor DetailArea = {read=GetDetailArea, write=SetDetailArea, nodefault};
	__property TCrWindowCursor DetailAreaField = {read=GetDetailAreaField, write=SetDetailAreaField, nodefault};
	__property TCrWindowCursor Graph = {read=GetGraph, write=SetGraph, nodefault};
	__property TCrWindowCursor OnDemandSubreport = {read=GetOnDemandSubreport, write=SetOnDemandSubreport, nodefault};
	__property TCrWindowCursor HyperLink = {read=GetHyperLink, write=SetHyperLink, nodefault};
	
public:
	void __fastcall Clear(void);
	void __fastcall Send(void);
	__fastcall TCrpeWindowCursor(void);
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpeWindowCursor(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

class DELPHICLASS TCrpeWindowSize;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeWindowSize : public TCrpePersistentX 
{
	typedef TCrpePersistentX inherited;
	
private:
	short FTop;
	short FLeft;
	short FWidth;
	short FHeight;
	
protected:
	short __fastcall GetLeft(void);
	void __fastcall SetLeft(const short Value);
	short __fastcall GetTop(void);
	void __fastcall SetTop(const short Value);
	short __fastcall GetWidth(void);
	void __fastcall SetWidth(const short Value);
	short __fastcall GetHeight(void);
	void __fastcall SetHeight(const short Value);
	
__published:
	__property short Left = {read=GetLeft, write=SetLeft, default=-1};
	__property short Top = {read=GetTop, write=SetTop, default=-1};
	__property short Width = {read=GetWidth, write=SetWidth, default=-1};
	__property short Height = {read=GetHeight, write=SetHeight, default=-1};
	
public:
	void __fastcall Clear(void);
	__fastcall TCrpeWindowSize(void);
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpeWindowSize(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

class DELPHICLASS TCrpeWindowStyle;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeWindowStyle : public TCrpePersistentX 
{
	typedef TCrpePersistentX inherited;
	
private:
	AnsiString FTitle;
	bool FSystemMenu;
	bool FMaxButton;
	bool FMinButton;
	Forms::TFormBorderStyle FBorderStyle;
	bool FDisabled;
	Forms::TForm* FMDIForm;
	
protected:
	void __fastcall SetTitle(const AnsiString Value);
	void __fastcall SetDisabled(const bool Value);
	void __fastcall OnMDIResize(System::TObject* Sender);
	void __fastcall OnMDIClose(System::TObject* Sender, Forms::TCloseAction &Action);
	
__published:
	__property AnsiString Title = {read=FTitle, write=SetTitle};
	__property bool SystemMenu = {read=FSystemMenu, write=FSystemMenu, default=1};
	__property bool MaxButton = {read=FMaxButton, write=FMaxButton, default=1};
	__property bool MinButton = {read=FMinButton, write=FMinButton, default=1};
	__property TCrFormBorderStyle BorderStyle = {read=FBorderStyle, write=FBorderStyle, default=2};
	__property bool Disabled = {read=FDisabled, write=SetDisabled, default=0};
	
public:
	void __fastcall Clear(void);
	__fastcall TCrpeWindowStyle(void);
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpeWindowStyle(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

class DELPHICLASS TCrpeWindowZoom;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeWindowZoom : public TCrpePersistentX 
{
	typedef TCrpePersistentX inherited;
	
private:
	TCrZoomPreview FPreview;
	TCrZoomMagnification FMagnification;
	
protected:
	void __fastcall SetPreview(const TCrZoomPreview Value);
	void __fastcall SetMagnification(const TCrZoomMagnification Value);
	
__published:
	__property TCrZoomPreview Preview = {read=FPreview, write=SetPreview, default=0};
	__property TCrZoomMagnification Magnification = {read=FMagnification, write=SetMagnification, default=0};
	
public:
	void __fastcall NextLevel(void);
	void __fastcall Clear(void);
	__fastcall TCrpeWindowZoom(void);
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpeWindowZoom(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

class DELPHICLASS TCrpeMargins;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeMargins : public TCrpePersistentX 
{
	typedef TCrpePersistentX inherited;
	
private:
	short FTop;
	short FBottom;
	short FLeft;
	short FRight;
	
protected:
	short __fastcall GetLeft(void);
	void __fastcall SetLeft(const short Value);
	short __fastcall GetRight(void);
	void __fastcall SetRight(const short Value);
	short __fastcall GetTop(void);
	void __fastcall SetTop(const short Value);
	short __fastcall GetBottom(void);
	void __fastcall SetBottom(const short Value);
	
__published:
	__property short Left = {read=GetLeft, write=SetLeft, default=-1};
	__property short Right = {read=GetRight, write=SetRight, default=-1};
	__property short Top = {read=GetTop, write=SetTop, default=-1};
	__property short Bottom = {read=GetBottom, write=SetBottom, default=-1};
	
public:
	void __fastcall Clear(void);
	__fastcall TCrpeMargins(void);
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpeMargins(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

class DELPHICLASS TCrpeSQL;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeSQL : public TCrpePersistentX 
{
	typedef TCrpePersistentX inherited;
	
private:
	Classes::TStrings* FQuery;
	Classes::TStrings* xQuery;
	
protected:
	void __fastcall SetQuery(Classes::TStrings* ListVar);
	void __fastcall OnChangeStrings(System::TObject* Sender);
	
__published:
	__property Classes::TStrings* Query = {read=FQuery, write=SetQuery};
	
public:
	void __fastcall Clear(void);
	bool __fastcall Retrieve(void);
	__fastcall TCrpeSQL(void);
	__fastcall virtual ~TCrpeSQL(void);
};

#pragma pack(pop)

class DELPHICLASS TCrpeSQLExpressions;
class DELPHICLASS TCrpeFieldObjectContainerX;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeFieldObjectContainerX : public Ucrpeclasses::TCrpeFieldObjectContainer 
{
	typedef Ucrpeclasses::TCrpeFieldObjectContainer inherited;
	
public:
	TCrpe* __fastcall Cr(void);
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Create */ inline __fastcall TCrpeFieldObjectContainerX(void) : Ucrpeclasses::TCrpeFieldObjectContainer() { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpeFieldObjectContainerX(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

class DELPHICLASS TCrpeSQLExpressionsItem;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeSQLExpressions : public TCrpeFieldObjectContainerX 
{
	typedef TCrpeFieldObjectContainerX inherited;
	
public:
	TCrpeSQLExpressionsItem* operator[](int nIndex) { return Items[nIndex]; }
	
private:
	AnsiString FName;
	Classes::TStrings* FNames;
	bool FObjectPropertiesActive;
	
protected:
	void __fastcall SetName(const AnsiString Value);
	void __fastcall SetObjectPropertiesActive(const bool Value);
	HIDESBASE void __fastcall SetIndex(int nIndex);
	TCrpeSQLExpressionsItem* __fastcall GetItems(int nIndex);
	TCrpeSQLExpressionsItem* __fastcall GetItem(void);
	void __fastcall SetItem(const TCrpeSQLExpressionsItem* nItem);
	
__published:
	__property AnsiString Name = {read=FName, write=SetName};
	__property int Number = {read=FIndex, write=SetIndex, default=-1};
	__property TCrpeSQLExpressionsItem* Item = {read=GetItem, write=SetItem};
	__property bool ObjectPropertiesActive = {read=FObjectPropertiesActive, write=SetObjectPropertiesActive, default=1};
	
public:
	__property int ItemIndex = {read=FIndex, write=SetIndex, nodefault};
	__property TCrpeSQLExpressionsItem* Items[int nIndex] = {read=GetItems/*, default*/};
	Classes::TStrings* __fastcall Names(void);
	virtual int __fastcall Count(void);
	void __fastcall Clear(void);
	int __fastcall IndexOf(AnsiString ExpressionName);
	TCrpeSQLExpressionsItem* __fastcall ByName(AnsiString ExpressionName);
	__fastcall TCrpeSQLExpressions(void);
	__fastcall virtual ~TCrpeSQLExpressions(void);
};

#pragma pack(pop)

class DELPHICLASS TCrpeConnect;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeConnect : public TCrpePersistentX 
{
	typedef TCrpePersistentX inherited;
	
private:
	AnsiString FServerName;
	AnsiString FUserID;
	AnsiString FPassword;
	AnsiString FDatabaseName;
	bool FPropagate;
	
protected:
	AnsiString __fastcall GetServerName();
	void __fastcall SetServerName(const AnsiString Value);
	AnsiString __fastcall GetUserID();
	void __fastcall SetUserID(const AnsiString Value);
	AnsiString __fastcall GetPassword();
	void __fastcall SetPassword(const AnsiString Value);
	AnsiString __fastcall GetDatabaseName();
	void __fastcall SetDatabaseName(const AnsiString Value);
	void __fastcall SetPropagate(const bool Value);
	
__published:
	__property AnsiString ServerName = {read=GetServerName, write=SetServerName};
	__property AnsiString UserID = {read=GetUserID, write=SetUserID};
	__property AnsiString Password = {read=GetPassword, write=SetPassword};
	__property AnsiString DatabaseName = {read=GetDatabaseName, write=SetDatabaseName};
	__property bool Propagate = {read=FPropagate, write=SetPropagate, default=0};
	
public:
	bool __fastcall Test(void);
	void __fastcall Clear(void);
	__fastcall TCrpeConnect(void);
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpeConnect(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

class DELPHICLASS TCrpeLogOnInfo;
class DELPHICLASS TCrpeLogOnInfoItem;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeLogOnInfoItem : public TCrpeItemX 
{
	typedef TCrpeItemX inherited;
	
private:
	AnsiString FServerName;
	AnsiString FUserID;
	AnsiString FPassword;
	AnsiString FDatabaseName;
	AnsiString FDLLName;
	AnsiString FServerType;
	TCrTableType FTableType;
	
protected:
	void __fastcall SetServerName(const AnsiString Value);
	void __fastcall SetUserID(const AnsiString Value);
	void __fastcall SetPassword(const AnsiString Value);
	void __fastcall SetDatabaseName(const AnsiString Value);
	void __fastcall SetTable(const int nIndex);
	void __fastcall SetServerType(const AnsiString Value);
	
__published:
	__property int Table = {read=FIndex, write=SetTable, nodefault};
	__property AnsiString ServerName = {read=FServerName, write=SetServerName};
	__property AnsiString UserID = {read=FUserID, write=SetUserID};
	__property AnsiString Password = {read=FPassword, write=SetPassword};
	__property AnsiString DatabaseName = {read=FDatabaseName, write=SetDatabaseName};
	__property AnsiString ServerType = {read=FServerType, write=SetServerType};
	
public:
	__property AnsiString DLLName = {read=FDLLName};
	__property TCrTableType TableType = {read=FTableType, nodefault};
	bool __fastcall Test(void);
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	void __fastcall Clear(void);
	__fastcall TCrpeLogOnInfoItem(void);
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpeLogOnInfoItem(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeLogOnInfo : public TCrpeContainerX 
{
	typedef TCrpeContainerX inherited;
	
public:
	TCrpeLogOnInfoItem* operator[](int nIndex) { return Items[nIndex]; }
	
private:
	bool FSQLTablesOnly;
	TCrpeLogOnInfoItem* FItem;
	
protected:
	void __fastcall SetIndex(int nIndex);
	TCrpeLogOnInfoItem* __fastcall GetItem(int nIndex);
	
__published:
	__property int Table = {read=FIndex, write=SetIndex, default=-1};
	__property bool SQLTablesOnly = {read=FSQLTablesOnly, write=FSQLTablesOnly, default=1};
	__property TCrpeLogOnInfoItem* Item = {read=FItem, write=FItem};
	
public:
	__property int ItemIndex = {read=FIndex, write=SetIndex, nodefault};
	__property TCrpeLogOnInfoItem* Items[int nIndex] = {read=GetItem/*, default*/};
	virtual int __fastcall Count(void);
	void __fastcall Clear(void);
	__fastcall TCrpeLogOnInfo(void);
	__fastcall virtual ~TCrpeLogOnInfo(void);
};

#pragma pack(pop)

class DELPHICLASS TCrpeFormulas;
class DELPHICLASS TCrpeFormulasItem;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeFormulas : public TCrpeFieldObjectContainerX 
{
	typedef TCrpeFieldObjectContainerX inherited;
	
public:
	TCrpeFormulasItem* operator[](int nIndex) { return Items[nIndex]; }
	
private:
	AnsiString FName;
	Classes::TStrings* FNames;
	bool FObjectPropertiesActive;
	
protected:
	void __fastcall SetName(const AnsiString Value);
	void __fastcall SetObjectPropertiesActive(const bool Value);
	HIDESBASE void __fastcall SetIndex(int nIndex);
	TCrpeFormulasItem* __fastcall GetItems(int nIndex);
	TCrpeFormulasItem* __fastcall GetItem(void);
	void __fastcall SetItem(const TCrpeFormulasItem* nItem);
	
__published:
	__property int Number = {read=FIndex, write=SetIndex, default=-1};
	__property AnsiString Name = {read=FName, write=SetName};
	__property TCrpeFormulasItem* Item = {read=GetItem, write=SetItem};
	__property bool ObjectPropertiesActive = {read=FObjectPropertiesActive, write=SetObjectPropertiesActive, default=1};
	
public:
	__property int ItemIndex = {read=FIndex, write=SetIndex, nodefault};
	__property TCrpeFormulasItem* Items[int nIndex] = {read=GetItems/*, default*/};
	Classes::TStrings* __fastcall Names(void);
	virtual int __fastcall Count(void);
	void __fastcall Clear(void);
	int __fastcall IndexOf(AnsiString FormulaName);
	TCrpeFormulasItem* __fastcall ByName(AnsiString FormulaName);
	__fastcall TCrpeFormulas(void);
	__fastcall virtual ~TCrpeFormulas(void);
};

#pragma pack(pop)

class DELPHICLASS TCrpeSelection;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeSelection : public TCrpePersistentX 
{
	typedef TCrpePersistentX inherited;
	
private:
	Classes::TStrings* FFormula;
	Classes::TStrings* xFormula;
	
protected:
	Classes::TStrings* __fastcall GetFormula(void);
	void __fastcall SetFormula(Classes::TStrings* ListVar);
	void __fastcall OnChangeStrings(System::TObject* Sender);
	
__published:
	__property Classes::TStrings* Formula = {read=GetFormula, write=SetFormula};
	
public:
	bool __fastcall Check(void);
	void __fastcall Clear(void);
	__fastcall TCrpeSelection(void);
	__fastcall virtual ~TCrpeSelection(void);
};

#pragma pack(pop)

class DELPHICLASS TCrpeGroupSelection;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeGroupSelection : public TCrpePersistentX 
{
	typedef TCrpePersistentX inherited;
	
private:
	Classes::TStrings* FFormula;
	Classes::TStrings* xFormula;
	
protected:
	Classes::TStrings* __fastcall GetFormula(void);
	void __fastcall SetFormula(Classes::TStrings* ListVar);
	void __fastcall OnChangeStrings(System::TObject* Sender);
	
__published:
	__property Classes::TStrings* Formula = {read=GetFormula, write=SetFormula};
	
public:
	bool __fastcall Check(void);
	void __fastcall Clear(void);
	__fastcall TCrpeGroupSelection(void);
	__fastcall virtual ~TCrpeGroupSelection(void);
};

#pragma pack(pop)

class DELPHICLASS TCrpeSortFields;
class DELPHICLASS TCrpeSortFieldsItem;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeSortFieldsItem : public TCrpeItemX 
{
	typedef TCrpeItemX inherited;
	
private:
	AnsiString FFieldName;
	TCrSortDirection FDirection;
	
protected:
	void __fastcall SetFieldName(const AnsiString Value);
	void __fastcall SetDirection(const TCrSortDirection Value);
	
__published:
	__property AnsiString FieldName = {read=FFieldName, write=SetFieldName};
	__property TCrSortDirection Direction = {read=FDirection, write=SetDirection, default=1};
	
public:
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	void __fastcall Clear(void);
	__fastcall TCrpeSortFieldsItem(void);
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpeSortFieldsItem(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeSortFields : public TCrpeContainerX 
{
	typedef TCrpeContainerX inherited;
	
public:
	TCrpeSortFieldsItem* operator[](int nIndex) { return Items[nIndex]; }
	
private:
	TCrpeSortFieldsItem* FItem;
	
protected:
	void __fastcall SetIndex(int nIndex);
	TCrpeSortFieldsItem* __fastcall GetItem(int nIndex);
	
__published:
	__property int Number = {read=FIndex, write=SetIndex, default=-1};
	__property TCrpeSortFieldsItem* Item = {read=FItem, write=FItem};
	
public:
	__property int ItemIndex = {read=FIndex, write=SetIndex, nodefault};
	__property TCrpeSortFieldsItem* Items[int nIndex] = {read=GetItem/*, default*/};
	virtual int __fastcall Count(void);
	void __fastcall Clear(void);
	int __fastcall Add(AnsiString FieldName);
	void __fastcall Delete(int nIndex);
	void __fastcall Insert(short Position, AnsiString FieldName, TCrSortDirection Direction);
	void __fastcall Swap(short SourceN, short TargetN);
	__fastcall TCrpeSortFields(void);
	__fastcall virtual ~TCrpeSortFields(void);
};

#pragma pack(pop)

class DELPHICLASS TCrpeGroupSortFields;
class DELPHICLASS TCrpeGroupSortFieldsItem;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeGroupSortFieldsItem : public TCrpeItemX 
{
	typedef TCrpeItemX inherited;
	
private:
	AnsiString FFieldName;
	TCrSortDirection FDirection;
	
protected:
	void __fastcall SetFieldName(const AnsiString Value);
	void __fastcall SetDirection(const TCrSortDirection Value);
	
__published:
	__property AnsiString FieldName = {read=FFieldName, write=SetFieldName};
	__property TCrSortDirection Direction = {read=FDirection, write=SetDirection, default=1};
	
public:
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	void __fastcall Clear(void);
	__fastcall TCrpeGroupSortFieldsItem(void);
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpeGroupSortFieldsItem(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeGroupSortFields : public TCrpeContainerX 
{
	typedef TCrpeContainerX inherited;
	
public:
	TCrpeGroupSortFieldsItem* operator[](int nIndex) { return Items[nIndex]; }
	
private:
	TCrpeGroupSortFieldsItem* FItem;
	
protected:
	void __fastcall SetIndex(int nIndex);
	TCrpeGroupSortFieldsItem* __fastcall GetItem(int nIndex);
	
__published:
	__property int Number = {read=FIndex, write=SetIndex, nodefault};
	__property TCrpeGroupSortFieldsItem* Item = {read=FItem, write=FItem};
	
public:
	__property int ItemIndex = {read=FIndex, write=SetIndex, nodefault};
	__property TCrpeGroupSortFieldsItem* Items[int nIndex] = {read=GetItem/*, default*/};
	virtual int __fastcall Count(void);
	void __fastcall Clear(void);
	int __fastcall Add(AnsiString FieldName);
	void __fastcall Delete(int nIndex);
	__fastcall TCrpeGroupSortFields(void);
	__fastcall virtual ~TCrpeGroupSortFields(void);
};

#pragma pack(pop)

class DELPHICLASS TCrpeGroups;
class DELPHICLASS TCrpeGroupsItem;
class DELPHICLASS TCrpeGroupTopN;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeGroupTopN : public TCrpePersistentX 
{
	typedef TCrpePersistentX inherited;
	
private:
	TCrTopNSortType FSortType;
	short FNGroups;
	AnsiString FSortField;
	bool FIncludeOthers;
	AnsiString FOthersName;
	
protected:
	void __fastcall SetSortType(const TCrTopNSortType Value);
	void __fastcall SetNGroups(const short Value);
	void __fastcall SetSortField(const AnsiString Value);
	void __fastcall SetIncludeOthers(const bool Value);
	void __fastcall SetOthersName(const AnsiString Value);
	
__published:
	__property TCrTopNSortType SortType = {read=FSortType, write=SetSortType, default=0};
	__property short NGroups = {read=FNGroups, write=SetNGroups, default=5};
	__property AnsiString SortField = {read=FSortField, write=SetSortField};
	__property bool IncludeOthers = {read=FIncludeOthers, write=SetIncludeOthers, default=1};
	__property AnsiString OthersName = {read=FOthersName, write=SetOthersName};
	
public:
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	void __fastcall Clear(void);
	__fastcall TCrpeGroupTopN(void);
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpeGroupTopN(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

class DELPHICLASS TCrpeGroupHierarchy;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeGroupHierarchy : public TCrpePersistentX 
{
	typedef TCrpePersistentX inherited;
	
private:
	bool FEnabled;
	AnsiString FInstanceField;
	AnsiString FParentField;
	int FIndent;
	
protected:
	void __fastcall SetEnabled(const bool Value);
	void __fastcall SetInstanceField(const AnsiString Value);
	void __fastcall SetParentField(const AnsiString Value);
	void __fastcall SetIndent(const int Value);
	
__published:
	__property bool Enabled = {read=FEnabled, write=SetEnabled, default=0};
	__property AnsiString InstanceField = {read=FInstanceField, write=SetInstanceField};
	__property AnsiString ParentField = {read=FParentField, write=SetParentField};
	__property int Indent = {read=FIndent, write=SetIndent, default=0};
	
public:
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	void __fastcall Clear(void);
	__fastcall TCrpeGroupHierarchy(void);
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpeGroupHierarchy(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeGroupsItem : public TCrpeItemX 
{
	typedef TCrpeItemX inherited;
	
private:
	AnsiString FFieldName;
	TCrGroupCondition FCondition;
	TCrGroupDirection FDirection;
	TCrGroupType FGroupType;
	bool FRepeatGH;
	bool FKeepTogether;
	TCrpeGroupTopN* FTopN;
	TCrpeGroupHierarchy* FHierarchy;
	bool FCustomizeGroupName;
	Classes::TStrings* FGroupNameFormula;
	Classes::TStrings* xFormula;
	
protected:
	void __fastcall SetFieldName(const AnsiString Value);
	void __fastcall SetGroupType(const TCrGroupType Value);
	void __fastcall SetCondition(const TCrGroupCondition Value);
	void __fastcall SetDirection(const TCrGroupDirection Value);
	void __fastcall SetRepeatGH(const bool Value);
	void __fastcall SetKeepTogether(const bool Value);
	void __fastcall SetCustomizeGroupName(const bool Value);
	Classes::TStrings* __fastcall GetGroupNameFormula(void);
	void __fastcall SetGroupNameFormula(const Classes::TStrings* Value);
	void __fastcall OnChangeGroupNameFormula(System::TObject* Sender);
	
__published:
	__property AnsiString FieldName = {read=FFieldName, write=SetFieldName};
	__property TCrGroupCondition Condition = {read=FCondition, write=SetCondition, default=0};
	__property TCrGroupDirection Direction = {read=FDirection, write=SetDirection, default=1};
	__property TCrGroupType GroupType = {read=FGroupType, write=SetGroupType, default=0};
	__property bool RepeatGH = {read=FRepeatGH, write=SetRepeatGH, default=0};
	__property bool KeepTogether = {read=FKeepTogether, write=SetKeepTogether, default=0};
	__property TCrpeGroupTopN* TopN = {read=FTopN, write=FTopN};
	__property TCrpeGroupHierarchy* Hierarchy = {read=FHierarchy, write=FHierarchy};
	__property bool CustomizeGroupName = {read=FCustomizeGroupName, write=SetCustomizeGroupName, nodefault};
	__property Classes::TStrings* GroupNameFormula = {read=GetGroupNameFormula, write=SetGroupNameFormula};
	
public:
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	void __fastcall Clear(void);
	__fastcall TCrpeGroupsItem(void);
	__fastcall virtual ~TCrpeGroupsItem(void);
};

#pragma pack(pop)

#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeGroups : public TCrpeContainerX 
{
	typedef TCrpeContainerX inherited;
	
public:
	TCrpeGroupsItem* operator[](int nIndex) { return Items[nIndex]; }
	
private:
	TCrpeGroupsItem* FItem;
	Classes::TStrings* FGroupNames;
	
protected:
	void __fastcall SetIndex(int nIndex);
	TCrpeGroupsItem* __fastcall GetItem(int nIndex);
	void __fastcall SetItem(const TCrpeGroupsItem* nItem);
	
__published:
	__property int Number = {read=FIndex, write=SetIndex, nodefault};
	__property TCrpeGroupsItem* Item = {read=FItem, write=SetItem};
	
public:
	__property int ItemIndex = {read=FIndex, write=SetIndex, nodefault};
	__property TCrpeGroupsItem* Items[int nIndex] = {read=GetItem/*, default*/};
	Classes::TStrings* __fastcall Names(void);
	virtual int __fastcall Count(void);
	void __fastcall Clear(void);
	void __fastcall Swap(short SourceN, short TargetN);
	__fastcall TCrpeGroups(void);
	__fastcall virtual ~TCrpeGroups(void);
};

#pragma pack(pop)

class DELPHICLASS TCrpeTables;
class DELPHICLASS TCrpeTablesItem;
class DELPHICLASS TCrpeTableFields;
class DELPHICLASS TCrpeTableFieldsItem;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeTableFieldsItem : public TCrpeItemX 
{
	typedef TCrpeItemX inherited;
	
private:
	AnsiString FFieldName;
	Ucrpeclasses::TCrFieldValueType FFieldType;
	Word FFieldLength;
	
protected:
	void __fastcall SetFieldName(const AnsiString Value);
	void __fastcall SetFieldType(const Ucrpeclasses::TCrFieldValueType Value);
	void __fastcall SetFieldLength(const Word Value);
	
__published:
	__property AnsiString FieldName = {read=FFieldName, write=SetFieldName};
	__property Ucrpeclasses::TCrFieldValueType FieldType = {read=FFieldType, write=SetFieldType, default=0};
	__property Word FieldLength = {read=FFieldLength, write=SetFieldLength, default=0};
	
public:
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	void __fastcall Clear(void);
	bool __fastcall InUse(void);
	AnsiString __fastcall FullName();
	__fastcall TCrpeTableFieldsItem(void);
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpeTableFieldsItem(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeTableFields : public TCrpeContainerX 
{
	typedef TCrpeContainerX inherited;
	
public:
	TCrpeTableFieldsItem* operator[](int nIndex) { return Items[nIndex]; }
	
private:
	TCrpeTableFieldsItem* FItem;
	Classes::TStrings* FFieldNames;
	
protected:
	void __fastcall SetIndex(int nIndex);
	TCrpeTableFieldsItem* __fastcall GetItem(int nIndex);
	
__published:
	__property int Number = {read=FIndex, write=SetIndex, default=-1};
	__property TCrpeTableFieldsItem* Item = {read=FItem, write=FItem};
	
public:
	__property int ItemIndex = {read=FIndex, write=SetIndex, nodefault};
	__property TCrpeTableFieldsItem* Items[int nIndex] = {read=GetItem/*, default*/};
	virtual int __fastcall Count(void);
	void __fastcall Clear(void);
	Classes::TStrings* __fastcall FieldNames(void);
	TCrpeTableFieldsItem* __fastcall FieldByName(AnsiString sFieldName);
	int __fastcall IndexOf(AnsiString sFieldName);
	__fastcall TCrpeTableFields(void);
	__fastcall virtual ~TCrpeTableFields(void);
};

#pragma pack(pop)

#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeTablesItem : public TCrpeItemX 
{
	typedef TCrpeItemX inherited;
	
private:
	AnsiString FName;
	AnsiString FAliasName;
	AnsiString FPath;
	AnsiString FSubName;
	AnsiString FConnectBuffer;
	AnsiString FPassword;
	TCrTableType FTableType;
	AnsiString FDLLName;
	AnsiString FServerType;
	void *FDataPointer;
	TCrpeTableFields* FFields;
	Classes::TStrings* FFieldNames;
	
protected:
	void __fastcall SetName(const AnsiString Value);
	void __fastcall SetAliasName(const AnsiString Value);
	void __fastcall SetPath(const AnsiString Value);
	void __fastcall SetSubName(const AnsiString Value);
	void __fastcall SetConnectBuffer(const AnsiString Value);
	void __fastcall SetPassword(const AnsiString Value);
	void __fastcall SetServerType(const AnsiString Value);
	void __fastcall SetDataPointer(const void * Value);
	
__published:
	__property AnsiString Name = {read=FName, write=SetName};
	__property AnsiString AliasName = {read=FAliasName, write=SetAliasName};
	__property AnsiString Path = {read=FPath, write=SetPath};
	__property AnsiString SubName = {read=FSubName, write=SetSubName};
	__property AnsiString ConnectBuffer = {read=FConnectBuffer, write=SetConnectBuffer};
	__property AnsiString Password = {read=FPassword, write=SetPassword};
	__property AnsiString ServerType = {read=FServerType, write=SetServerType};
	__property TCrpeTableFields* Fields = {read=FFields, write=FFields};
	
public:
	__property void * DataPointer = {read=FDataPointer, write=SetDataPointer};
	__property TCrTableType TableType = {read=FTableType, nodefault};
	__property AnsiString DLLName = {read=FDLLName};
	TCrpeTableFieldsItem* __fastcall FieldByName(AnsiString sFieldName);
	Classes::TStrings* __fastcall FieldNames(void);
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	void __fastcall Clear(void);
	bool __fastcall Test(void);
	bool __fastcall CheckDifferences(Classes::TStringList* &DifNums, Classes::TStringList* &DifStrings);
	__fastcall TCrpeTablesItem(void);
	__fastcall virtual ~TCrpeTablesItem(void);
};

#pragma pack(pop)

#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeTables : public TCrpeContainerX 
{
	typedef TCrpeContainerX inherited;
	
public:
	TCrpeTablesItem* operator[](int nIndex) { return Items[nIndex]; }
	
private:
	bool FPropagate;
	TCrFieldMappingType FFieldMapping;
	bool FVerifyFix;
	TCrpeTablesItem* FItem;
	Classes::TStrings* FFieldNames;
	
protected:
	void __fastcall SetPropagate(const bool Value);
	TCrFieldMappingType __fastcall GetFieldMapping(void);
	void __fastcall SetFieldMapping(const TCrFieldMappingType Value);
	void __fastcall SetIndex(int nIndex);
	TCrpeTablesItem* __fastcall GetItem(int nIndex);
	
__published:
	__property int Number = {read=FIndex, write=SetIndex, default=-1};
	__property bool Propagate = {read=FPropagate, write=SetPropagate, default=0};
	__property TCrFieldMappingType FieldMapping = {read=GetFieldMapping, write=SetFieldMapping, default=0};
	__property bool VerifyFix = {read=FVerifyFix, write=FVerifyFix, default=0};
	__property TCrpeTablesItem* Item = {read=FItem, write=FItem};
	
public:
	__property int ItemIndex = {read=FIndex, write=SetIndex, nodefault};
	__property TCrpeTablesItem* Items[int nIndex] = {read=GetItem/*, default*/};
	Classes::TStrings* __fastcall FieldNames(void);
	virtual int __fastcall Count(void);
	void __fastcall Clear(void);
	int __fastcall IndexOf(AnsiString TableName);
	TCrpeTablesItem* __fastcall ByName(AnsiString AliasName);
	bool __fastcall GetFieldInfo(TCrFieldInfo &FieldInfo);
	bool __fastcall Verify(void);
	bool __fastcall ConvertDriver(AnsiString DLLName);
	__fastcall TCrpeTables(void);
	__fastcall virtual ~TCrpeTables(void);
};

#pragma pack(pop)

class DELPHICLASS TCrpeSessionInfo;
class DELPHICLASS TCrpeSessionInfoItem;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeSessionInfoItem : public TCrpeItemX 
{
	typedef TCrpeItemX inherited;
	
private:
	AnsiString FUserID;
	AnsiString FDBPassword;
	AnsiString FUserPassword;
	unsigned FSessionHandle;
	bool FPropagate;
	bool FPrevProp;
	
protected:
	void __fastcall SetUserID(const AnsiString Value);
	void __fastcall SetDBPassword(const AnsiString Value);
	void __fastcall SetUserPassword(const AnsiString Value);
	void __fastcall SetSessionHandle(const unsigned Value);
	void __fastcall SetPropagate(const bool Value);
	
__published:
	__property AnsiString UserID = {read=FUserID, write=SetUserID};
	__property AnsiString DBPassword = {read=FDBPassword, write=SetDBPassword};
	__property AnsiString UserPassword = {read=FUserPassword, write=SetUserPassword};
	__property bool Propagate = {read=FPropagate, write=SetPropagate, nodefault};
	
public:
	__property unsigned SessionHandle = {read=FSessionHandle, write=SetSessionHandle, nodefault};
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	void __fastcall Clear(void);
	bool __fastcall Test(void);
	__fastcall TCrpeSessionInfoItem(void);
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpeSessionInfoItem(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeSessionInfo : public TCrpeContainerX 
{
	typedef TCrpeContainerX inherited;
	
public:
	TCrpeSessionInfoItem* operator[](int nIndex) { return Items[nIndex]; }
	
private:
	TCrpeSessionInfoItem* FItem;
	
protected:
	void __fastcall SetIndex(int nIndex);
	TCrpeSessionInfoItem* __fastcall GetItem(int nIndex);
	
__published:
	__property int Table = {read=FIndex, write=SetIndex, nodefault};
	__property TCrpeSessionInfoItem* Item = {read=FItem, write=FItem};
	
public:
	__property int ItemIndex = {read=FIndex, write=SetIndex, nodefault};
	__property TCrpeSessionInfoItem* Items[int nIndex] = {read=GetItem/*, default*/};
	virtual int __fastcall Count(void);
	void __fastcall Clear(void);
	__fastcall TCrpeSessionInfo(void);
	__fastcall virtual ~TCrpeSessionInfo(void);
};

#pragma pack(pop)

class DELPHICLASS TCrpeSectionFormat;
class DELPHICLASS TCrpeSectionFormatItem;
class DELPHICLASS TCrpeSectionFormatFormulas;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeSectionFormatFormulas : public TCrpePersistentX 
{
	typedef TCrpePersistentX inherited;
	
private:
	Classes::TStrings* FSuppress;
	Classes::TStrings* FNewPageBefore;
	Classes::TStrings* FNewPageAfter;
	Classes::TStrings* FKeepTogether;
	Classes::TStrings* FSuppressBlankSection;
	Classes::TStrings* FResetPageNAfter;
	Classes::TStrings* FPrintAtBottomOfPage;
	Classes::TStrings* FBackgroundColor;
	Classes::TStrings* FUnderlaySection;
	Classes::TStrings* xFormula;
	
protected:
	Classes::TStrings* __fastcall GetSuppress(void);
	void __fastcall SetSuppress(const Classes::TStrings* Value);
	Classes::TStrings* __fastcall GetNewPageBefore(void);
	void __fastcall SetNewPageBefore(const Classes::TStrings* Value);
	Classes::TStrings* __fastcall GetNewPageAfter(void);
	void __fastcall SetNewPageAfter(const Classes::TStrings* Value);
	Classes::TStrings* __fastcall GetKeepTogether(void);
	void __fastcall SetKeepTogether(const Classes::TStrings* Value);
	Classes::TStrings* __fastcall GetSuppressBlankSection(void);
	void __fastcall SetSuppressBlankSection(const Classes::TStrings* Value);
	Classes::TStrings* __fastcall GetResetPageNAfter(void);
	void __fastcall SetResetPageNAfter(const Classes::TStrings* Value);
	Classes::TStrings* __fastcall GetPrintAtBottomOfPage(void);
	void __fastcall SetPrintAtBottomOfPage(const Classes::TStrings* Value);
	Classes::TStrings* __fastcall GetBackgroundColor(void);
	void __fastcall SetBackgroundColor(const Classes::TStrings* Value);
	Classes::TStrings* __fastcall GetUnderlaySection(void);
	void __fastcall SetUnderlaySection(const Classes::TStrings* Value);
	void __fastcall OnChangeSuppress(System::TObject* Sender);
	void __fastcall OnChangeNewPageBefore(System::TObject* Sender);
	void __fastcall OnChangeNewPageAfter(System::TObject* Sender);
	void __fastcall OnChangeKeepTogether(System::TObject* Sender);
	void __fastcall OnChangeSuppressBlankSection(System::TObject* Sender);
	void __fastcall OnChangeResetPageNAfter(System::TObject* Sender);
	void __fastcall OnChangePrintAtBottomOfPage(System::TObject* Sender);
	void __fastcall OnChangeBackgroundColor(System::TObject* Sender);
	void __fastcall OnChangeUnderlaySection(System::TObject* Sender);
	
__published:
	__property Classes::TStrings* Suppress = {read=GetSuppress, write=SetSuppress};
	__property Classes::TStrings* NewPageBefore = {read=GetNewPageBefore, write=SetNewPageBefore};
	__property Classes::TStrings* NewPageAfter = {read=GetNewPageAfter, write=SetNewPageAfter};
	__property Classes::TStrings* KeepTogether = {read=GetKeepTogether, write=SetKeepTogether};
	__property Classes::TStrings* SuppressBlankSection = {read=GetSuppressBlankSection, write=SetSuppressBlankSection};
	__property Classes::TStrings* ResetPageNAfter = {read=GetResetPageNAfter, write=SetResetPageNAfter};
	__property Classes::TStrings* PrintAtBottomOfPage = {read=GetPrintAtBottomOfPage, write=SetPrintAtBottomOfPage};
	__property Classes::TStrings* BackgroundColor = {read=GetBackgroundColor, write=SetBackgroundColor};
	__property Classes::TStrings* UnderlaySection = {read=GetUnderlaySection, write=SetUnderlaySection};
	
public:
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	void __fastcall Clear(void);
	__fastcall TCrpeSectionFormatFormulas(void);
	__fastcall virtual ~TCrpeSectionFormatFormulas(void);
};

#pragma pack(pop)

#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeSectionFormatItem : public TCrpeItemX 
{
	typedef TCrpeItemX inherited;
	
private:
	AnsiString FSection;
	bool FSuppress;
	bool FNewPageBefore;
	bool FNewPageAfter;
	bool FKeepTogether;
	bool FSuppressBlankSection;
	bool FResetPageNAfter;
	bool FPrintAtBottomOfPage;
	Graphics::TColor FBackgroundColor;
	bool FUnderlaySection;
	bool FFreeFormPlacement;
	TCrpeSectionFormatFormulas* FFormulas;
	
protected:
	void __fastcall SetSection(const AnsiString Value);
	void __fastcall SetSuppress(const bool Value);
	void __fastcall SetNewPageBefore(const bool Value);
	void __fastcall SetNewPageAfter(const bool Value);
	void __fastcall SetKeepTogether(const bool Value);
	void __fastcall SetSuppressBlankSection(const bool Value);
	void __fastcall SetResetPageNAfter(const bool Value);
	void __fastcall SetPrintAtBottomOfPage(const bool Value);
	void __fastcall SetBackgroundColor(const Graphics::TColor Value);
	void __fastcall SetUnderlaySection(const bool Value);
	void __fastcall SetFreeFormPlacement(const bool Value);
	
__published:
	__property AnsiString Section = {read=FSection, write=SetSection};
	__property bool Suppress = {read=FSuppress, write=SetSuppress, default=0};
	__property bool NewPageBefore = {read=FNewPageBefore, write=SetNewPageBefore, default=0};
	__property bool NewPageAfter = {read=FNewPageAfter, write=SetNewPageAfter, default=0};
	__property bool KeepTogether = {read=FKeepTogether, write=SetKeepTogether, default=1};
	__property bool SuppressBlankSection = {read=FSuppressBlankSection, write=SetSuppressBlankSection, default=0};
	__property bool ResetPageNAfter = {read=FResetPageNAfter, write=SetResetPageNAfter, default=0};
	__property bool PrintAtBottomOfPage = {read=FPrintAtBottomOfPage, write=SetPrintAtBottomOfPage, default=0};
	__property Graphics::TColor BackgroundColor = {read=FBackgroundColor, write=SetBackgroundColor, default=536870911};
	__property bool UnderlaySection = {read=FUnderlaySection, write=SetUnderlaySection, default=0};
	__property bool FreeFormPlacement = {read=FFreeFormPlacement, write=SetFreeFormPlacement, default=1};
	__property TCrpeSectionFormatFormulas* Formulas = {read=FFormulas, write=FFormulas};
	
public:
	short __fastcall SectionAsCode(void);
	AnsiString __fastcall SectionType();
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	void __fastcall Clear(void);
	__fastcall TCrpeSectionFormatItem(void);
	__fastcall virtual ~TCrpeSectionFormatItem(void);
};

#pragma pack(pop)

#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeSectionFormat : public TCrpeContainerX 
{
	typedef TCrpeContainerX inherited;
	
public:
	TCrpeSectionFormatItem* operator[](int nIndex) { return Items[nIndex]; }
	
private:
	AnsiString FSection;
	TCrpeSectionFormatItem* FItem;
	Classes::TStrings* FSectionNames;
	
protected:
	void __fastcall SetSection(const AnsiString Value);
	void __fastcall SetSectionAsCode(const short nCode);
	short __fastcall GetSectionAsCode(void);
	void __fastcall SetIndex(int nIndex);
	TCrpeSectionFormatItem* __fastcall GetItem(int nIndex);
	
__published:
	__property int Number = {read=FIndex, write=SetIndex, default=-1};
	__property AnsiString Section = {read=FSection, write=SetSection};
	__property short SectionAsCode = {read=GetSectionAsCode, write=SetSectionAsCode, default=0};
	__property TCrpeSectionFormatItem* Item = {read=FItem, write=FItem};
	
public:
	__property int ItemIndex = {read=FIndex, write=SetIndex, nodefault};
	__property TCrpeSectionFormatItem* Items[int nIndex] = {read=GetItem/*, default*/};
	Classes::TStrings* __fastcall Names(void);
	AnsiString __fastcall AreaType();
	virtual int __fastcall Count(void);
	void __fastcall Clear(void);
	int __fastcall IndexOf(AnsiString SectionName);
	TCrpeSectionFormatItem* __fastcall ByName(AnsiString SectionName);
	__fastcall TCrpeSectionFormat(void);
	__fastcall virtual ~TCrpeSectionFormat(void);
};

#pragma pack(pop)

class DELPHICLASS TCrpeAreaFormat;
class DELPHICLASS TCrpeAreaFormatItem;
class DELPHICLASS TCrpeAreaFormatFormulas;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeAreaFormatFormulas : public TCrpePersistentX 
{
	typedef TCrpePersistentX inherited;
	
private:
	Classes::TStrings* FSuppress;
	Classes::TStrings* FHide;
	Classes::TStrings* FNewPageBefore;
	Classes::TStrings* FNewPageAfter;
	Classes::TStrings* FKeepTogether;
	Classes::TStrings* FResetPageNAfter;
	Classes::TStrings* FPrintAtBottomOfPage;
	Classes::TStrings* xFormula;
	
protected:
	Classes::TStrings* __fastcall GetSuppress(void);
	void __fastcall SetSuppress(const Classes::TStrings* Value);
	Classes::TStrings* __fastcall GetHide(void);
	void __fastcall SetHide(const Classes::TStrings* Value);
	Classes::TStrings* __fastcall GetNewPageBefore(void);
	void __fastcall SetNewPageBefore(const Classes::TStrings* Value);
	Classes::TStrings* __fastcall GetNewPageAfter(void);
	void __fastcall SetNewPageAfter(const Classes::TStrings* Value);
	Classes::TStrings* __fastcall GetKeepTogether(void);
	void __fastcall SetKeepTogether(const Classes::TStrings* Value);
	Classes::TStrings* __fastcall GetResetPageNAfter(void);
	void __fastcall SetResetPageNAfter(const Classes::TStrings* Value);
	Classes::TStrings* __fastcall GetPrintAtBottomOfPage(void);
	void __fastcall SetPrintAtBottomOfPage(const Classes::TStrings* Value);
	void __fastcall OnChangeSuppress(System::TObject* Sender);
	void __fastcall OnChangeHide(System::TObject* Sender);
	void __fastcall OnChangeNewPageBefore(System::TObject* Sender);
	void __fastcall OnChangeNewPageAfter(System::TObject* Sender);
	void __fastcall OnChangeKeepTogether(System::TObject* Sender);
	void __fastcall OnChangeResetPageNAfter(System::TObject* Sender);
	void __fastcall OnChangePrintAtBottomOfPage(System::TObject* Sender);
	
__published:
	__property Classes::TStrings* Hide = {read=GetHide, write=SetHide};
	__property Classes::TStrings* NewPageBefore = {read=GetNewPageBefore, write=SetNewPageBefore};
	__property Classes::TStrings* NewPageAfter = {read=GetNewPageAfter, write=SetNewPageAfter};
	__property Classes::TStrings* KeepTogether = {read=GetKeepTogether, write=SetKeepTogether};
	__property Classes::TStrings* ResetPageNAfter = {read=GetResetPageNAfter, write=SetResetPageNAfter};
	__property Classes::TStrings* PrintAtBottomOfPage = {read=GetPrintAtBottomOfPage, write=SetPrintAtBottomOfPage};
	__property Classes::TStrings* Suppress = {read=GetSuppress, write=SetSuppress};
	
public:
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	void __fastcall Clear(void);
	__fastcall TCrpeAreaFormatFormulas(void);
	__fastcall virtual ~TCrpeAreaFormatFormulas(void);
};

#pragma pack(pop)

#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeAreaFormatItem : public TCrpeItemX 
{
	typedef TCrpeItemX inherited;
	
private:
	AnsiString FArea;
	bool FHide;
	bool FNewPageBefore;
	bool FNewPageAfter;
	bool FKeepTogether;
	bool FResetPageNAfter;
	bool FPrintAtBottomOfPage;
	bool FSuppress;
	TCrpeAreaFormatFormulas* FFormulas;
	short FNSections;
	bool FReserveMinimumPageFooter;
	
protected:
	void __fastcall SetArea(const AnsiString Value);
	void __fastcall SetHide(const bool Value);
	void __fastcall SetNewPageBefore(const bool Value);
	void __fastcall SetNewPageAfter(const bool Value);
	void __fastcall SetKeepTogether(const bool Value);
	void __fastcall SetResetPageNAfter(const bool Value);
	void __fastcall SetPrintAtBottomOfPage(const bool Value);
	void __fastcall SetSuppress(const bool Value);
	void __fastcall SetNSections(const short Value);
	void __fastcall SetReserveMinimumPageFooter(const bool Value);
	
__published:
	__property AnsiString Area = {read=FArea, write=SetArea};
	__property bool Hide = {read=FHide, write=SetHide, default=0};
	__property bool NewPageBefore = {read=FNewPageBefore, write=SetNewPageBefore, default=0};
	__property bool NewPageAfter = {read=FNewPageAfter, write=SetNewPageAfter, default=0};
	__property bool KeepTogether = {read=FKeepTogether, write=SetKeepTogether, default=0};
	__property bool ResetPageNAfter = {read=FResetPageNAfter, write=SetResetPageNAfter, default=0};
	__property bool PrintAtBottomOfPage = {read=FPrintAtBottomOfPage, write=SetPrintAtBottomOfPage, default=0};
	__property bool Suppress = {read=FSuppress, write=SetSuppress, default=0};
	__property TCrpeAreaFormatFormulas* Formulas = {read=FFormulas, write=FFormulas};
	__property short NSections = {read=FNSections, write=SetNSections, nodefault};
	__property bool ReserveMinimumPageFooter = {read=FReserveMinimumPageFooter, write=SetReserveMinimumPageFooter, default=0};
	
public:
	short __fastcall AreaAsCode(void);
	AnsiString __fastcall AreaType();
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	void __fastcall Clear(void);
	__fastcall TCrpeAreaFormatItem(void);
	__fastcall virtual ~TCrpeAreaFormatItem(void);
};

#pragma pack(pop)

#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeAreaFormat : public TCrpeContainerX 
{
	typedef TCrpeContainerX inherited;
	
public:
	TCrpeAreaFormatItem* operator[](int nIndex) { return Items[nIndex]; }
	
private:
	AnsiString FArea;
	Classes::TStrings* FAreas;
	TCrpeAreaFormatItem* FItem;
	
protected:
	void __fastcall SetArea(const AnsiString Value);
	short __fastcall GetAreaAsCode(void);
	void __fastcall SetAreaAsCode(const short nArea);
	void __fastcall SetIndex(int nIndex);
	TCrpeAreaFormatItem* __fastcall GetItem(int nIndex);
	
__published:
	__property int Number = {read=FIndex, write=SetIndex, default=-1};
	__property AnsiString Area = {read=FArea, write=SetArea};
	__property short AreaAsCode = {read=GetAreaAsCode, write=SetAreaAsCode, default=0};
	__property TCrpeAreaFormatItem* Item = {read=FItem, write=FItem};
	
public:
	__property int ItemIndex = {read=FIndex, write=SetIndex, nodefault};
	__property TCrpeAreaFormatItem* Items[int nIndex] = {read=GetItem/*, default*/};
	Classes::TStrings* __fastcall Names(void);
	AnsiString __fastcall AreaType();
	virtual int __fastcall Count(void);
	void __fastcall Clear(void);
	int __fastcall IndexOf(AnsiString AreaName);
	TCrpeAreaFormatItem* __fastcall ByName(AnsiString AreaName);
	__fastcall TCrpeAreaFormat(void);
	__fastcall virtual ~TCrpeAreaFormat(void);
};

#pragma pack(pop)

class DELPHICLASS TCrpeSectionFont;
class DELPHICLASS TCrpeSectionFontItem;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeSectionFontItem : public TCrpeItemX 
{
	typedef TCrpeItemX inherited;
	
private:
	AnsiString FSection;
	TCrFontScope FScope;
	AnsiString FName;
	Graphics::TFontPitch FPitch;
	TCrFontFamily FFamily;
	TCrFontCharSet FCharSet;
	short FSize;
	TCrBoolean FItalic;
	TCrBoolean FUnderlined;
	TCrBoolean FStrikeThrough;
	TCrFontWeight FWeight;
	
protected:
	void __fastcall SetSection(const AnsiString Value);
	void __fastcall SetScope(const TCrFontScope Value);
	void __fastcall SetName(const AnsiString Value);
	void __fastcall SetPitch(const Graphics::TFontPitch Value);
	void __fastcall SetFamily(const TCrFontFamily Value);
	void __fastcall SetCharSet(const TCrFontCharSet Value);
	void __fastcall SetSize(const short Value);
	void __fastcall SetItalic(const TCrBoolean Value);
	void __fastcall SetUnderlined(const TCrBoolean Value);
	void __fastcall SetStrikeThrough(const TCrBoolean Value);
	void __fastcall SetWeight(const TCrFontWeight Value);
	void __fastcall Send(void);
	
__published:
	__property AnsiString Section = {read=FSection, write=SetSection};
	__property TCrFontScope Scope = {read=FScope, write=SetScope, default=2};
	__property AnsiString Name = {read=FName, write=SetName};
	__property Graphics::TFontPitch Pitch = {read=FPitch, write=SetPitch, default=0};
	__property TCrFontFamily Family = {read=FFamily, write=SetFamily, default=0};
	__property TCrFontCharSet CharSet = {read=FCharSet, write=SetCharSet, default=1};
	__property short Size = {read=FSize, write=SetSize, default=0};
	__property TCrBoolean Italic = {read=FItalic, write=SetItalic, default=2};
	__property TCrBoolean Underlined = {read=FUnderlined, write=SetUnderlined, default=2};
	__property TCrBoolean StrikeThrough = {read=FStrikeThrough, write=SetStrikeThrough, default=2};
	__property TCrFontWeight Weight = {read=FWeight, write=SetWeight, default=0};
	
public:
	short __fastcall SectionAsCode(void);
	AnsiString __fastcall SectionType();
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	void __fastcall Clear(void);
	__fastcall TCrpeSectionFontItem(void);
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpeSectionFontItem(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeSectionFont : public TCrpeContainerX 
{
	typedef TCrpeContainerX inherited;
	
public:
	TCrpeSectionFontItem* operator[](int nIndex) { return Items[nIndex]; }
	
private:
	AnsiString FSection;
	TCrpeSectionFontItem* FItem;
	
protected:
	void __fastcall SetSection(const AnsiString Value);
	void __fastcall SetIndex(int nIndex);
	TCrpeSectionFontItem* __fastcall GetItem(int nIndex);
	
__published:
	__property int Number = {read=FIndex, write=SetIndex, default=-1};
	__property AnsiString Section = {read=FSection, write=SetSection};
	__property TCrpeSectionFontItem* Item = {read=FItem, write=FItem};
	
public:
	__property int ItemIndex = {read=FIndex, write=SetIndex, nodefault};
	__property TCrpeSectionFontItem* Items[int nIndex] = {read=GetItem/*, default*/};
	virtual int __fastcall Count(void);
	void __fastcall Clear(void);
	int __fastcall IndexOf(AnsiString SectionName);
	__fastcall TCrpeSectionFont(void);
	__fastcall virtual ~TCrpeSectionFont(void);
};

#pragma pack(pop)

class DELPHICLASS TCrpeSectionSize;
class DELPHICLASS TCrpeSectionSizeItem;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeSectionSizeItem : public TCrpeItemX 
{
	typedef TCrpeItemX inherited;
	
private:
	AnsiString FSection;
	short FHeight;
	short FWidth;
	
protected:
	void __fastcall SetSection(const AnsiString Value);
	void __fastcall SetHeight(const short Value);
	void __fastcall SetWidth(const short Value);
	
__published:
	__property AnsiString Section = {read=FSection, write=SetSection};
	__property short Height = {read=FHeight, write=SetHeight, nodefault};
	__property short Width = {read=FWidth, write=SetWidth, nodefault};
	
public:
	short __fastcall SectionAsCode(void);
	AnsiString __fastcall SectionType();
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	void __fastcall Clear(void);
	__fastcall TCrpeSectionSizeItem(void);
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpeSectionSizeItem(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeSectionSize : public TCrpeContainerX 
{
	typedef TCrpeContainerX inherited;
	
public:
	TCrpeSectionSizeItem* operator[](int nIndex) { return Items[nIndex]; }
	
private:
	AnsiString FSection;
	TCrpeSectionSizeItem* FItem;
	
protected:
	void __fastcall SetSection(const AnsiString Value);
	void __fastcall SetIndex(int nIndex);
	TCrpeSectionSizeItem* __fastcall GetItem(int nIndex);
	
__published:
	__property int Number = {read=FIndex, write=SetIndex, default=-1};
	__property AnsiString Section = {read=FSection, write=SetSection};
	__property TCrpeSectionSizeItem* Item = {read=FItem, write=FItem};
	
public:
	__property int ItemIndex = {read=FIndex, write=SetIndex, nodefault};
	__property TCrpeSectionSizeItem* Items[int nIndex] = {read=GetItem/*, default*/};
	virtual int __fastcall Count(void);
	void __fastcall Clear(void);
	int __fastcall IndexOf(AnsiString SectionName);
	__fastcall TCrpeSectionSize(void);
	__fastcall virtual ~TCrpeSectionSize(void);
};

#pragma pack(pop)

class DELPHICLASS TCrpeParamFields;
class DELPHICLASS TCrpeParamFieldsItem;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeParamFields : public TCrpeFieldObjectContainerX 
{
	typedef TCrpeFieldObjectContainerX inherited;
	
public:
	TCrpeParamFieldsItem* operator[](int nIndex) { return Items[nIndex]; }
	
private:
	Classes::TStrings* FNames;
	Classes::TStrings* FReportNames;
	bool FAllowDialog;
	bool FObjectPropertiesActive;
	
protected:
	HIDESBASE void __fastcall SetIndex(int nIndex);
	void __fastcall SetAllowDialog(const bool Value);
	void __fastcall SetObjectPropertiesActive(const bool Value);
	TCrpeParamFieldsItem* __fastcall GetItems(int nIndex);
	TCrpeParamFieldsItem* __fastcall GetItem(void);
	void __fastcall SetItem(const TCrpeParamFieldsItem* nItem);
	
__published:
	__property int Number = {read=FIndex, write=SetIndex, default=-1};
	__property bool AllowDialog = {read=FAllowDialog, write=SetAllowDialog, nodefault};
	__property TCrpeParamFieldsItem* Item = {read=GetItem, write=SetItem};
	__property bool ObjectPropertiesActive = {read=FObjectPropertiesActive, write=SetObjectPropertiesActive, default=1};
	
public:
	__property int ItemIndex = {read=FIndex, write=SetIndex, nodefault};
	__property TCrpeParamFieldsItem* Items[int nIndex] = {read=GetItems/*, default*/};
	Classes::TStrings* __fastcall Names(void);
	virtual int __fastcall Count(void);
	void __fastcall Clear(void);
	int __fastcall IndexOf(AnsiString ParamFieldName, AnsiString ReportName);
	TCrpeParamFieldsItem* __fastcall ByName(AnsiString ParamFieldName, AnsiString ReportName);
	__fastcall TCrpeParamFields(void);
	__fastcall virtual ~TCrpeParamFields(void);
};

#pragma pack(pop)

class DELPHICLASS TCrpeGraphs;
class DELPHICLASS TCrpeGraphsItem;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeGraphs : public TCrpeObjectContainerAX 
{
	typedef TCrpeObjectContainerAX inherited;
	
public:
	TCrpeGraphsItem* operator[](int nIndex) { return Items[nIndex]; }
	
protected:
	HIDESBASE void __fastcall SetIndex(int nIndex);
	TCrpeGraphsItem* __fastcall GetItems(int nIndex);
	TCrpeGraphsItem* __fastcall GetItem(void);
	void __fastcall SetItem(const TCrpeGraphsItem* nItem);
	
__published:
	__property int Number = {read=FIndex, write=SetIndex, nodefault};
	__property TCrpeGraphsItem* Item = {read=GetItem, write=SetItem};
	
public:
	__property int ItemIndex = {read=FIndex, write=SetIndex, nodefault};
	__property TCrpeGraphsItem* Items[int nIndex] = {read=GetItems/*, default*/};
	virtual int __fastcall Count(void);
	void __fastcall Clear(void);
	__fastcall TCrpeGraphs(void);
	__fastcall virtual ~TCrpeGraphs(void);
};

#pragma pack(pop)

class DELPHICLASS TCrpeLines;
class DELPHICLASS TCrpeLinesItem;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeLinesItem : public TCrpeItemX 
{
	typedef TCrpeItemX inherited;
	
private:
	AnsiString FSectionStart;
	AnsiString FSectionEnd;
	Ucrpeclasses::TCrLineStyle FLineStyle;
	int FTop;
	int FLeft;
	int FWidth;
	int FRight;
	int FBottom;
	Graphics::TColor FColor;
	bool FExtend;
	bool FSuppress;
	
protected:
	void __fastcall SetSectionStart(const AnsiString Value);
	void __fastcall SetSectionEnd(const AnsiString Value);
	void __fastcall SetLineStyle(const Ucrpeclasses::TCrLineStyle Value);
	void __fastcall SetTop(const int Value);
	void __fastcall SetLeft(const int Value);
	void __fastcall SetWidth(const int Value);
	void __fastcall SetRight(const int Value);
	void __fastcall SetBottom(const int Value);
	void __fastcall SetColor(const Graphics::TColor Value);
	void __fastcall SetExtend(const bool Value);
	void __fastcall SetSuppress(const bool Value);
	
__published:
	__property AnsiString SectionStart = {read=FSectionStart, write=SetSectionStart};
	__property AnsiString SectionEnd = {read=FSectionEnd, write=SetSectionEnd};
	__property Ucrpeclasses::TCrLineStyle LineStyle = {read=FLineStyle, write=SetLineStyle, nodefault};
	__property int Left = {read=FLeft, write=SetLeft, default=0};
	__property int Right = {read=FRight, write=SetRight, default=0};
	__property int Width = {read=FWidth, write=SetWidth, default=0};
	__property int Top = {read=FTop, write=SetTop, default=0};
	__property int Bottom = {read=FBottom, write=SetBottom, default=0};
	__property Graphics::TColor Color = {read=FColor, write=SetColor, nodefault};
	__property bool Extend = {read=FExtend, write=SetExtend, nodefault};
	__property bool Suppress = {read=FSuppress, write=SetSuppress, nodefault};
	
public:
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	void __fastcall Clear(void);
	bool __fastcall StatusIsGo(void);
	__fastcall TCrpeLinesItem(void);
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpeLinesItem(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeLines : public TCrpeContainerX 
{
	typedef TCrpeContainerX inherited;
	
public:
	TCrpeLinesItem* operator[](int nIndex) { return Items[nIndex]; }
	
private:
	TCrpeLinesItem* FItem;
	
protected:
	void __fastcall SetIndex(int nIndex);
	TCrpeLinesItem* __fastcall GetItem(int nIndex);
	
__published:
	__property int Number = {read=FIndex, write=SetIndex, default=-1};
	__property TCrpeLinesItem* Item = {read=FItem, write=FItem};
	
public:
	__property int ItemIndex = {read=FIndex, write=SetIndex, nodefault};
	__property TCrpeLinesItem* Items[int nIndex] = {read=GetItem/*, default*/};
	void __fastcall Clear(void);
	virtual int __fastcall Count(void);
	bool __fastcall StatusIsGo(void);
	__fastcall TCrpeLines(void);
	__fastcall virtual ~TCrpeLines(void);
};

#pragma pack(pop)

class DELPHICLASS TCrpeBoxes;
class DELPHICLASS TCrpeBoxesItem;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeBoxesItem : public TCrpeItemX 
{
	typedef TCrpeItemX inherited;
	
private:
	int FTop;
	int FBottom;
	int FLeft;
	int FRight;
	AnsiString FSectionStart;
	AnsiString FSectionEnd;
	Ucrpeclasses::TCrLineStyle FBorderStyle;
	int FBorderWidth;
	Graphics::TColor FBorderColor;
	bool FDropShadow;
	Graphics::TColor FFillColor;
	bool FCloseBorder;
	bool FExtend;
	bool FSuppress;
	int FCornerRoundingHeight;
	int FCornerRoundingWidth;
	
protected:
	void __fastcall SetTop(const int Value);
	void __fastcall SetBottom(const int Value);
	void __fastcall SetLeft(const int Value);
	void __fastcall SetRight(const int Value);
	void __fastcall SetSectionStart(const AnsiString Value);
	void __fastcall SetSectionEnd(const AnsiString Value);
	void __fastcall SetBorderStyle(const Ucrpeclasses::TCrLineStyle Value);
	void __fastcall SetBorderWidth(const int Value);
	void __fastcall SetBorderColor(const Graphics::TColor Value);
	void __fastcall SetDropShadow(const bool Value);
	void __fastcall SetFillColor(const Graphics::TColor Value);
	void __fastcall SetCloseBorder(const bool Value);
	void __fastcall SetExtend(const bool Value);
	void __fastcall SetSuppress(const bool Value);
	void __fastcall SetCornerRoundingHeight(const int Value);
	void __fastcall SetCornerRoundingWidth(const int Value);
	
__published:
	__property int Top = {read=FTop, write=SetTop, default=-1};
	__property int Bottom = {read=FBottom, write=SetBottom, default=-1};
	__property int Left = {read=FLeft, write=SetLeft, default=-1};
	__property int Right = {read=FRight, write=SetRight, default=-1};
	__property AnsiString SectionStart = {read=FSectionStart, write=SetSectionStart};
	__property AnsiString SectionEnd = {read=FSectionEnd, write=SetSectionEnd};
	__property Ucrpeclasses::TCrLineStyle BorderStyle = {read=FBorderStyle, write=SetBorderStyle, default=0};
	__property int BorderWidth = {read=FBorderWidth, write=SetBorderWidth, default=-1};
	__property Graphics::TColor BorderColor = {read=FBorderColor, write=SetBorderColor, default=0};
	__property bool DropShadow = {read=FDropShadow, write=SetDropShadow, default=0};
	__property Graphics::TColor FillColor = {read=FFillColor, write=SetFillColor, default=536870911};
	__property bool CloseBorder = {read=FCloseBorder, write=SetCloseBorder, default=1};
	__property bool Extend = {read=FExtend, write=SetExtend, default=0};
	__property bool Suppress = {read=FSuppress, write=SetSuppress, default=0};
	__property int CornerRoundingHeight = {read=FCornerRoundingHeight, write=SetCornerRoundingHeight, default=-1};
	__property int CornerRoundingWidth = {read=FCornerRoundingWidth, write=SetCornerRoundingWidth, default=-1};
	
public:
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	void __fastcall Clear(void);
	bool __fastcall StatusIsGo(void);
	__fastcall TCrpeBoxesItem(void);
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpeBoxesItem(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeBoxes : public TCrpeContainerX 
{
	typedef TCrpeContainerX inherited;
	
public:
	TCrpeBoxesItem* operator[](int nIndex) { return Items[nIndex]; }
	
private:
	TCrpeBoxesItem* FItem;
	
protected:
	void __fastcall SetIndex(int nIndex);
	TCrpeBoxesItem* __fastcall GetItem(int nIndex);
	
__published:
	__property int Number = {read=FIndex, write=SetIndex, nodefault};
	__property TCrpeBoxesItem* Item = {read=FItem, write=FItem};
	
public:
	__property int ItemIndex = {read=FIndex, write=SetIndex, nodefault};
	__property TCrpeBoxesItem* Items[int nIndex] = {read=GetItem/*, default*/};
	void __fastcall Clear(void);
	virtual int __fastcall Count(void);
	__fastcall TCrpeBoxes(void);
	__fastcall virtual ~TCrpeBoxes(void);
};

#pragma pack(pop)

class DELPHICLASS TCrpePictures;
class DELPHICLASS TCrpePicturesItem;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpePictures : public TCrpeObjectContainerAX 
{
	typedef TCrpeObjectContainerAX inherited;
	
public:
	TCrpePicturesItem* operator[](int nIndex) { return Items[nIndex]; }
	
protected:
	HIDESBASE void __fastcall SetIndex(int nIndex);
	TCrpePicturesItem* __fastcall GetItems(int nIndex);
	TCrpePicturesItem* __fastcall GetItem(void);
	void __fastcall SetItem(const TCrpePicturesItem* nItem);
	
__published:
	__property int Number = {read=FIndex, write=SetIndex, default=-1};
	__property TCrpePicturesItem* Item = {read=GetItem, write=SetItem};
	
public:
	__property int ItemIndex = {read=FIndex, write=SetIndex, nodefault};
	__property TCrpePicturesItem* Items[int nIndex] = {read=GetItems/*, default*/};
	void __fastcall Clear(void);
	__fastcall TCrpePictures(void);
	__fastcall virtual ~TCrpePictures(void);
};

#pragma pack(pop)

class DELPHICLASS TCrpeTextObjects;
class DELPHICLASS TCrpeObjectContainerBX;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeObjectContainerBX : public Ucrpeclasses::TCrpeObjectContainerB 
{
	typedef Ucrpeclasses::TCrpeObjectContainerB inherited;
	
public:
	TCrpe* __fastcall Cr(void);
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Create */ inline __fastcall TCrpeObjectContainerBX(void) : Ucrpeclasses::TCrpeObjectContainerB() { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpeObjectContainerBX(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

class DELPHICLASS TCrpeTextObjectsItem;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeTextObjects : public TCrpeObjectContainerBX 
{
	typedef TCrpeObjectContainerBX inherited;
	
public:
	TCrpeTextObjectsItem* operator[](int nIndex) { return Items[nIndex]; }
	
protected:
	HIDESBASE void __fastcall SetIndex(int nIndex);
	TCrpeTextObjectsItem* __fastcall GetItems(int nIndex);
	TCrpeTextObjectsItem* __fastcall GetItem(void);
	void __fastcall SetItem(const TCrpeTextObjectsItem* nItem);
	
__published:
	__property int Number = {read=FIndex, write=SetIndex, default=-1};
	__property TCrpeTextObjectsItem* Item = {read=GetItem, write=SetItem};
	
public:
	__property int ItemIndex = {read=FIndex, write=SetIndex, nodefault};
	__property TCrpeTextObjectsItem* Items[int nIndex] = {read=GetItems/*, default*/};
	void __fastcall Clear(void);
	__fastcall TCrpeTextObjects(void);
	__fastcall virtual ~TCrpeTextObjects(void);
};

#pragma pack(pop)

class DELPHICLASS TCrpeOleObjects;
class DELPHICLASS TCrpeOleObjectsItem;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeOleObjects : public TCrpeObjectContainerAX 
{
	typedef TCrpeObjectContainerAX inherited;
	
public:
	TCrpeOleObjectsItem* operator[](int nIndex) { return Items[nIndex]; }
	
protected:
	HIDESBASE void __fastcall SetIndex(int nIndex);
	TCrpeOleObjectsItem* __fastcall GetItems(int nIndex);
	TCrpeOleObjectsItem* __fastcall GetItem(void);
	void __fastcall SetItem(const TCrpeOleObjectsItem* nItem);
	
__published:
	__property int Number = {read=FIndex, write=SetIndex, default=-1};
	__property TCrpeOleObjectsItem* Item = {read=GetItem, write=SetItem};
	
public:
	__property int ItemIndex = {read=FIndex, write=SetIndex, nodefault};
	__property TCrpeOleObjectsItem* Items[int nIndex] = {read=GetItems/*, default*/};
	void __fastcall Clear(void);
	__fastcall TCrpeOleObjects(void);
	__fastcall virtual ~TCrpeOleObjects(void);
};

#pragma pack(pop)

class DELPHICLASS TCrpeCrossTabs;
class DELPHICLASS TCrpeCrossTabsItem;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeCrossTabs : public TCrpeObjectContainerAX 
{
	typedef TCrpeObjectContainerAX inherited;
	
public:
	TCrpeCrossTabsItem* operator[](int nIndex) { return Items[nIndex]; }
	
protected:
	HIDESBASE void __fastcall SetIndex(int nIndex);
	TCrpeCrossTabsItem* __fastcall GetItems(int nIndex);
	TCrpeCrossTabsItem* __fastcall GetItem(void);
	void __fastcall SetItem(const TCrpeCrossTabsItem* nItem);
	
__published:
	__property int Number = {read=FIndex, write=SetIndex, default=-1};
	__property TCrpeCrossTabsItem* Item = {read=GetItem, write=SetItem};
	
public:
	__property int ItemIndex = {read=FIndex, write=SetIndex, nodefault};
	__property TCrpeCrossTabsItem* Items[int nIndex] = {read=GetItems/*, default*/};
	void __fastcall Clear(void);
	__fastcall TCrpeCrossTabs(void);
	__fastcall virtual ~TCrpeCrossTabs(void);
};

#pragma pack(pop)

class DELPHICLASS TCrpeMaps;
class DELPHICLASS TCrpeMapsItem;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeMaps : public TCrpeObjectContainerAX 
{
	typedef TCrpeObjectContainerAX inherited;
	
public:
	TCrpeMapsItem* operator[](int nIndex) { return Items[nIndex]; }
	
protected:
	HIDESBASE void __fastcall SetIndex(int nIndex);
	TCrpeMapsItem* __fastcall GetItems(int nIndex);
	TCrpeMapsItem* __fastcall GetItem(void);
	void __fastcall SetItem(const TCrpeMapsItem* nItem);
	
__published:
	__property int Number = {read=FIndex, write=SetIndex, default=-1};
	__property TCrpeMapsItem* Item = {read=GetItem, write=SetItem};
	
public:
	__property int ItemIndex = {read=FIndex, write=SetIndex, nodefault};
	__property TCrpeMapsItem* Items[int nIndex] = {read=GetItems/*, default*/};
	void __fastcall Clear(void);
	__fastcall TCrpeMaps(void);
	__fastcall virtual ~TCrpeMaps(void);
};

#pragma pack(pop)

class DELPHICLASS TCrpeOLAPCubes;
class DELPHICLASS TCrpeOLAPCubesItem;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeOLAPCubes : public TCrpeObjectContainerAX 
{
	typedef TCrpeObjectContainerAX inherited;
	
public:
	TCrpeOLAPCubesItem* operator[](int nIndex) { return Items[nIndex]; }
	
protected:
	HIDESBASE void __fastcall SetIndex(int nIndex);
	TCrpeOLAPCubesItem* __fastcall GetItems(int nIndex);
	TCrpeOLAPCubesItem* __fastcall GetItem(void);
	void __fastcall SetItem(const TCrpeOLAPCubesItem* nItem);
	
__published:
	__property int Number = {read=FIndex, write=SetIndex, default=-1};
	__property TCrpeOLAPCubesItem* Item = {read=GetItem, write=SetItem};
	
public:
	__property int ItemIndex = {read=FIndex, write=SetIndex, nodefault};
	__property TCrpeOLAPCubesItem* Items[int nIndex] = {read=GetItems/*, default*/};
	void __fastcall Clear(void);
	__fastcall TCrpeOLAPCubes(void);
	__fastcall virtual ~TCrpeOLAPCubes(void);
};

#pragma pack(pop)

class DELPHICLASS TCrpeDatabaseFields;
class DELPHICLASS TCrpeDatabaseFieldsItem;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeDatabaseFields : public TCrpeFieldObjectContainerX 
{
	typedef TCrpeFieldObjectContainerX inherited;
	
public:
	TCrpeDatabaseFieldsItem* operator[](int nIndex) { return Items[nIndex]; }
	
protected:
	HIDESBASE void __fastcall SetIndex(int nIndex);
	TCrpeDatabaseFieldsItem* __fastcall GetItems(int nIndex);
	TCrpeDatabaseFieldsItem* __fastcall GetItem(void);
	void __fastcall SetItem(const TCrpeDatabaseFieldsItem* nItem);
	
__published:
	__property int Number = {read=FIndex, write=SetIndex, default=-1};
	__property TCrpeDatabaseFieldsItem* Item = {read=GetItem, write=SetItem};
	
public:
	__property int ItemIndex = {read=FIndex, write=SetIndex, nodefault};
	__property TCrpeDatabaseFieldsItem* Items[int nIndex] = {read=GetItems/*, default*/};
	void __fastcall Clear(void);
	int __fastcall IndexOf(AnsiString FieldName);
	__fastcall TCrpeDatabaseFields(void);
	__fastcall virtual ~TCrpeDatabaseFields(void);
};

#pragma pack(pop)

class DELPHICLASS TCrpeSummaryFields;
class DELPHICLASS TCrpeSummaryFieldsItem;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeSummaryFields : public TCrpeFieldObjectContainerX 
{
	typedef TCrpeFieldObjectContainerX inherited;
	
public:
	TCrpeSummaryFieldsItem* operator[](int nIndex) { return Items[nIndex]; }
	
protected:
	HIDESBASE void __fastcall SetIndex(int nIndex);
	TCrpeSummaryFieldsItem* __fastcall GetItems(int nIndex);
	TCrpeSummaryFieldsItem* __fastcall GetItem(void);
	void __fastcall SetItem(const TCrpeSummaryFieldsItem* nItem);
	
__published:
	__property int Number = {read=FIndex, write=SetIndex, default=-1};
	__property TCrpeSummaryFieldsItem* Item = {read=GetItem, write=SetItem};
	
public:
	__property TCrpeSummaryFieldsItem* Items[int nIndex] = {read=GetItems/*, default*/};
	__property int ItemIndex = {read=FIndex, write=SetIndex, nodefault};
	void __fastcall Clear(void);
	__fastcall TCrpeSummaryFields(void);
	__fastcall virtual ~TCrpeSummaryFields(void);
};

#pragma pack(pop)

class DELPHICLASS TCrpeSpecialFields;
class DELPHICLASS TCrpeSpecialFieldsItem;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeSpecialFields : public TCrpeFieldObjectContainerX 
{
	typedef TCrpeFieldObjectContainerX inherited;
	
public:
	TCrpeSpecialFieldsItem* operator[](int nIndex) { return Items[nIndex]; }
	
protected:
	HIDESBASE void __fastcall SetIndex(int nIndex);
	TCrpeSpecialFieldsItem* __fastcall GetItems(int nIndex);
	TCrpeSpecialFieldsItem* __fastcall GetItem(void);
	void __fastcall SetItem(const TCrpeSpecialFieldsItem* nItem);
	
__published:
	__property int Number = {read=FIndex, write=SetIndex, nodefault};
	__property TCrpeSpecialFieldsItem* Item = {read=GetItem, write=SetItem};
	
public:
	__property int ItemIndex = {read=FIndex, write=SetIndex, nodefault};
	__property TCrpeSpecialFieldsItem* Items[int nIndex] = {read=GetItems/*, default*/};
	void __fastcall Clear(void);
	int __fastcall IndexOf(AnsiString FieldName);
	__fastcall TCrpeSpecialFields(void);
	__fastcall virtual ~TCrpeSpecialFields(void);
};

#pragma pack(pop)

class DELPHICLASS TCrpeGroupNameFields;
class DELPHICLASS TCrpeGroupNameFieldsItem;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeGroupNameFields : public TCrpeFieldObjectContainerX 
{
	typedef TCrpeFieldObjectContainerX inherited;
	
public:
	TCrpeGroupNameFieldsItem* operator[](int nIndex) { return Items[nIndex]; }
	
protected:
	HIDESBASE void __fastcall SetIndex(int nIndex);
	TCrpeGroupNameFieldsItem* __fastcall GetItems(int nIndex);
	TCrpeGroupNameFieldsItem* __fastcall GetItem(void);
	void __fastcall SetItem(const TCrpeGroupNameFieldsItem* nItem);
	
__published:
	__property int Number = {read=FIndex, write=SetIndex, nodefault};
	__property TCrpeGroupNameFieldsItem* Item = {read=GetItem, write=SetItem};
	
public:
	__property int ItemIndex = {read=FIndex, write=SetIndex, nodefault};
	__property TCrpeGroupNameFieldsItem* Items[int nIndex] = {read=GetItems/*, default*/};
	void __fastcall Clear(void);
	__fastcall TCrpeGroupNameFields(void);
	__fastcall virtual ~TCrpeGroupNameFields(void);
};

#pragma pack(pop)

class DELPHICLASS TCrpeRunningTotals;
class DELPHICLASS TCrpeRunningTotalsItem;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeRunningTotals : public TCrpeFieldObjectContainerX 
{
	typedef TCrpeFieldObjectContainerX inherited;
	
public:
	TCrpeRunningTotalsItem* operator[](int nIndex) { return Items[nIndex]; }
	
private:
	AnsiString FName;
	Classes::TStrings* FNames;
	
protected:
	HIDESBASE void __fastcall SetIndex(int nIndex);
	TCrpeRunningTotalsItem* __fastcall GetItems(int nIndex);
	TCrpeRunningTotalsItem* __fastcall GetItem(void);
	void __fastcall SetItem(const TCrpeRunningTotalsItem* nItem);
	void __fastcall SetName(const AnsiString Value);
	
__published:
	__property int Number = {read=FIndex, write=SetIndex, nodefault};
	__property AnsiString Name = {read=FName, write=SetName};
	__property TCrpeRunningTotalsItem* Item = {read=GetItem, write=SetItem};
	
public:
	__property int ItemIndex = {read=FIndex, write=SetIndex, nodefault};
	__property TCrpeRunningTotalsItem* Items[int nIndex] = {read=GetItems/*, default*/};
	Classes::TStrings* __fastcall Names(void);
	virtual int __fastcall Count(void);
	void __fastcall Clear(void);
	int __fastcall IndexOf(AnsiString RunningTotalName);
	TCrpeRunningTotalsItem* __fastcall ByName(AnsiString RunningTotalName);
	__fastcall TCrpeRunningTotals(void);
	__fastcall virtual ~TCrpeRunningTotals(void);
};

#pragma pack(pop)

#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpe : public Ucrpeclasses::TComponentX 
{
	typedef Ucrpeclasses::TComponentX inherited;
	
private:
	Crdynamic::TCrpeEngine* FCrpeEngine;
	short FPrintJob;
	Classes::TStrings* FPrintJobs;
	unsigned hDLL;
	AnsiString FAbout;
	AnsiString FTempPath;
	TCrState FCrpeState;
	AnsiString FDesignControls;
	bool FEngineOpened;
	bool FLoadEngineOnUse;
	bool FIgnoreKnownProblems;
	TCrOutput FOutput;
	bool FProgressDialog;
	AnsiString FReportName;
	AnsiString FReportTitle;
	short FDetailCopies;
	TCrFormulaSyntax FFormulaSyntax;
	TCrReportStyle FReportStyle;
	short FLastErrorNumber;
	AnsiString FLastErrorString;
	TCrpeJobNumEvent FOnJobOpened;
	TCrpeCancelEvent FOnExecuteBegin;
	TCrpeCancelEvent FOnExecuteDoneSend;
	Classes::TNotifyEvent FOnCreate;
	Classes::TNotifyEvent FOnDestroy;
	Classes::TNotifyEvent FOnExecuteEnd;
	Classes::TNotifyEvent FOnWindowClose;
	Classes::TNotifyEvent FOnPrintEnded;
	TCrpePrinterEvent FOnPrinterSend;
	TCrpeVersionEvent FOnGetVersion;
	TCrpeErrorEvent FOnError;
	TCrpeFieldMappingEvent FOnFieldMapping;
	bool FWindowEvents;
	TCrpeGeneralPrintWindowEvent FwOnCloseWindow;
	TCrpeGeneralPrintWindowEvent FwOnPrintBtnClick;
	TCrpeGeneralPrintWindowEvent FwOnExportBtnClick;
	TCrpeGeneralPrintWindowEvent FwOnFirstPageBtnClick;
	TCrpeGeneralPrintWindowEvent FwOnPreviousPageBtnClick;
	TCrpeGeneralPrintWindowEvent FwOnNextPageBtnClick;
	TCrpeGeneralPrintWindowEvent FwOnLastPageBtnClick;
	TCrpeGeneralPrintWindowEvent FwOnCancelBtnClick;
	TCrpeGeneralPrintWindowEvent FwOnActivateWindow;
	TCrpeGeneralPrintWindowEvent FwOnDeActivateWindow;
	TCrpeGeneralPrintWindowEvent FwOnPrintSetupBtnClick;
	TCrpeGeneralPrintWindowEvent FwOnRefreshBtnClick;
	TCrpeZoomLevelChangingEvent FwOnZoomLevelChange;
	TCrpeCloseButtonClickedEvent FwOnCloseBtnClick;
	TCrpeSearchButtonClickedEvent FwOnSearchBtnClick;
	TCrpeGroupTreeButtonClickedEvent FwOnGroupTreeBtnClick;
	TCrpeReadingRecordsEvent FwOnReadingRecords;
	TCrpeStartEvent FwOnStartEvent;
	TCrpeStopEvent FwOnStopEvent;
	TCrpeShowGroupEvent FwOnShowGroup;
	TCrpeDrillOnGroupEvent FwOnDrillGroup;
	TCrpeDrillOnDetailEvent FwOnDrillDetail;
	TCrpeMouseClickEvent FwOnMouseClick;
	TCrpeOnDrillHyperLinkEvent FwOnDrillHyperLink;
	TCrpeOnLaunchSeagateAnalysisEvent FwOnLaunchSeagateAnalysis;
	TCrpeExportOptions* FExportOptions;
	TCrpeVersion* FVersion;
	TCrpePrintDate* FPrintDate;
	TCrpeSubreports* FSubreports;
	TCrpeLogOnServer* FLogOnServer;
	TCrpeRecords* FRecords;
	TCrpePages* FPages;
	TCrpePrinter* FPrinter;
	TCrpePrintOptions* FPrintOptions;
	TCrpeSummaryInfo* FSummaryInfo;
	TCrpeReportOptions* FReportOptions;
	TCrpeGlobalOptions* FGlobalOptions;
	HWND FParentFormHandle;
	Controls::TWinControl* FDialogParent;
	Controls::TWinControl* FWindowParent;
	TCrpeWindowButtonBar* FWindowButtonBar;
	TCrpeWindowCursor* FWindowCursor;
	TCrpeWindowSize* FWindowSize;
	Forms::TWindowState FWindowState;
	TCrpeWindowStyle* FWindowStyle;
	TCrpeWindowZoom* FWindowZoom;
	TCrpeMargins* FMargins;
	TCrpeSQL* FSQL;
	TCrpeSQLExpressions* FSQLExpressions;
	TCrpeConnect* FConnect;
	TCrpeLogOnInfo* FLogOnInfo;
	TCrpeFormulas* FFormulas;
	TCrpeSelection* FSelection;
	TCrpeGroupSelection* FGroupSelection;
	TCrpeSortFields* FSortFields;
	TCrpeGroupSortFields* FGroupSortFields;
	TCrpeGroups* FGroups;
	TCrpeTables* FTables;
	TCrpeSessionInfo* FSessionInfo;
	TCrpeSectionFormat* FSectionFormat;
	TCrpeAreaFormat* FAreaFormat;
	TCrpeSectionFont* FSectionFont;
	TCrpeSectionSize* FSectionSize;
	TCrpeParamFields* FParamFields;
	TCrpeGraphs* FGraphs;
	TCrpeLines* FLines;
	TCrpeBoxes* FBoxes;
	TCrpePictures* FPictures;
	TCrpeTextObjects* FTextObjects;
	TCrpeOleObjects* FOleObjects;
	TCrpeCrossTabs* FCrossTabs;
	TCrpeMaps* FMaps;
	TCrpeOLAPCubes* FOLAPCubes;
	TCrpeDatabaseFields* FDatabaseFields;
	TCrpeSummaryFields* FSummaryFields;
	TCrpeSpecialFields* FSpecialFields;
	TCrpeGroupNameFields* FGroupNameFields;
	TCrpeRunningTotals* FRunningTotals;
	
protected:
	void __fastcall SetTempPath(AnsiString TempPath);
	short __fastcall GetDetailCopies(void);
	void __fastcall SetDetailCopies(const short Value);
	void __fastcall SetProgressDialog(const bool Value);
	void __fastcall SetReportName(AnsiString NewName);
	AnsiString __fastcall GetReportTitle();
	void __fastcall SetReportTitle(const AnsiString Value);
	TCrFormulaSyntax __fastcall GetFormulaSyntax(void);
	void __fastcall SetFormulaSyntax(const TCrFormulaSyntax Value);
	TCrReportStyle __fastcall GetReportStyle(void);
	void __fastcall SetReportStyle(const TCrReportStyle Value);
	virtual void __fastcall Loaded(void);
	void __fastcall GetCRPEVersion(void);
	bool __fastcall OpenPrintEngine(void);
	void __fastcall ClosePrintEngine(void);
	bool __fastcall OpenPrintJob(void);
	void __fastcall ClosePrintJob(void);
	Controls::TWinControl* __fastcall GetWindowParent(void);
	void __fastcall SetWindowParent(const Controls::TWinControl* Value);
	Controls::TWinControl* __fastcall GetDialogParent(void);
	void __fastcall SetDialogParent(const Controls::TWinControl* Value);
	int __fastcall PreviewWindowStyle(void);
	Forms::TWindowState __fastcall GetWindowState(void);
	void __fastcall SetWindowState(const Forms::TWindowState Value);
	bool __fastcall GetSectionCodes(short JobNum, Classes::TStringList* &slNCodes, Classes::TStringList* &slSCodes, bool bArea);
	Ucrpeclasses::TCrFieldValueType __fastcall GetFieldTypeFromName(AnsiString FieldName);
	
__published:
	__property AnsiString About = {read=FAbout, write=FAbout};
	__property AnsiString DesignControls = {read=FDesignControls, write=FDesignControls};
	__property TCrpeVersion* Version = {read=FVersion, write=FVersion};
	__property AnsiString ReportName = {read=FReportName, write=SetReportName};
	__property AnsiString TempPath = {read=FTempPath, write=SetTempPath};
	__property TCrOutput Output = {read=FOutput, write=FOutput, default=0};
	__property AnsiString ReportTitle = {read=GetReportTitle, write=SetReportTitle};
	__property short DetailCopies = {read=GetDetailCopies, write=SetDetailCopies, default=1};
	__property TCrpeMargins* Margins = {read=FMargins, write=FMargins};
	__property bool ProgressDialog = {read=FProgressDialog, write=SetProgressDialog, default=1};
	__property bool LoadEngineOnUse = {read=FLoadEngineOnUse, write=FLoadEngineOnUse, default=0};
	__property TCrFormulaSyntax FormulaSyntax = {read=GetFormulaSyntax, write=SetFormulaSyntax, default=0};
	__property TCrReportStyle ReportStyle = {read=GetReportStyle, write=SetReportStyle, default=0};
	__property Classes::TNotifyEvent OnCreate = {read=FOnCreate, write=FOnCreate};
	__property Classes::TNotifyEvent OnDestroy = {read=FOnDestroy, write=FOnDestroy};
	__property TCrpeCancelEvent OnExecuteBegin = {read=FOnExecuteBegin, write=FOnExecuteBegin};
	__property TCrpeJobNumEvent OnJobOpened = {read=FOnJobOpened, write=FOnJobOpened};
	__property TCrpeCancelEvent OnExecuteDoneSend = {read=FOnExecuteDoneSend, write=FOnExecuteDoneSend};
	__property Classes::TNotifyEvent OnExecuteEnd = {read=FOnExecuteEnd, write=FOnExecuteEnd};
	__property Classes::TNotifyEvent OnWindowClose = {read=FOnWindowClose, write=FOnWindowClose};
	__property Classes::TNotifyEvent OnPrintEnded = {read=FOnPrintEnded, write=FOnPrintEnded};
	__property TCrpePrinterEvent OnPrinterSend = {read=FOnPrinterSend, write=FOnPrinterSend};
	__property TCrpeVersionEvent OnGetVersion = {read=FOnGetVersion, write=FOnGetVersion};
	__property TCrpeErrorEvent OnError = {read=FOnError, write=FOnError};
	__property bool WindowEvents = {read=FWindowEvents, write=FWindowEvents, default=0};
	__property TCrpeGeneralPrintWindowEvent wOnCloseWindow = {read=FwOnCloseWindow, write=FwOnCloseWindow};
	__property TCrpeGeneralPrintWindowEvent wOnPrintBtnClick = {read=FwOnPrintBtnClick, write=FwOnPrintBtnClick};
	__property TCrpeGeneralPrintWindowEvent wOnExportBtnClick = {read=FwOnExportBtnClick, write=FwOnExportBtnClick};
	__property TCrpeGeneralPrintWindowEvent wOnFirstPageBtnClick = {read=FwOnFirstPageBtnClick, write=FwOnFirstPageBtnClick};
	__property TCrpeGeneralPrintWindowEvent wOnPreviousPageBtnClick = {read=FwOnPreviousPageBtnClick, write=FwOnPreviousPageBtnClick};
	__property TCrpeGeneralPrintWindowEvent wOnNextPageBtnClick = {read=FwOnNextPageBtnClick, write=FwOnNextPageBtnClick};
	__property TCrpeGeneralPrintWindowEvent wOnLastPageBtnClick = {read=FwOnLastPageBtnClick, write=FwOnLastPageBtnClick};
	__property TCrpeGeneralPrintWindowEvent wOnCancelBtnClick = {read=FwOnCancelBtnClick, write=FwOnCancelBtnClick};
	__property TCrpeGeneralPrintWindowEvent wOnActivateWindow = {read=FwOnActivateWindow, write=FwOnActivateWindow};
	__property TCrpeGeneralPrintWindowEvent wOnDeActivateWindow = {read=FwOnDeActivateWindow, write=FwOnDeActivateWindow};
	__property TCrpeGeneralPrintWindowEvent wOnPrintSetupBtnClick = {read=FwOnPrintSetupBtnClick, write=FwOnPrintSetupBtnClick};
	__property TCrpeGeneralPrintWindowEvent wOnRefreshBtnClick = {read=FwOnRefreshBtnClick, write=FwOnRefreshBtnClick};
	__property TCrpeZoomLevelChangingEvent wOnZoomLevelChange = {read=FwOnZoomLevelChange, write=FwOnZoomLevelChange};
	__property TCrpeCloseButtonClickedEvent wOnCloseBtnClick = {read=FwOnCloseBtnClick, write=FwOnCloseBtnClick};
	__property TCrpeSearchButtonClickedEvent wOnSearchBtnClick = {read=FwOnSearchBtnClick, write=FwOnSearchBtnClick};
	__property TCrpeGroupTreeButtonClickedEvent wOnGroupTreeBtnClick = {read=FwOnGroupTreeBtnClick, write=FwOnGroupTreeBtnClick};
	__property TCrpeReadingRecordsEvent wOnReadingRecords = {read=FwOnReadingRecords, write=FwOnReadingRecords};
	__property TCrpeStartEvent wOnStartEvent = {read=FwOnStartEvent, write=FwOnStartEvent};
	__property TCrpeStopEvent wOnStopEvent = {read=FwOnStopEvent, write=FwOnStopEvent};
	__property TCrpeShowGroupEvent wOnShowGroup = {read=FwOnShowGroup, write=FwOnShowGroup};
	__property TCrpeDrillOnGroupEvent wOnDrillGroup = {read=FwOnDrillGroup, write=FwOnDrillGroup};
	__property TCrpeDrillOnDetailEvent wOnDrillDetail = {read=FwOnDrillDetail, write=FwOnDrillDetail};
	__property TCrpeFieldMappingEvent OnFieldMapping = {read=FOnFieldMapping, write=FOnFieldMapping};
	__property TCrpeMouseClickEvent wOnMouseClick = {read=FwOnMouseClick, write=FwOnMouseClick};
	__property TCrpeOnDrillHyperLinkEvent wOnDrillHyperLink = {read=FwOnDrillHyperLink, write=FwOnDrillHyperLink};
	__property TCrpeOnLaunchSeagateAnalysisEvent wOnLaunchSeagateAnalysis = {read=FwOnLaunchSeagateAnalysis, write=FwOnLaunchSeagateAnalysis};
	__property TCrpePrintDate* PrintDate = {read=FPrintDate, write=FPrintDate};
	__property TCrpeSubreports* Subreports = {read=FSubreports, write=FSubreports};
	__property TCrpeTables* Tables = {read=FTables, write=FTables};
	__property TCrpeSortFields* SortFields = {read=FSortFields, write=FSortFields};
	__property TCrpeGroupSortFields* GroupSortFields = {read=FGroupSortFields, write=FGroupSortFields};
	__property TCrpeGroups* Groups = {read=FGroups, write=FGroups};
	__property TCrpeParamFields* ParamFields = {read=FParamFields, write=FParamFields};
	__property TCrpeFormulas* Formulas = {read=FFormulas, write=FFormulas};
	__property TCrpeGroupSelection* GroupSelection = {read=FGroupSelection, write=FGroupSelection};
	__property TCrpeSelection* Selection = {read=FSelection, write=FSelection};
	__property TCrpeSectionFormat* SectionFormat = {read=FSectionFormat, write=FSectionFormat};
	__property TCrpeAreaFormat* AreaFormat = {read=FAreaFormat, write=FAreaFormat};
	__property TCrpeSectionFont* SectionFont = {read=FSectionFont, write=FSectionFont};
	__property TCrpeSectionSize* SectionSize = {read=FSectionSize, write=FSectionSize};
	__property TCrpeConnect* Connect = {read=FConnect, write=FConnect};
	__property TCrpeSQL* SQL = {read=FSQL, write=FSQL};
	__property TCrpeSQLExpressions* SQLExpressions = {read=FSQLExpressions, write=FSQLExpressions};
	__property TCrpeLogOnInfo* LogOnInfo = {read=FLogOnInfo, write=FLogOnInfo};
	__property TCrpeLogOnServer* LogOnServer = {read=FLogOnServer, write=FLogOnServer};
	__property TCrpeSessionInfo* SessionInfo = {read=FSessionInfo, write=FSessionInfo};
	__property TCrpeExportOptions* ExportOptions = {read=FExportOptions, write=FExportOptions};
	__property TCrpePrinter* Printer = {read=FPrinter, write=FPrinter};
	__property TCrpePrintOptions* PrintOptions = {read=FPrintOptions, write=FPrintOptions};
	__property TCrpeLines* Lines = {read=FLines, write=FLines};
	__property TCrpeBoxes* Boxes = {read=FBoxes, write=FBoxes};
	__property TCrpePictures* Pictures = {read=FPictures, write=FPictures};
	__property TCrpeTextObjects* TextObjects = {read=FTextObjects, write=FTextObjects};
	__property TCrpeOleObjects* OleObjects = {read=FOleObjects, write=FOleObjects};
	__property TCrpeCrossTabs* CrossTabs = {read=FCrossTabs, write=FCrossTabs};
	__property TCrpeMaps* Maps = {read=FMaps, write=FMaps};
	__property TCrpeOLAPCubes* OLAPCubes = {read=FOLAPCubes, write=FOLAPCubes};
	__property TCrpeDatabaseFields* DatabaseFields = {read=FDatabaseFields, write=FDatabaseFields};
	__property TCrpeSummaryFields* SummaryFields = {read=FSummaryFields, write=FSummaryFields};
	__property TCrpeSpecialFields* SpecialFields = {read=FSpecialFields, write=FSpecialFields};
	__property TCrpeGroupNameFields* GroupNameFields = {read=FGroupNameFields, write=FGroupNameFields};
	__property TCrpeRunningTotals* RunningTotals = {read=FRunningTotals, write=FRunningTotals};
	__property TCrpeWindowZoom* WindowZoom = {read=FWindowZoom, write=FWindowZoom};
	__property TCrpeWindowStyle* WindowStyle = {read=FWindowStyle, write=FWindowStyle};
	__property Forms::TWindowState WindowState = {read=GetWindowState, write=SetWindowState, default=0};
	__property TCrpeWindowSize* WindowSize = {read=FWindowSize, write=FWindowSize};
	__property TCrpeWindowButtonBar* WindowButtonBar = {read=FWindowButtonBar, write=FWindowButtonBar};
	__property TCrpeWindowCursor* WindowCursor = {read=FWindowCursor, write=FWindowCursor};
	__property Controls::TWinControl* WindowParent = {read=GetWindowParent, write=SetWindowParent};
	__property Controls::TWinControl* DialogParent = {read=GetDialogParent, write=SetDialogParent};
	__property TCrpeGraphs* Graphs = {read=FGraphs, write=FGraphs};
	__property TCrpeSummaryInfo* SummaryInfo = {read=FSummaryInfo, write=FSummaryInfo};
	__property TCrpeReportOptions* ReportOptions = {read=FReportOptions, write=FReportOptions};
	__property TCrpeGlobalOptions* GlobalOptions = {read=FGlobalOptions, write=FGlobalOptions};
	
public:
	__property bool IgnoreKnownProblems = {read=FIgnoreKnownProblems, write=FIgnoreKnownProblems, default=1};
	__property Crdynamic::TCrpeEngine* CrpeEngine = {read=FCrpeEngine};
	__property short LastErrorNumber = {read=FLastErrorNumber, write=FLastErrorNumber, default=0};
	__property AnsiString LastErrorString = {read=FLastErrorString, write=FLastErrorString};
	__property TCrpePages* Pages = {read=FPages, write=FPages};
	__property TCrpeRecords* Records = {read=FRecords, write=FRecords};
	short __fastcall PrintJobs(int ReportNumber);
	AnsiString __fastcall SectionCodeToStringEx(short SectionCode, bool bArea);
	int __fastcall GetNObjects(Ucrpeclasses::TCrObjectType ObjectType, Ucrpeclasses::TCrFieldObjectType ObjectFieldType);
	unsigned __fastcall GetObjectHandle(short SubObjectN, Ucrpeclasses::TCrObjectType ObjectType, Ucrpeclasses::TCrFieldObjectType FieldObjectType);
	unsigned __fastcall GetFieldObjectHandle(AnsiString FieldName, Ucrpeclasses::TCrFieldObjectType FieldObjectType, int &Index);
	AnsiString __fastcall BuildErrorString(Ucrpeclasses::TCrpePersistent* Source);
	TCrErrorResult __fastcall GetErrorMsg(Word nJob, TCrErrorOption Option, TCrError ErrType, AnsiString ErrConst, AnsiString ErrString);
	bool __fastcall StatusIsGo(int nIndex);
	short __fastcall ConvertFormulaName(Ucrpeclasses::TCrFormatFormulaName FName);
	bool __fastcall LogOnPrivateInfo(AnsiString DllName, void * PrivateInfo);
	TCrpeFormulasItem* __fastcall FormulaByName(AnsiString FormulaName);
	TCrpeParamFieldsItem* __fastcall ParamByName(AnsiString ParamFieldName, AnsiString ReportName);
	TCrpeRunningTotalsItem* __fastcall RunningTotalByName(AnsiString RunningTotalName);
	TCrpeSQLExpressionsItem* __fastcall SQLExpressionByName(AnsiString ExpressionName);
	TCrpeSubreportsItem* __fastcall SubreportByName(AnsiString SubreportName);
	TCrpeTablesItem* __fastcall TableByName(AnsiString AliasName);
	TCrpeSectionFormatItem* __fastcall SectionFormatByName(AnsiString SectionName);
	TCrpeAreaFormatItem* __fastcall AreaFormatByName(AnsiString AreaName);
	bool __fastcall Focused(void);
	void __fastcall SetFocus(void);
	HWND __fastcall ReportWindowHandle(void);
	void __fastcall CloseWindow(void);
	void __fastcall PrintWindow(void);
	void __fastcall ExportWindow(bool bMail);
	void __fastcall HideWindow(void);
	void __fastcall ShowWindow(void);
	void __fastcall Search(AnsiString SearchText);
	TCrFieldInfo __fastcall FieldNameToFieldInfo(AnsiString FieldName);
	AnsiString __fastcall FieldInfoToFieldName(const TCrFieldInfo &FieldInfo);
	bool __fastcall SendOutput(void);
	TCrStatus __fastcall Status(void);
	bool __fastcall IsJobFinished(void);
	bool __fastcall CanCloseEngine(void);
	bool __fastcall PrintEnded(void);
	bool __fastcall LoadEngine(void);
	bool __fastcall OpenEngine(void);
	void __fastcall CloseEngine(void);
	void __fastcall UnloadEngine(void);
	bool __fastcall EngineOpen(void);
	bool __fastcall OpenJob(void);
	bool __fastcall JobIsOpen(void);
	void __fastcall CloseJob(void);
	void __fastcall CancelJob(void);
	void __fastcall Refresh(void);
	short __fastcall JobNumber(void);
	bool __fastcall Execute(void);
	bool __fastcall Show(void);
	bool __fastcall Print(void);
	bool __fastcall Export(void);
	unsigned __fastcall CrpeHandle(void);
	bool __fastcall Save(AnsiString filePath);
	bool __fastcall SaveAs(AnsiString filePath);
	bool __fastcall HasSavedData(void);
	bool __fastcall DiscardSavedData(void);
	void __fastcall Clear(void);
	__fastcall virtual TCrpe(Classes::TComponent* AOwner);
	__fastcall virtual ~TCrpe(void);
};

#pragma pack(pop)

class DELPHICLASS TCrpeObjectItemAX;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeObjectItemAX : public Ucrpeclasses::TCrpeObjectItemA 
{
	typedef Ucrpeclasses::TCrpeObjectItemA inherited;
	
public:
	TCrpe* __fastcall Cr(void);
public:
	#pragma option push -w-inl
	/* TCrpeObjectItemA.Create */ inline __fastcall TCrpeObjectItemAX(void) : Ucrpeclasses::TCrpeObjectItemA() { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCrpeObjectItemA.Destroy */ inline __fastcall virtual ~TCrpeObjectItemAX(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

class DELPHICLASS TCrpeObjectItemBX;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeObjectItemBX : public Ucrpeclasses::TCrpeObjectItemB 
{
	typedef Ucrpeclasses::TCrpeObjectItemB inherited;
	
public:
	TCrpe* __fastcall Cr(void);
public:
	#pragma option push -w-inl
	/* TCrpeObjectItemB.Create */ inline __fastcall TCrpeObjectItemBX(void) : Ucrpeclasses::TCrpeObjectItemB() { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCrpeObjectItemB.Destroy */ inline __fastcall virtual ~TCrpeObjectItemBX(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

class DELPHICLASS TCrpeFieldObjectItemX;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeFieldObjectItemX : public Ucrpeclasses::TCrpeFieldObjectItem 
{
	typedef Ucrpeclasses::TCrpeFieldObjectItem inherited;
	
public:
	TCrpe* __fastcall Cr(void);
public:
	#pragma option push -w-inl
	/* TCrpeFieldObjectItem.Create */ inline __fastcall TCrpeFieldObjectItemX(void) : Ucrpeclasses::TCrpeFieldObjectItem() { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCrpeFieldObjectItem.Destroy */ inline __fastcall virtual ~TCrpeFieldObjectItemX(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

class DELPHICLASS TCrpeCrossTabSummariesItem;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeCrossTabSummariesItem : public TCrpeItemX 
{
	typedef TCrpeItemX inherited;
	
private:
	AnsiString FSummarizedField;
	Ucrpeclasses::TCrFieldValueType FFieldType;
	Word FFieldLength;
	TCrSummaryType FSummaryType;
	short FSummaryTypeN;
	AnsiString FSummaryTypeField;
	
protected:
	void __fastcall SetSummarizedField(const AnsiString Value);
	void __fastcall SetFieldType(const Ucrpeclasses::TCrFieldValueType Value);
	void __fastcall SetFieldLength(const Word Value);
	void __fastcall SetSummaryType(const TCrSummaryType Value);
	void __fastcall SetSummaryTypeN(const short Value);
	void __fastcall SetSummaryTypeField(const AnsiString Value);
	
__published:
	__property AnsiString SummarizedField = {read=FSummarizedField, write=SetSummarizedField};
	__property Ucrpeclasses::TCrFieldValueType FieldType = {read=FFieldType, write=SetFieldType, default=0};
	__property Word FieldLength = {read=FFieldLength, write=SetFieldLength, default=0};
	__property TCrSummaryType SummaryType = {read=FSummaryType, write=SetSummaryType, default=6};
	__property short SummaryTypeN = {read=FSummaryTypeN, write=SetSummaryTypeN, default=-1};
	__property AnsiString SummaryTypeField = {read=FSummaryTypeField, write=SetSummaryTypeField};
	
public:
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	void __fastcall Clear(void);
	bool __fastcall StatusIsGo(int nIndex);
	__fastcall TCrpeCrossTabSummariesItem(void);
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpeCrossTabSummariesItem(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

class DELPHICLASS TCrpeCrossTabSummaries;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeCrossTabSummaries : public TCrpeContainerX 
{
	typedef TCrpeContainerX inherited;
	
public:
	TCrpeCrossTabSummariesItem* operator[](int nIndex) { return Items[nIndex]; }
	
private:
	TCrpeCrossTabSummariesItem* FItem;
	
protected:
	void __fastcall SetIndex(int nIndex);
	TCrpeCrossTabSummariesItem* __fastcall GetItem(int nIndex);
	
__published:
	__property int Number = {read=FIndex, write=SetIndex, default=-1};
	__property TCrpeCrossTabSummariesItem* Item = {read=FItem, write=FItem};
	
public:
	__property int ItemIndex = {read=FIndex, write=SetIndex, nodefault};
	__property TCrpeCrossTabSummariesItem* Items[int nIndex] = {read=GetItem/*, default*/};
	virtual int __fastcall Count(void);
	void __fastcall Clear(void);
	__fastcall TCrpeCrossTabSummaries(void);
	__fastcall virtual ~TCrpeCrossTabSummaries(void);
};

#pragma pack(pop)

class DELPHICLASS TCrpeCrossTabGroupsItem;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeCrossTabGroupsItem : public TCrpeItemX 
{
	typedef TCrpeItemX inherited;
	
private:
	TCrCrossTabGroupPlacement FRowCol;
	AnsiString FFieldName;
	TCrGroupCondition FCondition;
	TCrGroupDirection FDirection;
	Graphics::TColor FBackgroundColor;
	bool FSuppressSubtotal;
	bool FSuppressLabel;
	
protected:
	void __fastcall SetFieldName(const AnsiString Value);
	void __fastcall SetCondition(const TCrGroupCondition Value);
	void __fastcall SetDirection(const TCrGroupDirection Value);
	void __fastcall SetBackgroundColor(const Graphics::TColor Value);
	void __fastcall SetSuppressSubtotal(const bool Value);
	void __fastcall SetSuppressLabel(const bool Value);
	
__published:
	__property AnsiString FieldName = {read=FFieldName, write=SetFieldName};
	__property TCrGroupCondition Condition = {read=FCondition, write=SetCondition, default=0};
	__property TCrGroupDirection Direction = {read=FDirection, write=SetDirection, default=1};
	__property Graphics::TColor BackgroundColor = {read=FBackgroundColor, write=SetBackgroundColor, default=536870911};
	__property bool SuppressSubtotal = {read=FSuppressSubtotal, write=SetSuppressSubtotal, default=0};
	__property bool SuppressLabel = {read=FSuppressLabel, write=SetSuppressLabel, default=0};
	
public:
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	void __fastcall Clear(void);
	bool __fastcall StatusIsGo(int nIndex);
	__fastcall TCrpeCrossTabGroupsItem(void);
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpeCrossTabGroupsItem(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

class DELPHICLASS TCrpeCrossTabGroups;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeCrossTabGroups : public TCrpeContainerX 
{
	typedef TCrpeContainerX inherited;
	
public:
	TCrpeCrossTabGroupsItem* operator[](int nIndex) { return Items[nIndex]; }
	
private:
	TCrpeCrossTabGroupsItem* FItem;
	
protected:
	void __fastcall SetIndex(int nIndex);
	TCrpeCrossTabGroupsItem* __fastcall GetItem(int nIndex);
	
__published:
	__property int Number = {read=FIndex, write=SetIndex, default=-1};
	__property TCrpeCrossTabGroupsItem* Item = {read=FItem, write=FItem};
	
public:
	__property int ItemIndex = {read=FIndex, write=SetIndex, nodefault};
	__property TCrpeCrossTabGroupsItem* Items[int nIndex] = {read=GetItem/*, default*/};
	virtual int __fastcall Count(void);
	void __fastcall Clear(void);
	__fastcall TCrpeCrossTabGroups(void);
	__fastcall virtual ~TCrpeCrossTabGroups(void);
};

#pragma pack(pop)

#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeCrossTabsItem : public TCrpeObjectItemAX 
{
	typedef TCrpeObjectItemAX inherited;
	
private:
	bool FShowCellMargins;
	bool FShowGridLines;
	bool FRepeatRowLabels;
	bool FKeepColumnsTogether;
	bool FSuppressEmptyRows;
	bool FSuppressEmptyColumns;
	bool FSuppressRowGrandTotals;
	bool FSuppressColumnGrandTotals;
	Graphics::TColor FColorRowGrandTotals;
	Graphics::TColor FColorColumnGrandTotals;
	TCrpeCrossTabSummaries* FSummaries;
	TCrpeCrossTabGroups* FRowGroups;
	TCrpeCrossTabGroups* FColumnGroups;
	
protected:
	void __fastcall SetShowCellMargins(const bool Value);
	void __fastcall SetSuppressEmptyRows(const bool Value);
	void __fastcall SetSuppressEmptyColumns(const bool Value);
	void __fastcall SetKeepColumnsTogether(const bool Value);
	void __fastcall SetRepeatRowLabels(const bool Value);
	void __fastcall SetSuppressRowGrandTotals(const bool Value);
	void __fastcall SetSuppressColumnGrandTotals(const bool Value);
	void __fastcall SetColorRowGrandTotals(const Graphics::TColor Value);
	void __fastcall SetColorColumnGrandTotals(const Graphics::TColor Value);
	void __fastcall SetShowGridLines(const bool Value);
	
__published:
	__property bool ShowCellMargins = {read=FShowCellMargins, write=SetShowCellMargins, default=1};
	__property bool SuppressEmptyRows = {read=FSuppressEmptyRows, write=SetSuppressEmptyRows, default=0};
	__property bool SuppressEmptyColumns = {read=FSuppressEmptyColumns, write=SetSuppressEmptyColumns, default=0};
	__property bool KeepColumnsTogether = {read=FKeepColumnsTogether, write=SetKeepColumnsTogether, default=1};
	__property bool RepeatRowLabels = {read=FRepeatRowLabels, write=SetRepeatRowLabels, default=0};
	__property bool SuppressRowGrandTotals = {read=FSuppressRowGrandTotals, write=SetSuppressRowGrandTotals, default=0};
	__property bool SuppressColumnGrandTotals = {read=FSuppressColumnGrandTotals, write=SetSuppressColumnGrandTotals, default=0};
	__property Graphics::TColor ColorRowGrandTotals = {read=FColorRowGrandTotals, write=SetColorRowGrandTotals, default=536870911};
	__property Graphics::TColor ColorColumnGrandTotals = {read=FColorColumnGrandTotals, write=SetColorColumnGrandTotals, default=536870911};
	__property bool ShowGridLines = {read=FShowGridLines, write=SetShowGridLines, default=1};
	__property TCrpeCrossTabSummaries* Summaries = {read=FSummaries, write=FSummaries};
	__property TCrpeCrossTabGroups* RowGroups = {read=FRowGroups, write=FRowGroups};
	__property TCrpeCrossTabGroups* ColumnGroups = {read=FColumnGroups, write=FColumnGroups};
	
public:
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	HIDESBASE void __fastcall Clear(void);
	__fastcall TCrpeCrossTabsItem(void);
	__fastcall virtual ~TCrpeCrossTabsItem(void);
};

#pragma pack(pop)

#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeDatabaseFieldsItem : public TCrpeFieldObjectItemX 
{
	typedef TCrpeFieldObjectItemX inherited;
	
public:
	virtual void __fastcall Assign(Classes::TPersistent* Source);
public:
	#pragma option push -w-inl
	/* TCrpeFieldObjectItem.Create */ inline __fastcall TCrpeDatabaseFieldsItem(void) : TCrpeFieldObjectItemX() { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCrpeFieldObjectItem.Destroy */ inline __fastcall virtual ~TCrpeDatabaseFieldsItem(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeFormulasItem : public TCrpeFieldObjectItemX 
{
	typedef TCrpeFieldObjectItemX inherited;
	
private:
	AnsiString FName;
	Classes::TStrings* FFormula;
	Classes::TStrings* xFormula;
	
protected:
	void __fastcall SetName(const AnsiString Value);
	void __fastcall SetFormula(const Classes::TStrings* ListVar);
	void __fastcall OnChangeFormula(System::TObject* Sender);
	
__published:
	__property AnsiString Name = {read=FName, write=SetName};
	__property Classes::TStrings* Formula = {read=FFormula, write=SetFormula};
	
public:
	bool __fastcall Check(void);
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	HIDESBASE void __fastcall Clear(void);
	__fastcall TCrpeFormulasItem(void);
	__fastcall virtual ~TCrpeFormulasItem(void);
};

#pragma pack(pop)

class DELPHICLASS TCrpeGraphAxis;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeGraphAxis : public TCrpePersistentX 
{
	typedef TCrpePersistentX inherited;
	
private:
	TCrGraphGridLines FGridLineX;
	TCrGraphGridLines FGridLineY;
	TCrGraphGridLines FGridLineY2;
	TCrGraphGridLines FGridLineZ;
	TCrGraphDVType FDataValuesY;
	TCrGraphDVType FDataValuesY2;
	TCrGraphDVType FDataValuesZ;
	double FMinY;
	double FMaxY;
	double FMinY2;
	double FMaxY2;
	double FMinZ;
	double FMaxZ;
	TCrGraphNumberFormat FNumberFormatY;
	TCrGraphNumberFormat FNumberFormatY2;
	TCrGraphNumberFormat FNumberFormatZ;
	TCrGraphDVType FDivisionTypeY;
	TCrGraphDVType FDivisionTypeY2;
	TCrGraphDVType FDivisionTypeZ;
	int FDivisionsY;
	int FDivisionsY2;
	int FDivisionsZ;
	
protected:
	void __fastcall GetAxis(void);
	void __fastcall SetGridLineX(const TCrGraphGridLines Value);
	void __fastcall SetGridLineY(const TCrGraphGridLines Value);
	void __fastcall SetGridLineY2(const TCrGraphGridLines Value);
	void __fastcall SetGridLineZ(const TCrGraphGridLines Value);
	void __fastcall SetDataValuesY(const TCrGraphDVType Value);
	void __fastcall SetDataValuesY2(const TCrGraphDVType Value);
	void __fastcall SetDataValuesZ(const TCrGraphDVType Value);
	void __fastcall SetMinY(const double Value);
	void __fastcall SetMaxY(const double Value);
	void __fastcall SetMinY2(const double Value);
	void __fastcall SetMaxY2(const double Value);
	void __fastcall SetMinZ(const double Value);
	void __fastcall SetMaxZ(const double Value);
	void __fastcall SetNumberFormatY(const TCrGraphNumberFormat Value);
	void __fastcall SetNumberFormatY2(const TCrGraphNumberFormat Value);
	void __fastcall SetNumberFormatZ(const TCrGraphNumberFormat Value);
	void __fastcall SetDivisionTypeY(const TCrGraphDVType Value);
	void __fastcall SetDivisionTypeY2(const TCrGraphDVType Value);
	void __fastcall SetDivisionTypeZ(const TCrGraphDVType Value);
	void __fastcall SetDivisionsY(const int Value);
	void __fastcall SetDivisionsY2(const int Value);
	void __fastcall SetDivisionsZ(const int Value);
	
__published:
	__property TCrGraphGridLines GridLineX = {read=FGridLineX, write=SetGridLineX, nodefault};
	__property TCrGraphGridLines GridLineY = {read=FGridLineY, write=SetGridLineY, nodefault};
	__property TCrGraphGridLines GridLineY2 = {read=FGridLineY2, write=SetGridLineY2, nodefault};
	__property TCrGraphGridLines GridLineZ = {read=FGridLineZ, write=SetGridLineZ, nodefault};
	__property TCrGraphDVType DataValuesY = {read=FDataValuesY, write=SetDataValuesY, nodefault};
	__property TCrGraphDVType DataValuesY2 = {read=FDataValuesY2, write=SetDataValuesY2, nodefault};
	__property TCrGraphDVType DataValuesZ = {read=FDataValuesZ, write=SetDataValuesZ, nodefault};
	__property double MinY = {read=FMinY, write=SetMinY};
	__property double MaxY = {read=FMaxY, write=SetMaxY};
	__property double MinY2 = {read=FMinY2, write=SetMinY2};
	__property double MaxY2 = {read=FMaxY2, write=SetMaxY2};
	__property double MinZ = {read=FMinZ, write=SetMinZ};
	__property double MaxZ = {read=FMaxZ, write=SetMaxZ};
	__property TCrGraphNumberFormat NumberFormatY = {read=FNumberFormatY, write=SetNumberFormatY, nodefault};
	__property TCrGraphNumberFormat NumberFormatY2 = {read=FNumberFormatY2, write=SetNumberFormatY2, nodefault};
	__property TCrGraphNumberFormat NumberFormatZ = {read=FNumberFormatZ, write=SetNumberFormatZ, nodefault};
	__property TCrGraphDVType DivisionTypeY = {read=FDivisionTypeY, write=SetDivisionTypeY, nodefault};
	__property TCrGraphDVType DivisionTypeY2 = {read=FDivisionTypeY2, write=SetDivisionTypeY2, nodefault};
	__property TCrGraphDVType DivisionTypeZ = {read=FDivisionTypeZ, write=SetDivisionTypeZ, nodefault};
	__property int DivisionsY = {read=FDivisionsY, write=SetDivisionsY, nodefault};
	__property int DivisionsY2 = {read=FDivisionsY2, write=SetDivisionsY2, nodefault};
	__property int DivisionsZ = {read=FDivisionsZ, write=SetDivisionsZ, nodefault};
	
public:
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	void __fastcall Clear(void);
	__fastcall TCrpeGraphAxis(void);
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpeGraphAxis(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

class DELPHICLASS TCrpeGraphOptionInfo;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeGraphOptionInfo : public TCrpePersistentX 
{
	typedef TCrpePersistentX inherited;
	
private:
	TCrGraphColor FColor;
	TCrGraphLegend FLegend;
	TCrGraphPieSize FPieSize;
	TCrGraphPieSlice FPieSlice;
	TCrGraphBarSize FBarSize;
	TCrGraphBarDirection FBarDirection;
	TCrGraphMarkerSize FMarkerSize;
	TCrGraphMarkerShape FMarkerShape;
	TCrGraphDataPoints FDataPoints;
	TCrGraphNumberFormat FNumberFormat;
	TCrGraphViewingAngle FViewingAngle;
	TCrGraphLegendLayout FLegendLayout;
	
protected:
	void __fastcall SetColor(const TCrGraphColor Value);
	void __fastcall SetLegend(const TCrGraphLegend Value);
	void __fastcall SetPieSize(const TCrGraphPieSize Value);
	void __fastcall SetPieSlice(const TCrGraphPieSlice Value);
	void __fastcall SetBarSize(const TCrGraphBarSize Value);
	void __fastcall SetBarDirection(const TCrGraphBarDirection Value);
	void __fastcall SetMarkerSize(const TCrGraphMarkerSize Value);
	void __fastcall SetMarkerShape(const TCrGraphMarkerShape Value);
	void __fastcall SetDataPoints(const TCrGraphDataPoints Value);
	void __fastcall SetNumberFormat(const TCrGraphNumberFormat Value);
	void __fastcall SetViewingAngle(const TCrGraphViewingAngle Value);
	void __fastcall SetLegendLayout(const TCrGraphLegendLayout Value);
	void __fastcall GetOptionInfo(void);
	
__published:
	__property TCrGraphColor Color = {read=FColor, write=SetColor, default=0};
	__property TCrGraphLegend Legend = {read=FLegend, write=SetLegend, default=4};
	__property TCrGraphPieSize PieSize = {read=FPieSize, write=SetPieSize, default=2};
	__property TCrGraphPieSlice PieSlice = {read=FPieSlice, write=SetPieSlice, default=0};
	__property TCrGraphBarSize BarSize = {read=FBarSize, write=SetBarSize, default=3};
	__property TCrGraphBarDirection BarDirection = {read=FBarDirection, write=SetBarDirection, default=1};
	__property TCrGraphMarkerSize MarkerSize = {read=FMarkerSize, write=SetMarkerSize, default=2};
	__property TCrGraphMarkerShape MarkerShape = {read=FMarkerShape, write=SetMarkerShape, default=0};
	__property TCrGraphDataPoints DataPoints = {read=FDataPoints, write=SetDataPoints, default=0};
	__property TCrGraphNumberFormat NumberFormat = {read=FNumberFormat, write=SetNumberFormat, default=0};
	__property TCrGraphViewingAngle ViewingAngle = {read=FViewingAngle, write=SetViewingAngle, default=0};
	__property TCrGraphLegendLayout LegendLayout = {read=FLegendLayout, write=SetLegendLayout, default=0};
	
public:
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	void __fastcall Clear(void);
	__fastcall TCrpeGraphOptionInfo(void);
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpeGraphOptionInfo(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

class DELPHICLASS TCrpeGraphText;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeGraphText : public TCrpePersistentX 
{
	typedef TCrpePersistentX inherited;
	
private:
	AnsiString FTitle;
	AnsiString FSubTitle;
	AnsiString FFootNote;
	AnsiString FGroupsTitle;
	AnsiString FSeriesTitle;
	AnsiString FXAxisTitle;
	AnsiString FYAxisTitle;
	AnsiString FZAxisTitle;
	Ucrpeclasses::TCrpeFont* FTitleFont;
	Ucrpeclasses::TCrpeFont* FSubTitleFont;
	Ucrpeclasses::TCrpeFont* FFootNoteFont;
	Ucrpeclasses::TCrpeFont* FGroupsTitleFont;
	Ucrpeclasses::TCrpeFont* FDataTitleFont;
	Ucrpeclasses::TCrpeFont* FLegendFont;
	Ucrpeclasses::TCrpeFont* FGroupLabelsFont;
	Ucrpeclasses::TCrpeFont* FDataLabelsFont;
	Ucrpeclasses::TCrpeFont* xFont;
	
protected:
	void __fastcall SetTitle(const AnsiString Value);
	void __fastcall SetSubTitle(const AnsiString Value);
	void __fastcall SetFootNote(const AnsiString Value);
	void __fastcall SetGroupsTitle(const AnsiString Value);
	void __fastcall SetSeriesTitle(const AnsiString Value);
	void __fastcall SetXAxisTitle(const AnsiString Value);
	void __fastcall SetYAxisTitle(const AnsiString Value);
	void __fastcall SetZAxisTitle(const AnsiString Value);
	void __fastcall SetTitleFont(const Ucrpeclasses::TCrpeFont* Value);
	void __fastcall SetSubTitleFont(const Ucrpeclasses::TCrpeFont* Value);
	void __fastcall SetFootNoteFont(const Ucrpeclasses::TCrpeFont* Value);
	void __fastcall SetGroupsTitleFont(const Ucrpeclasses::TCrpeFont* Value);
	void __fastcall SetDataTitleFont(const Ucrpeclasses::TCrpeFont* Value);
	void __fastcall SetLegendFont(const Ucrpeclasses::TCrpeFont* Value);
	void __fastcall SetGroupLabelsFont(const Ucrpeclasses::TCrpeFont* Value);
	void __fastcall SetDataLabelsFont(const Ucrpeclasses::TCrpeFont* Value);
	void __fastcall OnChangeTitleFont(System::TObject* Sender);
	void __fastcall OnChangeSubTitleFont(System::TObject* Sender);
	void __fastcall OnChangeFootNoteFont(System::TObject* Sender);
	void __fastcall OnChangeGroupsTitleFont(System::TObject* Sender);
	void __fastcall OnChangeDataTitleFont(System::TObject* Sender);
	void __fastcall OnChangeLegendFont(System::TObject* Sender);
	void __fastcall OnChangeGroupLabelsFont(System::TObject* Sender);
	void __fastcall OnChangeDataLabelsFont(System::TObject* Sender);
	void __fastcall GetText(void);
	bool __fastcall CompareFonts(const Crdynamic::PEFontColorInfo &RptFontInfo, Ucrpeclasses::TCrpeFont* &RptFont, Word FontArea);
	void __fastcall CopyFontInfo(Crdynamic::PEFontColorInfo &FontInfo, Ucrpeclasses::TCrpeFont* VCLFont);
	
__published:
	__property AnsiString Title = {read=FTitle, write=SetTitle};
	__property AnsiString SubTitle = {read=FSubTitle, write=SetSubTitle};
	__property AnsiString FootNote = {read=FFootNote, write=SetFootNote};
	__property AnsiString GroupsTitle = {read=FGroupsTitle, write=SetGroupsTitle};
	__property AnsiString SeriesTitle = {read=FSeriesTitle, write=SetSeriesTitle};
	__property AnsiString XAxisTitle = {read=FXAxisTitle, write=SetXAxisTitle};
	__property AnsiString YAxisTitle = {read=FYAxisTitle, write=SetYAxisTitle};
	__property AnsiString ZAxisTitle = {read=FZAxisTitle, write=SetZAxisTitle};
	__property Ucrpeclasses::TCrpeFont* TitleFont = {read=FTitleFont, write=SetTitleFont};
	__property Ucrpeclasses::TCrpeFont* SubTitleFont = {read=FSubTitleFont, write=SetSubTitleFont};
	__property Ucrpeclasses::TCrpeFont* FootNoteFont = {read=FFootNoteFont, write=SetFootNoteFont};
	__property Ucrpeclasses::TCrpeFont* GroupsTitleFont = {read=FGroupsTitleFont, write=SetGroupsTitleFont};
	__property Ucrpeclasses::TCrpeFont* DataTitleFont = {read=FDataTitleFont, write=SetDataTitleFont};
	__property Ucrpeclasses::TCrpeFont* LegendFont = {read=FLegendFont, write=SetLegendFont};
	__property Ucrpeclasses::TCrpeFont* GroupLabelsFont = {read=FGroupLabelsFont, write=SetGroupLabelsFont};
	__property Ucrpeclasses::TCrpeFont* DataLabelsFont = {read=FDataLabelsFont, write=SetDataLabelsFont};
	
public:
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	void __fastcall Clear(void);
	__fastcall TCrpeGraphText(void);
	__fastcall virtual ~TCrpeGraphText(void);
};

#pragma pack(pop)

#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeGraphsItem : public TCrpeObjectItemAX 
{
	typedef TCrpeObjectItemAX inherited;
	
private:
	short FSectionGraphNum;
	TCrGraphType FStyle;
	TCrpeGraphText* FText;
	TCrpeGraphOptionInfo* FOptionInfo;
	TCrpeGraphAxis* FAxis;
	
protected:
	void __fastcall SetStyle(const TCrGraphType Value);
	void __fastcall SetSectionGraphNum(const short Value);
	TCrGraphType __fastcall GetGraphType(short nGraphType, short nSubType);
	void __fastcall GetGraphTypeConst(TCrGraphType xGraphType, short &nGraphType, short &nSubType);
	
__published:
	__property TCrGraphType Style = {read=FStyle, write=SetStyle, nodefault};
	__property TCrpeGraphText* Text = {read=FText, write=FText};
	__property TCrpeGraphOptionInfo* OptionInfo = {read=FOptionInfo, write=FOptionInfo};
	__property TCrpeGraphAxis* Axis = {read=FAxis, write=FAxis};
	
public:
	__property short SectionGraphNum = {read=FSectionGraphNum, write=SetSectionGraphNum, nodefault};
	short __fastcall SectionAsCode(void);
	AnsiString __fastcall SectionType();
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	HIDESBASE void __fastcall Clear(void);
	__fastcall TCrpeGraphsItem(void);
	__fastcall virtual ~TCrpeGraphsItem(void);
};

#pragma pack(pop)

#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeGroupNameFieldsItem : public TCrpeFieldObjectItemX 
{
	typedef TCrpeFieldObjectItemX inherited;
	
public:
	HIDESBASE void __fastcall Clear(void);
	__fastcall TCrpeGroupNameFieldsItem(void);
public:
	#pragma option push -w-inl
	/* TCrpeFieldObjectItem.Destroy */ inline __fastcall virtual ~TCrpeGroupNameFieldsItem(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

class DELPHICLASS TCrpeMapSummaryFieldsItem;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeMapSummaryFieldsItem : public TCrpeItemX 
{
	typedef TCrpeItemX inherited;
	
private:
	AnsiString FFieldName;
	
protected:
	void __fastcall SetFieldName(const AnsiString Value);
	
__published:
	__property AnsiString FieldName = {read=FFieldName, write=SetFieldName};
	
public:
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	void __fastcall Clear(void);
	__fastcall TCrpeMapSummaryFieldsItem(void);
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpeMapSummaryFieldsItem(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

class DELPHICLASS TCrpeMapSummaryFields;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeMapSummaryFields : public TCrpeContainerX 
{
	typedef TCrpeContainerX inherited;
	
public:
	TCrpeMapSummaryFieldsItem* operator[](int nIndex) { return Items[nIndex]; }
	
private:
	TCrpeMapSummaryFieldsItem* FItem;
	
protected:
	void __fastcall SetIndex(int nIndex);
	TCrpeMapSummaryFieldsItem* __fastcall GetItem(int nIndex);
	
__published:
	__property int Number = {read=FIndex, write=SetIndex, default=-1};
	__property TCrpeMapSummaryFieldsItem* Item = {read=FItem, write=FItem};
	
public:
	__property int ItemIndex = {read=FIndex, write=SetIndex, nodefault};
	__property TCrpeMapSummaryFieldsItem* Items[int nIndex] = {read=GetItem/*, default*/};
	void __fastcall Clear(void);
	virtual int __fastcall Count(void);
	__fastcall TCrpeMapSummaryFields(void);
	__fastcall virtual ~TCrpeMapSummaryFields(void);
};

#pragma pack(pop)

class DELPHICLASS TCrpeMapConditionFieldsItem;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeMapConditionFieldsItem : public TCrpeItemX 
{
	typedef TCrpeItemX inherited;
	
private:
	AnsiString FFieldName;
	
protected:
	void __fastcall SetFieldName(const AnsiString Value);
	
__published:
	__property AnsiString FieldName = {read=FFieldName, write=SetFieldName};
	
public:
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	void __fastcall Clear(void);
	__fastcall TCrpeMapConditionFieldsItem(void);
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpeMapConditionFieldsItem(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

class DELPHICLASS TCrpeMapConditionFields;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeMapConditionFields : public TCrpeContainerX 
{
	typedef TCrpeContainerX inherited;
	
public:
	TCrpeMapConditionFieldsItem* operator[](int nIndex) { return Items[nIndex]; }
	
private:
	TCrpeMapConditionFieldsItem* FItem;
	
protected:
	void __fastcall SetIndex(int nIndex);
	TCrpeMapConditionFieldsItem* __fastcall GetItem(int nIndex);
	
__published:
	__property int Number = {read=FIndex, write=SetIndex, default=-1};
	__property TCrpeMapConditionFieldsItem* Item = {read=FItem, write=FItem};
	
public:
	__property int ItemIndex = {read=FIndex, write=SetIndex, nodefault};
	__property TCrpeMapConditionFieldsItem* Items[int nIndex] = {read=GetItem/*, default*/};
	void __fastcall Clear(void);
	virtual int __fastcall Count(void);
	__fastcall TCrpeMapConditionFields(void);
	__fastcall virtual ~TCrpeMapConditionFields(void);
};

#pragma pack(pop)

#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeMapsItem : public TCrpeObjectItemAX 
{
	typedef TCrpeObjectItemAX inherited;
	
private:
	TCrMapLayout FLayout;
	bool FDontSummarizeValues;
	TCrMapType FMapType;
	short FNumberOfIntervals;
	TCrMapDistributionMethod FDistributionMethod;
	Graphics::TColor FColorHighestInterval;
	Graphics::TColor FColorLowestInterval;
	bool FAllowEmptyIntervals;
	short FDotSize;
	short FPieSize;
	bool FPieProportional;
	short FBarSize;
	AnsiString FTitle;
	TCrMapLegend FLegend;
	TCrMapLegendTitle FLegendTitleType;
	AnsiString FLegendTitle;
	AnsiString FLegendSubTitle;
	TCrMapOrientation FOrientation;
	bool FGroupSelected;
	TCrpeMapSummaryFields* FSummaryFields;
	TCrpeMapConditionFields* FConditionFields;
	
protected:
	void __fastcall SetLayout(const TCrMapLayout Value);
	void __fastcall SetDontSummarizeValues(const bool Value);
	void __fastcall SetMapType(const TCrMapType Value);
	void __fastcall SetNumberOfIntervals(const short Value);
	void __fastcall SetDotSize(const short Value);
	void __fastcall SetPieSize(const short Value);
	void __fastcall SetBarSize(const short Value);
	void __fastcall SetAllowEmptyIntervals(const bool Value);
	void __fastcall SetPieProportional(const bool Value);
	void __fastcall SetDistributionMethod(const TCrMapDistributionMethod Value);
	void __fastcall SetColorLowestInterval(const Graphics::TColor Value);
	void __fastcall SetColorHighestInterval(const Graphics::TColor Value);
	void __fastcall SetLegend(const TCrMapLegend Value);
	void __fastcall SetLegendTitleType(const TCrMapLegendTitle Value);
	void __fastcall SetTitle(const AnsiString Value);
	void __fastcall SetLegendTitle(const AnsiString Value);
	void __fastcall SetLegendSubTitle(const AnsiString Value);
	void __fastcall SetOrientation(const TCrMapOrientation Value);
	void __fastcall SetGroupSelected(const bool Value);
	
__published:
	__property TCrMapLayout Layout = {read=FLayout, write=SetLayout, default=1};
	__property bool DontSummarizeValues = {read=FDontSummarizeValues, write=SetDontSummarizeValues, default=0};
	__property TCrMapType MapType = {read=FMapType, write=SetMapType, default=0};
	__property short NumberOfIntervals = {read=FNumberOfIntervals, write=SetNumberOfIntervals, default=5};
	__property short DotSize = {read=FDotSize, write=SetDotSize, default=0};
	__property short PieSize = {read=FPieSize, write=SetPieSize, default=0};
	__property short BarSize = {read=FBarSize, write=SetBarSize, default=0};
	__property bool AllowEmptyIntervals = {read=FAllowEmptyIntervals, write=SetAllowEmptyIntervals, default=1};
	__property bool PieProportional = {read=FPieProportional, write=SetPieProportional, default=1};
	__property TCrMapDistributionMethod DistributionMethod = {read=FDistributionMethod, write=SetDistributionMethod, default=0};
	__property Graphics::TColor ColorLowestInterval = {read=FColorLowestInterval, write=SetColorLowestInterval, default=0};
	__property Graphics::TColor ColorHighestInterval = {read=FColorHighestInterval, write=SetColorHighestInterval, default=16777215};
	__property TCrMapLegend Legend = {read=FLegend, write=SetLegend, default=0};
	__property TCrMapLegendTitle LegendTitleType = {read=FLegendTitleType, write=SetLegendTitleType, default=0};
	__property AnsiString Title = {read=FTitle, write=SetTitle};
	__property AnsiString LegendTitle = {read=FLegendTitle, write=SetLegendTitle};
	__property AnsiString LegendSubTitle = {read=FLegendSubTitle, write=SetLegendSubTitle};
	__property TCrMapOrientation Orientation = {read=FOrientation, write=SetOrientation, default=0};
	__property bool GroupSelected = {read=FGroupSelected, write=SetGroupSelected, default=1};
	__property TCrpeMapSummaryFields* SummaryFields = {read=FSummaryFields, write=FSummaryFields};
	__property TCrpeMapConditionFields* ConditionFields = {read=FConditionFields, write=FConditionFields};
	
public:
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	HIDESBASE void __fastcall Clear(void);
	__fastcall TCrpeMapsItem(void);
	__fastcall virtual ~TCrpeMapsItem(void);
};

#pragma pack(pop)

#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeOLAPCubesItem : public TCrpeObjectItemAX 
{
	typedef TCrpeObjectItemAX inherited;
	
private:
	AnsiString FServerName;
	AnsiString FUserID;
	AnsiString FPassword;
	AnsiString FDatabaseName;
	AnsiString FConnectionString;
	AnsiString FCubeName;
	
protected:
	void __fastcall SetServerName(const AnsiString Value);
	void __fastcall SetDatabaseName(const AnsiString Value);
	void __fastcall SetConnectionString(const AnsiString Value);
	void __fastcall SetCubeName(const AnsiString Value);
	void __fastcall SetUserID(const AnsiString Value);
	void __fastcall SetPassword(const AnsiString Value);
	
__published:
	__property AnsiString ServerName = {read=FServerName, write=SetServerName};
	__property AnsiString DatabaseName = {read=FDatabaseName, write=SetDatabaseName};
	__property AnsiString ConnectionString = {read=FConnectionString, write=SetConnectionString};
	__property AnsiString CubeName = {read=FCubeName, write=SetCubeName};
	__property AnsiString UserID = {read=FUserID, write=SetUserID};
	__property AnsiString Password = {read=FPassword, write=SetPassword};
	
public:
	HIDESBASE void __fastcall Clear(void);
	bool __fastcall Test(void);
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	__fastcall TCrpeOLAPCubesItem(void);
public:
	#pragma option push -w-inl
	/* TCrpeObjectItemA.Destroy */ inline __fastcall virtual ~TCrpeOLAPCubesItem(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeOleObjectsItem : public TCrpeObjectItemAX 
{
	typedef TCrpeObjectItemAX inherited;
	
private:
	TCrOleObjectType FOleType;
	TCrOleUpdateType FUpdateType;
	AnsiString FLinkSource;
	
protected:
	void __fastcall SetOleType(const TCrOleObjectType Value);
	void __fastcall SetUpdateType(const TCrOleUpdateType Value);
	void __fastcall SetLinkSource(const AnsiString Value);
	
__published:
	__property TCrOleObjectType OleType = {read=FOleType, write=SetOleType, default=2};
	__property TCrOleUpdateType UpdateType = {read=FUpdateType, write=SetUpdateType, default=0};
	__property AnsiString LinkSource = {read=FLinkSource, write=SetLinkSource};
	
public:
	HIDESBASE void __fastcall Clear(void);
	__fastcall TCrpeOleObjectsItem(void);
public:
	#pragma option push -w-inl
	/* TCrpeObjectItemA.Destroy */ inline __fastcall virtual ~TCrpeOleObjectsItem(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

class DELPHICLASS TCrpeParamFieldInfo;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeParamFieldInfo : public TCrpePersistentX 
{
	typedef TCrpePersistentX inherited;
	
private:
	bool FAllowNull;
	bool FAllowEditing;
	bool FAllowMultipleValues;
	bool FPartOfGroup;
	bool FMutuallyExclusiveGroup;
	TCrParamInfoValueType FValueType;
	short FGroupNum;
	
protected:
	void __fastcall SetAllowNull(const bool Value);
	void __fastcall SetAllowEditing(const bool Value);
	void __fastcall SetAllowMultipleValues(const bool Value);
	void __fastcall SetValueType(const TCrParamInfoValueType Value);
	void __fastcall SetPartOfGroup(const bool Value);
	void __fastcall SetMutuallyExclusiveGroup(const bool Value);
	void __fastcall SetGroupNum(const short Value);
	
__published:
	__property bool AllowNull = {read=FAllowNull, write=SetAllowNull, nodefault};
	__property bool AllowEditing = {read=FAllowEditing, write=SetAllowEditing, nodefault};
	__property bool AllowMultipleValues = {read=FAllowMultipleValues, write=SetAllowMultipleValues, nodefault};
	__property TCrParamInfoValueType ValueType = {read=FValueType, write=SetValueType, nodefault};
	__property bool PartOfGroup = {read=FPartOfGroup, write=SetPartOfGroup, nodefault};
	__property bool MutuallyExclusiveGroup = {read=FMutuallyExclusiveGroup, write=SetMutuallyExclusiveGroup, nodefault};
	__property short GroupNum = {read=FGroupNum, write=SetGroupNum, nodefault};
	
public:
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	void __fastcall Clear(void);
	__fastcall TCrpeParamFieldInfo(void);
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpeParamFieldInfo(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

class DELPHICLASS TCrpeParamFieldRangesItem;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeParamFieldRangesItem : public TCrpeItemX 
{
	typedef TCrpeItemX inherited;
	
private:
	AnsiString FRangeStart;
	AnsiString FRangeEnd;
	TCrRangeBounds FBounds;
	
protected:
	void __fastcall SetRangeStart(const AnsiString Value);
	void __fastcall SetRangeEnd(const AnsiString Value);
	void __fastcall SetBounds(const TCrRangeBounds Value);
	
__published:
	__property AnsiString RangeStart = {read=FRangeStart, write=SetRangeStart};
	__property AnsiString RangeEnd = {read=FRangeEnd, write=SetRangeEnd};
	__property TCrRangeBounds Bounds = {read=FBounds, write=SetBounds, nodefault};
	
public:
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	void __fastcall Clear(void);
	bool __fastcall Send(void);
	__fastcall TCrpeParamFieldRangesItem(void);
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpeParamFieldRangesItem(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

class DELPHICLASS TCrpeParamFieldRanges;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeParamFieldRanges : public TCrpeContainerX 
{
	typedef TCrpeContainerX inherited;
	
public:
	TCrpeParamFieldRangesItem* operator[](int nIndex) { return Items[nIndex]; }
	
private:
	TCrpeParamFieldRangesItem* FItem;
	
protected:
	void __fastcall SetIndex(int nIndex);
	TCrpeParamFieldRangesItem* __fastcall GetItem(int nIndex);
	
__published:
	__property int Number = {read=FIndex, write=SetIndex, default=-1};
	__property TCrpeParamFieldRangesItem* Item = {read=FItem, write=FItem};
	
public:
	__property int ItemIndex = {read=FIndex, write=SetIndex, nodefault};
	__property TCrpeParamFieldRangesItem* Items[int nIndex] = {read=GetItem/*, default*/};
	virtual int __fastcall Count(void);
	int __fastcall Add(void);
	void __fastcall Delete(int nIndex);
	void __fastcall Clear(void);
	__fastcall TCrpeParamFieldRanges(void);
	__fastcall virtual ~TCrpeParamFieldRanges(void);
};

#pragma pack(pop)

class DELPHICLASS TCrpeParamFieldPromptValuesItem;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeParamFieldPromptValuesItem : public TCrpeItemX 
{
	typedef TCrpeItemX inherited;
	
private:
	AnsiString FText;
	AnsiString FDescription;
	
protected:
	void __fastcall SetText(const AnsiString Value);
	void __fastcall SetDescription(const AnsiString Value);
	
__published:
	__property AnsiString Text = {read=FText, write=SetText};
	__property AnsiString Description = {read=FDescription, write=SetDescription};
	
public:
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	void __fastcall Clear(void);
	__fastcall TCrpeParamFieldPromptValuesItem(void);
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpeParamFieldPromptValuesItem(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

class DELPHICLASS TCrpeParamFieldPromptValues;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeParamFieldPromptValues : public TCrpeContainerX 
{
	typedef TCrpeContainerX inherited;
	
public:
	TCrpeParamFieldPromptValuesItem* operator[](int nIndex) { return Items[nIndex]; }
	
private:
	bool FDescriptionOnly;
	TCrPickListSortMethod FSortMethod;
	bool FSortByDescription;
	TCrpeParamFieldPromptValuesItem* FItem;
	
protected:
	void __fastcall SetDescriptionOnly(const bool Value);
	void __fastcall SetSortMethod(const TCrPickListSortMethod Value);
	void __fastcall SetSortByDescription(const bool Value);
	void __fastcall SetIndex(int nIndex);
	TCrpeParamFieldPromptValuesItem* __fastcall GetItem(int nIndex);
	
__published:
	__property int Number = {read=FIndex, write=SetIndex, default=-1};
	__property bool DescriptionOnly = {read=FDescriptionOnly, write=SetDescriptionOnly, default=0};
	__property TCrPickListSortMethod SortMethod = {read=FSortMethod, write=SetSortMethod, default=0};
	__property bool SortByDescription = {read=FSortByDescription, write=SetSortByDescription, default=0};
	__property TCrpeParamFieldPromptValuesItem* Item = {read=FItem, write=FItem};
	
public:
	__property int ItemIndex = {read=FIndex, write=SetIndex, nodefault};
	__property TCrpeParamFieldPromptValuesItem* Items[int nIndex] = {read=GetItem/*, default*/};
	virtual int __fastcall Count(void);
	int __fastcall Add(const AnsiString Value);
	void __fastcall Delete(int nIndex);
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	void __fastcall Clear(void);
	__fastcall TCrpeParamFieldPromptValues(void);
	__fastcall virtual ~TCrpeParamFieldPromptValues(void);
};

#pragma pack(pop)

class DELPHICLASS TCrpeParamFieldCurrentValuesItem;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeParamFieldCurrentValuesItem : public TCrpeItemX 
{
	typedef TCrpeItemX inherited;
	
private:
	AnsiString FText;
	
protected:
	void __fastcall SetText(const AnsiString Value);
	
__published:
	__property AnsiString Text = {read=FText, write=SetText};
	
public:
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	void __fastcall Clear(void);
	__fastcall TCrpeParamFieldCurrentValuesItem(void);
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpeParamFieldCurrentValuesItem(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

class DELPHICLASS TCrpeParamFieldCurrentValues;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeParamFieldCurrentValues : public TCrpeContainerX 
{
	typedef TCrpeContainerX inherited;
	
public:
	TCrpeParamFieldCurrentValuesItem* operator[](int nIndex) { return Items[nIndex]; }
	
private:
	TCrpeParamFieldCurrentValuesItem* FItem;
	
protected:
	void __fastcall SetIndex(int nIndex);
	TCrpeParamFieldCurrentValuesItem* __fastcall GetItem(int nIndex);
	
__published:
	__property int Number = {read=FIndex, write=SetIndex, default=-1};
	__property TCrpeParamFieldCurrentValuesItem* Item = {read=FItem, write=FItem};
	
public:
	__property int ItemIndex = {read=FIndex, write=SetIndex, nodefault};
	__property TCrpeParamFieldCurrentValuesItem* Items[int nIndex] = {read=GetItem/*, default*/};
	virtual int __fastcall Count(void);
	int __fastcall Add(const AnsiString Value);
	void __fastcall Delete(int nIndex);
	void __fastcall Clear(void);
	__fastcall TCrpeParamFieldCurrentValues(void);
	__fastcall virtual ~TCrpeParamFieldCurrentValues(void);
};

#pragma pack(pop)

#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeParamFieldsItem : public TCrpeFieldObjectItemX 
{
	typedef TCrpeFieldObjectItemX inherited;
	
private:
	AnsiString FName;
	AnsiString FPrompt;
	AnsiString FPromptValue;
	AnsiString FCurrentValue;
	bool FShowDialog;
	TCrParamFieldType FParamType;
	AnsiString FReportName;
	bool FNeedsCurrentValue;
	TCrpeParamFieldRanges* FRanges;
	TCrpeParamFieldInfo* FInfo;
	TCrpeParamFieldPromptValues* FPromptValues;
	TCrpeParamFieldCurrentValues* FCurrentValues;
	TCrParamFieldSource FParamSource;
	bool FValueLimit;
	AnsiString FValueMin;
	AnsiString FValueMax;
	AnsiString FEditMask;
	AnsiString FBrowseField;
	bool FIsLinked;
	
protected:
	void __fastcall SetName(const AnsiString Value);
	void __fastcall SetPrompt(const AnsiString Value);
	void __fastcall SetPromptValue(const AnsiString Value);
	void __fastcall SetCurrentValue(const AnsiString Value);
	void __fastcall SetShowDialog(const bool Value);
	void __fastcall SetParamType(const TCrParamFieldType Value);
	void __fastcall SetReportName(const AnsiString Value);
	void __fastcall SetNeedsCurrentValue(const bool Value);
	void __fastcall SetIsLinked(const bool Value);
	void __fastcall SetParamSource(const TCrParamFieldSource Value);
	void __fastcall SetValueLimit(const bool Value);
	void __fastcall SetValueMin(const AnsiString Value);
	void __fastcall SetValueMax(const AnsiString Value);
	void __fastcall SetEditMask(const AnsiString Value);
	void __fastcall SetBrowseField(const AnsiString Value);
	
__published:
	__property AnsiString Name = {read=FName, write=SetName};
	__property AnsiString Prompt = {read=FPrompt, write=SetPrompt};
	__property AnsiString PromptValue = {read=FPromptValue, write=SetPromptValue};
	__property AnsiString CurrentValue = {read=FCurrentValue, write=SetCurrentValue};
	__property bool ShowDialog = {read=FShowDialog, write=SetShowDialog, default=0};
	__property TCrParamFieldType ParamType = {read=FParamType, write=SetParamType, nodefault};
	__property TCrParamFieldSource ParamSource = {read=FParamSource, write=SetParamSource, nodefault};
	__property AnsiString EditMask = {read=FEditMask, write=SetEditMask};
	__property TCrpeParamFieldInfo* Info = {read=FInfo, write=FInfo};
	__property TCrpeParamFieldPromptValues* PromptValues = {read=FPromptValues, write=FPromptValues};
	__property TCrpeParamFieldCurrentValues* CurrentValues = {read=FCurrentValues, write=FCurrentValues};
	__property bool ValueLimit = {read=FValueLimit, write=SetValueLimit, nodefault};
	__property AnsiString ValueMin = {read=FValueMin, write=SetValueMin};
	__property AnsiString ValueMax = {read=FValueMax, write=SetValueMax};
	__property TCrpeParamFieldRanges* Ranges = {read=FRanges, write=FRanges};
	__property AnsiString BrowseField = {read=FBrowseField, write=SetBrowseField};
	__property AnsiString ReportName = {read=FReportName, write=SetReportName};
	__property bool NeedsCurrentValue = {read=FNeedsCurrentValue, write=SetNeedsCurrentValue, nodefault};
	__property bool IsLinked = {read=FIsLinked, write=SetIsLinked, nodefault};
	
public:
	AnsiString __fastcall ParamTypeAsString();
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	HIDESBASE void __fastcall Clear(void);
	__fastcall TCrpeParamFieldsItem(void);
	__fastcall virtual ~TCrpeParamFieldsItem(void);
};

#pragma pack(pop)

#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpePicturesItem : public TCrpeObjectItemAX 
{
	typedef TCrpeObjectItemAX inherited;
	
private:
	int FCropLeft;
	int FCropRight;
	int FCropTop;
	int FCropBottom;
	double FScalingWidth;
	double FScalingHeight;
	bool FCanGrow;
	
protected:
	void __fastcall SetCropLeft(const int Value);
	void __fastcall SetCropRight(const int Value);
	void __fastcall SetCropTop(const int Value);
	void __fastcall SetCropBottom(const int Value);
	void __fastcall SetScalingWidth(const double Value);
	void __fastcall SetScalingHeight(const double Value);
	bool __fastcall GetCanGrow(void);
	void __fastcall SetCanGrow(const bool Value);
	
__published:
	__property int CropLeft = {read=FCropLeft, write=SetCropLeft, nodefault};
	__property int CropRight = {read=FCropRight, write=SetCropRight, nodefault};
	__property int CropTop = {read=FCropTop, write=SetCropTop, nodefault};
	__property int CropBottom = {read=FCropBottom, write=SetCropBottom, nodefault};
	__property double ScalingWidth = {read=FScalingWidth, write=SetScalingWidth};
	__property double ScalingHeight = {read=FScalingHeight, write=SetScalingHeight};
	__property bool CanGrow = {read=GetCanGrow, write=SetCanGrow, default=0};
	
public:
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	HIDESBASE void __fastcall Clear(void);
	__fastcall TCrpePicturesItem(void);
public:
	#pragma option push -w-inl
	/* TCrpeObjectItemA.Destroy */ inline __fastcall virtual ~TCrpePicturesItem(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeRunningTotalsItem : public TCrpeFieldObjectItemX 
{
	typedef TCrpeFieldObjectItemX inherited;
	
private:
	AnsiString FName;
	AnsiString FSummaryField;
	TCrSummaryType FSummaryType;
	short FSummaryTypeN;
	AnsiString FSummaryTypeField;
	TCrRunningTotalCondition FEvalCondition;
	AnsiString FEvalField;
	short FEvalGroupN;
	Classes::TStrings* FEvalFormula;
	AnsiString FResetField;
	Classes::TStrings* FResetFormula;
	TCrRunningTotalCondition FResetCondition;
	short FResetGroupN;
	Classes::TStrings* xEvalFormula;
	Classes::TStrings* xResetFormula;
	
protected:
	void __fastcall SetName(const AnsiString Value);
	void __fastcall SetSummaryField(const AnsiString Value);
	void __fastcall SetSummaryType(const TCrSummaryType Value);
	void __fastcall SetSummaryTypeN(const short Value);
	void __fastcall SetSummaryTypeField(const AnsiString Value);
	void __fastcall SetEvalField(const AnsiString Value);
	void __fastcall SetEvalFormula(const Classes::TStrings* Value);
	void __fastcall OnChangeEvalFormula(System::TObject* Sender);
	void __fastcall SetEvalCondition(const TCrRunningTotalCondition Value);
	void __fastcall SetEvalGroupN(const short Value);
	void __fastcall SetResetField(const AnsiString Value);
	void __fastcall SetResetFormula(const Classes::TStrings* Value);
	void __fastcall OnChangeResetFormula(System::TObject* Sender);
	void __fastcall SetResetCondition(const TCrRunningTotalCondition Value);
	void __fastcall SetResetGroupN(const short Value);
	
__published:
	__property AnsiString Name = {read=FName, write=SetName};
	__property AnsiString SummaryField = {read=FSummaryField, write=SetSummaryField};
	__property TCrSummaryType SummaryType = {read=FSummaryType, write=SetSummaryType, default=6};
	__property short SummaryTypeN = {read=FSummaryTypeN, write=SetSummaryTypeN, default=-1};
	__property AnsiString SummaryTypeField = {read=FSummaryTypeField, write=SetSummaryTypeField};
	__property AnsiString EvalField = {read=FEvalField, write=SetEvalField};
	__property Classes::TStrings* EvalFormula = {read=FEvalFormula, write=SetEvalFormula};
	__property TCrRunningTotalCondition EvalCondition = {read=FEvalCondition, write=SetEvalCondition, default=0};
	__property short EvalGroupN = {read=FEvalGroupN, write=SetEvalGroupN, default=-1};
	__property AnsiString ResetField = {read=FResetField, write=SetResetField};
	__property Classes::TStrings* ResetFormula = {read=FResetFormula, write=SetResetFormula};
	__property TCrRunningTotalCondition ResetCondition = {read=FResetCondition, write=SetResetCondition, default=0};
	__property short ResetGroupN = {read=FResetGroupN, write=SetResetGroupN, default=-1};
	
public:
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	HIDESBASE void __fastcall Clear(void);
	__fastcall TCrpeRunningTotalsItem(void);
	__fastcall virtual ~TCrpeRunningTotalsItem(void);
};

#pragma pack(pop)

#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeSpecialFieldsItem : public TCrpeFieldObjectItemX 
{
	typedef TCrpeFieldObjectItemX inherited;
	
public:
	virtual void __fastcall Assign(Classes::TPersistent* Source);
public:
	#pragma option push -w-inl
	/* TCrpeFieldObjectItem.Create */ inline __fastcall TCrpeSpecialFieldsItem(void) : TCrpeFieldObjectItemX() { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCrpeFieldObjectItem.Destroy */ inline __fastcall virtual ~TCrpeSpecialFieldsItem(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeSQLExpressionsItem : public TCrpeFieldObjectItemX 
{
	typedef TCrpeFieldObjectItemX inherited;
	
private:
	AnsiString FName;
	Classes::TStrings* FExpression;
	Classes::TStrings* xExpression;
	
protected:
	void __fastcall SetName(const AnsiString Value);
	void __fastcall SetExpression(Classes::TStrings* ListVar);
	void __fastcall OnChangeStrings(System::TObject* Sender);
	
__published:
	__property AnsiString Name = {read=FName, write=SetName};
	__property Classes::TStrings* Expression = {read=FExpression, write=SetExpression};
	
public:
	bool __fastcall Check(void);
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	HIDESBASE void __fastcall Clear(void);
	__fastcall TCrpeSQLExpressionsItem(void);
	__fastcall virtual ~TCrpeSQLExpressionsItem(void);
};

#pragma pack(pop)

class DELPHICLASS TCrpeSubreportLinksItem;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeSubreportLinksItem : public TCrpeItemX 
{
	typedef TCrpeItemX inherited;
	
private:
	AnsiString FMainReportFieldName;
	AnsiString FSubreportFieldName;
	AnsiString FParamFieldName;
	
protected:
	void __fastcall SetMainReportFieldName(const AnsiString Value);
	void __fastcall SetSubreportFieldName(const AnsiString Value);
	void __fastcall SetParamFieldName(const AnsiString Value);
	
__published:
	__property AnsiString MainReportFieldName = {read=FMainReportFieldName, write=SetMainReportFieldName};
	__property AnsiString SubreportFieldName = {read=FSubreportFieldName, write=SetSubreportFieldName};
	__property AnsiString ParamFieldName = {read=FParamFieldName, write=SetParamFieldName};
	
public:
	void __fastcall Clear(void);
	bool __fastcall StatusIsGo(void);
	__fastcall TCrpeSubreportLinksItem(void);
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpeSubreportLinksItem(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

class DELPHICLASS TCrpeSubreportLinks;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeSubreportLinks : public TCrpeContainerX 
{
	typedef TCrpeContainerX inherited;
	
public:
	TCrpeSubreportLinksItem* operator[](int nIndex) { return Items[nIndex]; }
	
private:
	TCrpeSubreportLinksItem* FItem;
	
protected:
	void __fastcall SetIndex(int nIndex);
	bool __fastcall StatusIsGo(void);
	TCrpeSubreportLinksItem* __fastcall GetItem(int nIndex);
	
__published:
	__property int Number = {read=FIndex, write=SetIndex, default=-1};
	__property TCrpeSubreportLinksItem* Item = {read=FItem, write=FItem};
	
public:
	__property int ItemIndex = {read=FIndex, write=SetIndex, nodefault};
	__property TCrpeSubreportLinksItem* Items[int nIndex] = {read=GetItem/*, default*/};
	virtual int __fastcall Count(void);
	void __fastcall Clear(void);
	__fastcall TCrpeSubreportLinks(void);
	__fastcall virtual ~TCrpeSubreportLinks(void);
};

#pragma pack(pop)

#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeSubreportsItem : public TCrpeObjectItemAX 
{
	typedef TCrpeObjectItemAX inherited;
	
private:
	AnsiString FName;
	short FNLinks;
	bool FOnDemand;
	AnsiString FOnDemandCaption;
	AnsiString FPreviewTabCaption;
	bool FIsExternal;
	bool FReImportWhenOpening;
	TCrpeSubreportLinks* FLinks;
	
protected:
	void __fastcall SetName(const AnsiString Value);
	void __fastcall SetNLinks(const short Value);
	void __fastcall SetOnDemand(const bool Value);
	void __fastcall SetOnDemandCaption(const AnsiString Value);
	void __fastcall SetPreviewTabCaption(const AnsiString Value);
	void __fastcall SetIsExternal(const bool Value);
	void __fastcall SetReImportWhenOpening(const bool Value);
	short __fastcall GetDetailCopies(void);
	void __fastcall SetDetailCopies(const short Value);
	AnsiString __fastcall GetReportTitle();
	void __fastcall SetReportTitle(const AnsiString Value);
	
__published:
	__property AnsiString Name = {read=FName, write=SetName};
	__property short NLinks = {read=FNLinks, write=SetNLinks, nodefault};
	__property bool OnDemand = {read=FOnDemand, write=SetOnDemand, default=0};
	__property AnsiString OnDemandCaption = {read=FOnDemandCaption, write=SetOnDemandCaption};
	__property AnsiString PreviewTabCaption = {read=FPreviewTabCaption, write=SetPreviewTabCaption};
	__property bool IsExternal = {read=FIsExternal, write=SetIsExternal, default=0};
	__property bool ReImportWhenOpening = {read=FReImportWhenOpening, write=SetReImportWhenOpening, default=1};
	__property TCrpeSubreportLinks* Links = {read=FLinks, write=FLinks};
	
public:
	__property AnsiString ReportTitle = {read=GetReportTitle, write=SetReportTitle};
	__property short DetailCopies = {read=GetDetailCopies, write=SetDetailCopies, nodefault};
	short __fastcall PrintJob(void);
	TCrpeReportOptions* __fastcall ReportOptions(void);
	TCrpeGlobalOptions* __fastcall GlobalOptions(void);
	TCrpeMargins* __fastcall Margins(void);
	TCrpeConnect* __fastcall Connect(void);
	TCrpeLogOnInfo* __fastcall LogOnInfo(void);
	TCrpeSectionFont* __fastcall SectionFont(void);
	TCrpeSectionFormat* __fastcall SectionFormat(void);
	TCrpeAreaFormat* __fastcall AreaFormat(void);
	TCrpeSectionSize* __fastcall SectionSize(void);
	TCrpeSelection* __fastcall Selection(void);
	TCrpeGroupSelection* __fastcall GroupSelection(void);
	TCrpeSortFields* __fastcall SortFields(void);
	TCrpeGroupSortFields* __fastcall GroupSortFields(void);
	TCrpeGroups* __fastcall Groups(void);
	TCrpeSQL* __fastcall SQL(void);
	TCrpeSQLExpressions* __fastcall SQLExpressions(void);
	TCrpeFormulas* __fastcall Formulas(void);
	TCrpeParamFields* __fastcall ParamFields(void);
	TCrpeTables* __fastcall Tables(void);
	TCrpeSessionInfo* __fastcall SessionInfo(void);
	TCrpeGraphs* __fastcall Graphs(void);
	TCrpeLines* __fastcall Lines(void);
	TCrpeBoxes* __fastcall Boxes(void);
	TCrpeTextObjects* __fastcall TextObjects(void);
	TCrpeOleObjects* __fastcall OleObjects(void);
	TCrpeCrossTabs* __fastcall CrossTabs(void);
	TCrpeMaps* __fastcall Maps(void);
	TCrpeOLAPCubes* __fastcall OLAPCubes(void);
	TCrpePictures* __fastcall Pictures(void);
	TCrpeDatabaseFields* __fastcall DatabaseFields(void);
	TCrpeSummaryFields* __fastcall SummaryFields(void);
	TCrpeSpecialFields* __fastcall SpecialFields(void);
	TCrpeGroupNameFields* __fastcall GroupNameFields(void);
	TCrpeRunningTotals* __fastcall RunningTotals(void);
	HIDESBASE void __fastcall Clear(void);
	void __fastcall ReImport(void);
	__fastcall TCrpeSubreportsItem(void);
	__fastcall virtual ~TCrpeSubreportsItem(void);
};

#pragma pack(pop)

#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeSummaryFieldsItem : public TCrpeFieldObjectItemX 
{
	typedef TCrpeFieldObjectItemX inherited;
	
private:
	AnsiString FName;
	AnsiString FSummarizedField;
	TCrSummaryType FSummaryType;
	short FSummaryTypeN;
	AnsiString FSummaryTypeField;
	AnsiString FHeaderAreaCode;
	AnsiString FFooterAreaCode;
	
protected:
	void __fastcall SetName(const AnsiString Value);
	void __fastcall SetSummarizedField(const AnsiString Value);
	void __fastcall SetSummaryType(const TCrSummaryType Value);
	void __fastcall SetSummaryTypeN(const short Value);
	void __fastcall SetSummaryTypeField(const AnsiString Value);
	void __fastcall SetHeaderAreaCode(const AnsiString Value);
	void __fastcall SetFooterAreaCode(const AnsiString Value);
	
__published:
	__property AnsiString Name = {read=FName, write=SetName};
	__property AnsiString SummarizedField = {read=FSummarizedField, write=SetSummarizedField};
	__property TCrSummaryType SummaryType = {read=FSummaryType, write=SetSummaryType, default=6};
	__property short SummaryTypeN = {read=FSummaryTypeN, write=SetSummaryTypeN, default=-1};
	__property AnsiString SummaryTypeField = {read=FSummaryTypeField, write=SetSummaryTypeField};
	__property AnsiString HeaderAreaCode = {read=FHeaderAreaCode, write=SetHeaderAreaCode};
	__property AnsiString FooterAreaCode = {read=FFooterAreaCode, write=SetFooterAreaCode};
	
public:
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	HIDESBASE void __fastcall Clear(void);
	void __fastcall ChangeType(TCrSummaryType SumType);
	__fastcall TCrpeSummaryFieldsItem(void);
public:
	#pragma option push -w-inl
	/* TCrpeFieldObjectItem.Destroy */ inline __fastcall virtual ~TCrpeSummaryFieldsItem(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

class DELPHICLASS TCrpeTabStopsItem;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeTabStopsItem : public TCrpeItemX 
{
	typedef TCrpeItemX inherited;
	
private:
	Ucrpeclasses::TCrHorizontalAlignment FAlignment;
	int FOffset;
	
protected:
	bool __fastcall StatusIsGo(void);
	void __fastcall SetAlignment(const Ucrpeclasses::TCrHorizontalAlignment Value);
	void __fastcall SetOffset(const int Value);
	
__published:
	__property Ucrpeclasses::TCrHorizontalAlignment Alignment = {read=FAlignment, write=SetAlignment, nodefault};
	__property int Offset = {read=FOffset, write=SetOffset, nodefault};
	
public:
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	void __fastcall Clear(void);
	__fastcall TCrpeTabStopsItem(void);
public:
	#pragma option push -w-inl
	/* TCrpePersistent.Destroy */ inline __fastcall virtual ~TCrpeTabStopsItem(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

class DELPHICLASS TCrpeTabStops;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeTabStops : public TCrpeContainerX 
{
	typedef TCrpeContainerX inherited;
	
public:
	TCrpeTabStopsItem* operator[](int nIndex) { return Items[nIndex]; }
	
private:
	TCrpeTabStopsItem* FItem;
	
protected:
	void __fastcall SetIndex(int nIndex);
	TCrpeTabStopsItem* __fastcall GetItem(int nIndex);
	
__published:
	__property int Number = {read=FIndex, write=SetIndex, default=-1};
	__property TCrpeTabStopsItem* Item = {read=FItem, write=FItem};
	
public:
	__property int ItemIndex = {read=FIndex, write=SetIndex, nodefault};
	__property TCrpeTabStopsItem* Items[int nIndex] = {read=GetItem/*, default*/};
	virtual int __fastcall Count(void);
	int __fastcall Add(Ucrpeclasses::TCrHorizontalAlignment Alignment, int Offset);
	void __fastcall Delete(int nTab);
	void __fastcall Clear(void);
	__fastcall TCrpeTabStops(void);
	__fastcall virtual ~TCrpeTabStops(void);
};

#pragma pack(pop)

class DELPHICLASS TCrpeParagraphsItem;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeParagraphsItem : public TCrpeItemX 
{
	typedef TCrpeItemX inherited;
	
private:
	Ucrpeclasses::TCrHorizontalAlignment FAlignment;
	int FIndentFirstLine;
	int FIndentLeft;
	int FIndentRight;
	int FTextStart;
	int FTextEnd;
	TCrpeTabStops* FTabStops;
	
__published:
	void __fastcall SetAlignment(const Ucrpeclasses::TCrHorizontalAlignment Value);
	void __fastcall SetIndentFirstLine(const int Value);
	void __fastcall SetIndentLeft(const int Value);
	void __fastcall SetIndentRight(const int Value);
	void __fastcall SetTextStart(const int Value);
	void __fastcall SetTextEnd(const int Value);
	__property Ucrpeclasses::TCrHorizontalAlignment Alignment = {read=FAlignment, write=SetAlignment, nodefault};
	__property int IndentFirstLine = {read=FIndentFirstLine, write=SetIndentFirstLine, nodefault};
	__property int IndentLeft = {read=FIndentLeft, write=SetIndentLeft, nodefault};
	__property int IndentRight = {read=FIndentRight, write=SetIndentRight, nodefault};
	__property int TextStart = {read=FTextStart, write=SetTextStart, nodefault};
	__property int TextEnd = {read=FTextEnd, write=SetTextEnd, nodefault};
	__property TCrpeTabStops* TabStops = {read=FTabStops, write=FTabStops};
	
public:
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	bool __fastcall StatusIsGo(void);
	void __fastcall Clear(void);
	__fastcall TCrpeParagraphsItem(void);
	__fastcall virtual ~TCrpeParagraphsItem(void);
};

#pragma pack(pop)

class DELPHICLASS TCrpeParagraphs;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeParagraphs : public TCrpeContainerX 
{
	typedef TCrpeContainerX inherited;
	
public:
	TCrpeParagraphsItem* operator[](int nIndex) { return Items[nIndex]; }
	
private:
	TCrpeParagraphsItem* FItem;
	
protected:
	void __fastcall SetIndex(int nIndex);
	TCrpeParagraphsItem* __fastcall GetItem(int nIndex);
	
__published:
	__property int Number = {read=FIndex, write=SetIndex, default=-1};
	__property TCrpeParagraphsItem* Item = {read=FItem, write=FItem};
	
public:
	__property int ItemIndex = {read=FIndex, write=SetIndex, nodefault};
	__property TCrpeParagraphsItem* Items[int nIndex] = {read=GetItem/*, default*/};
	virtual int __fastcall Count(void);
	void __fastcall Clear(void);
	__fastcall TCrpeParagraphs(void);
	__fastcall virtual ~TCrpeParagraphs(void);
};

#pragma pack(pop)

class DELPHICLASS TCrpeEmbeddedFieldsItem;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeEmbeddedFieldsItem : public TCrpeItemX 
{
	typedef TCrpeItemX inherited;
	
private:
	AnsiString FFieldName;
	Ucrpeclasses::TCrFieldObjectType FFieldObjectType;
	Ucrpeclasses::TCrFieldValueType FFieldType;
	short FFieldN;
	int FTextStart;
	int FTextEnd;
	Ucrpeclasses::TCrpeFieldObjectFormat* FFormat;
	Ucrpeclasses::TCrpeBorder* FBorder;
	
protected:
	void __fastcall SetFieldType(Ucrpeclasses::TCrFieldValueType FType);
	void __fastcall SetFieldN(short nField);
	void __fastcall SetFObjectType(const Ucrpeclasses::TCrFieldObjectType Value);
	void __fastcall SetFType(const Ucrpeclasses::TCrFieldValueType Value);
	void __fastcall SetFName(const AnsiString Value);
	void __fastcall SetTextStart(const int Value);
	void __fastcall SetTextEnd(const int Value);
	
__published:
	__property AnsiString FieldName = {read=FFieldName, write=SetFName};
	__property Ucrpeclasses::TCrFieldObjectType FieldObjectType = {read=FFieldObjectType, write=SetFObjectType, nodefault};
	__property Ucrpeclasses::TCrFieldValueType FieldType = {read=FFieldType, write=SetFType, nodefault};
	__property int TextStart = {read=FTextStart, write=SetTextStart, nodefault};
	__property int TextEnd = {read=FTextEnd, write=SetTextEnd, nodefault};
	__property Ucrpeclasses::TCrpeFieldObjectFormat* Format = {read=FFormat, write=FFormat};
	__property Ucrpeclasses::TCrpeBorder* Border = {read=FBorder, write=FBorder};
	
public:
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	void __fastcall Clear(void);
	__fastcall TCrpeEmbeddedFieldsItem(void);
	__fastcall virtual ~TCrpeEmbeddedFieldsItem(void);
};

#pragma pack(pop)

class DELPHICLASS TCrpeEmbeddedFields;
#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeEmbeddedFields : public TCrpeContainerX 
{
	typedef TCrpeContainerX inherited;
	
public:
	TCrpeEmbeddedFieldsItem* operator[](int nIndex) { return Items[nIndex]; }
	
private:
	TCrpeEmbeddedFieldsItem* FItem;
	
protected:
	void __fastcall SetIndex(int nIndex);
	TCrpeEmbeddedFieldsItem* __fastcall GetItem(int nIndex);
	
__published:
	__property int Number = {read=FIndex, write=SetIndex, default=-1};
	__property TCrpeEmbeddedFieldsItem* Item = {read=FItem, write=FItem};
	
public:
	__property int ItemIndex = {read=FIndex, write=SetIndex, nodefault};
	__property TCrpeEmbeddedFieldsItem* Items[int nIndex] = {read=GetItem/*, default*/};
	virtual int __fastcall Count(void);
	void __fastcall Delete(int nField);
	void __fastcall Insert(AnsiString FieldName, int Position);
	void __fastcall Clear(void);
	__fastcall TCrpeEmbeddedFields(void);
	__fastcall virtual ~TCrpeEmbeddedFields(void);
};

#pragma pack(pop)

#pragma pack(push, 1)
class PASCALIMPLEMENTATION TCrpeTextObjectsItem : public TCrpeObjectItemBX 
{
	typedef TCrpeObjectItemBX inherited;
	
private:
	TCrpeParagraphs* FParagraphs;
	TCrpeEmbeddedFields* FEmbeddedFields;
	Classes::TStrings* FLines;
	Classes::TStrings* xLines;
	int FTextSize;
	int FTextHeight;
	
protected:
	void __fastcall SetLines(Classes::TStrings* ListVar);
	void __fastcall OnChangeLines(System::TObject* Sender);
	void __fastcall SetTextSize(const int Value);
	void __fastcall SetTextHeight(const int Value);
	
__published:
	__property TCrpeParagraphs* Paragraphs = {read=FParagraphs, write=FParagraphs};
	__property TCrpeEmbeddedFields* EmbeddedFields = {read=FEmbeddedFields, write=FEmbeddedFields};
	__property Classes::TStrings* Lines = {read=FLines, write=SetLines};
	__property int TextSize = {read=FTextSize, write=SetTextSize, nodefault};
	__property int TextHeight = {read=FTextHeight, write=SetTextHeight, nodefault};
	
public:
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	HIDESBASE void __fastcall Clear(void);
	void __fastcall InsertText(Classes::TStrings* Text, int Position);
	void __fastcall DeleteText(int TextStart, int TextEnd);
	void __fastcall InsertFile(AnsiString FilePath, int Position);
	__fastcall TCrpeTextObjectsItem(void);
	__fastcall virtual ~TCrpeTextObjectsItem(void);
};

#pragma pack(pop)

//-- var, const, procedure ---------------------------------------------------
#define TCRPE_LANGUAGE "Delphi / C++Builder"
#define TCRPE_VERSION "11.0.0.0"
#define TCRPE_COMPANY_NAME "Business Objects Inc."
#define TCRPE_COMPANY_ADDRESS1 "840 Cambie Street"
#define TCRPE_COMPANY_ADDRESS2 "Vancouver, B.C., Canada  V6B 4J2"
#define TCRPE_COPYRIGHT "Copyright (c)2001-2005 "
#define TCRPE_CR_PHONE "1-604-669-8379 "
#define TCRPE_CR_EMAIL "http://support.businessobjects.com"
#define TCRPE_CR_WEBSITE "http://www.businessobjects.com"
#define TCRPE_VCL_EMAIL "crystalvcl@businessobjects.com"
#define TCRPE_VCL_WEBSITE "http://www.businessobjects.com/products/crystalreports/vcl"\
	""
extern PACKAGE short PECursorTypes[20];
#define ECRPE_LOAD_DLL "100:Error loading library: CRPE32.DLL"
#define ECRPE_FREE_DLL "101:Error freeing library: CRPE32.DLL"
#define ECRPE_NOT_LOADED "102:CRPE32.DLL is not loaded"
#define ECRPE_VERSION "103:Incompatible CRPE version: requires version 11.x"
#define ECRPE_VERSION_INFO "104:Failed to obtain Version Information from CRPE32.DLL"
#define ECRPE_LOAD_DLL_FUNCTION "105:Failed to load function from CRPE32.DLL"
#define ECRPE_ALLOCATE_MEMORY "110:Could not Allocate Memory for Internal Variables"
#define ECRPE_NO_NAME "112:No ReportName assigned"
#define ECRPE_REPORT_NOT_FOUND "114:Report not found"
#define ECRPE_SUBSCRIPT "116:Subscript out of range"
#define ECRPE_NOT_FOUND "120:Lookup item not found"
#define ECRPE_FAILED_GETTING_ERROR "130:Failed to Retrieve Error Message from Print Engine"
#define ECRPE_UNDEFINED "140:Undefined Print Engine Error"
#define ECRPE_FORMULA_BY_NAME "200:Formula Name could not be found"
#define ECRPE_PARAM_BY_NAME "202:Parameter Name could not be found"
#define ECRPE_RUNNINGTOTAL_BY_NAME "204:RunningTotal Name could not be found"
#define ECRPE_SQLEXPRESSION_BY_NAME "206:SQLExpression Name could not be found"
#define ECRPE_SUBREPORT_BY_NAME "208:Subreport Name could not be found"
#define ECRPE_TABLE_BY_NAME "210:Table Name could not be found"
#define ECRPE_SECTIONFORMAT_BY_NAME "211:Section Name could not be found"
#define ECRPE_AREAFORMAT_BY_NAME "212:Area Name could not be found"
#define ECRPE_SERVERNAME "251:Invalid ServerName"
#define ECRPE_GET_AS_DATE "280:Value could not be converted to Date"
#define ECRPE_GET_AS_DATETIME "282:Value could not be converted to DateTime"
#define ECRPE_GET_AS_TIME "284:Value could not be converted to Time"
#define ECRPE_PARAMETER_NUMBER "292:Invalid Number Value"
#define ECRPE_PARAMETER_CURRENCY "293:Invalid Currency Value"
#define ECRPE_PARAMETER_BOOLEAN "294:Invalid Boolean Value (Proper format: True/False)"
#define ECRPE_PARAMETER_DATE "296:Invalid Date Value (Proper format: YYYY,MM,DD)"
#define ECRPE_PARAMETER_STRING "297:Invalid String Value"
#define ECRPE_PARAMETER_DATETIME "298:Invalid DateTime Value (Proper format: YYYY,MM,DD HH:M"\
	"M:SS)"
#define ECRPE_PARAMETER_TIME "299:Invalid Time Value (Proper format: HH:MM:SS)"
#define ECRPE_STR2VALUEINFO "305:Error converting string to ValueInfo"
#define ECRPE_ALIAS_NAME "322:Invalid BDE Alias Name"
#define ECRPE_SECTION_CODE "360:Invalid Section Code or String"
#define ECRPE_GET_SECTIONS "372:Error retrieving Report Sections"

}	/* namespace Ucrpe32 */
using namespace Ucrpe32;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// UCrpe32
