// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'UDWindowButtonBar.pas' rev: 6.00

#ifndef UDWindowButtonBarHPP
#define UDWindowButtonBarHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <UCrpe32.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Udwindowbuttonbar
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TCrpeWindowButtonBarDlg;
class PASCALIMPLEMENTATION TCrpeWindowButtonBarDlg : public Forms::TForm 
{
	typedef Forms::TForm inherited;
	
__published:
	Extctrls::TPanel* pnlWindowButtonBar;
	Stdctrls::TCheckBox* cbVisible;
	Stdctrls::TCheckBox* cbCancelBtn;
	Stdctrls::TCheckBox* cbCloseBtn;
	Stdctrls::TCheckBox* cbRefreshBtn;
	Stdctrls::TCheckBox* cbZoomCtl;
	Stdctrls::TCheckBox* cbPrintBtn;
	Stdctrls::TCheckBox* cbPrintSetupBtn;
	Stdctrls::TCheckBox* cbExportBtn;
	Stdctrls::TCheckBox* cbSearchBtn;
	Stdctrls::TCheckBox* cbAllowDrillDown;
	Stdctrls::TCheckBox* cbGroupTree;
	Stdctrls::TCheckBox* cbNavigationCtls;
	Stdctrls::TCheckBox* cbProgressCtls;
	Stdctrls::TButton* btnOk;
	Stdctrls::TButton* btnCancel;
	Stdctrls::TButton* btnClear;
	Stdctrls::TCheckBox* cbDocumentTips;
	Stdctrls::TCheckBox* cbToolbarTips;
	Stdctrls::TButton* btnActivateAll;
	Stdctrls::TCheckBox* cbLaunchBtn;
	void __fastcall FormClose(System::TObject* Sender, Forms::TCloseAction &Action);
	void __fastcall FormShow(System::TObject* Sender);
	void __fastcall btnClearClick(System::TObject* Sender);
	void __fastcall UpdateWindowButtonBar(void);
	void __fastcall cbVisibleClick(System::TObject* Sender);
	void __fastcall cbCancelBtnClick(System::TObject* Sender);
	void __fastcall cbCloseBtnClick(System::TObject* Sender);
	void __fastcall cbRefreshBtnClick(System::TObject* Sender);
	void __fastcall cbZoomCtlClick(System::TObject* Sender);
	void __fastcall cbPrintBtnClick(System::TObject* Sender);
	void __fastcall cbPrintSetupBtnClick(System::TObject* Sender);
	void __fastcall cbExportBtnClick(System::TObject* Sender);
	void __fastcall cbSearchBtnClick(System::TObject* Sender);
	void __fastcall cbAllowDrillDownClick(System::TObject* Sender);
	void __fastcall cbGroupTreeClick(System::TObject* Sender);
	void __fastcall cbNavigationCtlsClick(System::TObject* Sender);
	void __fastcall cbProgressCtlsClick(System::TObject* Sender);
	void __fastcall cbToolbarTipsClick(System::TObject* Sender);
	void __fastcall cbDocumentTipsClick(System::TObject* Sender);
	void __fastcall FormCreate(System::TObject* Sender);
	void __fastcall btnOkClick(System::TObject* Sender);
	void __fastcall btnCancelClick(System::TObject* Sender);
	void __fastcall btnActivateAllClick(System::TObject* Sender);
	void __fastcall InitializeControls(bool OnOff);
	void __fastcall cbLaunchBtnClick(System::TObject* Sender);
	
public:
	Ucrpe32::TCrpe* Cr;
	bool rVisible;
	bool rCancel;
	bool rClose;
	bool rRefresh;
	bool rZoom;
	bool rPrint;
	bool rPrintSetup;
	bool rExport;
	bool rLaunch;
	bool rSearch;
	bool rAllowDrillDown;
	bool rGroupTree;
	bool rNavigation;
	bool rProgress;
	bool rToolbarTips;
	bool rDocumentTips;
public:
	#pragma option push -w-inl
	/* TCustomForm.Create */ inline __fastcall virtual TCrpeWindowButtonBarDlg(Classes::TComponent* AOwner) : Forms::TForm(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.CreateNew */ inline __fastcall virtual TCrpeWindowButtonBarDlg(Classes::TComponent* AOwner, int Dummy) : Forms::TForm(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TCrpeWindowButtonBarDlg(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TCrpeWindowButtonBarDlg(HWND ParentWindow) : Forms::TForm(ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TCrpeWindowButtonBarDlg* CrpeWindowButtonBarDlg;
extern PACKAGE bool bWindowButtonBar;

}	/* namespace Udwindowbuttonbar */
using namespace Udwindowbuttonbar;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// UDWindowButtonBar
