// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'UDPrintDate.pas' rev: 6.00

#ifndef UDPrintDateHPP
#define UDPrintDateHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <UCrpe32.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <Buttons.hpp>	// Pascal unit
#include <Calendar.hpp>	// Pascal unit
#include <Grids.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Udprintdate
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TCrpePrintDateDlg;
class PASCALIMPLEMENTATION TCrpePrintDateDlg : public Forms::TForm 
{
	typedef Forms::TForm inherited;
	
__published:
	Extctrls::TPanel* pnlPrintDate;
	Stdctrls::TLabel* lblMonthYear;
	Buttons::TSpeedButton* sbYearMinus;
	Buttons::TSpeedButton* sbYearPlus;
	Buttons::TSpeedButton* sbMonthPlus;
	Buttons::TSpeedButton* sbMonthMinus;
	Stdctrls::TLabel* lblYear;
	Stdctrls::TLabel* lblMonth;
	Stdctrls::TLabel* lblDay;
	Calendar::TCalendar* Calendar1;
	Stdctrls::TEdit* editDay;
	Stdctrls::TEdit* editMonth;
	Stdctrls::TEdit* editYear;
	Stdctrls::TCheckBox* cbToday;
	Stdctrls::TButton* btnOk;
	Stdctrls::TButton* btnCancel;
	Stdctrls::TButton* btnClear;
	void __fastcall Calendar1Change(System::TObject* Sender);
	void __fastcall sbMonthMinusClick(System::TObject* Sender);
	void __fastcall sbMonthPlusClick(System::TObject* Sender);
	void __fastcall sbYearMinusClick(System::TObject* Sender);
	void __fastcall sbYearPlusClick(System::TObject* Sender);
	void __fastcall editDayChange(System::TObject* Sender);
	void __fastcall editMonthChange(System::TObject* Sender);
	void __fastcall editYearChange(System::TObject* Sender);
	void __fastcall editDayEnter(System::TObject* Sender);
	void __fastcall editMonthEnter(System::TObject* Sender);
	void __fastcall editYearEnter(System::TObject* Sender);
	void __fastcall cbTodayClick(System::TObject* Sender);
	void __fastcall UpdatePrintDate(void);
	void __fastcall btnClearClick(System::TObject* Sender);
	void __fastcall FormShow(System::TObject* Sender);
	void __fastcall FormClose(System::TObject* Sender, Forms::TCloseAction &Action);
	void __fastcall btnOkClick(System::TObject* Sender);
	void __fastcall btnCancelClick(System::TObject* Sender);
	void __fastcall FormCreate(System::TObject* Sender);
	void __fastcall InitializeControls(bool OnOff);
	
private:
	Word rptDay;
	Word rptMonth;
	Word rptYear;
	Word Year;
	Word Month;
	Word Day;
	AnsiString prevYear;
	AnsiString prevMonth;
	AnsiString prevDay;
	System::TDateTime Present;
	
public:
	Ucrpe32::TCrpe* Cr;
public:
	#pragma option push -w-inl
	/* TCustomForm.Create */ inline __fastcall virtual TCrpePrintDateDlg(Classes::TComponent* AOwner) : Forms::TForm(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.CreateNew */ inline __fastcall virtual TCrpePrintDateDlg(Classes::TComponent* AOwner, int Dummy) : Forms::TForm(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TCrpePrintDateDlg(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TCrpePrintDateDlg(HWND ParentWindow) : Forms::TForm(ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TCrpePrintDateDlg* CrpePrintDateDlg;
extern PACKAGE bool bPrintDate;

}	/* namespace Udprintdate */
using namespace Udprintdate;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// UDPrintDate
