// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'UDExportSepVal.pas' rev: 6.00

#ifndef UDExportSepValHPP
#define UDExportSepValHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <UCrpe32.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Buttons.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Udexportsepval
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TCrpeSepValDlg;
class PASCALIMPLEMENTATION TCrpeSepValDlg : public Forms::TForm 
{
	typedef Forms::TForm inherited;
	
__published:
	Extctrls::TPanel* pnlSepVal;
	Stdctrls::TEdit* editStringDelimiter;
	Stdctrls::TEdit* editFieldSeparator;
	Stdctrls::TLabel* lblStringDelimiter;
	Stdctrls::TLabel* lblFieldSeparator;
	Buttons::TSpeedButton* sb1;
	Buttons::TSpeedButton* sb2;
	Buttons::TSpeedButton* sb4;
	Buttons::TSpeedButton* sb3;
	Buttons::TSpeedButton* sb5;
	Buttons::TSpeedButton* sb13;
	Buttons::TSpeedButton* sb6;
	Buttons::TSpeedButton* sb14;
	Buttons::TSpeedButton* sb15;
	Buttons::TSpeedButton* sb16;
	Buttons::TSpeedButton* sb17;
	Buttons::TSpeedButton* sb7;
	Buttons::TSpeedButton* sb8;
	Buttons::TSpeedButton* sb9;
	Buttons::TSpeedButton* sb10;
	Buttons::TSpeedButton* sb11;
	Buttons::TSpeedButton* sb12;
	Buttons::TSpeedButton* sb18;
	Buttons::TSpeedButton* sb19;
	Buttons::TSpeedButton* sb20;
	Buttons::TSpeedButton* sb22;
	Buttons::TSpeedButton* sb23;
	Buttons::TSpeedButton* sb21;
	Buttons::TSpeedButton* sb24;
	Stdctrls::TButton* btnOk;
	Stdctrls::TButton* btnCancel;
	Buttons::TSpeedButton* sbTab;
	Buttons::TSpeedButton* sbComma;
	Stdctrls::TCheckBox* cbUseRptNumberFmt;
	Stdctrls::TCheckBox* cbUseRptDateFmt;
	void __fastcall BtnCharClick(System::TObject* Sender);
	void __fastcall FormClose(System::TObject* Sender, Forms::TCloseAction &Action);
	void __fastcall btnOKClick(System::TObject* Sender);
	void __fastcall FormShow(System::TObject* Sender);
	void __fastcall editStringDelimiterKeyDown(System::TObject* Sender, Word &Key, Classes::TShiftState Shift);
	void __fastcall sb1MouseDown(System::TObject* Sender, Controls::TMouseButton Button, Classes::TShiftState Shift, int X, int Y);
	void __fastcall FormCreate(System::TObject* Sender);
	void __fastcall btnCancelClick(System::TObject* Sender);
	void __fastcall sbTabClick(System::TObject* Sender);
	void __fastcall sbCommaClick(System::TObject* Sender);
	
public:
	Ucrpe32::TCrpe* Cr;
public:
	#pragma option push -w-inl
	/* TCustomForm.Create */ inline __fastcall virtual TCrpeSepValDlg(Classes::TComponent* AOwner) : Forms::TForm(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.CreateNew */ inline __fastcall virtual TCrpeSepValDlg(Classes::TComponent* AOwner, int Dummy) : Forms::TForm(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TCrpeSepValDlg(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TCrpeSepValDlg(HWND ParentWindow) : Forms::TForm(ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TCrpeSepValDlg* CrpeSepValDlg;

}	/* namespace Udexportsepval */
using namespace Udexportsepval;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// UDExportSepVal
